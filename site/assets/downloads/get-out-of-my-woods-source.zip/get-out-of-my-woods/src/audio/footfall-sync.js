// Presentation-only contact clock. Gameplay footsteps/noise still belong to the
// simulations; this observes the counselor's rendered locomotion phase only.
const GAITS = new Set(['walk', 'sneak', 'run']);
const EPS = 1e-8;
const MAX_DELAY = .12;
const SOLE_CLEARANCE = .035;

// The rigid shoe's bottom flat, inset from its bevel. Animator.apply has already
// updated these world matrices. Sampling both ends handles a pitched shoe without
// allocating vectors or changing the rendered pose.
export function readFootSoles(figure) {
  const base = figure.root.matrixWorld.elements[13];
  const height = (side) => {
    const e = figure.rig.b('foot' + side).matrixWorld.elements;
    return Math.min(e[5] * -.08 + e[9] * -.047 + e[13],
      e[5] * -.08 + e[9] * .187 + e[13]) - base;
  };
  return { L: height('L'), R: height('R') };
}

export function createFootfallSync() {
  let previous = null, pending = null;
  return {
    reset() { previous = pending = null; },
    sample({ phase, gait, x, z, dt, soles, active = true }) {
      const valid = [phase, x, z, dt].every(Number.isFinite);
      const ready = valid && active && GAITS.has(gait) && dt > 0 && dt <= .25;
      const next = valid ? { phase, x, z, ready, index: Math.floor(phase * 2 + EPS) } : null;
      const before = previous;
      previous = next;
      // Starting, returning from a non-walking pose, or resuming never replays
      // contacts from the interval during which footsteps were inaudible.
      if (!ready || !before?.ready) { pending = null; return null; }
      const advance = phase - before.phase;
      const distance = Math.hypot(x - before.x, z - before.z);
      // A phase reset/seek, teleport or long catch-up frame is not a footfall.
      if (advance <= EPS || advance > .5 + EPS || distance <= EPS || distance > dt * 12 + .025) {
        pending = null; return null;
      }
      if (pending) pending.delay += dt;
      if (next.index > before.index) {
        // Walk/sneak/run share a continuous phase. Retain it through crossfades;
        // repeatedly changing gait must not continually reset the contact clock.
        pending = { side: next.index % 2 === 0 ? 'L' : 'R', phase: next.index / 2, delay: 0 };
      }
      if (!pending) return null;
      if (pending.delay > MAX_DELAY + EPS) { pending = null; return null; }
      // A rapid run blend can leave the nominal landing foot briefly airborne.
      // Defer that single contact until the visible sole is near the floor, with
      // a strict expiry: no backlog or sound burst after a pause or obstruction.
      const height = soles?.[pending.side];
      if (!Number.isFinite(height) || height > SOLE_CLEARANCE) return null;
      const contact = pending; pending = null;
      return contact;
    },
  };
}
