import { BANK_NAMES, LOOP_NAMES, MUSIC_NAMES, ROOM_SETTINGS, makeBuffer, makeImpulse, score } from './synth.js';
import { createCuePriority } from './cue-priority.js';

// The Rain and wind setting: this value plays the storm as mixed; 1 is about 3 dB louder, 0 is silence.
export const WEATHER_DEFAULT = 0.7;
// How far the weather drops when he is right on top of you (about 3 dB), so his steps carry.
const THREAT_DUCK = 0.3;
// Storm bed levels: low enough that his one step sound (which also carries farther in the storm,
// see the killerStep cue) is plain inside about 12 m and still there at 20.
const STORM_RAIN = 0.34, STORM_WIND = 0.42;
const clamp = (v, fallback = 0) => Number.isFinite(v) ? Math.max(0, Math.min(1, v)) : fallback;
const noopHandle = () => ({ stop() {}, setVolume() {}, setPos() {} });
const safePromise = (p) => p?.catch?.(() => {});
const mobile = () => typeof navigator !== 'undefined' && (/iPhone|iPad|iPod|Android/.test(navigator.userAgent) || navigator.maxTouchPoints > 1);
const change = (param, value, time, seconds = 0.08) => {
  param.cancelScheduledValues(time);
  param.setTargetAtTime(value, time, seconds);
};

// One fixed effects graph. Room changes only automate gains and the world low-pass.
export function createMixer(ctx, destination = ctx.destination) {
  const input = ctx.createGain(), world = ctx.createGain(), local = ctx.createGain(), music = ctx.createGain();
  const weatherWorld = ctx.createGain(), weatherLocal = ctx.createGain(), scoreBus = ctx.createGain(), stingers = ctx.createGain();
  // The player's Rain and wind level, and the hush when he is near, sit after the cue dips so neither fights them.
  const weatherTrimWorld = ctx.createGain(), weatherTrimLocal = ctx.createGain();
  const filter = ctx.createBiquadFilter(), dry = ctx.createGain(), master = ctx.createGain();
  const highpass = ctx.createBiquadFilter(), compressor = ctx.createDynamicsCompressor();
  const limiter = ctx.createDynamicsCompressor(), ceiling = ctx.createWaveShaper();
  highpass.type = 'highpass'; highpass.frequency.value = 24; highpass.Q.value = 0.5;
  filter.type = 'lowpass'; filter.frequency.value = 18000; filter.Q.value = 0.5;
  dry.gain.value = 0.9; master.gain.value = 0.8;
  compressor.threshold.value = -17; compressor.knee.value = 14; compressor.ratio.value = 2.5;
  compressor.attack.value = 0.012; compressor.release.value = 0.25;
  limiter.threshold.value = -3; limiter.knee.value = 0; limiter.ratio.value = 20;
  limiter.attack.value = 0.001; limiter.release.value = 0.09;
  const curve = new Float32Array(2049);
  // Unity at ordinary levels; a hard ceiling catches compressor attack transients.
  for (let i = 0; i < curve.length; i++) curve[i] = Math.max(-0.96, Math.min(0.96, i / 1024 - 1));
  ceiling.curve = curve;
  world.connect(filter); filter.connect(local); local.connect(dry); dry.connect(input); music.connect(input);
  weatherWorld.connect(weatherTrimWorld); weatherTrimWorld.connect(world);
  weatherLocal.connect(weatherTrimLocal); weatherTrimLocal.connect(local);
  scoreBus.connect(music); stingers.connect(music);
  const priority = createCuePriority(ctx, { weather: [weatherWorld, weatherLocal], score: scoreBus, stingers });
  input.connect(master); master.connect(highpass); highpass.connect(compressor);
  compressor.connect(limiter); limiter.connect(ceiling); ceiling.connect(destination);
  const rooms = {};
  for (const [name, cfg] of Object.entries(ROOM_SETTINGS)) {
    const convolver = ctx.createConvolver(), gain = ctx.createGain();
    convolver.normalize = false; convolver.buffer = makeImpulse(ctx, name);
    gain.gain.value = name === 'outside' ? cfg.wet : 0;
    local.connect(convolver); convolver.connect(gain); gain.connect(input);
    rooms[name] = { convolver, gain };
  }
  return {
    world, local, music, weatherWorld, weatherLocal, score: scoreBus, stingers, master, filter, rooms, compressor, limiter,
    cue: priority.cue, resetPriority: priority.reset,
    setWeather(level, seconds = 0.5) {
      const time = ctx.currentTime;
      for (const node of [weatherTrimWorld, weatherTrimLocal]) {
        if (seconds <= 0) { node.gain.cancelScheduledValues(time); node.gain.setValueAtTime(level, time); }
        else change(node.gain, level, time, seconds);
      }
    },
    setRoom(name, instant = false) {
      const cfg = ROOM_SETTINGS[name];
      if (!cfg) return;
      const time = ctx.currentTime;
      for (const [key, room] of Object.entries(rooms)) {
        if (instant) room.gain.gain.value = key === name ? cfg.wet : 0;
        else change(room.gain.gain, key === name ? cfg.wet : 0, time, 0.14);
      }
      if (instant) filter.frequency.value = cfg.lowpass;
      else change(filter.frequency, cfg.lowpass, time, 0.09);
    },
  };
}

class AudioEngine {
  constructor() {
    this.ctx = null; this.mix = null; this.buffers = new Map(); this.voices = new Set();
    this.volume = 0.8; this.room = 'outside'; this.musicName = 'none'; this.ambientName = 'none';
    this.intensity = 0; this.listener = [0, 1.6, 0, 0]; this.ambient = null; this.musicTrack = null;
    this.paused = false; this.hidden = false; this.unlocked = false; this.failed = false;
    this.pendingLoops = new Set(); this.generatedMs = 0; this.maxVoices = 20;
    this.nextWildlife = 0; this.nextHole = 0; this.holeUntil = 0; this.nextHeart = 0;
    this.intensityBed = null;
    // Rain and wind: the player's level (0.7 is the mix as designed) and how near he is (0..1).
    this.weather = WEATHER_DEFAULT; this.threat = 0;
    this.stepVariants = new Map();
    this.stepIndex = 0;
    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', () => {
        this.hidden = document.hidden;
        if (this.hidden) { if (this.ctx) safePromise(this.ctx.suspend()); }
        else if (!this.paused && this.unlocked) this._resume();
      });
      // A new gesture also recovers Safari's interrupted state after calls / device lock.
      // The first touch of all starts the sound, so the title is not silent.
      const recover = () => {
        if (!this.unlocked) this.unlock();
        else if (!this.paused && !this.hidden) this._resume();
      };
      document.addEventListener('pointerdown', recover, { passive: true });
      document.addEventListener('touchend', recover, { passive: true });
      document.addEventListener('keydown', recover, { passive: true });
      // Generate at load in short slices without needing autoplay permission.
      setTimeout(() => this._init(), 0);
    }
  }

  _init() {
    if (this.ctx || this.failed) return;
    try {
      const Context = globalThis.AudioContext || globalThis.webkitAudioContext;
      if (!Context) { this.failed = true; return; }
      this.ctx = new Context({ latencyHint: 'interactive' });
      this.mix = createMixer(this.ctx);
      this.mix.master.gain.value = this.volume;
      this.mix.setWeather(this._weatherGain(), 0);
      this.mix.setRoom(this.room, true); this._listener();
      const names = [...BANK_NAMES];
      this.ready = new Promise((resolve) => {
        const slice = () => {
          const start = performance.now();
          try {
            do {
              const name = names.shift();
              this.buffers.set(name, makeBuffer(this.ctx, name));
              if (name.startsWith('step_')) this.stepVariants.set(name, [this.buffers.get(name), makeBuffer(this.ctx, name, 1), makeBuffer(this.ctx, name, 2), makeBuffer(this.ctx, name, 3)]);
            }
            while (names.length && performance.now() - start < 7);
          } catch { this.failed = true; resolve(false); return; }
          this.generatedMs += performance.now() - start;
          if (names.length) setTimeout(slice, 0);
          else {
            for (const pending of this.pendingLoops) pending.start();
            this.pendingLoops.clear();
            this._setAmbience(this.ambientName); this._setMusic(this.musicName);
            resolve(true);
          }
        };
        setTimeout(slice, 0);
      });
      this.timer = setInterval(() => this._tick(), 100);
    } catch (e) {
      console.warn('Sound could not start:', e);
      this.failed = true;
      this.ctx = null;
    }
  }

  _resume() {
    try { if (this.ctx && this.ctx.state !== 'running' && this.ctx.state !== 'closed') safePromise(this.ctx.resume()); } catch { /* No audio device is a valid game mode. */ }
  }

  unlock() {
    this._init();
    if (!this.ctx || this.failed) return;
    try {
      if (typeof navigator !== 'undefined' && navigator.audioSession) navigator.audioSession.type = 'playback';
    } catch { /* Older Safari can expose a read-only session. */ }
    this.unlocked = true;
    if (!this.paused && !this.hidden) this._resume();
    try {
      const silent = this.ctx.createBufferSource();
      silent.buffer = this.ctx.createBuffer(1, 1, this.ctx.sampleRate);
      silent.connect(this.ctx.destination); silent.onended = () => silent.disconnect(); silent.start();
    } catch { /* The next gesture can retry. */ }
  }

  setVolume(v) { this.volume = clamp(v); if (this.mix) change(this.mix.master.gain, this.volume, this.ctx.currentTime); }
  _weatherGain() { return (this.weather / WEATHER_DEFAULT) * (1 - THREAT_DUCK * this.threat); }
  // Rain, wind and thunder only. His footsteps, the score and every other sound keep their level.
  setWeather(v) { this.weather = clamp(v, WEATHER_DEFAULT); this.mix?.setWeather(this._weatherGain(), 0.15); }
  // 0 = he is nowhere near, 1 = he is on top of you. The weather sinks a little as he closes in.
  setThreat(v) {
    const next = clamp(v);
    if (Math.abs(next - this.threat) < 0.02 && (next > 0) === (this.threat > 0)) return;
    this.threat = next; this.mix?.setWeather(this._weatherGain(), 0.6);
  }
  // An explicit gesture-driven check uses the same volume, mixer and limiter as play.
  // A running context cannot tell us whether the browser tab or output device is muted.
  async testOutput() {
    this.unlock();
    if (!this.ctx || this.failed) return 'unavailable';
    if (this.volume === 0) return 'muted';
    this.resumeAll();
    try {
      await Promise.race([this.ctx.resume().catch(() => {}), new Promise(resolve => setTimeout(resolve, 800))]);
      if (this.ctx.state !== 'running') return 'blocked';
      const start = this.ctx.currentTime + .03;
      [440, 554.37, 659.25].forEach((frequency, i) => {
        const oscillator = this.ctx.createOscillator(), gain = this.ctx.createGain();
        const at = start + i * .23;
        oscillator.frequency.value = frequency;
        gain.gain.setValueAtTime(0, at);
        gain.gain.linearRampToValueAtTime(.12, at + .018);
        gain.gain.exponentialRampToValueAtTime(.001, at + .18);
        oscillator.connect(gain); gain.connect(this.mix.local);
        oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
        oscillator.start(at); oscillator.stop(at + .21);
      });
      return 'running';
    } catch { return 'unavailable'; }
  }
  setListener(x, y, z, yaw) {
    if (![x, y, z, yaw].every(Number.isFinite)) return;
    this.listener[0] = x; this.listener[1] = y; this.listener[2] = z; this.listener[3] = yaw;
    this._listener();
  }
  _listener() {
    if (!this.ctx) return;
    const l = this.ctx.listener, [x, y, z, yaw] = this.listener, t = this.ctx.currentTime;
    // Same heading convention as LAYOUT: yaw zero faces +z; PI/2 faces +x.
    if (l.positionX) {
      l.positionX.setValueAtTime(x, t); l.positionY.setValueAtTime(y, t); l.positionZ.setValueAtTime(z, t);
      l.forwardX.setValueAtTime(Math.sin(yaw), t); l.forwardY.setValueAtTime(0, t); l.forwardZ.setValueAtTime(Math.cos(yaw), t);
      l.upX.setValueAtTime(0, t); l.upY.setValueAtTime(1, t); l.upZ.setValueAtTime(0, t);
    } else { l.setPosition(x, y, z); l.setOrientation(Math.sin(yaw), 0, Math.cos(yaw), 0, 1, 0); }
  }

  _voice(name, opts = {}, destination, when = this.ctx?.currentTime || 0, looping = false, priority = 2) {
    if (!this.ctx || this.failed || !this.buffers.has(name)) return null;
    if (this.voices.size >= this.maxVoices) {
      let victim = null;
      for (const voice of this.voices) {
        if (!voice.stopping && voice.priority < priority && (!victim || voice.priority < victim.priority)) victim = voice;
      }
      if (victim) victim.stop(0.025, true); else return null;
    }
    try {
      const ctx = this.ctx, source = ctx.createBufferSource(), gain = ctx.createGain();
      // Rotate through different noise grains instead of pitching the same footfall forever.
      const steps = !Number.isFinite(opts.x) && this.stepVariants.get(name);
      source.buffer = steps ? steps[this.stepIndex++ % steps.length] : this.buffers.get(name);
      source.loop = looping;
      source.playbackRate.value = Math.max(0.25, Math.min(4, Number.isFinite(opts.rate) ? opts.rate : 1));
      gain.gain.value = Number.isFinite(opts.volume) ? clamp(opts.volume) : 1;
      source.connect(gain);
      let panner = null;
      if (Number.isFinite(opts.x)) {
        panner = ctx.createPanner(); panner.panningModel = mobile() ? 'equalpower' : 'HRTF';
        panner.distanceModel = 'inverse'; panner.refDistance = Number.isFinite(opts.ref) ? opts.ref : name.startsWith('killer_step') ? 5 : name === 'fork_ting' ? 4 : 2;
        panner.maxDistance = 180; panner.rolloffFactor = 0.9;
        gain.connect(panner); panner.connect(destination || (name.startsWith('thunder') ? this.mix.weatherWorld : this.mix.world));
      } else gain.connect(destination || (name.startsWith('thunder') ? this.mix.weatherLocal : name.startsWith('stinger_') ? this.mix.stingers : name.startsWith('ui_') ? this.mix.music : this.mix.local));
      const voice = {
        name, priority, source, gain, panner, stopping: false,
        setVolume: (v, seconds = 0.08) => { if (!voice.stopping) change(gain.gain, clamp(v), ctx.currentTime, seconds); },
        setPos: (x, y, z) => {
          if (!panner || ![x, y, z].every(Number.isFinite)) return;
          if (panner.positionX) { panner.positionX.setValueAtTime(x, ctx.currentTime); panner.positionY.setValueAtTime(y, ctx.currentTime); panner.positionZ.setValueAtTime(z, ctx.currentTime); }
          else panner.setPosition(x, y, z);
        },
        stop: (seconds = 0.06, steal = false) => {
          if (voice.stopping) return;
          voice.stopping = true;
          change(gain.gain, 0, ctx.currentTime, Math.max(0.004, seconds / 3));
          try { source.stop(ctx.currentTime + seconds); } catch { /* Already ended. */ }
          if (steal) this.voices.delete(voice);
        },
      };
      if (panner) voice.setPos(opts.x, Number.isFinite(opts.y) ? opts.y : 0, Number.isFinite(opts.z) ? opts.z : 0);
      source.onended = () => {
        source.disconnect(); gain.disconnect(); panner?.disconnect(); this.voices.delete(voice);
        if (voice.track?.retired) {
          let remaining = false;
          for (const other of this.voices) if (other.track === voice.track) { remaining = true; break; }
          if (!remaining) voice.track.gain.disconnect();
        }
      };
      this.voices.add(voice); source.start(Math.max(when, ctx.currentTime));
      return voice;
    } catch { return null; }
  }

  sfx(name, opts = {}) {
    if (this.paused || this.hidden || this.failed) return;
    this._init();
    if (name.startsWith('step_') && !Number.isFinite(opts.x)) opts = { ...opts, volume: (Number.isFinite(opts.volume) ? opts.volume : 1) * (0.92 + Math.random() * 0.16) };
    if (!Number.isFinite(opts.rate)) opts = { ...opts, rate: 0.96 + Math.random() * 0.08 };
    // A first-gesture cue can arrive before the short buffer-generation slices finish.
    if (!this.buffers.has(name)) {
      const chapter=this.chapterGeneration||0;
      if (BANK_NAMES.includes(name) && this.ready) this.ready.then(() => { if (chapter===(this.chapterGeneration||0) && !this.paused && !this.hidden) this._playSfx(name, opts); });
      return;
    }
    this._playSfx(name, opts);
  }

  _playSfx(name, opts) {
    const scale = this.mix.cue(name);
    if (scale !== 1) opts = { ...opts, volume: (Number.isFinite(opts.volume) ? opts.volume : 1) * scale };
    this._voice(name, opts, null, undefined, false, /killer|fork|stinger|scream|engine_start/.test(name) ? 4 : 3);
  }

  loop(name, opts = {}) {
    if (!LOOP_NAMES.includes(name) || this.failed) return noopHandle();
    this._init();
    let voice = null, stopped = false;
    const settings = { ...opts };
    const pending = { start: () => { if (!stopped) voice = this._voice(name, settings, this.mix.world, undefined, true, 2); } };
    if (this.buffers.has(name)) pending.start(); else if (this.ctx) this.pendingLoops.add(pending);
    return {
      stop: () => { stopped = true; this.pendingLoops.delete(pending); voice?.stop(); },
      setVolume: (v) => { settings.volume = clamp(v); voice?.setVolume(v); },
      setPos: (x, y, z) => { Object.assign(settings, { x, y, z }); voice?.setPos(x, y, z); },
    };
  }

  setRoom(name) { if (!ROOM_SETTINGS[name]) return; this.room = name; this.mix?.setRoom(name); }
  ambience(name) {
    if (!['forest', 'storm', 'none'].includes(name)) return;
    if (this.ambientName === name && this.ambient) return;
    this.ambientName = name; this._init(); this._setAmbience(name);
  }
  _setAmbience(name) {
    if (!this.mix || !this.buffers.has('crickets')) return;
    this.ambient?.voices.forEach((v) => v?.stop(1.8));
    if (name === 'none') { this.ambient = null; return; }
    const voices = [], start = (sound, volume) => {
      const v = this._voice(sound, { volume: 0 }, sound === 'crickets' ? this.mix.world : this.mix.weatherWorld, undefined, true, 1);
      v?.setVolume(volume, 0.7); voices.push(v); return v;
    };
    const wind = start('wind', name === 'storm' ? STORM_WIND : 0.24);
    const crickets = name === 'forest' ? start('crickets', 0.35) : null;
    if (name === 'storm') start('rain', STORM_RAIN);
    this.ambient = { voices, wind, crickets, name };
    const t = this.ctx.currentTime; this.nextWildlife = t + 8 + Math.random() * 15; this.nextHole = t + 18 + Math.random() * 28;
  }

  music(name) {
    if (name !== 'none' && !MUSIC_NAMES.includes(name)) return;
    if (this.musicName === name && this.musicTrack) return;
    this.musicName = name; this._init(); this._setMusic(name);
  }
  _setMusic(name) {
    if (!this.mix || !this.buffers.has('warm')) return;
    const old = this.musicTrack;
    if (old) {
      change(old.gain.gain, 0, this.ctx.currentTime, 0.65);
      old.retired = true;
      let remaining = false;
      for (const voice of this.voices) if (voice.track === old) { voice.stop(3.8); remaining = true; }
      if (!remaining) old.gain.disconnect();
    }
    if (name === 'none') { this.musicTrack = null; return; }
    const gain = this.ctx.createGain(); gain.gain.value = 0; gain.connect(this.mix.score);
    change(gain.gain, 1, this.ctx.currentTime, 0.7);
    const length = name === 'chase' ? 0.285 * 128 : name === 'stalk' ? 1.65 * 24 : 38.4;
    this.musicTrack = { name, gain, notes: score(name, length), start: this.ctx.currentTime + 0.05, index: 0, length };
  }

  setIntensity(v) { this.intensity = clamp(v); }
  resetChapter() {
    // Retain the unlocked AudioContext across the cut (especially on iPhone),
    // but retire all scheduled notes/loops from the outgoing chapter.
    this.chapterGeneration=(this.chapterGeneration||0)+1;
    const tracks=new Set(this.musicTrack?[this.musicTrack]:[]);
    for(const voice of this.voices){
      if(voice.track)tracks.add(voice.track);
      voice.stopping=true;
      try{voice.gain.gain.cancelScheduledValues(0);voice.gain.gain.setValueAtTime(0,this.ctx.currentTime);voice.source.stop();voice.source.disconnect?.();voice.gain.disconnect?.();voice.panner?.disconnect();}catch{}
    }
    // Free the voice budget now, before onended callbacks get their next turn.
    this.voices.clear();for(const track of tracks){track.retired=true;track.gain?.disconnect();}
    this.pendingLoops.clear();this.musicName=this.ambientName='none';
    this.musicTrack=null;this.ambient=null;this.intensity=0;this.intensityBed=null;this.threat=0;this.mix?.setWeather(this._weatherGain(),0);
    this.mix?.resetPriority?.();
    this.setRoom('outside');this.resumeAll();
  }
  pauseAll() { this.paused = true; if (this.ctx) { try { safePromise(this.ctx.suspend()); } catch { /* Safe no-op. */ } } }
  resumeAll() { this.paused = false; if (!this.hidden && this.unlocked) this._resume(); }

  _tick() {
    if (!this.ctx || this.failed || this.paused || this.hidden || this.ctx.state !== 'running') return;
    const now = this.ctx.currentTime, track = this.musicTrack;
    if (this.intensityBed?.stopping) this.intensityBed = null;
    if (this.intensity > 0.05 && !this.intensityBed) {
      this.intensityBed = this._voice('dread_bed', { volume: 0 }, this.mix.score, now, true, 1);
    }
    if (this.intensityBed) {
      this.intensityBed.setVolume(this.intensity * 0.12, 0.65);
      if (this.intensity === 0) { this.intensityBed.stop(2); this.intensityBed = null; }
    }
    if (track) {
      const bed = ['dread', 'stalk'].includes(track.name) ? 0.65 + this.intensity * 0.9 : 1;
      change(track.gain.gain, bed, now, 0.3);
      while (track.index < track.notes.length && track.start + track.notes[track.index].at < now + 0.22) {
        const note = track.notes[track.index++];
        if (track.start + note.at >= now - 0.15) {
          const v = this._voice(note.sound, note, track.gain, track.start + note.at, false, 0);
          if (v) v.track = track;
        }
      }
      if (now >= track.start + track.length - 0.22) { track.start += track.length; track.index = 0; }
    }
    if (this.intensity > 0.35 && now >= this.nextHeart) {
      const u = (this.intensity - 0.35) / 0.65;
      this._voice('heartbeat', { volume: u * 0.29 }, this.mix.music, now, false, 1);
      this.nextHeart = now + 60 / (58 + 91 * u);
    }
    const ambient = this.ambient;
    if (!ambient) return;
    const storm = ambient.name === 'storm';
    if (!storm && now > this.nextHole) {
      this.holeUntil = now + 4 + Math.random() * 5; this.nextHole = this.holeUntil + 22 + Math.random() * 36;
    }
    ambient.crickets?.setVolume(now < this.holeUntil ? 0 : 0.26 + 0.08 * Math.sin(now * 0.21), 0.45);
    ambient.wind?.setVolume((storm ? STORM_WIND : 0.16) * (0.8 + 0.2 * Math.sin(now * 0.17) + 0.13 * Math.sin(now * 0.071)), 0.7);
    if (now > this.nextWildlife) {
      const names = storm ? ['thunder'] : ['owl', 'loon', 'coyote', 'branch_creak'];
      const name = names[Math.floor(Math.random() * names.length)];
      const [x, , z] = this.listener, angle = Math.random() * Math.PI * 2;
      const distance = name === 'branch_creak' ? 18 : 40 + Math.random() * 45;
      this._voice(name, { x: name === 'loon' ? -38 : x + Math.sin(angle) * distance, y: 3, z: name === 'loon' ? 86 : z + Math.cos(angle) * distance, volume: storm ? 0.8 : 0.65 }, null, now, false, 1);
      this.nextWildlife = now + (storm ? 18 : 16) + Math.random() * 28;
    }
  }

  // Read-only diagnostics keep the game contract small and the debug page honest.
  inspect() {
    return { weather: this.weather, threat: this.threat, weatherGain: this._weatherGain(), state: this.ctx?.state || (this.failed ? 'unavailable' : 'waiting'), generated: this.buffers.size, generationMs: this.generatedMs, voices: this.voices.size, panning: mobile() ? 'equalpower' : 'HRTF', room: this.room, music: this.musicName, ambience: this.ambientName, paused: this.paused, hidden: this.hidden };
  }
}

export const audio = new AudioEngine();
