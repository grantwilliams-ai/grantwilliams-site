// Briefly make space for a strike without turning down spatial footsteps or
// ordinary environmental detail. AudioContext time also freezes on pause.
export function createCuePriority(ctx, { weather, score, stingers }) {
  let lastStinger = -Infinity;
  const until = new Map();
  const dip = (node, level, at, hold) => {
    const end = Math.max(until.get(node) || 0, at + hold);
    until.set(node, end);
    const gain = node.gain;
    if (gain.cancelAndHoldAtTime) gain.cancelAndHoldAtTime(at);
    else { const value = gain.value; gain.cancelScheduledValues(at); gain.setValueAtTime(value, at); }
    gain.setTargetAtTime(level, at, .025);
    gain.setTargetAtTime(1, end, .28);
  };
  return {
    cue(name, at = ctx.currentTime) {
      const hold = name === 'fork_stab' || name === 'scream_death' ? 1.25
        : name === 'fork_swing' || name === 'fork_thunk' ? .85 : 0;
      if (hold) {
        for (const node of weather) dip(node, .55, at, hold);
        dip(score, .72, at, hold);
        dip(stingers, .72, at, hold);
      }
      if (!name.startsWith('stinger_')) return 1;
      // Keep a first warning intact; a second simultaneous scare is an accent.
      const gain = at - lastStinger < .9 ? .65 : 1;
      lastStinger = at;
      return gain;
    },
    reset() {
      lastStinger = -Infinity; until.clear();
      for (const node of [...weather, score, stingers]) {
        node.gain.cancelScheduledValues(ctx.currentTime);
        node.gain.setValueAtTime(1, ctx.currentTime);
      }
    },
  };
}
