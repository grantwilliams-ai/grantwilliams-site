import { makeRng } from '../core/rng.js';

export const SAMPLE_RATE = 22050;
export const SFX_NAMES = (`step_dirt step_leaf step_wood step_gravel step_water killer_step killer_step_wood killer_breath fork_ting fork_swing fork_thunk fork_stab door_open door_close door_slam door_bash closet_open closet_close rummage item_keys item_battery found_nothing hood_open battery_install car_door crank_fail engine_start tires_gravel glass_smash metal_crash body_hit body_fall window_smash vault_window stumble gasp player_breath_fast scream_death scream_distant wood_crack branch_snap thunder thunder_near phone_ring stinger_spot stinger_near stinger_title stinger_jump stinger_found ui_click ui_back tape_insert page_turn`).split(' ');
export const LOOP_NAMES = 'fire generator radio_static lantern_buzz water_lap engine_idle engine_rev rain_roof fork_drag'.split(' ');
export const MUSIC_NAMES = 'title dread stalk chase finale dawn'.split(' ');
export const INTERNAL_NAMES = 'wind rain crickets owl loon coyote branch_creak heartbeat piano bass strings pad warm dread_bed'.split(' ');
export const BANK_NAMES = [...SFX_NAMES, ...LOOP_NAMES, ...INTERNAL_NAMES];
const TAU = Math.PI * 2;
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const hash = (name) => [...name].reduce((a, c) => Math.imul(a ^ c.charCodeAt(0), 16777619), 1984) >>> 0;

// Additive resonators and filtered noise are baked once; gameplay only plays buffers.
export function synthesize(name, sr = SAMPLE_RATE, variant = 0) {
  const rng = makeRng(hash(variant && name.startsWith('step_') ? `${name}:${variant}` : name));
  let duration = 0.7, peak = 0.58;
  const lengths = {
    step_dirt: 0.19, step_leaf: 0.23, step_wood: 0.2, step_gravel: 0.22, step_water: 0.24,
    fork_ting: 3.2, killer_breath: 2.1, crank_fail: 3.1, engine_start: 3.4,
    thunder: 6, thunder_near: 4.5, scream_death: 0.72, scream_distant: 1.7,
    player_breath_fast: 1.05, phone_ring: 2.8, stinger_spot: 2.2,
    stinger_near: 2.8, stinger_title: 3.8, stinger_jump: 1.4, stinger_found: 1.7,
    rummage: 1.5, tires_gravel: 1.8, glass_smash: 1.4, window_smash: 1.2,
    metal_crash: 2.2, owl: 2.5, loon: 3, coyote: 3.5, branch_creak: 2.4,
    wind: 8, rain: 6, crickets: 7, heartbeat: 0.65,
    piano: 3.8, bass: 1.3, strings: 1.8, pad: 5, warm: 4, dread_bed: 6,
    ui_click: 0.07, ui_back: 0.12, item_keys: 1.2, item_battery: 0.85,
  };
  duration = lengths[name] || (LOOP_NAMES.includes(name) ? 4 : duration);
  const data = new Float32Array(Math.ceil(duration * sr));
  function tone(f, amp, decay, start = 0, length = duration - start, endF = f, rough = 0) {
    const from = Math.floor(start * sr), count = Math.min(data.length - from, Math.ceil(length * sr));
    let phase = 0, increment = TAU * f / sr, envelope = amp;
    const incrementStep = TAU * (endF - f) / (length * sr * sr), fade = Math.exp(-decay / sr);
    for (let j = 0; j < count; j++) {
      phase += increment; increment += incrementStep;
      const attack = Math.min(1, j / (sr * 0.003));
      data[from + j] += envelope * attack * Math.sin(rough ? phase + rough * Math.sin(phase * 0.51) : phase);
      envelope *= fade;
    }
  }
  function noise(amp, cutoff, decay, start = 0, length = duration - start, hp = false, mod = 0) {
    let low = 0;
    const a = 1 - Math.exp(-TAU * cutoff / sr), from = Math.floor(start * sr);
    const count = Math.min(data.length - from, Math.ceil(length * sr));
    const fade = Math.exp(-decay / sr); let envelope = amp;
    for (let j = 0; j < count; j++) {
      const t = j / sr, n = rng() * 2 - 1;
      low += a * (n - low);
      data[from + j] += envelope * (hp ? n - low : low) * Math.min(1, t * 500) * (mod ? 0.55 + 0.45 * Math.sin(t * mod) : 1);
      envelope *= fade;
    }
  }
  function impact(weight = 1, wood = false, start = 0) {
    tone(wood ? 128 : 65, 0.7 * weight, 19, start, Math.min(0.45, duration - start), wood ? 80 : 39);
    noise(0.65 * weight, wood ? 1900 : 680, 25, start, Math.min(0.35, duration - start));
    if (wood) [231, 407, 711].forEach((f, i) => tone(f, 0.15 / (i + 1), 14 + i * 6, start));
  }
  function metal(base = 740, length = duration, start = 0, amp = 1) {
    [1, 1.421, 2.091, 2.807, 3.73].forEach((r, i) => tone(base * r, amp * 0.43 / (i + 1), 1.4 + i * 1.5, start, length));
    noise(amp * 0.24, 4500, 80, start, Math.min(length, 0.08));
  }
  function breath(fast = false) {
    noise(0.8, fast ? 2400 : 1350, 0.8, 0, duration, false, fast ? 9 : 3.3);
    noise(0.8, 310, 1.2, 0, duration, false, fast ? 11 : 3.6);
    tone(71, 0.16, 1.5, 0, duration, 56, 1.8);
    if (!fast) {
      tone(148, 0.07, 2, 0.5, 0.8, 109, 1.4);
      let low = 0;
      for (let i = 0; i < data.length; i++) {
        low += 0.24 * (data[i] - low);
        data[i] = low * Math.min(1, i / sr / 0.22);
      }
    }
  }
  if (name.startsWith('step_')) {
    if (name === 'step_dirt') {
      noise(0.9, 950, 34, 0, 0.15);
      noise(0.3, 2800, 45, 0.012, 0.12, true);
      noise(0.24, 480, 42, 0.025, 0.12);
      tone(78, 0.07, 48, 0, 0.085, 58);
    } else if (name === 'step_leaf') {
      noise(0.7, 2400, 30, 0, 0.18, true, 55);
      noise(0.2, 900, 35, 0, 0.1);
      for (let i = 0; i < 5; i++) {
        const start = 0.008 + i * 0.031 + rng() * 0.012;
        noise(0.22 + rng() * 0.22, 3200 + rng() * 1800, 55, start, 0.035 + rng() * 0.035, true);
      }
    } else if (name === 'step_wood') {
      noise(0.9, 1500, 40, 0, 0.13);
      noise(0.28, 3600, 55, 0.008, 0.09, true);
      tone(96, 0.1, 52, 0, 0.085, 68);
    } else if (name === 'step_gravel') {
      noise(0.55, 2800, 36, 0, 0.16);
      for (let i = 0; i < 6; i++) {
        const start = 0.005 + i * 0.022 + rng() * 0.014;
        noise(0.2 + rng() * 0.28, 2200 + rng() * 3000, 60, start, 0.025 + rng() * 0.03, rng() > 0.35);
      }
    } else if (name === 'step_water') {
      noise(0.85, 1200, 24, 0, 0.22);
      noise(0.45, 2600, 30, 0.015, 0.19, true, 38);
      for (let i = 0; i < 4; i++) {
        const start = 0.025 + i * 0.035 + rng() * 0.018;
        noise(0.18 + rng() * 0.18, 1800 + rng() * 1800, 45, start, 0.04 + rng() * 0.04, true);
      }
    }
    peak = 0.42;
  } else if (name.startsWith('killer_step') || name === 'stumble') {
    const heavy = name.startsWith('killer'), wood = name.includes('wood');
    impact(heavy ? 1.5 : 0.7, wood);
    noise(name.includes('leaf') ? 1.3 : 0.55, name.includes('gravel') ? 4200 : 2300, 13, 0.045, 0.45, name.includes('leaf'));
    if (name.includes('water')) { noise(1.2, 1800, 8, 0.03, 0.5); tone(330, 0.25, 18, 0.05, 0.3, 90); }
    if (heavy) { tone(44, 0.8, 9); impact(0.3, false, 0.12); peak = 0.8; }
  } else if (name === 'fork_ting') { metal(827); tone(1173, 0.13, 0.75); peak = 0.64;
  } else if (name === 'killer_breath' || name === 'player_breath_fast' || name === 'gasp') { breath(name !== 'killer_breath');
  } else if (name.includes('scream')) {
    // Irregular glottal pulses through fixed vocal formants, abruptly choked off.
    let phase = 0, nlow = 0;
    const filters = [780, 1240, 2530].map((f) => ({ c: 2 * Math.cos(TAU * f / sr) * 0.974, y1: 0, y2: 0 }));
    for (let i = 0; i < data.length; i++) {
      const t = i / sr, u = t / duration;
      phase += (174 + 35 * Math.sin(t * 15) + 13 * Math.sin(t * 81) - u * 37) / sr;
      const n = rng() * 2 - 1;
      nlow += 0.27 * (n - nlow);
      const excitation = (phase % 1 < 0.13 ? 0.7 : -0.1) * (0.65 + 0.35 * rng()) + (n - nlow) * 0.22;
      let sum = 0;
      for (const f of filters) { const y = excitation + f.c * f.y1 - 0.948676 * f.y2; f.y2 = f.y1; f.y1 = y; sum += y * 0.065; }
      data[i] = Math.tanh(sum * 2.8) * Math.min(1, t * 55) * Math.pow(Math.max(0, 1 - u), 0.25) * (0.7 + 0.3 * Math.sin(t * 61));
    }
    peak = name === 'scream_death' ? 0.65 : 0.4;
  } else if (name === 'crank_fail' || name === 'engine_start') {
    let phase = 0;
    for (let i = 0; i < data.length; i++) {
      const t = i / sr, u = t / duration, success = name === 'engine_start';
      const rev = success && t > 1 ? 27 + 29 * Math.exp(-(t - 1) * 0.8) : 7 + 4 * Math.sin(t * 2.2) - u * 3;
      phase += TAU * Math.max(3, rev) / sr;
      const catchPulse = Math.exp(-(((t - 1.2) / 0.12) ** 2)) + Math.exp(-(((t - 2.05) / 0.09) ** 2));
      const piston = Math.sin(phase), p2 = piston * piston, p4 = p2 * p2;
      data[i] = Math.tanh(p4 * p4 * piston * 1.6 + Math.sin(phase * 5.03) * 0.22 + (rng() * 2 - 1) * (0.12 + catchPulse * 0.8)) * (success ? 0.7 : (1 - u ** 3));
    }
    noise(0.3, 2300, 0.5);
    if (name === 'crank_fail') {
      tone(67, 0.32, 11, 1.18, 0.27, 126, 2.3);
      tone(83, 0.4, 15, 2.02, 0.24, 142, 2.3);
    }
    peak = 0.7;
  } else if (name.startsWith('stinger')) {
    const base = name === 'stinger_found' ? 164.81 : 61.735;
    [1, 1.059463, 1.4983].forEach((r, i) => {
      tone(base * r, 0.6 / (i + 1), 1.8, i * 0.018, duration - i * 0.018, base * r * 0.96, 2.5);
      tone(base * 16 * r, 0.27, 3.5, i * 0.025, duration - i * 0.025, base * 15.6 * r, 1.1);
    });
    noise(0.6, 4300, 8, 0, 0.8, true); peak = 0.78;
  } else if (name.startsWith('thunder')) {
    noise(1.4, name === 'thunder_near' ? 900 : 260, 0.65);
    noise(0.5, 70, 0.5, 0.18, duration - 0.18);
    [0.08, 0.43, 0.9, 1.6, 2.4].forEach((t) => noise(0.5, 360, 4, t, Math.min(1, duration - t)));
    peak = name === 'thunder_near' ? 0.8 : 0.56;
  } else if (name.includes('glass') || name === 'window_smash') {
    impact(0.7); for (let j = 0; j < 22; j++) metal(1900 + rng() * 4000, 0.18 + rng() * 0.35, rng() * 0.7, 0.18);
    noise(0.5, 6000, 10, 0, 0.6, true);
  } else if (name.includes('metal') || name === 'item_keys' || name === 'battery_install' || name === 'hood_open') {
    impact(0.6); metal(name === 'item_keys' ? 2100 : 310, duration - 0.06, 0.06, 0.55);
  } else if (name.includes('door') || name.includes('closet') || name.includes('wood') || name === 'branch_snap' || name === 'fork_thunk' || name === 'fork_stab' || name.includes('body') || name === 'item_battery') {
    const slam = /slam|bash|body|stab/.test(name);
    impact(slam ? 1.4 : 0.6, /wood|door|closet|branch/.test(name));
    if (/open|close/.test(name)) tone(270, 0.18, 6, 0.05, 0.45, 130, 1.5);
    if (name === 'fork_stab') noise(0.7, 900, 13, 0.04, 0.5);
  } else if (name === 'phone_ring') {
    for (const t of [0, 0.075, 0.15, 0.225, 0.3, 0.375, 1.3, 1.375, 1.45, 1.525, 1.6, 1.675]) metal(1450, 0.2, t, 0.5);
    peak = 0.5;
  } else if (name === 'heartbeat') {
    tone(57, 0.8, 24, 0, 0.21, 38); tone(46, 0.6, 22, 0.19, 0.3, 33); peak = 0.62;
  } else if (name === 'dread_bed') {
    tone(55, 0.4, 0); tone(54.5, 0.24, 0); tone(82.5, 0.15, 0); peak = 0.35;
  } else if (name === 'piano') {
    [1, 2.003, 3.013, 4.028, 6.07].forEach((r, i) => { tone(220 * r, 0.5 / (i + 1), 1.6 + i * 1.3); tone(219.2 * r, 0.3 / (i + 1), 1.8 + i); });
    noise(0.12, 2400, 90, 0, 0.05); peak = 0.55;
  } else if (name === 'bass') {
    tone(55, 0.6, 3.7, 0, duration, 54.8, 0.6); tone(110.3, 0.16, 7); peak = 0.55;
  } else if (name === 'strings' || name === 'pad' || name === 'warm') {
    [1, 1.003, 2, 2.997, 4.006].forEach((r, i) => tone(220 * r, 0.36 / (i + 1), name === 'strings' ? 2 : 0.35, 0, duration, 219.6 * r, name === 'strings' ? 1.4 : 0.1));
    if (name === 'strings') noise(0.3, 4200, 3, 0, duration, true);
    for (let i = 0; i < data.length; i++) data[i] *= Math.min(1, i / sr / (name === 'strings' ? 0.025 : 0.4));
    peak = 0.42;
  } else if (name === 'owl' || name === 'loon' || name === 'coyote') {
    const f = name === 'owl' ? 340 : name === 'loon' ? 820 : 530;
    for (let j = 0; j < 3; j++) tone(f * (1 - j * 0.11), 0.5, 3, j * 0.6, Math.min(1.2, duration - j * 0.6), f * (0.87 - j * 0.08), 0.2);
    peak = 0.4;
  } else if (name === 'branch_creak') { tone(170, 0.3, 0.8, 0, duration, 340, 2); noise(0.4, 1200, 1, 0, duration, false, 31);
  } else if (name === 'crickets') {
    for (let j = 0; j < 3; j++) {
      const f = [3870, 4620, 5310][j];
      for (let i = 0; i < data.length; i++) {
        const t = i / sr, phrase = (t + j * 0.43) % (1.9 + j * 0.32);
        const gate = phrase < 0.58 ? Math.max(0, Math.sin(phrase * TAU * (23 + j * 4))) ** 4 : 0;
        data[i] += Math.sin(TAU * f * t) * gate * 0.24;
      }
    }
    peak = 0.25;
  } else if (name === 'wind' || name === 'rain' || LOOP_NAMES.includes(name)) {
    if (name === 'wind') { noise(1, 450, 0); noise(0.2, 1800, 0); peak = 0.27; }
    if (name === 'rain' || name === 'rain_roof') { noise(0.7, 6200, 0, 0, duration, true); noise(0.5, 1200, 0); peak = 0.4; }
    if (name === 'radio_static') { noise(0.6, 6400, 0); tone(1730, 0.025, 0); peak = 0.28; }
    if (name === 'fire') { noise(0.7, 500, 0); for (let j = 0; j < 24; j++) noise(0.7, 3500, 80, rng() * 3.8, 0.12); peak = 0.4; }
    if (name === 'water_lap') { noise(0.8, 1000, 0, 0, duration, false, 4.2); tone(270, 0.1, 0, 0, duration, 240); peak = 0.32; }
    if (name === 'fork_drag') { noise(0.6, 4500, 0, 0, duration, true, 37); metal(740, duration, 0, 0.4); peak = 0.45; }
    if (/generator|engine_|lantern/.test(name)) {
      const f = name === 'lantern_buzz' ? 120 : name === 'engine_rev' ? 48 : 27;
      [1, 2, 3, 5, 8].forEach((r, i) => tone(f * r, 0.45 / (i + 1), 0, 0, duration, f * r, 0.3)); noise(0.2, 1700, 0); peak = 0.4;
    }
  } else if (name === 'ui_click' || name === 'ui_back' || name === 'found_nothing' || name === 'stinger_found') {
    tone(name === 'ui_back' ? 310 : 510, 0.35, 35, 0, duration, 240); noise(0.15, 2000, 45); peak = 0.25;
  } else {
    // Cloth, paper, tape transport and air movement have different grain envelopes.
    noise(0.65, /page|swing/.test(name) ? 4800 : 1700, name === 'rummage' ? 1 : 5, 0, duration, true, name === 'rummage' ? 23 : 7);
    if (name === 'vault_window') impact(0.5, true, 0.2);
    if (name === 'tape_insert') { impact(0.4, false, 0.18); metal(900, 0.3, 0.3, 0.1); }
  }
  const looping = LOOP_NAMES.includes(name) || ['wind', 'rain', 'crickets', 'dread_bed'].includes(name);
  if (looping) {
    // Overlap the tail into the head; both value and slope join at the loop boundary.
    const overlap = Math.floor(sr * 0.08), end = data.length - overlap;
    for (let i = 0; i < overlap; i++) { const u = i / overlap; data[i] = data[end + i] * (1 - u) + data[i] * u; }
    data.fill(0, end);
    return finish(data.subarray(0, end), sr, peak, true);
  }
  return finish(data, sr, peak, false);
}

function finish(data, sr, peak, looping) {
  let previous = 0, dc = 0, maximum = 0;
  if (looping) {
    // Start the DC blocker in its periodic steady state, avoiding a click on wrap.
    for (let i = Math.max(0, data.length - Math.ceil(sr * 0.2)); i < data.length; i++) {
      dc = data[i] - previous + 0.995 * dc; previous = data[i];
    }
  }
  for (let i = 0; i < data.length; i++) {
    const x = data[i]; dc = x - previous + 0.995 * dc; previous = x;
    const edge = looping ? 1 : Math.min(1, i / (sr * 0.002), (data.length - 1 - i) / (sr * 0.018));
    data[i] = dc * edge; maximum = Math.max(maximum, Math.abs(data[i]));
  }
  const gain = maximum > 0 ? peak / maximum : 0;
  for (let i = 0; i < data.length; i++) data[i] *= gain;
  return { data, sampleRate: sr, duration: data.length / sr, loop: looping };
}

export function makeBuffer(ctx, name, variant = 0) {
  const pcm = synthesize(name, SAMPLE_RATE, variant);
  const buffer = ctx.createBuffer(1, pcm.data.length, pcm.sampleRate);
  buffer.getChannelData(0).set(pcm.data);
  return buffer;
}

export const ROOM_SETTINGS = {
  outside: { length: 2.9, cutoff: 2400, wet: 0.3, lowpass: 18000 },
  room: { length: 0.48, cutoff: 4200, wet: 0.25, lowpass: 14500 },
  closet: { length: 0.16, cutoff: 1200, wet: 0.13, lowpass: 850 },
  car: { length: 0.12, cutoff: 2800, wet: 0.18, lowpass: 7200 },
};

export function makeImpulse(ctx, name) {
  // A ConvolverNode refuses any buffer that is not at the context's own rate.
  const cfg = ROOM_SETTINGS[name], sr = ctx.sampleRate;
  const buffer = ctx.createBuffer(2, Math.ceil(cfg.length * sr), sr), rng = makeRng(hash(name));
  for (let channel = 0; channel < 2; channel++) {
    const data = buffer.getChannelData(channel);
    let low = 0;
    const a = 1 - Math.exp(-TAU * cfg.cutoff / sr);
    for (let i = 0; i < data.length; i++) {
      low += a * (rng() * 2 - 1 - low);
      const t = i / sr;
      data[i] = low * Math.exp(-6.9 * t / cfg.length) * Math.min(1, t / 0.012) * 0.045;
    }
    for (const [t, gain] of [[0.013, 0.2], [0.027, 0.13], [0.043, 0.08]]) data[Math.floor((t + channel * 0.0017) * sr)] += gain;
  }
  return buffer;
}

// A–Ab–Eb: falling 1 then 5 semitones. Its spacing and rhythm are this score's signature.
const MOTIF = [0, -1, -6];
export function score(name, duration = 20) {
  const notes = [], add = (at, sound, midi, volume) => notes.push({ at, sound, rate: sound === 'heartbeat' ? 1 : 2 ** ((midi - (sound === 'bass' ? 33 : 57)) / 12), volume });
  if (!MUSIC_NAMES.includes(name)) return notes;
  const fast = name === 'chase' || name === 'finale', shift = name === 'finale' ? 1 : 0;
  if (fast) {
    const beat = name === 'finale' ? 0.24 : 0.285;
    const pattern = [0, -1, -6, -6, 0, -1, -6, -8];
    for (let i = 0; i * beat < duration; i++) {
      add(i * beat, 'bass', 33 + shift + pattern[i % 8], 0.32);
      if (i % 8 === 3 || i % 8 === 7) add(i * beat, 'strings', 69 + shift + MOTIF[Math.floor(i / 8) % 3], 0.16);
      if (name === 'finale' && i % 2 === 0) add(i * beat, 'heartbeat', 33, 0.28);
    }
  } else if (name === 'stalk') {
    for (let t = 0; t < duration; t += 1.65) add(t, 'bass', 33 + MOTIF[Math.floor(t / 6.6) % 3], 0.19);
  }
  for (let t = 0; t < duration; t += 3.7) add(t, 'pad', name === 'dawn' ? 45 : 33 + shift, name === 'dread' ? 0.13 : 0.09);
  if (name === 'title' || name === 'dawn') {
    for (let t = 0; t < duration; t += 9.6) {
      [0, 1.65, 4.05].forEach((offset, i) => { if (t + offset < duration) add(t + offset, name === 'dawn' ? 'warm' : 'piano', 57 + MOTIF[i] + (name === 'dawn' ? 12 : 0), name === 'title' ? 0.23 : 0.25); });
    }
  }
  return notes.sort((a, b) => a.at - b.at);
}
