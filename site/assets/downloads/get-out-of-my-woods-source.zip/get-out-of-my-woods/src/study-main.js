// Entry point. Waits for the embedded fonts (the car's painted message is drawn with one), checks
// for WebGL 2, then starts the game.
import { PreviewApp } from './act2/app.js';

async function boot() {
  const bootEl = document.getElementById('boot');
  const fail = (msg) => {
    if (bootEl) {
      bootEl.textContent = msg;
      bootEl.style.display = 'flex';
    }
  };
  const probe = document.createElement('canvas');
  if (!probe.getContext('webgl2')) {
    fail('This game needs WebGL 2. Please try a newer browser.');
    return;
  }
  try {
    if (document.fonts?.load) {
      await Promise.race([
        Promise.all(["40px 'Rock Salt'", "40px 'Anton'", "700 20px 'Oswald'", "20px 'Special Elite'", "20px 'VT323'"].map((f) => document.fonts.load(f))),
        new Promise((r) => setTimeout(r, 2500)),
      ]);
    }
    // Let the browser paint the loading card before the heavy generation starts.
    await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 30)));
    const app = new PreviewApp();
    window.__woodsPreview = app;
    window.__goomw = app; // used by the automated browser tests
    if (bootEl) bootEl.remove();
  } catch (e) {
    console.error(e);
    fail('Something went wrong loading the game: ' + (e.message || e));
  }
}

boot();
