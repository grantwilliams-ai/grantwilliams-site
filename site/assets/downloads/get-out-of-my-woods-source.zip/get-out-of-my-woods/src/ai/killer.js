// The killer's brain: a finite-state machine that only knows what he can see and hear.
// States: wait, lurk, patrol, notice, investigate, search, chase, strike, checkhide, ambush, guard, kill.
// He never teleports (one exception: placing him off-screen during the opening, before the hunt).
// He walks. Only in a chase does he stride. When he is far away and out of sight he may hurry,
// which is how he is always somehow ahead of you, but he still has to cover the ground.
import { KILLER, LURK } from './tuning.js';

const angleTo = (from, to) => Math.atan2(to.x - from.x, to.z - from.z);
const wrap = (a) => {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
};

export class Killer {
  constructor(sim, tune, rng, start) {
    this.sim = sim;
    this.tune = tune;
    this.rng = rng;
    this.start = start;
    this.x = start.x;
    this.z = start.z;
    this.yaw = 0;
    this.headYaw = 0; // offset of the head from the body
    this.state = 'wait';
    this.anim = 'idle';
    this.speed = 0;
    this.path = null;
    this.pathI = 0;
    this.pathTimer = 0;
    this.target = null;
    this.timer = 0;
    this.awareness = 0;
    this.sees = false;
    this.lastSeen = null;
    this.lostFor = 0;
    this.spots = [];
    this.stuckT = 0;
    this.lastX = this.x;
    this.lastZ = this.z;
    this.stepAcc = 0;
    this.tingT = 8 + rng() * 14;
    this.breathT = 3;
    this.doorWait = 0;
    this.strikePhase = 0;
    this.knownDoors = new Map();
    this.checking = null;
    this.chases = 0;
    this.chaseT = 0;
    this.swings = 0;
    this.pendingNoise = null;
    this.sawHide = null;
    this.pursuitActive = false;
  }

  speedFactor() {
    const act = this.sim.act;
    return act >= 2 ? KILLER.act3Speed : act === 1 ? KILLER.act2Speed : 1;
  }

  go(state, timer = 0) {
    this.state = state;
    this.timer = timer;
  }

  setPath(x, z) {
    const p = this.sim.nav.findPath(this.x, this.z, x, z);
    this.path = p;
    this.pathI = 0;
    this.target = { x, z };
    return !!p;
  }

  // Walks along the current path. Returns true on arrival.
  follow(dt, speed, ignoreDoorPause = false) {
    if (!this.path || this.pathI >= this.path.length) {
      this.speed = 0;
      return true;
    }
    if (this.doorWait > 0) {
      this.doorWait -= dt;
      this.speed = 0;
      return false;
    }
    const pt = this.path[this.pathI];
    const dx = pt[0] - this.x, dz = pt[1] - this.z;
    const d = Math.hypot(dx, dz);
    if (d < Math.max(0.35, speed * dt * 1.5)) {
      this.pathI++;
      return this.pathI >= this.path.length;
    }
    // A shut door in the way: he opens it, or goes through it.
    const door = this.doorAhead();
    if (door) {
      this.sim.killerDoor(door, this.state === 'chase');
      if (!ignoreDoorPause) this.doorWait = this.state === 'chase' ? 0.3 : 0.85;
      this.anim = 'openDoor';
      return false;
    }
    const want = Math.atan2(dx, dz);
    const turn = wrap(want - this.yaw);
    const rate = this.state === 'chase' ? 7 : 3.2;
    this.yaw = wrap(this.yaw + Math.max(-rate * dt, Math.min(rate * dt, turn)));
    // Heavy men slow down to turn.
    const slow = 1 - Math.min(0.6, Math.abs(turn) * 0.45);
    const step = speed * slow * dt;
    const nx = this.x + (dx / d) * step, nz = this.z + (dz / d) * step;
    const [rx, rz] = this.sim.moveKiller(this.x, this.z, nx, nz);
    this.x = rx;
    this.z = rz;
    this.speed = speed * slow;
    return false;
  }

  doorAhead() {
    for (const d of this.sim.collision.doors) {
      if (d.open) continue;
      if (Math.hypot(d.x - this.x, d.z - this.z) < 1.25) {
        const a = angleTo(this, d);
        if (Math.abs(wrap(a - this.yaw)) < 1.2) return d;
      }
    }
    return null;
  }

  // Sight: fills an awareness meter instead of snapping straight to a chase, so a distant
  // player gets a moment to break line of sight, and a close one does not.
  observe() {
    const p = this.sim.player;
    const dist = Math.hypot(p.x - this.x, p.z - this.z);
    const out = { visible: false, dist };
    if (p.hidden) {
      return out;
    }
    if (this.sim.player.inCar) return out;
    let range = this.tune.sight;
    if (!p.flashlight) range *= KILLER.darkSight;
    if (p.moveMode === 'sneak') range *= 0.72;
    else if (p.moveMode === 'run') range *= 1.15;
    if (p.inBrush) range *= 0.35;
    if (p.nearLight) range *= 1.3;
    range *= 1 - this.sim.storm * 0.18;

    const a = angleTo(this, p);
    const facing = this.yaw + this.headYaw;
    const c = Math.cos(wrap(a - facing));
    if (c < KILLER.fovCos) range *= c > KILLER.sideCos ? 0.42 : 0;
    if (dist < KILLER.feelRange) range = Math.max(range, KILLER.feelRange + 0.1);

    if (dist < range) {
      const op = this.sim.collision.sightOpacity(this.x, this.z, p.x, p.z);
      if (op < 1 || (dist < 2 && op < 2)) { // up close foliage cannot hide you, but a wall still does
        out.visible = true;
        const close = 1 - dist / range;
        const rate = this.tune.sightRate * (0.45 + 3.2 * close * close) * (1 - Math.min(0.75, op * 0.75));
        out.rate = rate;
      }
    }
    return out;
  }

  perceive(dt) {
    const out = this.observe();
    if (out.visible) this.awareness = Math.min(1.3, this.awareness + out.rate * dt);
    else this.awareness = Math.max(0, this.awareness - dt * (this.sim.player.hidden ? 0.5 : 0.28));
    this.sees = out.visible;
    return out;
  }

  // Called by the sim whenever the player or the world makes a sound.
  hear(x, z, radius, what) {
    if (this.state === 'wait' || this.state === 'lurk' || this.state === 'kill' || this.state === 'chase' || this.state === 'strike') return;
    const d = Math.hypot(x - this.x, z - this.z);
    if (d > radius * this.tune.hearing) return;
    // Less certain the farther away it was.
    const err = d * 0.12;
    const tx = x + (this.rng() - 0.5) * err, tz = z + (this.rng() - 0.5) * err;
    if (this.state === 'ambush' && d > 10) return;
    this.pendingNoise = { x: tx, z: tz, what };
  }

  beginChase() {
    const fresh = this.state !== 'chase' && this.state !== 'strike';
    this.state = 'chase';
    this.pursuitActive = true;
    this.pathTimer = 0;
    this.lostFor = 0;
    this.noticeThen = null;
    this.pendingNoise = null;
    this.checking = null;
    this.sawHide = null;
    if (fresh) {
      this.chaseT = 0;
      this.swings = 0;
      this.chases++;
      this.sim.emit({ t: 'spotted', x: this.x, z: this.z });
    }
  }

  // Before the hunt he is only a shape standing in the road. He lets you get a look at him, then he
  // walks off into the trees. Nothing he does here can hurt you, and nothing here can see you.
  startLurk() {
    this.x = LURK.x;
    this.z = LURK.z;
    this.state = 'lurk';
    this.leaving = false;
    this.hushed = false;
  }

  lurk(dt) {
    const sim = this.sim;
    const p = sim.player;
    const d = Math.hypot(p.x - this.x, p.z - this.z);
    if (!this.hushed && d < LURK.showAt) {
      this.hushed = true;
      sim.emit({ t: 'hush' });
    }
    if (!this.leaving) {
      this.speed = 0;
      this.anim = 'standStill';
      this.yaw = angleTo(this, p);
      if (d < LURK.leaveAt) {
        this.leaving = true;
        sim.emit({ t: 'ting', x: this.x, z: this.z });
      }
      return;
    }
    const to = { x: LURK.toX, z: LURK.toZ };
    const want = angleTo(this, to);
    this.yaw += wrap(want - this.yaw) * Math.min(1, dt * 4);
    this.speed = LURK.speed;
    this.anim = 'walk';
    this.x += Math.sin(this.yaw) * this.speed * dt;
    this.z += Math.cos(this.yaw) * this.speed * dt;
    const walked = Math.hypot(this.x - LURK.x, this.z - LURK.z);
    const hidden = walked > 6 && sim.collision.sightOpacity(p.x, p.z, this.x, this.z) >= 1;
    if (hidden || Math.hypot(to.x - this.x, to.z - this.z) < 1) this.vanish();
  }

  // He may only do this before the hunt, out of sight, and it is the reason the map stays fair.
  vanish() {
    this.x = this.start.x;
    this.z = this.start.z;
    this.state = 'wait';
    this.speed = 0;
    this.awareness = 0;
    this.sim.emit({ t: 'lurkGone' });
  }

  update(dt) {
    const sim = this.sim;
    const p = sim.player;
    if (this.state === 'lurk') {
      this.lurk(dt);
      this.sounds(dt);
      return;
    }
    const look = this.perceive(dt);

    if (look.visible) {
      this.lastSeen = { x: p.x, z: p.z, vx: p.vx, vz: p.vz, t: sim.time };
      this.lostFor = 0;
    } else {
      this.lostFor += dt;
    }

    // Standing among the dummies he has already seen you. He is waiting for you to come closer.
    const waiting = this.state === 'ambush' && this.ambushArrived;
    if (!waiting && this.state !== 'wait' && this.state !== 'kill' && this.state !== 'strike' && this.state !== 'chase') {
      // Suspicion alone cannot reacquire someone behind a wall or inside cover.
      if (this.awareness >= 1 && look.visible) this.beginChase();
      else if (this.awareness >= KILLER.noticeAt && this.state !== 'notice' && this.state !== 'checkhide' && look.visible) {
        this.go('notice', 0.7 + this.rng() * 0.5);
        sim.emit({ t: 'noticed', x: this.x, z: this.z });
      }
    }

    switch (this.state) {
      case 'wait':
        this.anim = 'standStill';
        this.speed = 0;
        break;
      case 'patrol': this.patrol(dt); break;
      case 'notice': this.notice(dt); break;
      case 'investigate': this.investigate(dt); break;
      case 'search': this.searchState(dt); break;
      case 'chase': this.chase(dt, look); break;
      case 'strike': this.strike(dt); break;
      case 'checkhide': this.checkHide(dt); break;
      case 'ambush': this.ambush(dt, look); break;
      case 'guard': this.guard(dt, look); break;
      default: break;
    }

    // A noise pulls him off whatever routine he is on.
    if (this.pendingNoise) {
      const n = this.pendingNoise;
      this.pendingNoise = null;
      if (this.state === 'patrol' || this.state === 'search' || this.state === 'investigate' || this.state === 'guard') {
        this.spots = [];
        this.setPath(n.x, n.z);
        this.go('notice', 0.5 + this.rng() * 0.6);
        this.noticeThen = { x: n.x, z: n.z };
      }
    }

    this.sounds(dt);
    this.unstick(dt);
  }

  patrol(dt) {
    const sim = this.sim;
    if (sim.director.pressureNudge) {
      this.timer = 0;
      this.path = null;
      this.pickNext();
      return;
    }
    if (this.timer > 0) {
      this.timer -= dt;
      this.speed = 0;
      this.anim = this.pauseAnim || 'listen';
      this.headYaw = Math.sin(sim.time * 0.5 + this.x) * 0.9;
      if (this.timer <= 0) this.pickNext();
      return;
    }
    this.headYaw *= 1 - dt * 3;
    if (!this.path) {
      this.pickNext();
      return;
    }
    const far = this.farAndUnseen();
    const base = this.tune.walk * this.speedFactor();
    // Out of sight and a long way off, he covers ground faster than anyone would believe.
    const speed = far && sim.director.relax <= 0 ? this.tune.catchUp : base;
    this.anim = speed > base ? 'stalk' : 'walk';
    if (this.follow(dt, speed)) {
      this.path = null;
      this.timer = 1.6 + this.rng() * 4.2;
      this.pauseAnim = this.rng() < 0.5 ? 'listen' : 'lookAround';
      // Sometimes he looks in on a door someone left open.
      for (const d of sim.collision.doors) {
        const was = this.knownDoors.get(d.id);
        const near = Math.hypot(d.x - this.x, d.z - this.z) < 16;
        if (near && d.open && was === false && this.rng() < 0.75) {
          this.knownDoors.set(d.id, true);
          this.spots = [{ x: d.x, z: d.z }];
          this.setPath(d.x, d.z);
          this.timer = 0;
          this.go('investigate');
          return;
        }
        if (near) this.knownDoors.set(d.id, d.open);
      }
    }
  }

  pickNext() {
    const sim = this.sim;
    const guard = sim.director.wantsCarGuard(sim.act);
    if (guard) {
      this.setPath(guard.x, guard.z);
      this.go('guard', 0);
      this.guardT = 34 + this.rng() * 14;
      this.guardArrived = false;
      return;
    }
    const am = sim.director.wantsAmbush(this, sim.player);
    if (am && !this.playerCanSee(am)) {
      this.setPath(am.x, am.z);
      this.go('ambush', 0);
      this.ambushT = 45;
      this.ambushArrived = false;
      return;
    }
    const w = sim.director.nextWaypoint(this, sim.player, sim.act);
    this.setPath(w.x, w.z);
    this.go('patrol', 0);
  }

  // He only ever hurries where nobody could see him do it.
  farAndUnseen() {
    const p = this.sim.player;
    const d = Math.hypot(p.x - this.x, p.z - this.z);
    // A walking player must not permanently outrun a patrol behind opaque trees.
    // After a long quiet spell he can close the gap physically, but never hurry
    // within twenty metres, in clear sight, or during a hidden/recovery window.
    const director = this.sim.director;
    const approach = director.pressured && director.sinceContact > this.tune.pressure + 25;
    return d > (approach ? 20 : 34) && (d > 75 || this.sim.collision.sightOpacity(p.x, p.z, this.x, this.z) >= 1);
  }

  playerCanSee(pt) {
    const p = this.sim.player;
    return Math.hypot(pt.x - p.x, pt.z - p.z) < 30;
  }

  notice(dt) {
    const sim = this.sim;
    this.timer -= dt;
    this.speed = 0;
    this.anim = 'listen';
    if (this.sees) {
      const a = angleTo(this, sim.player);
      this.headYaw = Math.max(-1.1, Math.min(1.1, wrap(a - this.yaw)));
    }
    if (this.timer <= 0) {
      const t = this.noticeThen || (this.lastSeen ? { x: this.lastSeen.x, z: this.lastSeen.z } : null);
      this.noticeThen = null;
      this.headYaw = 0;
      if (t && this.setPath(t.x, t.z)) this.go('investigate');
      else this.go('patrol', 0.5);
    }
  }

  investigate(dt) {
    this.headYaw = Math.sin(this.sim.time * 1.3) * 0.5;
    this.anim = 'stalk';
    const arrived = this.follow(dt, this.tune.stalk * this.speedFactor());
    if (arrived) this.startSearch(this.target || this, 2 + Math.floor(this.rng() * 2));
  }

  // Build a short list of places to look near a point, hiding places first.
  startSearch(center, count) {
    const sim = this.sim;
    // First inspect where the trail ended, then sweep nearby cover. Never use the
    // player's new position when choosing a search route.
    const spots = [{ x: center.x, z: center.z }];
    const hides = sim.hides
      .filter((h) => Math.hypot(h.x - center.x, h.z - center.z) < 13)
      .map((h) => ({ h, order: this.rng() }))
      .sort((a, b) => a.order - b.order).map(({ h }) => h);
    for (const h of hides.slice(0, 2)) if (this.rng() < 0.75) spots.push({ x: h.x, z: h.z, hide: h });
    for (let i = spots.length; i < count; i++) {
      const a = this.rng() * Math.PI * 2, r = 5 + this.rng() * 8;
      spots.push({ x: center.x + Math.cos(a) * r, z: center.z + Math.sin(a) * r });
    }
    this.spots = spots;
    this.checking = null;
    this.sawHide = null;
    this.searchLeft = this.tune.searchTime * (0.7 + this.rng() * 0.6);
    this.path = null;
    this.go('search', 1.4 + this.rng() * 1.4);
  }

  searchState(dt) {
    this.searchLeft -= dt;
    // Even an awkward route has a finite search budget. A witnessed hiding place
    // gets a longer approach budget, but no route can pin the night indefinitely.
    if (this.searchLeft <= 0) {
      this.finishSearch();
      return;
    }
    if (this.timer > 0) {
      this.timer -= dt;
      this.speed = 0;
      this.anim = 'lookAround';
      this.headYaw = Math.sin(this.sim.time * 1.1) * 1.0;
      return;
    }
    this.headYaw *= 1 - dt * 3;
    if (!this.path) {
      if (this.searchLeft <= 0 || this.spots.length === 0) {
        this.finishSearch();
        return;
      }
      const s = this.spots.shift();
      this.checking = s.hide || null;
      if (!this.setPath(s.x, s.z)) this.path = null;
      return;
    }
    this.anim = 'stalk';
    if (this.follow(dt, this.tune.stalk * this.speedFactor())) {
      this.path = null;
      if (this.checking) {
        this.go('checkhide', 1.8);
        if (this.sim.player.hidden?.id === this.checking.id) {
          this.sim.emit({ t: 'hideDanger', id: this.checking.id, x: this.x, z: this.z });
        }
      }
      else this.timer = 1.1 + this.rng() * 1.5;
    }
  }

  finishSearch() {
    this.path = null;
    this.checking = null;
    this.sawHide = null;
    this.spots = [];
    this.awareness = Math.min(this.awareness, 0.2);
    if (this.pursuitActive) {
      this.sim.director.contact(20);
      this.sim.emit({ t: 'evaded', x: this.x, z: this.z });
    }
    this.pursuitActive = false;
    this.go('patrol', 0.6);
  }

  // He stands in front of a hiding place. He may open it. Everyone holds their breath.
  checkHide(dt) {
    const sim = this.sim;
    const h = this.checking;
    this.speed = 0;
    this.timer -= dt;
    this.anim = 'searchCloset';
    if (h) this.yaw = angleTo(this, { x: h.view.pos[0], z: h.view.pos[2] });
    if (this.timer <= 0) {
      const inside = sim.player.hidden && sim.player.hidden.id === h?.id;
      const sawIt = this.sawHide === h?.id;
      this.checking = null;
      this.sawHide = null;
      if (inside && (sawIt || this.rng() < this.tune.checkHide)) {
        const type = sim.player.hidden.type;
        sim.kill(['closet', 'bed', 'canoe', 'outhouse'].includes(type) ? type : 'impale');
        return;
      }
      if (h) sim.emit({ t: 'hidechecked', id: h.id, x: h.x, z: h.z });
      this.timer = 0.8;
      this.go('search', 0.8);
    }
  }

  chase(dt, look) {
    const sim = this.sim;
    const p = sim.player;
    this.headYaw *= 1 - dt * 5;
    this.pathTimer -= dt;
    this.chaseT += dt;
    // He watched you go in. There is nothing to work out.
    if (p.hidden && p.seenEntering && this.setPath(p.hidden.x, p.hidden.z)) {
      this.sawHide = p.hidden.id;
      this.checking = p.hidden;
      this.go('search', 0);
      this.spots = [];
      this.searchLeft = 30;
      return;
    }
    if (this.chaseT > KILLER.chaseMax && !look.visible && look.dist > 6) {
      this.endChase();
      return;
    }
    // You can outrun him for a while. Not for a minute.
    const speed = this.tune.chase * this.speedFactor() * (1 + KILLER.chaseRamp * Math.min(1, this.chaseT / 60));
    if (look.visible || this.lostFor < this.tune.memory) {
      // Inside his memory window he still knows which way you went.
      if (this.pathTimer <= 0) {
        this.pathTimer = look.dist < 16 ? 0.22 : 0.45;
        if (look.visible) this.setPath(p.x, p.z);
        else if (this.lastSeen) {
          // A short, fixed extrapolation gives turning a corner real value. Do
          // not keep moving the target along an imaginary three-second sprint.
          const lead = Math.min(this.lostFor, 0.8);
          const tx = this.lastSeen.x + this.lastSeen.vx * lead;
          const tz = this.lastSeen.z + this.lastSeen.vz * lead;
          if (!this.setPath(tx, tz)) this.setPath(this.lastSeen.x, this.lastSeen.z);
        }
      }
    } else {
      this.endChase();
      return;
    }
    this.anim = 'chase';
    const arrived = this.follow(dt, speed);
    // Close enough to swing.
    if (look.visible && look.dist < this.tune.strikeReach && !p.hidden) {
      this.state = 'strike';
      this.strikePhase = 0;
      this.timer = this.tune.windup;
      this.anim = 'raise';
      sim.emit({ t: 'windup', x: this.x, z: this.z });
    } else if (arrived && !look.visible) {
      this.endChase();
    }
  }

  endChase() {
    const sim = this.sim;
    const at = this.lastSeen || this;
    sim.director.contact();
    this.awareness = 0.2;
    sim.emit({ t: 'lost', x: this.x, z: this.z });
    this.startSearch(at, 3);
  }

  strike(dt) {
    const sim = this.sim;
    const p = sim.player;
    const startX = this.x, startZ = this.z;
    this.timer -= dt;
    const a = angleTo(this, p);
    if (this.strikePhase === 0) {
      this.yaw = wrap(this.yaw + Math.max(-6 * dt, Math.min(6 * dt, wrap(a - this.yaw))));
      // He does not stop to swing. If you are running you get clear; if you are spent you do not.
      if (Math.hypot(p.x - this.x, p.z - this.z) > 1.3) {
        const run = this.tune.chase * this.speedFactor() * dt;
        const [wx, wz] = sim.moveKiller(this.x, this.z, this.x + Math.sin(this.yaw) * run, this.z + Math.cos(this.yaw) * run);
        this.x = wx;
        this.z = wz;
      }
      if (this.timer <= 0) {
        this.strikePhase = 1;
        this.timer = 0.18;
        this.anim = 'strike';
        sim.emit({ t: 'swing', x: this.x, z: this.z });
      }
    } else if (this.strikePhase === 1) {
      // The lunge carries him forward a stride, but not through you.
      if (Math.hypot(p.x - this.x, p.z - this.z) > 1.2) {
        const step = 5.5 * dt;
        const [rx, rz] = sim.moveKiller(this.x, this.z, this.x + Math.sin(this.yaw) * step, this.z + Math.cos(this.yaw) * step);
        this.x = rx;
        this.z = rz;
      }
      if (this.timer <= 0) {
        const d = Math.hypot(p.x - this.x, p.z - this.z);
        const inFront = d < 1.3 || Math.abs(wrap(angleTo(this, p) - this.yaw)) < 1.0;
        // The first swing of a chase is the one that goes past your ear, if you are still moving.
        // Anyone standing still within the length of the fork gets it, log or no log.
        const reach = this.swings === 0 && p.speed > 1.8 ? 0 : p.speed < 1.2 ? 2.5 : 1.9;
        this.swings++;
        if (d < reach && inFront && !p.hidden && !sim.collision.wallBetween(this.x, this.z, p.x, p.z)) {
          sim.kill(sim.nearSolidBehindPlayer() ? 'pinned' : 'impale');
        } else {
          const nearMiss = !p.hidden && d < 2.65 && inFront &&
            !sim.collision.wallBetween(this.x, this.z, p.x, p.z);
          if (nearMiss) {
            if (!p.wounded) {
              p.wounded = true;
              sim.emit({ t: 'graze', x: p.x, z: p.z });
            }
            sim.emit({ t: 'miss', x: this.x + Math.sin(this.yaw) * 1.8, z: this.z + Math.cos(this.yaw) * 1.8 });
            sim.closeCalls++;
            // Only a genuinely close escape gives the adrenaline refill.
            p.stamina = Math.min(1, p.stamina + KILLER.terror);
            p.winded = false;
          }
          this.strikePhase = 2;
          this.timer = 0.75;
          this.anim = 'idle';
        }
      }
    } else if (this.timer <= 0) {
      this.state = 'chase';
      this.pathTimer = 0;
    }
    // Sound and animation describe the distance actually traveled, including a stopped recovery.
    this.speed = this.state !== 'kill' && dt > 0 ? Math.hypot(this.x - startX, this.z - startZ) / dt : 0;
  }

  ambush(dt, look) {
    if (!this.ambushArrived) {
      this.anim = 'walk';
      if (this.follow(dt, this.farAndUnseen() ? this.tune.catchUp : this.tune.walk)) {
        this.ambushArrived = true;
        this.yaw = 0; // facing the range, like the dummies
      }
      return;
    }
    this.speed = 0;
    this.anim = 'scarecrow';
    this.ambushT -= dt;
    // He does not move until you are close enough that it is too late to be sure.
    if (look.dist < 7.5 && look.visible) {
      this.awareness = 1;
      this.sim.emit({ t: 'ambush', x: this.x, z: this.z });
      this.beginChase();
    } else if (this.ambushT <= 0) {
      this.go('patrol', 0.3);
      this.path = null;
    }
  }

  guard(dt, look) {
    if (!this.guardArrived) {
      this.anim = 'walk';
      if (this.follow(dt, this.farAndUnseen() ? this.tune.catchUp : this.tune.walk * 1.2)) {
        this.guardArrived = true;
        this.sim.emit({ t: 'guarding' });
      }
      return;
    }
    this.speed = 0;
    this.anim = 'listen';
    this.headYaw = Math.sin(this.sim.time * 0.4) * 1.1;
    this.guardT -= dt;
    if (this.guardT <= 0) {
      this.path = null;
      this.sim.director.contact(10);
      this.go('patrol', 0.2);
    }
  }

  sounds(dt) {
    const sim = this.sim;
    if (this.state === 'wait') return;
    const moving = this.speed > 0.2;
    if (moving) {
      this.stepAcc += this.speed * dt;
      const stride = this.state === 'chase' ? 1.75 : 1.05;
      if (this.stepAcc > stride) {
        this.stepAcc = 0;
        // Far off and out of sight he covers ground at an unnatural pace (catchUp). Those footfalls
        // are flagged so they are never played: at one per 1.05 m they come four a second, a rapid
        // banging in his own step sound just before his real walk becomes audible.
        const hurry = this.speed >= this.tune.catchUp * 0.9 && this.state !== 'chase' && this.state !== 'strike';
        sim.emit({ t: 'killerStep', x: this.x, z: this.z, indoors: !!sim.buildingAt(this.x, this.z), hurry });
      }
    }
    this.tingT -= dt;
    if (this.tingT <= 0) {
      this.tingT = 9 + this.rng() * 22;
      if (this.state !== 'chase') sim.emit({ t: 'ting', x: this.x, z: this.z });
    }
    this.breathT -= dt;
    if (this.breathT <= 0) {
      this.breathT = this.state === 'chase' ? 2.2 : 4.2;
      sim.emit({ t: 'killerBreath', x: this.x, z: this.z });
    }
  }

  // Safety net: if something ever pins him, he repaths; if that fails he reroutes to a waypoint.
  unstick(dt) {
    if (this.state === 'wait' || this.state === 'strike' || this.state === 'kill' || this.speed < 0.3) {
      this.stuckT = 0;
      this.stuckN = 0;
      this.lastX = this.x;
      this.lastZ = this.z;
      return;
    }
    this.stuckT += dt;
    if (this.stuckT > 1.2) {
      const moved = Math.hypot(this.x - this.lastX, this.z - this.lastZ);
      if (moved < 0.4) {
        this.sim.stats.killerStuck++;
        this.sim.stats.stuckAt = `${this.state} ${this.x.toFixed(0)},${this.z.toFixed(0)}`;
        this.stuckN = (this.stuckN || 0) + 1;
        if (this.stuckN >= 3 && this.state !== 'chase') {
          // The same spot three times over: the place he wants cannot be reached from here (a noise
          // from behind an open door leaf, say). He gives it up and looks around where he stands.
          this.stuckN = 0;
          if (this.state === 'investigate') this.startSearch(this, 2 + Math.floor(this.rng() * 2));
          else this.path = null;
        } else if (this.target) this.setPath(this.target.x, this.target.z);
      } else this.stuckN = 0;
      this.stuckT = 0;
      this.lastX = this.x;
      this.lastZ = this.z;
    }
  }
}
