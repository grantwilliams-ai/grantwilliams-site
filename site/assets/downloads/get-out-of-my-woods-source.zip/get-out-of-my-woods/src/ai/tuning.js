// Every number that decides how the night feels.
export const PLAYER = {
  radius: 0.3,
  sneak: 1.5,
  walk: 2.9,
  run: 5.15,
  winded: 2.35,
  staminaSeconds: 12,
  staminaBack: 0.12, // fraction per second, walking
  staminaBackStill: 0.24,
  batteryDrain: 1.5, // running with the battery burns stamina this much faster
  windedUntil: 0.5,
  noiseSneak: 1.6,
  noiseWalk: 6.5,
  noiseRun: 18,
  stepSneak: 0.8,
  stepWalk: 1.35,
  stepRun: 1.8,
};

export const DIFFICULTY = {
  easy: {
    // For someone on their first night: he is slower, sees and hears less, gives up sooner, telegraphs
    // his swing longer, and she can run a third longer before she is winded.
    introGrace: 60,
    walk: 1.3, stalk: 1.85, chase: 3.3, sight: 18.5, sightRate: 0.5, hearing: 0.65, memory: 1.7, pressure: 85, idlePressure: 50,
    checkHide: 0.2, windup: 0.6, searchTime: 12, strikeReach: 1.95, catchUp: 4.1, stamina: 1.3,
  },
  normal: {
    introGrace: 35,
    walk: 1.5, stalk: 2.3, chase: 3.75, sight: 25, sightRate: 0.80, hearing: 0.95, memory: 2.6, pressure: 38, idlePressure: 23,
    checkHide: 0.38, windup: 0.4, searchTime: 18, strikeReach: 2.2, catchUp: 5.2,
  },
  hard: {
    introGrace: 25,
    walk: 1.65, stalk: 2.55, chase: 3.95, sight: 28.5, sightRate: 0.98, hearing: 1.1, memory: 2.9, pressure: 28, idlePressure: 17,
    checkHide: 0.50, windup: 0.34, searchTime: 22, strikeReach: 2.25, catchUp: 5.8,
  },
};

export const KILLER = {
  radius: 0.36,
  fovCos: Math.cos((62 * Math.PI) / 180), // full sight within this half-angle
  sideCos: Math.cos((105 * Math.PI) / 180), // peripheral vision out to here
  noticeAt: 0.35, // awareness at which he stops and turns his head
  feelRange: 2.6, // he knows you are there, even behind him, this close
  act2Speed: 1.05, // speed multiplier after the first item
  act3Speed: 1.12, // after both
  darkSight: 0.6, // how much of that sight is left when your light is off
  chaseRamp: 0.14, // he gets faster the longer you run, up to this much after a minute
  chaseMax: 75, // after this long he stops, if you have kept your distance
  terror: 0.4, // stamina a near miss gives back
};

// Before the hunt: where he stands in the road, and which way he walks off into the trees.
export const LURK = { x: 52, z: 7.4, toX: 50.2, toZ: 26, showAt: 36, leaveAt: 18, speed: 1.75 };
