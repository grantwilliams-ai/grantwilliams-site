// The director knows roughly where the player is. The killer does not. The director only ever
// chooses where he strolls next, so that tension rises and falls like a film: long quiet stretches,
// then he is somewhere near, then a chase, then quiet again. He still has to find you himself.
import { WAYPOINTS, AMBUSH_SPOTS, CAR, BUILDINGS } from '../sim/layout.js';

const dist = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);

export class Director {
  constructor(rng, tune) {
    this.rng = rng;
    this.tune = tune;
    this.relax = 0; // seconds of backing off left
    this.sinceContact = 0;
    this.idleFor = 0;
    this.lastPlayer = null;
    this.pressured = false;
    this.pressureNudge = false;
    this.pressureRefreshAt = 0;
    this.lastInspection = -45;
    this.visited = new Map();
    this.time = 0;
    this.ambushUsed = 0;
    this.carGuarded = false;
    this.nextScare = 40 + rng() * 40;
  }

  // A chase or close call just ended. Give the player room to breathe.
  contact(seconds = 32) {
    this.relax = Math.max(this.relax, seconds + this.rng() * 16);
    this.sinceContact = 0;
    this.idleFor = 0;
    this.pressured = false;
    this.pressureNudge = false;
    this.pressureRefreshAt = this.time + 12;
  }

  update(dt, player) {
    this.time += dt;
    this.relax = Math.max(0, this.relax - dt);
    this.sinceContact += dt;
    if (!player) return;
    if (this.lastPlayer) {
      const moved = dist(player, this.lastPlayer);
      // By speed, so a fast screen (120 frames a second) does not read a walk as standing still.
      if (this.relax > 0 || player.hidden || moved > dt * 0.5) this.idleFor = 0;
      else this.idleFor += dt;
    }
    this.lastPlayer = { x: player.x, z: player.z };
    const pressured = this.relax <= 0 && !player.hidden && (this.idleFor > this.tune.idlePressure || this.sinceContact > this.tune.pressure);
    if (pressured && !this.pressured) this.pressureNudge = true;
    // A moving counselor can leave an old patrol destination behind. Refresh
    // only an active patrol, at a modest cadence, using a broad region below.
    if (pressured && this.sinceContact > this.tune.pressure + 25 && this.time >= this.pressureRefreshAt) {
      this.pressureNudge = true;
      this.pressureRefreshAt = this.time + 12;
    }
    if (!pressured) this.pressureNudge = false;
    this.pressured = pressured;
  }

  // Next place for him to walk to.
  nextWaypoint(killer, player, act) {
    const idle = this.relax <= 0 && !player.hidden && this.idleFor > this.tune.idlePressure;
    const pressure = this.relax <= 0 && !player.hidden && (idle || this.sinceContact > this.tune.pressure);
    const prolonged = pressure && this.sinceContact > this.tune.pressure + 25;
    // Route into the general area, never onto a moving/hidden player. Prolonged
    // pressure uses a sixteen-metre region; stealth still has to beat his senses.
    const region = player.hidden ? killer : prolonged
      ? { x: Math.round(player.x / 16) * 16, z: Math.round(player.z / 16) * 16 }
      : player;
    // Closed cabins need real visits, not an outdoor orbit forever. These are
    // fixed map destinations, selected without knowing who is inside a hide.
    if (prolonged && idle && this.time - this.lastInspection >= 45) {
      const nearby = BUILDINGS.filter((b) => dist(b, region) < 44);
      const inspectionScore = (b) => {
        const age = this.time - (this.visited.get('inspect-' + b.id) ?? -999);
        return dist(b, region) + Math.max(0, 100 - age) * 0.35;
      };
      // A coarse region can straddle two buildings. Do not orbit the slightly
      // nearer one forever while its neighbour's door is never tried.
      nearby.sort((a, b) => inspectionScore(a) - inspectionScore(b));
      if (nearby.length) {
        const b = nearby[0];
        const w = { id: 'inspect-' + b.id, x: b.x, z: b.z };
        this.lastInspection = this.time;
        // Let him finish the physical walk through the door before refreshing.
        this.pressureRefreshAt = this.time + Math.min(60, dist(killer, b) / this.tune.walk + 12);
        this.visited.set(w.id, this.time);
        this.pressureNudge = false;
        return w;
      }
    }
    const ideal = this.relax > 0 ? 90 : prolonged ? 12 : idle ? 14 : pressure ? 26 : 60 - act * 8;
    let best = null, bestScore = -Infinity;
    for (const w of WAYPOINTS) {
      const d = dist(w, region);
      const k = dist(w, killer);
      if (k < 8) continue;
      const age = this.time - (this.visited.get(w.id) ?? -999);
      let score = -Math.abs(d - ideal) * 1.35 + this.rng() * (pressure ? 7 : 12) + Math.min(age, 120) * 0.1;
      if (this.relax > 0 && d < 40) score -= 60;
      if (score > bestScore) {
        bestScore = score;
        best = w;
      }
    }
    this.visited.set(best.id, this.time);
    this.pressureNudge = false;
    return best;
  }

  // Now and then he stands among the scarecrows and waits, when the player is heading that way.
  wantsAmbush(killer, player) {
    if (this.ambushUsed >= 2 || this.relax > 0 || player.hidden || this.sinceContact > this.tune.pressure + 25) return null;
    const near = AMBUSH_SPOTS[0];
    const dp = dist(near, player);
    const dk = dist(near, killer);
    if (dp > 30 && dp < 75 && dk < 70 && this.rng() < 0.3) {
      this.ambushUsed++;
      return AMBUSH_SPOTS[Math.floor(this.rng() * AMBUSH_SPOTS.length)];
    }
    return null;
  }

  // Once, when you finally have both items, he goes and stands by your car.
  wantsCarGuard(act) {
    if (act < 2 || this.carGuarded) return null;
    this.carGuarded = true;
    return { x: CAR.x - 6, z: CAR.z + 7 };
  }
}
