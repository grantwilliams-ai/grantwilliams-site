// 2D physics on the ground plane: circles (trees), wall segments, rotated boxes (furniture, props,
// the car), doors. Everything a person can bump into, and every sightline test.
import { BUILDINGS, TEMPLATES, CAR, LAYOUT, PROPS, PROP_SHAPES } from './layout.js';

const CELL = 4;
const ORIGIN = -188;
const N = 94;
// The renderer swings each hinge toward its room, in the building's local frame.
const DOOR_SWING = new Map(BUILDINGS.flatMap(b => (TEMPLATES[b.template].doors || []).map((d, i) =>
  [`${b.id}.d${i}`, d.wall === 'front' || d.wall === 'left' ? 1 : -1])));

// +1 or -1: which way this door's leaf turns about its hinge as it opens (always into its room).
export function doorSwing(d) {
  return DOOR_SWING.get(d.id) ?? 1;
}

export function doorAmount(d) {
  return d.motion?.amount ?? (d.open ? 1 : 0);
}

export function doorSegment(d, amount = doorAmount(d)) {
  const angle = (DOOR_SWING.get(d.id) ?? 1) * 1.75 * amount;
  const c = Math.cos(angle), s = Math.sin(angle), dx = d.ex - d.hx, dz = d.ez - d.hz;
  return { kind: 's', x1: d.hx, z1: d.hz, x2: d.hx + dx * c + dz * s, z2: d.hz - dx * s + dz * c, t: .08 };
}

// Stop at first circle contact, then keep only the tangential part of the step.
// Existing overlap may be escaped; it is never repaired by teleporting a body.
function slideActor(ax, az, bx, bz, other, radius) {
  const mx = ax - other.x, mz = az - other.z, dx = bx - ax, dz = bz - az;
  const length2 = dx * dx + dz * dz, start2 = mx * mx + mz * mz;
  if (length2 < 1e-16) return [ax, az];
  const dot = mx * dx + mz * dz;
  if (start2 < radius * radius - 1e-8) return dot >= -1e-10 && Math.hypot(bx - other.x, bz - other.z) > Math.sqrt(start2) ? [bx, bz] : [ax, az];
  const disc = dot * dot - length2 * (start2 - radius * radius);
  if (dot >= 0 || disc < 0) return [bx, bz];
  const hit = Math.max(0, (-dot - Math.sqrt(disc)) / length2);
  if (hit > 1) return [bx, bz];
  const cx = ax + dx * hit, cz = az + dz * hit;
  const nx = (cx - other.x) / radius, nz = (cz - other.z) / radius;
  const inward = Math.min(0, (dx * nx + dz * nz) * (1 - hit));
  return [bx - nx * inward, bz - nz * inward];
}

function cellIndex(x, z) {
  const ix = Math.min(N - 1, Math.max(0, Math.floor((x - ORIGIN) / CELL)));
  const iz = Math.min(N - 1, Math.max(0, Math.floor((z - ORIGIN) / CELL)));
  return iz * N + ix;
}

function segCross(ax, az, bx, bz, cx, cz, dx, dz) {
  const d1x = bx - ax, d1z = bz - az, d2x = dx - cx, d2z = dz - cz;
  const den = d1x * d2z - d1z * d2x;
  if (Math.abs(den) < 1e-9) return false;
  const t = ((cx - ax) * d2z - (cz - az) * d2x) / den;
  const u = ((cx - ax) * d1z - (cz - az) * d1x) / den;
  return t >= 0 && t <= 1 && u >= 0 && u <= 1;
}

export class Collision {
  constructor(forest, opts = {}) {
    this.grid = new Array(N * N);
    this.stamp = 0;
    this.obstacles = [];
    this.doors = LAYOUT.doors;
    this.walls = LAYOUT.walls;
    this.solids = LAYOUT.solids; // furniture boxes, read by the killer's render-only fork clearance
    this.addedCar = !opts.noCar;

    for (const t of forest.trees) if (t.solid) this._add({ kind: 'c', x: t.x, z: t.z, r: t.r });
    for (const r of forest.rocks) this._add({ kind: 'c', x: r.x, z: r.z, r: r.r });
    for (const w of LAYOUT.walls) this._add({ kind: 's', x1: w.x1, z1: w.z1, x2: w.x2, z2: w.z2, t: 0.1 });
    for (const d of LAYOUT.doors) this._add({ kind: 's', x1: d.hx, z1: d.hz, x2: d.ex, z2: d.ez, t: 0.08, door: d });
    for (const s of LAYOUT.solids) this._addBox(s.x, s.z, s.hx, s.hz, s.rot);
    for (const p of PROPS) {
      const sh = PROP_SHAPES[p.type];
      if (!sh) continue;
      if (sh.circle) this._add({ kind: 'c', x: p.x, z: p.z, r: sh.circle });
      else if (sh.box) this._addBox(p.x, p.z, sh.box[0], sh.box[1], p.rot || 0);
      else if (sh.fence) this._addBox(p.x, p.z, p.length / 2, 0.12, p.rot || 0);
    }
    this._addBox(CAR.x, CAR.z, CAR.hx, CAR.hz, CAR.rot);

    // Foliage opacity, for sightlines: how much a 2 m cell of woods hides.
    this.fogN = 180;
    this.foliage = new Float32Array(this.fogN * this.fogN);
    const addF = (x, z, v) => {
      const i = Math.floor((x + 180) / 2), j = Math.floor((z + 180) / 2);
      if (i >= 0 && j >= 0 && i < this.fogN && j < this.fogN) this.foliage[j * this.fogN + i] += v;
    };
    for (const t of forest.trees) addF(t.x, t.z, 0.5);
    for (const b of forest.bushes) addF(b.x, b.z, 0.3);
  }

  _add(o) {
    o.stamp = 0;
    this.obstacles.push(o);
    let minX, maxX, minZ, maxZ;
    if (o.kind === 'c') {
      minX = o.x - o.r; maxX = o.x + o.r; minZ = o.z - o.r; maxZ = o.z + o.r;
    } else if (o.door) {
      // Register the complete swing envelope once; the narrow phase uses its live pose.
      minX = o.door.hx - o.door.width - o.t; maxX = o.door.hx + o.door.width + o.t;
      minZ = o.door.hz - o.door.width - o.t; maxZ = o.door.hz + o.door.width + o.t;
    } else if (o.kind === 's') {
      minX = Math.min(o.x1, o.x2) - o.t; maxX = Math.max(o.x1, o.x2) + o.t;
      minZ = Math.min(o.z1, o.z2) - o.t; maxZ = Math.max(o.z1, o.z2) + o.t;
    } else {
      const R = Math.hypot(o.hx, o.hz);
      minX = o.x - R; maxX = o.x + R; minZ = o.z - R; maxZ = o.z + R;
    }
    const pad = 1; // the largest body radius we ever query with
    for (let z = Math.floor((minZ - pad - ORIGIN) / CELL); z <= Math.floor((maxZ + pad - ORIGIN) / CELL); z++) {
      for (let x = Math.floor((minX - pad - ORIGIN) / CELL); x <= Math.floor((maxX + pad - ORIGIN) / CELL); x++) {
        if (x < 0 || z < 0 || x >= N || z >= N) continue;
        const k = z * N + x;
        (this.grid[k] || (this.grid[k] = [])).push(o);
      }
    }
  }

  _addBox(x, z, hx, hz, rot) {
    this._add({ kind: 'b', x, z, hx, hz, c: Math.cos(rot), s: Math.sin(rot) });
  }

  // Push one obstacle's overlap out of a circle. Returns [dx,dz] or null.
  _push(o, x, z, r, ignoreDoors) {
    if (o.kind === 'c') {
      const dx = x - o.x, dz = z - o.z, min = o.r + r;
      const d2 = dx * dx + dz * dz;
      if (d2 >= min * min) return null;
      if (d2 < 1e-12) return [min, 0];
      const d = Math.sqrt(d2);
      return [(dx / d) * (min - d), (dz / d) * (min - d)];
    }
    if (o.kind === 's') {
      if (o.door) {
        if (ignoreDoors === true) return null;
        o = doorSegment(o.door, ignoreDoors === 'open' ? 1 : doorAmount(o.door));
      }
      const ex = o.x2 - o.x1, ez = o.z2 - o.z1;
      const length2 = ex * ex + ez * ez;
      const k = length2 > 0 ? Math.max(0, Math.min(1, ((x - o.x1) * ex + (z - o.z1) * ez) / length2)) : 0;
      const dx = x - (o.x1 + ex * k), dz = z - (o.z1 + ez * k);
      const min = o.t + r, d2 = dx * dx + dz * dz;
      if (d2 >= min * min) return null;
      if (d2 < 1e-12) {
        const length = Math.sqrt(length2);
        return length > 0 ? [-ez / length * min, ex / length * min] : [min, 0];
      }
      const d = Math.sqrt(d2);
      return [(dx / d) * (min - d), (dz / d) * (min - d)];
    }
    // Box: work in its local frame (the same convention as localToWorld).
    const wx = x - o.x, wz = z - o.z;
    const lx = wx * o.c - wz * o.s, lz = wx * o.s + wz * o.c;
    const cx = Math.max(-o.hx, Math.min(o.hx, lx)), cz = Math.max(-o.hz, Math.min(o.hz, lz));
    let dx = lx - cx, dz = lz - cz;
    let d2 = dx * dx + dz * dz;
    if (d2 >= r * r) return null;
    let px, pz;
    if (d2 < 1e-9) {
      // Centre is inside the box: leave by the nearest side.
      const ox = o.hx - Math.abs(lx), oz = o.hz - Math.abs(lz);
      if (ox < oz) { px = Math.sign(lx || 1) * (ox + r); pz = 0; } else { px = 0; pz = Math.sign(lz || 1) * (oz + r); }
    } else {
      const d = Math.sqrt(d2);
      px = (dx / d) * (r - d);
      pz = (dz / d) * (r - d);
    }
    return [px * o.c + pz * o.s, -px * o.s + pz * o.c];
  }

  // Moves a circle out of everything it overlaps. Returns the corrected position.
  resolve(x, z, r, ignoreDoors = false) {
    for (let pass = 0; pass < 4; pass++) {
      const list = this.grid[cellIndex(x, z)];
      if (!list) break;
      let moved = false;
      for (let i = 0; i < list.length; i++) {
        const p = this._push(list[i], x, z, r, ignoreDoors);
        if (p) {
          x += p[0];
          z += p[1];
          moved = true;
        }
      }
      if (!moved) break;
    }
    return [x, z];
  }

  // Sweep in substeps narrower than a body radius before resolving contacts.
  // Endpoint-only resolution can place a long lunge on the opposite side of a
  // thin wall. This also retains sliding along walls and around door jambs.
  move(ax, az, bx, bz, r, ignoreDoors = false) {
    const dx = bx - ax, dz = bz - az;
    const steps = Math.max(1, Math.ceil(Math.hypot(dx, dz) / Math.max(.04, r * .5)));
    let x = ax, z = az;
    for (let i = 0; i < steps; i++) [x, z] = this.resolve(x + dx / steps, z + dz / steps, r, ignoreDoors);
    return [x, z];
  }

  // A scenery-checked sweep against a second actor. Reject an impossible corner
  // correction instead of pushing either person through a wall or through the other.
  moveWithActor(ax, az, bx, bz, r, other, otherRadius) {
    if (!other) return this.move(ax, az, bx, bz, r);
    const dx = bx - ax, dz = bz - az, separation = r + otherRadius;
    const steps = Math.max(1, Math.ceil(Math.hypot(dx, dz) / Math.max(.04, r * .5)));
    let x = ax, z = az;
    for (let i = 0; i < steps; i++) {
      let [nx, nz] = this.move(x, z, x + dx / steps, z + dz / steps, r);
      [nx, nz] = slideActor(x, z, nx, nz, other, separation);
      [nx, nz] = this.move(x, z, nx, nz, r);
      const before = Math.hypot(x - other.x, z - other.z), after = Math.hypot(nx - other.x, nz - other.z);
      const clearActor = after >= separation - 1e-7 || (before < separation && after > before + 1e-8);
      if (clearActor && !this.blocked(nx, nz, r - 1e-7)) { x = nx; z = nz; }
    }
    return [x, z];
  }

  doorAmount(d) { return doorAmount(d); }

  // Door animation is physical, not a second visual-only clock. Closing waits
  // for an occupant. Opening may make a small, validated push into the room so
  // walking out does not pin an inward-swinging door against the counselor.
  updateDoors(dt, bodies = []) {
    for (const d of this.doors) {
      const m = d.motion;
      if (!m) continue;
      const delta = Math.sign(m.target - m.amount) * Math.min(Math.abs(m.target - m.amount), Math.max(0, dt) * m.speed);
      const count = Math.max(1, Math.ceil(Math.abs(delta) * d.width * 1.75 / .025));
      for (let i = 0; i < count; i++) {
        const next = m.amount + delta / count, leaf = doorSegment(d, next);
        const moves = [];
        let blocked = false;
        for (const entry of bodies) {
          const { body, radius } = entry, push = this._push(leaf, body.x, body.z, radius, false);
          if (!push) continue;
          if (m.target !== 1) { blocked = true; break; }
          const length = Math.hypot(...push), nx = push[0] / length, nz = push[1] / length;
          const dir = DOOR_SWING.get(d.id) ?? 1;
          const ix = dir * (d.ez - d.hz) / d.width, iz = -dir * (d.ex - d.hx) / d.width;
          const alignment = ix * nx + iz * nz, candidates = [];
          // Prefer backing into the room over sliding the occupant into the hinge jamb.
          if (alignment > .5) candidates.push([ix * (length + 1e-6) / alignment, iz * (length + 1e-6) / alignment]);
          candidates.push([push[0] + nx * 1e-6, push[1] + nz * 1e-6]);
          const other = bodies.find(b => b !== entry);
          const maxPush = Math.abs(delta / count) * d.width * 1.75 * 2 + 1e-5;
          let accepted = null;
          for (const [px, pz] of candidates) {
            if (Math.hypot(px, pz) > maxPush) continue;
            const [x, z] = this.moveWithActor(body.x, body.z, body.x + px, body.z + pz, radius, other?.body, other?.radius);
            if (Math.hypot(x - body.x - px, z - body.z - pz) > 1e-5 || this._push(leaf, x, z, radius, false)) continue;
            accepted = { body, x, z }; break;
          }
          if (!accepted) { blocked = true; break; }
          moves.push(accepted);
        }
        if (blocked) break;
        // Both proposals were checked against the old positions. Validate the
        // combined result too before committing either push or the panel angle.
        for (let a = 0; a < bodies.length; a++) for (let b = a + 1; b < bodies.length; b++) {
          const first = bodies[a], second = bodies[b];
          const pa = moves.find(m => m.body === first.body) || first.body, pb = moves.find(m => m.body === second.body) || second.body;
          const before = Math.hypot(first.body.x - second.body.x, first.body.z - second.body.z);
          if (Math.hypot(pa.x - pb.x, pa.z - pb.z) < Math.min(before, first.radius + second.radius) - 1e-7) blocked = true;
        }
        if (blocked) break;
        for (const { body, x, z } of moves) { body.x = x; body.z = z; }
        m.amount = next;
      }
      if (Math.abs(m.amount - m.target) < 1e-9) d.motion = null;
    }
  }

  // True if a circle here overlaps anything.
  blocked(x, z, r, ignoreDoors = false) {
    const list = this.grid[cellIndex(x, z)];
    if (!list) return false;
    for (let i = 0; i < list.length; i++) if (this._push(list[i], x, z, r, ignoreDoors)) return true;
    return false;
  }

  // The tree trunk at this point, if that is what is there.
  trunkAt(x, z, r) {
    const list = this.grid[cellIndex(x, z)];
    if (!list) return null;
    for (let i = 0; i < list.length; i++) if (list[i].kind === 'c' && this._push(list[i], x, z, r)) return list[i];
    return null;
  }

  // Walls and the actual door leaf stop sight and attacks, including while swinging.
  wallBetween(ax, az, bx, bz) {
    const w = this.walls;
    for (let i = 0; i < w.length; i++) if (segCross(ax, az, bx, bz, w[i].x1, w[i].z1, w[i].x2, w[i].z2)) return true;
    const d = this.doors;
    for (let i = 0; i < d.length; i++) {
      const leaf = doorSegment(d[i]);
      if (segCross(ax, az, bx, bz, leaf.x1, leaf.z1, leaf.x2, leaf.z2)) return true;
    }
    return false;
  }

  // 0 = clear sight, 1 or more = hidden. Woods add up along the ray.
  sightOpacity(ax, az, bx, bz) {
    if (this.wallBetween(ax, az, bx, bz)) return 2;
    const dist = Math.hypot(bx - ax, bz - az);
    const steps = Math.ceil(dist / 2);
    let sum = 0;
    for (let s = 1; s < steps; s++) {
      const t = s / steps;
      const i = Math.floor((ax + (bx - ax) * t + 180) / 2), j = Math.floor((az + (bz - az) * t + 180) / 2);
      if (i >= 0 && j >= 0 && i < this.fogN && j < this.fogN) sum += this.foliage[j * this.fogN + i];
    }
    return sum;
  }
}
