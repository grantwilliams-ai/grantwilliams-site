// Ground height. Pure and deterministic: the mesh and the physics read the same grid.
import { fbm } from '../core/rng.js';
import { BUILDINGS, CLEARINGS, DECKS, LAKE, TEMPLATES, TRAILS, WATER_LEVEL, WORLD_HALF, worldToLocal } from './layout.js';

export const GRID_STEP = 2; // metres between height samples
export const GRID_HALF = 180; // the mesh runs past the playable edge so the world has no visible end
export const GRID_N = Math.round((GRID_HALF * 2) / GRID_STEP) + 1;

const smooth = (a, b, x) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};

// Below 1 inside the lake, above 1 outside it.
export function lakeField(x, z) {
  let d = Infinity;
  for (const e of LAKE) {
    const nx = (x - e.x) / e.rx, nz = (z - e.z) / e.rz;
    d = Math.min(d, Math.sqrt(nx * nx + nz * nz));
  }
  // A wobble so the shore is not a clean ellipse.
  return d + (fbm(x * 0.03, z * 0.03, 5, 2) - 0.5) * 0.16;
}

function rawHeight(x, z) {
  let h = 1.6 + (fbm(x * 0.011, z * 0.011, 11, 4) - 0.5) * 9 + (fbm(x * 0.05, z * 0.05, 23, 3) - 0.5) * 1.5;
  h = 0.5 + Math.sqrt((h - 0.5) * (h - 0.5) + 0.8) * 0.5 + (h - 0.5) * 0.5; // soft floor: dry land never dips below about 0.9
  const edge = Math.max(Math.abs(x), Math.abs(z)) / WORLD_HALF;
  h += smooth(0.72, 1.15, edge) * 7; // the camp sits in a shallow bowl
  const lk = lakeField(x, z);
  h = h + (-5.5 - h) * smooth(1.22, 0.8, lk);
  // Pull the land down gently toward the shore so it meets the water.
  h = Math.min(h, WATER_LEVEL + 0.1 + Math.max(0, (lk - 1.0)) * 26);
  return h;
}

// Levelled pads: buildings need flat ground, clearings get gentle ground.
const PADS = [];
for (const b of BUILDINGS) {
  const t = TEMPLATES[b.template];
  if (t.floorAbs !== undefined) continue; // boathouse stands on stilts
  PADS.push({ x: b.x, z: b.z, r: Math.max(t.hx, t.hz) + 2.5, blend: 5, y: rawHeight(b.x, b.z) });
}
for (const c of CLEARINGS) {
  if (c.id === 'boathouse' || c.id === 'cabins') continue;
  PADS.push({ x: c.x, z: c.z, r: c.r * 0.6, blend: c.r * 0.7, y: rawHeight(c.x, c.z) });
}

function padded(x, z) {
  let h = rawHeight(x, z);
  for (const p of PADS) {
    const d = Math.hypot(x - p.x, z - p.z);
    if (d < p.r + p.blend) h += (p.y - h) * (1 - smooth(p.r, p.r + p.blend, d));
  }
  return h;
}

const heights = new Float32Array(GRID_N * GRID_N);
for (let j = 0; j < GRID_N; j++) {
  for (let i = 0; i < GRID_N; i++) heights[j * GRID_N + i] = padded(-GRID_HALF + i * GRID_STEP, -GRID_HALF + j * GRID_STEP);
}

export const heightGrid = heights;

// Terrain height, bilinear between grid samples.
export function heightAt(x, z) {
  const fx = Math.min(GRID_N - 1.001, Math.max(0, (x + GRID_HALF) / GRID_STEP));
  const fz = Math.min(GRID_N - 1.001, Math.max(0, (z + GRID_HALF) / GRID_STEP));
  const ix = Math.floor(fx), iz = Math.floor(fz);
  const tx = fx - ix, tz = fz - iz;
  const a = heights[iz * GRID_N + ix], b = heights[iz * GRID_N + ix + 1];
  const c = heights[(iz + 1) * GRID_N + ix], d = heights[(iz + 1) * GRID_N + ix + 1];
  return a + (b - a) * tx + (c - a) * tz + (a - b - c + d) * tx * tz;
}

// Floors: each building's floor rectangle at its height, with a soft ramp just outside it.
const FLOORS = BUILDINGS.map((b) => {
  const t = TEMPLATES[b.template];
  const base = t.floorAbs !== undefined ? t.floorAbs : heightAt(b.x, b.z) + (t.floorY || 0);
  return { b, t, y: base, ground: t.floorAbs !== undefined ? null : heightAt(b.x, b.z) };
});

// The height a person stands at: floors and decks win over terrain.
export function surfaceY(x, z) {
  const ground = heightAt(x, z);
  for (const d of DECKS) {
    if (x >= d.minX && x <= d.maxX && z >= d.minZ && z <= d.maxZ) return Math.max(ground, d.y);
  }
  for (const f of FLOORS) {
    if (Math.abs(x - f.b.x) > 14 || Math.abs(z - f.b.z) > 14) continue;
    const [lx, lz] = worldToLocal(f.b, x, z);
    const hz = f.t.hz + (f.t.porch || 0);
    const ox = Math.max(0, Math.abs(lx) - f.t.hx);
    const oz = lz > 0 ? Math.max(0, lz - hz) : Math.max(0, -lz - f.t.hz);
    const out = Math.hypot(ox, oz);
    if (out <= 0) return f.y;
    const ramp = f.ground === null ? 2.2 : 1.1; // boathouse has a longer gangway
    if (out < ramp) return ground + (f.y - ground) * (1 - smooth(0, ramp, out));
  }
  return ground;
}

// Metres of water above the ground here (0 when dry). Decks stay dry.
export function waterDepth(x, z) {
  const s = surfaceY(x, z);
  return Math.max(0, WATER_LEVEL - s);
}

// Distance from a point to the nearest trail centre line, and that trail.
export function nearestTrail(x, z) {
  let best = Infinity, trail = null;
  for (const t of TRAILS) {
    for (let i = 0; i + 1 < t.pts.length; i++) {
      const [ax, az] = t.pts[i], [bx, bz] = t.pts[i + 1];
      const dx = bx - ax, dz = bz - az;
      const k = Math.max(0, Math.min(1, ((x - ax) * dx + (z - az) * dz) / (dx * dx + dz * dz)));
      const d = Math.hypot(x - (ax + k * dx), z - (az + k * dz));
      if (d < best) {
        best = d;
        trail = t;
      }
    }
  }
  return { dist: best, trail };
}
