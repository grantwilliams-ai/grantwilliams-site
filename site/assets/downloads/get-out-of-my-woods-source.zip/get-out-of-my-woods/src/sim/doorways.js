// Getting a person through a doorway without a fight.
//
// A cabin door is 1.1 m wide and a body is 0.6 m across, with wall ends 0.1 m thick on either side:
// the centre of the body has to pass within about 12 cm of the middle of the opening. On a thumbstick
// that is a needle to thread, and a near miss used to stop the walker dead against the frame. These
// helpers bend the walker's own direction toward the opening, only while they are heading through it:
// close to the wall, walking fairly squarely at it, on a line that passes through the opening or just
// clips its frame. Someone walking past a door, along its wall, or across the room is left alone.
// Nothing here moves anybody: the result is a direction, and collision still has the last word.
import { doorAmount, doorSwing } from './collision.js';

const REACH = 1.6; // how far from the door's plane the help begins
const MARGIN = 0.35; // how far beyond the frame her line may strike the wall and still count as "at the door"
const SQUARE = 0.45; // least share of her heading that must point at the wall (about 63 degrees off square)
const WALL = 0.1; // half-thickness of a wall end (see Collision: walls use t = 0.1)

// Unit vectors of a door: u runs hinge to latch, n is the normal on the side the leaf swings to (the room).
export function doorFrame(d) {
  if (d.frame) return d.frame;
  const ux = (d.ex - d.hx) / d.width, uz = (d.ez - d.hz) / d.width;
  // The leaf swings by +angle * swing about the hinge (collision.doorSegment): its tip moves along (uz, -ux) * swing.
  const s = doorSwing(d);
  d.frame = { ux, uz, nx: uz * s, nz: -ux * s };
  return d.frame;
}

// (dx, dz): the unit direction the walker wants. Returns the direction to actually take.
// committed: a door she has just pushed open by walking into it. Until she is through, it keeps
// helping even if stepping back for its swing has knocked her off her original line.
export function doorwaySteer(doors, x, z, dx, dz, radius, committed = null) {
  let best = null, bestAlong = Infinity;
  for (const d of doors) {
    if (Math.abs(d.x - x) > 4 || Math.abs(d.z - z) > 4) continue;
    const f = doorFrame(d);
    const rx = x - d.x, rz = z - d.z;
    const along = rx * f.nx + rz * f.nz, lat = rx * f.ux + rz * f.uz;
    // On the room side the help reaches past the end of an open leaf: someone leaving who has just
    // stepped back for the door must be taken round its edge, not handed back to walk into it.
    // (Only her line through the opening brings any of this into play; see below.)
    if (Math.abs(along) > (along > 0 ? Math.max(REACH, d.width + radius + 0.9) : REACH)) continue;
    const toward = -(dx * f.nx + dz * f.nz) * Math.sign(along || 1); // > 0: closing on the door's plane
    if (d === committed) {
      if (toward < 0.25) continue;
    } else {
      if (toward < SQUARE) continue;
      // Where her line meets the wall. Beside the door, not through it: she is going somewhere else.
      const strike = lat + (dx * f.ux + dz * f.uz) * (Math.abs(along) / toward);
      if (Math.abs(strike) > d.width / 2 + MARGIN) continue;
    }
    if (Math.abs(along) < bestAlong) { bestAlong = Math.abs(along); best = { d, f, along, lat, toward }; }
  }
  if (!best) return [dx, dz];
  const { d, f, along, lat, toward } = best;
  const amount = doorAmount(d);
  // An open leaf stands in the room beside the opening. Someone leaving from behind it has to round
  // its free end first; aim them there instead of into the back of the door.
  if (along > 0 && amount > 0.5) {
    const tipLat = -d.width / 2 + Math.cos(1.75 * amount) * d.width, tipAlong = Math.sin(1.75 * amount) * d.width;
    // Behind the leaf, or level with its end and not yet past it: head for a point clear of the end,
    // on the opening's side. Sideways progress only ever grows here, so the two rules cannot trade her back and forth.
    if (lat < tipLat + 0.05 && along < tipAlong + radius + 0.45) {
      const wl = tipLat + 0.35, wa = tipAlong + radius + 0.5;
      const ex = (wl - lat) * f.ux + (wa - along) * f.nx, ez = (wl - lat) * f.uz + (wa - along) * f.nz;
      const el = Math.hypot(ex, ez) || 1;
      return unit(dx * 0.25 + ex / el, dz * 0.25 + ez / el, dx, dz);
    }
  }
  // Farther out than that, only a door she has already pushed open still has her.
  if (Math.abs(along) > REACH && d !== committed) return [dx, dz];
  // The lane a body fits through. Inside it, nothing to do.
  const free = Math.max(0.04, d.width / 2 - radius - WALL - 0.04);
  const error = lat - Math.max(-free, Math.min(free, lat));
  if (error === 0) return [dx, dz];
  // Sideways travel needed per unit of forward travel to be in the lane on reaching the wall.
  const need = Math.abs(error) / Math.max(Math.abs(along) - radius, 0.08);
  const side = Math.min(2.4, need * 1.3) * Math.min(1, toward * 1.6);
  const sx = -Math.sign(error) * side;
  return unit(dx + f.ux * sx, dz + f.uz * sx, dx, dz);
}

function unit(x, z, fx, fz) {
  const l = Math.hypot(x, z);
  return l > 1e-6 ? [x / l, z / l] : [fx, fz];
}

// A shut door that is opening toward someone standing in its sweep. Returns the unit direction that
// takes them out of the leaf's way fastest (straight away from the hinge), or null when they are clear.
// It is the half-step back a person takes when they pull a door open; the swing lasts about 0.3 s.
// limit: the longest one swing may hold anyone back, in seconds. A door that cannot finish opening
// (she is cornered, or something else is in its way) must never keep her from walking.
export function doorStepBack(doors, x, z, radius, dt = 0, limit = Infinity) {
  for (const d of doors) {
    const m = d.motion;
    if (!m || m.target !== 1 || m.amount > 0.9 || (m.heldBack || 0) >= limit) continue;
    const f = doorFrame(d);
    const hx = x - d.hx, hz = z - d.hz, reach = Math.hypot(hx, hz);
    if (reach > d.width + radius + 0.08 || reach < 1e-6) continue;
    const along = hx * f.nx + hz * f.nz;
    if (along < -0.05) continue; // on the other side of the wall
    // Already behind where the leaf comes to rest, or the leaf has gone past: nothing to wait for.
    const angle = Math.atan2(along, hx * f.ux + hz * f.uz), leaf = 1.75 * m.amount;
    const half = Math.asin(Math.min(1, (radius + 0.1) / reach));
    if (angle > 1.75 + half || angle < leaf - half) continue;
    m.heldBack = (m.heldBack || 0) + dt;
    return [hx / reach, hz / reach];
  }
  return null;
}

// A door that is closing with someone in its way: the unit direction that takes them clear, or null.
// On or just outside the threshold they step out; in the room they step in and away from the hinge.
// Without this the door waits on them and never shuts. limit: the longest one swing may move anyone.
export function doorStepClear(doors, x, z, radius, dt = 0, limit = Infinity) {
  for (const d of doors) {
    const m = d.motion;
    if (!m || m.target !== 0 || m.amount < 0.02 || (m.heldClear || 0) >= limit) continue;
    const f = doorFrame(d);
    const hx = x - d.hx, hz = z - d.hz, reach = Math.hypot(hx, hz);
    if (reach > d.width + radius + 0.08 || reach < 1e-6) continue;
    const along = hx * f.nx + hz * f.nz;
    if (along < -radius - 0.12) continue; // outside, clear of the shut leaf
    // Between the open leaf and its wall the leaf is moving away from them: nothing to do.
    const angle = Math.atan2(along, hx * f.ux + hz * f.uz), leaf = 1.75 * m.amount;
    const half = Math.asin(Math.min(1, (radius + 0.1) / reach));
    if (angle > leaf + half) continue;
    m.heldClear = (m.heldClear || 0) + dt;
    // On the threshold the closing leaf is already between her and the room: out is the only way.
    // (Wanting in from there is settled before the swing starts; see doorwayStand.)
    if (along < 0.12) return [-f.nx, -f.nz];
    return unit(hx / reach + f.nx, hz / reach + f.nz, f.nx, f.nz);
  }
  return null;
}

// Is she standing in this open door's doorway, where its leaf will come to rest? Returns 0 if not;
// otherwise which side she should end up on when it is closed: 1 in the room, -1 outside.
// The stick decides if it is pushed; else she is kept from whoever is hunting her; else she stays
// on the side of the wall line she is already on.
export function doorwayStand(d, x, z, radius, { dx = 0, dz = 0, avoid = null } = {}) {
  const f = doorFrame(d);
  const hx = x - d.hx, hz = z - d.hz, reach = Math.hypot(hx, hz);
  const along = hx * f.nx + hz * f.nz;
  if (reach > d.width + radius + 0.08 || along >= 0.12 || along < -radius - 0.12) return 0;
  const push = dx * f.nx + dz * f.nz;
  if (push > 0.3) return 1;
  if (push < -0.3) return -1;
  if (avoid && Math.hypot(avoid.x - d.x, avoid.z - d.z) < 9) return (avoid.x - d.x) * f.nx + (avoid.z - d.z) * f.nz < 0 ? 1 : -1;
  return along >= 0 ? 1 : -1;
}

// How far into the room she is from this door's wall line.
export function doorDepth(d, x, z) {
  const f = doorFrame(d);
  return (x - d.hx) * f.nx + (z - d.hz) * f.nz;
}

// Is she walking into this door: squarely enough, on a line through the opening? Brushing past a
// shut door, or sliding along it toward a corner, is not.
export function headedThrough(d, x, z, dx, dz, margin = MARGIN) {
  const f = doorFrame(d);
  const rx = x - d.x, rz = z - d.z;
  const along = rx * f.nx + rz * f.nz, lat = rx * f.ux + rz * f.uz;
  const toward = -(dx * f.nx + dz * f.nz) * Math.sign(along || 1);
  if (toward < SQUARE) return false;
  return Math.abs(lat + (dx * f.ux + dz * f.uz) * (Math.abs(along) / toward)) <= d.width / 2 + margin;
}
