// Where the keys and the battery are tonight, and what you find when they are not there.
import { LAYOUT } from './layout.js';
import { shuffle } from '../core/rng.js';

// Keys and battery always land far apart, so every run crosses the camp.
export function placeItems(rng) {
  const keys = shuffle(rng, LAYOUT.searches.filter((s) => s.can.includes('keys')));
  const batt = shuffle(rng, LAYOUT.searches.filter((s) => s.can.includes('battery')));
  for (const k of keys) {
    for (const b of batt) {
      if (k.id !== b.id && Math.hypot(k.wx - b.wx, k.wz - b.wz) > 55) return { keys: k.id, battery: b.id };
    }
  }
  return { keys: keys[0].id, battery: batt.find((b) => b.id !== keys[0].id).id };
}

const NOTHING = {
  'c1-locker': 'Tube socks. A carton of bug spray. A letter home, never sent.',
  'c2-duffel': 'A damp towel and a paperback with the last pages torn out.',
  'c3-desk': 'Staff schedule. Every name crossed out, in red, except yours.',
  'mess-lost': 'One flip-flop. A cracked Walkman. Eleven left socks.',
  'mess-kitchen': 'Forks. All the forks are gone. Only spoons.',
  'boat-tackle': 'Lures and a rusty fillet knife holder. The knife is missing.',
  'boat-motor': 'The battery cradle is empty. The cables were cut, not unplugged.',
  'shed-bench': 'Oily rags and a coffee can of bolts. One clean handprint on the bench, much too big.',
  'shed-toolbox': 'Wrenches, all there. Every one of them wiped clean.',
  'shack-bench': 'You do not want to know what this is. You put it back.',
  'range-box': 'Arrows, snapped in half. All of them. Carefully.',
  'dock-cooler': 'Warm soda and a bait bucket. Something has been eating the bait.',
};

export const nothingLine = (id) => NOTHING[id] || 'Nothing.';

export const FOUND_LINES = {
  keys: 'YOUR KEYS. The tag is sticky with something.',
  battery: 'A CAR BATTERY. Heavy. You can\'t run as far with this.',
};
