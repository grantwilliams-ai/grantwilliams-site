// Where every tree, bush and rock stands. Deterministic: physics and visuals both call
// generateForest() and get the same list. The same woods every night, so players can learn them.
import { fbm, makeRng, WORLD_SEED } from '../core/rng.js';
import { BUILDINGS, BUSH_HIDES, CLEARINGS, DECKS, PROPS, TEMPLATES, WORLD_HALF, LAYOUT, CAR } from './layout.js';
import { heightAt, lakeField, nearestTrail } from './terrain.js';

const VISUAL_HALF = 172; // trees carry on past the playable edge so there is never an end to the woods

function keepClear(x, z) {
  for (const c of CLEARINGS) if (Math.hypot(x - c.x, z - c.z) < c.r) return true;
  for (const b of BUILDINGS) {
    const t = TEMPLATES[b.template];
    if (Math.hypot(x - b.x, z - b.z) < Math.max(t.hx, t.hz) + 3) return true;
  }
  for (const p of PROPS) if (Math.hypot(x - p.x, z - p.z) < 3) return true;
  for (const h of BUSH_HIDES) if (Math.hypot(x - h.x, z - h.z) < 2.2) return true;
  for (const d of DECKS) if (x > d.minX - 3 && x < d.maxX + 3 && z > d.minZ - 3 && z < d.maxZ + 3) return true;
  for (const s of LAYOUT.searches) if (Math.hypot(x - s.wx, z - s.wz) < 2.5) return true;
  if (Math.hypot(x - CAR.x, z - CAR.z) < 7) return true;
  return false;
}

let cached = null;

// Returns { trees:[{x,z,y,r,kind,scale,rot,solid}], bushes:[{x,z,y,scale,rot}], rocks:[{x,z,y,r,scale,rot}] }
// kind: 'pine' | 'tallpine' | 'dead' | 'birch'. r is the trunk radius for collision. solid=false
// means past the playable edge, visual only.
export function generateForest() {
  if (cached) return cached;
  const rng = makeRng(WORLD_SEED + 1);
  const trees = [], bushes = [], rocks = [];
  const cell = 3.9;
  const n = Math.ceil((VISUAL_HALF * 2) / cell);
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const x = -VISUAL_HALF + (i + 0.5 + (rng() - 0.5) * 0.9) * cell;
      const z = -VISUAL_HALF + (j + 0.5 + (rng() - 0.5) * 0.9) * cell;
      const roll = rng();
      const patch = fbm(x * 0.022, z * 0.022, 7, 3);
      const edge = Math.max(Math.abs(x), Math.abs(z));
      const beyond = edge > WORLD_HALF - 4;
      const lk = lakeField(x, z);
      if (lk < 1.06) continue;
      const trail = nearestTrail(x, z);
      const margin = trail.trail ? trail.trail.width * 0.5 + (trail.trail.kind === 'overgrown' ? 0.6 : 1.5) : 0;
      if (trail.dist < margin) continue;
      if (keepClear(x, z)) continue;
      // Woods thin near the shore and in patches, and close into a wall at the far edge.
      const density = beyond ? 1 : 0.28 + patch * 0.95 - (lk < 1.3 ? 0.25 : 0);
      if (roll < density) {
        const kr = rng();
        const kind = kr < 0.62 ? 'pine' : kr < 0.84 ? 'tallpine' : kr < 0.93 ? 'birch' : 'dead';
        const scale = 0.8 + rng() * 0.75;
        trees.push({
          x, z, y: heightAt(x, z), kind, scale, rot: rng() * Math.PI * 2,
          r: (kind === 'birch' ? 0.17 : kind === 'dead' ? 0.2 : 0.3) * scale,
          solid: edge < WORLD_HALF + 6,
        });
      } else if (roll < density + 0.2 && !beyond) {
        bushes.push({ x, z, y: heightAt(x, z), scale: 0.7 + rng() * 0.9, rot: rng() * Math.PI * 2 });
      } else if (roll > 0.975 && !beyond) {
        rocks.push({ x, z, y: heightAt(x, z), r: 0.4 + rng() * 0.5, scale: 0.6 + rng() * 1.1, rot: rng() * Math.PI * 2 });
      }
    }
  }
  cached = { trees, bushes, rocks };
  return cached;
}
