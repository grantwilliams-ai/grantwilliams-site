// The killer's map of where a big man can walk: a half-metre grid, A*, and path smoothing.
// Half a metre so that no wall or fence, inflated by his body width, can slip between two grid points.
// Doors count as fully open here. He opens them on approach, then follows a route
// around the real open leaf instead of planning through where it will stand.
import { LAYOUT, WATER_LEVEL, DECKS } from './layout.js';
import { surfaceY } from './terrain.js';

const HALF = 134;
const CELL = 0.5;
const SIZE = (HALF * 2) / CELL;
const COUNT = SIZE * SIZE;
export const BODY = 0.36; // cells closer than this to anything are not walkable

const toCell = (v) => Math.max(0, Math.min(SIZE - 1, Math.floor((v + HALF) / CELL)));
const fromCell = (i) => (i + 0.5) * CELL - HALF;
const DIRS = [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, 1.414], [1, -1, 1.414], [-1, 1, 1.414], [-1, -1, 1.414]];

export class Nav {
  constructor(collision) {
    this.collision = collision;
    this.pass = new Uint8Array(COUNT);
    this.g = new Float32Array(COUNT);
    this.seen = new Uint32Array(COUNT);
    this.closed = new Uint32Array(COUNT);
    this.from = new Int32Array(COUNT);
    this.heap = new Int32Array(COUNT);
    this.heapF = new Float32Array(COUNT);
    this.searchId = 0;

    for (let z = 0; z < SIZE; z++) {
      for (let x = 0; x < SIZE; x++) {
        const wx = fromCell(x), wz = fromCell(z);
        const dry = surfaceY(wx, wz) > WATER_LEVEL - 0.45;
        this.pass[z * SIZE + x] = dry && !collision.blocked(wx, wz, BODY, 'open') ? 1 : 0;
      }
    }
    // Door gaps are narrower than the grid can see: cut each one through by hand, three cells wide
    // so that a door in a rotated building still leaves a path that does not rely on corners.
    for (const d of LAYOUT.doors) {
      const ux = (d.ex - d.hx) / d.width, uz = (d.ez - d.hz) / d.width;
      const nx = -uz, nz = ux;
      for (let t = -2.4; t <= 2.4; t += 0.2) {
        for (let u = -0.32; u <= 0.33; u += 0.16) {
          const wx = d.x + nx * t + ux * u, wz = d.z + nz * t + uz * u;
          if (!collision.blocked(wx, wz, 0.2, 'open')) this.pass[toCell(wz) * SIZE + toCell(wx)] = 1;
        }
      }
    }
    this._keepMainRegion();
  }

  // Little pockets between trees are cut off from everywhere. Keep only what connects to the fire
  // pit, so a search never floods the whole map looking for a way into one.
  _keepMainRegion() {
    const { pass } = this;
    const start = toCell(16) * SIZE + toCell(3);
    const keep = new Uint8Array(COUNT);
    const stack = new Int32Array(COUNT);
    let n = 0;
    stack[n++] = start;
    keep[start] = 1;
    while (n > 0) {
      const c = stack[--n];
      const x = c % SIZE, z = (c - x) / SIZE;
      for (let d = 0; d < 4; d++) {
        const nx = x + DIRS[d][0], nz = z + DIRS[d][1];
        if (nx < 0 || nz < 0 || nx >= SIZE || nz >= SIZE) continue;
        const i = nz * SIZE + nx;
        if (pass[i] && !keep[i]) {
          keep[i] = 1;
          stack[n++] = i;
        }
      }
    }
    this.pass = keep;
  }

  walkable(x, z) {
    return this.pass[toCell(z) * SIZE + toCell(x)] === 1;
  }

  // Nearest walkable cell centre, searching outward in rings.
  snap(x, z) {
    const cx = toCell(x), cz = toCell(z);
    if (this.pass[cz * SIZE + cx]) return [cx, cz];
    for (let r = 1; r < 28; r++) {
      for (let dz = -r; dz <= r; dz++) {
        for (let dx = -r; dx <= r; dx++) {
          if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
          const ix = cx + dx, iz = cz + dz;
          if (ix < 0 || iz < 0 || ix >= SIZE || iz >= SIZE) continue;
          if (this.pass[iz * SIZE + ix]) return [ix, iz];
        }
      }
    }
    return null;
  }

  _lineClear(ax, az, bx, bz) {
    const dist = Math.hypot(bx - ax, bz - az);
    const steps = Math.ceil(dist / 0.24);
    for (let s = 1; s < steps; s++) {
      const t = s / steps;
      if (!this.walkable(ax + (bx - ax) * t, az + (bz - az) * t)) return false;
    }
    return true;
  }

  // Returns a list of [x,z] points to walk, or null if there is no way.
  findPath(ax, az, bx, bz) {
    const start = this.snap(ax, az), goal = this.snap(bx, bz);
    if (!start || !goal) return null;
    const startI = start[1] * SIZE + start[0], goalI = goal[1] * SIZE + goal[0];
    if (startI === goalI) return [[bx, bz]];
    // The common case in a chase: nothing between you and him. No search needed.
    if (Math.hypot(bx - ax, bz - az) < 34 && this.walkable(ax, az) && this.walkable(bx, bz) && this._lineClear(ax, az, bx, bz)) return [[bx, bz]];
    const id = ++this.searchId;
    const { g, seen, closed, from, heap, heapF, pass } = this;
    let size = 0;
    const push = (i, f) => {
      let c = size++;
      while (c > 0) {
        const p = (c - 1) >> 1;
        if (heapF[p] <= f) break;
        heap[c] = heap[p];
        heapF[c] = heapF[p];
        c = p;
      }
      heap[c] = i;
      heapF[c] = f;
    };
    const pop = () => {
      const top = heap[0];
      const li = heap[--size], lf = heapF[size];
      let c = 0;
      for (;;) {
        let k = 2 * c + 1;
        if (k >= size) break;
        if (k + 1 < size && heapF[k + 1] < heapF[k]) k++;
        if (heapF[k] >= lf) break;
        heap[c] = heap[k];
        heapF[c] = heapF[k];
        c = k;
      }
      heap[c] = li;
      heapF[c] = lf;
      return top;
    };
    const gx = goal[0], gz = goal[1];
    const h = (x, z) => {
      const dx = Math.abs(x - gx), dz = Math.abs(z - gz);
      return dx + dz - 0.586 * Math.min(dx, dz);
    };
    g[startI] = 0;
    seen[startI] = id;
    from[startI] = -1;
    push(startI, h(start[0], start[1]));
    let found = false, guard = 0;
    while (size > 0 && guard++ < 300000) {
      const cur = pop();
      if (cur === goalI) {
        found = true;
        break;
      }
      if (closed[cur] === id) continue; // an older, longer entry for a cell already done
      closed[cur] = id;
      const cx = cur % SIZE, cz = (cur - cx) / SIZE;
      const cg = g[cur];
      for (let d = 0; d < 8; d++) {
        const nx = cx + DIRS[d][0], nz = cz + DIRS[d][1];
        if (nx < 0 || nz < 0 || nx >= SIZE || nz >= SIZE) continue;
        const ni = nz * SIZE + nx;
        if (!pass[ni] || closed[ni] === id) continue;
        // No cutting a corner through a blocked cell.
        if (DIRS[d][2] > 1 && (!pass[cz * SIZE + nx] || !pass[nz * SIZE + cx])) continue;
        const ng = cg + DIRS[d][2];
        if (seen[ni] === id && ng >= g[ni]) continue;
        seen[ni] = id;
        g[ni] = ng;
        from[ni] = cur;
        push(ni, ng + h(nx, nz) * 1.5); // weighted: slightly longer routes, far fewer cells searched
      }
    }
    if (!found) return null;

    const raw = [];
    for (let i = goalI; i !== -1; i = from[i]) {
      const x = i % SIZE, z = (i - x) / SIZE;
      raw.push([fromCell(x), fromCell(z)]);
    }
    raw.reverse();
    // String-pull: keep only the corners.
    const out = [];
    let anchor = 0;
    while (anchor < raw.length - 1) {
      let far = Math.min(raw.length - 1, anchor + 70);
      while (far > anchor + 1 && !this._lineClear(raw[anchor][0], raw[anchor][1], raw[far][0], raw[far][1])) far = Math.max(anchor + 1, far - 5);
      out.push(raw[far]);
      anchor = far;
    }
    if (this.walkable(bx, bz)) out[out.length - 1] = [bx, bz];
    return this._throughDoorCentres(ax, az, out);
  }

  // Smoothing can graze the edge of a doorway, and a big man's shoulder catches the end of the wall.
  // So any leg that crosses a door is rerouted through its exact centre, square on.
  _throughDoorCentres(ax, az, path) {
    const out = [];
    let px = ax, pz = az;
    for (const q of path) {
      const hits = [];
      for (const d of LAYOUT.doors) {
        const ux = (d.ex - d.hx) / d.width, uz = (d.ez - d.hz) / d.width;
        const nx = -uz, nz = ux;
        const ta = (px - d.x) * nx + (pz - d.z) * nz, tb = (q[0] - d.x) * nx + (q[1] - d.z) * nz;
        if (ta * tb >= 0) continue;
        const k = ta / (ta - tb);
        const sa = (px - d.x) * ux + (pz - d.z) * uz, sb = (q[0] - d.x) * ux + (q[1] - d.z) * uz;
        if (Math.abs(sa + (sb - sa) * k) > d.width / 2 + 0.7) continue;
        const side = ta > 0 ? 1 : -1;
        const pts = [[d.x, d.z], [d.x - nx * side * 0.85, d.z - nz * side * 0.85]];
        // A chase replans frequently. Once safely inside the approach corridor,
        // going back to its entrance on every replan creates an endless turn loop.
        const entering = out.length === 0 && Math.abs(ta) < 0.85 && Math.abs(sa) < d.width / 2 - BODY;
        if (!entering) pts.unshift([d.x + nx * side * 0.85, d.z + nz * side * 0.85]);
        hits.push({ k, pts });
      }
      hits.sort((a, b) => a.k - b.k);
      for (const h of hits) out.push(...h.pts);
      out.push(q);
      px = q[0];
      pz = q[1];
    }
    return out;
  }
}

export { DECKS };
