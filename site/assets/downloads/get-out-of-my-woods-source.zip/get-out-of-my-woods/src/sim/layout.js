// THE MAP. One source of truth for gameplay and visuals: collision, the killer's navigation, the
// camera and every mesh are all derived from this file. Pure data, no three.js, runs in Node too.
//
// Units are metres. +x is east, +z is south, y is up. rot is a rotation about Y in radians;
// a building's front (local +z) faces world (sin rot, cos rot): rot 0 south, PI/2 east, PI north.

export const WORLD_HALF = 130; // playable limit
export const WATER_LEVEL = -1.2;

export const LAKE = [
  { x: -72, z: 92, rx: 78, rz: 54 },
  { x: -18, z: 112, rx: 48, rz: 44 },
];

// Open ground with no trees.
export const CLEARINGS = [
  { id: 'firepit', x: 0, z: 8, r: 14 },
  { id: 'cabins', x: -4, z: -14, r: 24 },
  { id: 'mess', x: -12, z: -58, r: 15 },
  { id: 'archery', x: 32, z: -84, r: 19 },
  { id: 'shed', x: 70, z: -42, r: 9 },
  { id: 'lot', x: 92, z: 0, r: 16 },
  { id: 'gate', x: 122, z: 0, r: 7 },
  { id: 'shack', x: -92, z: -72, r: 6 },
  { id: 'boathouse', x: -34, z: 34, r: 11 },
];

// kind 'road' is wide packed dirt; 'path' is a footpath; 'overgrown' is barely there.
export const TRAILS = [
  { id: 'camp-road', kind: 'road', width: 5, pts: [[150, 0], [122, 0], [106, 0], [92, 1], [78, 4], [60, 7], [36, 8], [13, 8]] },
  { id: 'to-mess', kind: 'path', width: 2.6, pts: [[-3, -4], [-12, -14], [-16, -30], [-13, -44], [-12, -53]] },
  { id: 'to-cabin3', kind: 'path', width: 2, pts: [[7, -2], [15, -9], [18, -12]] },
  { id: 'to-boathouse', kind: 'path', width: 2.6, pts: [[-6, 20], [-14, 28], [-26, 31], [-33, 36]] },
  { id: 'mess-archery', kind: 'path', width: 2.2, pts: [[-1, -60], [12, -68], [24, -78], [31, -80]] },
  { id: 'archery-shed', kind: 'path', width: 2.2, pts: [[44, -78], [56, -66], [66, -54], [70, -47]] },
  { id: 'shed-lot', kind: 'path', width: 2.2, pts: [[72, -37], [80, -24], [87, -12], [90, -3]] },
  { id: 'shore', kind: 'path', width: 2.2, pts: [[-27, 37], [-8, 42], [14, 46], [34, 40], [52, 26], [66, 12], [72, 6]] },
  { id: 'to-shack', kind: 'overgrown', width: 1.6, pts: [[-21, -58], [-40, -55], [-60, -63], [-76, -72], [-87, -72]] },
  { id: 'west-loop', kind: 'overgrown', width: 1.6, pts: [[-92, -66], [-104, -38], [-100, -8], [-84, 14], [-62, 24], [-42, 31]] },
];

// Where each kind of structure goes. The template (below) holds its insides.
const P = Math.PI;
export const BUILDINGS = [
  { id: 'cabin1', template: 'cabin', x: -27, z: -5, rot: 1.25, name: 'Cabin 1' },
  { id: 'cabin2', template: 'cabin', x: -3, z: -25, rot: 0.08, name: 'Cabin 2' },
  { id: 'cabin3', template: 'cabin', x: 21, z: -19, rot: -0.72, name: 'Cabin 3' },
  { id: 'mess', template: 'messhall', x: -12, z: -62, rot: 0, name: 'Mess Hall' },
  { id: 'boathouse', template: 'boathouse', x: -34, z: 45, rot: P, name: 'Boathouse' },
  { id: 'shed', template: 'shed', x: 70, z: -43, rot: 0.1, name: 'Maintenance Shed' },
  { id: 'shack', template: 'shack', x: -92, z: -72, rot: P / 2, name: 'The Shack' },
  { id: 'outhouse1', template: 'outhouse', x: 36, z: -6, rot: -1.2, name: 'Outhouse' },
  { id: 'outhouse2', template: 'outhouse', x: -33, z: -30, rot: 1.0, name: 'Outhouse' },
];

// Templates are in local coordinates. Walls run around the rectangle hx,hz; 'gaps' are openings.
// wall names: front (+z), back (-z), left (-x), right (+x). 'at' is the offset along that wall.
// solids: furniture collision boxes {x,z,hx,hz,h,kind}. The mesh must match the box.
// doors: {wall, at, width}. windows: decorative glazing. vault: window the player can climb.
// hide: {id,type,stand:[x,z],view:{pos:[x,y,z],look:[x,y,z]}}.
// search: {id,label,x,z,y,can:[...]}. cams: fixed interior cameras, each with a rect in local coords.
export const TEMPLATES = {
  cabin: {
    hx: 3.2, hz: 4.0, wallH: 2.5, ridgeH: 3.9, floorY: 0.3, porch: 1.5,
    doors: [{ wall: 'front', at: 0, width: 1.1 }],
    windows: [
      { wall: 'left', at: -1.2, width: 1.0 },
      { wall: 'right', at: -1.2, width: 1.0 },
    ],
    vault: [{ wall: 'back', at: 0, width: 1.0, inside: [0, -3.2], outside: [0, -5.0] }],
    solids: [
      { kind: 'bunk', x: -2.45, z: 2.0, hx: 0.45, hz: 0.98, h: 1.7 },
      { kind: 'bunk', x: -2.45, z: -0.4, hx: 0.45, hz: 0.98, h: 1.7 },
      { kind: 'bunk', x: 2.45, z: 2.0, hx: 0.45, hz: 0.98, h: 1.7 },
      { kind: 'bunk', x: 2.45, z: -0.4, hx: 0.45, hz: 0.98, h: 1.7 },
      { kind: 'closet', x: -2.5, z: -3.1, hx: 0.55, hz: 0.72, h: 2.1 },
      { kind: 'desk', x: 2.45, z: -3.1, hx: 0.5, hz: 0.6, h: 0.8 },
      { kind: 'footlocker', x: -1.72, z: 2.0, hx: 0.26, hz: 0.42, h: 0.42 },
    ],
    hide: [
      { id: 'closet', type: 'closet', stand: [-1.55, -3.1], view: { pos: [-1.78, 1.42, -3.1], look: [2.0, 0.95, 0.8] } },
      { id: 'bed', type: 'bed', stand: [1.55, 2.0], view: { pos: [2.5, 0.2, 2.0], look: [-0.9, 0.3, 3.8] } },
    ],
    cams: [{ id: 'room', rect: [-3.3, -4.1, 3.3, 4.1], pos: [2.75, 2.32, -3.55], look: [-0.9, 0.7, 2.5], fov: 74 }],
  },
  messhall: {
    hx: 9, hz: 5.25, wallH: 3.2, ridgeH: 5.4, floorY: 0.25, porch: 2,
    doors: [
      { wall: 'front', at: -3, width: 1.6 },
      { wall: 'back', at: 6, width: 1.1 },
    ],
    windows: [
      { wall: 'front', at: -7, width: 1.5 },
      { wall: 'front', at: 1, width: 1.5 },
      { wall: 'front', at: 6, width: 1.2 },
      { wall: 'back', at: -6, width: 1.5 },
      { wall: 'back', at: -1, width: 1.5 },
      { wall: 'left', at: 0, width: 1.5 },
    ],
    innerWalls: [
      { x1: 3, z1: -5.25, x2: 3, z2: -1.3 },
      { x1: 3, z1: 0.3, x2: 3, z2: 5.25 },
    ],
    solids: [
      { kind: 'table', x: -6.6, z: -1.3, hx: 0.82, hz: 2.5, h: 0.78 },
      { kind: 'table', x: -3.2, z: -1.3, hx: 0.82, hz: 2.5, h: 0.78 },
      { kind: 'table', x: 0.2, z: -1.3, hx: 0.82, hz: 2.5, h: 0.78 },
      { kind: 'crate', x: -8.2, z: 4.3, hx: 0.55, hz: 0.55, h: 0.9 },
      { kind: 'counter', x: 8.35, z: 0, hx: 0.5, hz: 4.6, h: 0.95 },
      { kind: 'stove', x: 5.5, z: 2.6, hx: 0.75, hz: 1.1, h: 0.95 },
      { kind: 'closet', x: 3.75, z: 4.45, hx: 0.6, hz: 0.68, h: 2.2 },
    ],
    hide: [{ id: 'pantry', type: 'closet', stand: [3.75, 3.2], view: { pos: [3.75, 1.45, 3.62], look: [5.8, 1.0, -2.5] } }],
    cams: [
      { id: 'hall', rect: [-9.1, -5.4, 3, 5.4], pos: [-8.55, 3.0, -4.85], look: [-0.6, 0.6, 3.6], fov: 76 },
      { id: 'kitchen', rect: [3, -5.4, 9.1, 5.4], pos: [8.5, 2.9, -4.8], look: [4.0, 0.6, 2.6], fov: 78 },
    ],
  },
  boathouse: {
    hx: 3.6, hz: 6.0, wallH: 2.8, ridgeH: 4.2, floorAbs: 0.25,
    doors: [{ wall: 'front', at: 0, width: 1.2 }],
    openWalls: ['back'], // the lake end has no wall at all
    windows: [{ wall: 'left', at: 2, width: 1.0 }, { wall: 'right', at: 2, width: 1.0 }],
    solids: [
      { kind: 'canoeRack', x: -3.05, z: 0, hx: 0.48, hz: 4.6, h: 2.0 },
      { kind: 'bench', x: 3.15, z: 2.4, hx: 0.42, hz: 1.7, h: 0.9 },
      { kind: 'canoe', x: 1.15, z: -2.2, hx: 0.5, hz: 2.3, h: 0.5 },
      { kind: 'motorStand', x: 3.1, z: -2.6, hx: 0.42, hz: 0.5, h: 1.0 },
    ],
    hide: [{ id: 'canoe', type: 'canoe', stand: [0.3, -2.2], view: { pos: [1.15, 0.5, -2.8], look: [-1.0, 0.45, 4.8] } }],
    cams: [{ id: 'room', rect: [-3.7, -6.1, 3.7, 6.1], pos: [-3.25, 2.55, 5.55], look: [1.0, 0.3, -4.4], fov: 74 }],
  },
  shed: {
    hx: 3.2, hz: 2.6, wallH: 2.4, ridgeH: 3.2, floorY: 0.1,
    doors: [{ wall: 'front', at: -1, width: 1.1 }],
    windows: [{ wall: 'right', at: 0, width: 0.9 }],
    solids: [
      { kind: 'bench', x: 0.3, z: -2.1, hx: 2.8, hz: 0.42, h: 0.9 },
      { kind: 'generator', x: 2.4, z: 1.3, hx: 0.6, hz: 0.75, h: 1.0 },
      { kind: 'locker', x: -2.72, z: -0.6, hx: 0.42, hz: 0.5, h: 2.0 },
    ],
    hide: [{ id: 'locker', type: 'closet', stand: [-1.75, -0.6], view: { pos: [-2.16, 1.5, -0.6], look: [1.8, 1.0, 1.4] } }],
    cams: [{ id: 'room', rect: [-3.3, -2.7, 3.3, 2.7], pos: [2.85, 2.1, -2.25], look: [-1.5, 0.5, 2.2], fov: 80 }],
  },
  shack: {
    hx: 2.6, hz: 2.6, wallH: 2.2, ridgeH: 2.9, floorY: 0.05,
    doors: [{ wall: 'front', at: 0, width: 1.0 }],
    solids: [{ kind: 'bench', x: 0, z: -2.15, hx: 2.2, hz: 0.36, h: 0.85 }],
    hide: [],
    cams: [{ id: 'room', rect: [-2.7, -2.7, 2.7, 2.7], pos: [2.25, 1.95, -2.25], look: [-0.9, 0.7, 2.2], fov: 84 }],
  },
  outhouse: {
    hx: 0.72, hz: 0.72, wallH: 2.1, ridgeH: 2.5, floorY: 0, sealed: true,
    doors: [],
    solids: [],
    hide: [{ id: 'stall', type: 'outhouse', stand: [0, 1.35], view: { pos: [0, 1.5, 0.86], look: [0, 1.25, 7] } }],
    cams: [],
  },
};

// What can be found where. Each run the keys and the battery land on one spot each (see objectives).
// y is the height of the object above the floor, for the sparkle and the camera to aim at.
export const SEARCH_SPOTS = [
  { id: 'c1-locker', building: 'cabin1', x: -1.72, z: 2.0, y: 0.42, label: 'Footlocker', can: ['keys'] },
  { id: 'c2-duffel', building: 'cabin2', x: -2.0, z: -0.4, y: 0.55, label: 'Duffel bag', can: ['keys'] },
  { id: 'c3-desk', building: 'cabin3', x: 1.95, z: -3.0, y: 0.8, label: 'Staff desk', can: ['keys'] },
  { id: 'mess-lost', building: 'mess', x: -8.15, z: 3.7, y: 0.9, label: 'Lost and Found box', can: ['keys'] },
  { id: 'mess-kitchen', building: 'mess', x: 7.8, z: -2.0, y: 0.95, label: 'Kitchen drawers', can: ['keys', 'battery'] },
  { id: 'boat-tackle', building: 'boathouse', x: 2.7, z: 2.6, y: 0.9, label: 'Tackle box', can: ['keys'] },
  { id: 'boat-motor', building: 'boathouse', x: 2.6, z: -2.6, y: 1.0, label: 'Outboard motor', can: ['battery'] },
  { id: 'shed-bench', building: 'shed', x: 0.9, z: -1.6, y: 0.9, label: 'Workbench', can: ['battery'] },
  { id: 'shed-toolbox', building: 'shed', x: -1.9, z: -1.6, y: 0.9, label: 'Toolbox', can: ['keys'] },
  { id: 'shack-bench', building: 'shack', x: 0.6, z: -1.7, y: 0.85, label: 'Workbench', can: ['keys', 'battery'] },
  { id: 'range-box', x: 22, z: -91, y: 0.6, label: 'Equipment box', can: ['keys', 'battery'] },
  { id: 'dock-cooler', x: -34.8, z: 72.5, y: 0.45, label: 'Cooler', can: ['keys'] },
];

// Walkable wooden decks, world coordinates. y is absolute.
export const DECKS = [
  { id: 'dock', minX: -36.1, maxX: -31.9, minZ: 50.9, maxZ: 75, y: 0.25 },
];

// Hiding places outdoors, in thick brush. type 'bush'.
export const BUSH_HIDES = [
  { id: 'b1', x: 11, z: 21 }, { id: 'b2', x: -21, z: 15 }, { id: 'b3', x: -30, z: -40 },
  { id: 'b4', x: 12, z: -56 }, { id: 'b5', x: 47, z: -60 }, { id: 'b6', x: 55, z: -8 },
  { id: 'b7', x: 86, z: -30 }, { id: 'b8', x: 76, z: 18 }, { id: 'b9', x: 28, z: 32 },
  { id: 'b10', x: -55, z: 10 }, { id: 'b11', x: -64, z: -52 }, { id: 'b12', x: -5, z: 39 },
  { id: 'b13', x: 104, z: 14 }, { id: 'b14', x: -96, z: -28 },
];

// Outdoor props. Their shapes are in PROP_SHAPES. rot as above.
export const PROPS = [
  // fire pit
  { type: 'firepit', x: 0, z: 8 },
  { type: 'logbench', x: -5.4, z: 6, rot: 1.2 }, { type: 'logbench', x: 5.2, z: 11, rot: 1.1 }, { type: 'logbench', x: -1, z: 13.6, rot: 0.1 },
  { type: 'noticeboard', x: 9, z: -1, rot: -0.5 },
  { type: 'flagpole', x: -12, z: 1 },
  { type: 'picnictable', x: 11, z: 15, rot: 0.3 }, { type: 'picnictable', x: -13, z: 11, rot: 1.4 },
  // mess hall yard
  { type: 'picnictable', x: -24, z: -52, rot: 1.8 }, { type: 'picnictable', x: 3, z: -50, rot: 0.2 },
  { type: 'barrel', x: -2, z: -70.5 }, { type: 'barrel', x: -0.8, z: -71.4 }, { type: 'dumpster', x: 3.5, z: -71, rot: 0.1 },
  // boathouse and shore
  { type: 'canoe', x: -24, z: 37, rot: 0.9 }, { type: 'canoe', x: -22, z: 34.5, rot: 0.7 },
  // archery range
  { type: 'fence', x: 32, z: -66, rot: 0, length: 26 },
  // shed yard
  { type: 'barrel', x: 62, z: -38 }, { type: 'barrel', x: 61, z: -36.6 }, { type: 'fueltank', x: 78, z: -48, rot: 0.2 },
  { type: 'tractor', x: 60, z: -49, rot: 2.1 },
  // parking lot
  { type: 'phonebooth', x: 84, z: 12, rot: 2.8 },
  { type: 'campsign', x: 112, z: -7, rot: -1.57 },
  { type: 'gate', x: 122, z: 0, rot: 1.57 },
  { type: 'busstop', x: 104, z: 8, rot: 3.14 },
];

// Radius of 'circle' props, half sizes of 'box' props. null = no collision.
export const PROP_SHAPES = {
  firepit: { circle: 1.3 },
  logbench: { box: [1.3, 0.3] },
  noticeboard: { box: [1.0, 0.15] },
  flagpole: { circle: 0.2 },
  picnictable: { box: [1.0, 0.8] },
  barrel: { circle: 0.42 },
  dumpster: { box: [1.2, 0.8] },
  canoe: { box: [0.5, 2.3] },
  fence: { fence: true },
  fueltank: { box: [1.3, 0.7] },
  tractor: { box: [1.0, 1.6] },
  phonebooth: { box: [0.5, 0.5] },
  campsign: { box: [2.0, 0.2] },
  gate: { box: [6.0, 0.25] },
  busstop: { box: [1.6, 0.7] },
};

// Light sources that stay on. kind: lantern, window, fire, yardlight. Windows light up by building.
export const LIGHTS = [
  { kind: 'fire', x: 0, y: 0.7, z: 8 },
  { kind: 'lantern', x: -3.5, y: 2.6, z: -19.5 },
  { kind: 'lantern', x: -9, y: 2.6, z: -55.5 },
  { kind: 'lantern', x: -33.5, y: 2.5, z: 37.8 },
  { kind: 'yardlight', x: 87, y: 5.5, z: -8 },
  { kind: 'yardlight', x: 67, y: 4.5, z: -38 },
];

// The escape car, an old wood-panel station wagon. It faces east, down the road to the gate.
export const CAR = { x: 96, z: -5.5, rot: Math.PI / 2, hood: { x: 98.8, z: -5.5 }, door: { x: 95.4, z: -6.9 }, hx: 0.95, hz: 2.6 };

export const PLAYER_START = { x: 3.4, z: 11.4, yaw: 1.05 };
export const KILLER_START = { x: -92, z: -66 };

// The sack-headed target dummies on the archery range. The killer sometimes stands among them.
export const SCARECROWS = [
  { x: 20, z: -96, rot: 0.1 }, { x: 27, z: -97, rot: -0.1 }, { x: 34, z: -97, rot: 0.15 }, { x: 41, z: -96, rot: -0.2 }, { x: 47, z: -94, rot: -0.3 },
];
export const AMBUSH_SPOTS = [{ x: 30.5, z: -96.6 }, { x: 37.5, z: -97 }];

// Patrol graph nodes: where he walks to. The director chooses among these.
export const WAYPOINTS = [
  { id: 'firepit', x: 3, z: 16 }, { id: 'noticeboard', x: 6, z: 1 },
  { id: 'cabin1-yard', x: -18, z: -2 }, { id: 'cabin2-yard', x: -4, z: -16 }, { id: 'cabin3-yard', x: 15, z: -11 },
  { id: 'mess-front', x: -14, z: -52 }, { id: 'mess-back', x: 4, z: -72 },
  { id: 'mess-side', x: -26, z: -62 }, { id: 'archery-east', x: 45, z: -80 }, { id: 'archery-west', x: 17, z: -85 },
  { id: 'shed-yard', x: 68, z: -36 }, { id: 'shed-back', x: 82, z: -52 }, { id: 'lot-north', x: 89, z: -13 },
  { id: 'lot-east', x: 108, z: 2 }, { id: 'lot-south', x: 82, z: 12 }, { id: 'road-mid', x: 58, z: 7 },
  { id: 'road-west', x: 30, z: 8 }, { id: 'shore-east', x: 50, z: 28 }, { id: 'shore-mid', x: 14, z: 45 },
  { id: 'boathouse-yard', x: -33, z: 33 }, { id: 'boat-west', x: -48, z: 30 }, { id: 'west-mid', x: -84, z: 13 },
  { id: 'west-north', x: -102, z: -24 }, { id: 'shack-yard', x: -82, z: -72 }, { id: 'trail-midwest', x: -50, z: -59 },
  { id: 'woods-north', x: -48, z: -22 }, { id: 'woods-east', x: 46, z: -32 }, { id: 'woods-south', x: 32, z: 24 },
];

// Signposts at trail forks. Text is shown on screen when the player is near.
export const SIGNS = [
  { x: 11, z: 3, rot: 0.6, text: 'EAST: PARKING LOT.   NORTH: CABINS, MESS HALL.   SOUTH: BOATHOUSE.' },
  { x: -18, z: -40, rot: 0.2, text: 'NORTH: MESS HALL.   SOUTH: CABINS, FIRE PIT.' },
  { x: -25, z: -55, rot: 1.5, text: 'WEST: NO TRAIL. NOTHING OUT HERE. TURN BACK.' },
  { x: 46, z: -76, rot: -0.8, text: 'WEST: ARCHERY RANGE, MESS HALL.   SOUTHEAST: MAINTENANCE SHED.' },
  { x: 72, z: 2, rot: 1.2, text: 'EAST: PARKING LOT, GATE.   WEST: FIRE PIT.   SOUTHWEST: LAKE TRAIL.' },
  { x: -18, z: 29, rot: 2.8, text: 'SOUTH: BOATHOUSE AND DOCK.   NORTH: FIRE PIT.' },
];

// Text labels for the paper camp map.
export const MAP_LABELS = [
  { x: 0, z: 18, text: 'Fire Pit' }, { x: -33, z: -13, text: 'Cabin 1' }, { x: -3, z: -35, text: 'Cabin 2' },
  { x: 32, z: -24, text: 'Cabin 3' }, { x: -12, z: -74, text: 'Mess Hall' }, { x: 32, z: -104, text: 'Archery Range' },
  { x: 70, z: -56, text: 'Shed' }, { x: 92, z: 16, text: 'Parking Lot' }, { x: -34, z: 62, text: 'Boathouse + Dock' },
  { x: -92, z: -84, text: '???' }, { x: 118, z: 12, text: 'Gate' },
];

// ---- Derived world-space data -------------------------------------------------------------------

export function localToWorld(b, x, z) {
  const c = Math.cos(b.rot), s = Math.sin(b.rot);
  return [b.x + x * c + z * s, b.z - x * s + z * c];
}

export function worldToLocal(b, wx, wz) {
  const dx = wx - b.x, dz = wz - b.z;
  const c = Math.cos(b.rot), s = Math.sin(b.rot);
  return [dx * c - dz * s, dx * s + dz * c];
}

const WALLS = {
  front: (t) => ({ ax: -t.hx, az: t.hz, bx: t.hx, bz: t.hz, axis: 'x' }),
  back: (t) => ({ ax: -t.hx, az: -t.hz, bx: t.hx, bz: -t.hz, axis: 'x' }),
  left: (t) => ({ ax: -t.hx, az: -t.hz, bx: -t.hx, bz: t.hz, axis: 'z' }),
  right: (t) => ({ ax: t.hx, az: -t.hz, bx: t.hx, bz: t.hz, axis: 'z' }),
};

// Local wall segments of a template, cut around door gaps. Returns [{x1,z1,x2,z2}].
export function templateWallSegments(t) {
  const out = [];
  for (const name of ['front', 'back', 'left', 'right']) {
    if (t.openWalls?.includes(name)) continue;
    const w = WALLS[name](t);
    const gaps = (t.doors || []).filter((d) => d.wall === name).map((d) => [d.at - d.width / 2, d.at + d.width / 2]).sort((a, b) => a[0] - b[0]);
    const lo = w.axis === 'x' ? w.ax : w.az;
    const hi = w.axis === 'x' ? w.bx : w.bz;
    let cursor = lo;
    const seg = (a, b) => {
      if (b - a < 0.01) return;
      out.push(w.axis === 'x' ? { x1: a, z1: w.az, x2: b, z2: w.az } : { x1: w.ax, z1: a, x2: w.ax, z2: b });
    };
    for (const [a, b] of gaps) {
      seg(cursor, a);
      cursor = b;
    }
    seg(cursor, hi);
  }
  for (const iw of t.innerWalls || []) out.push(iw);
  return out;
}

// Local door centre, plus the unit vector along the door's width.
export function templateDoorPose(t, d) {
  const w = WALLS[d.wall](t);
  if (w.axis === 'x') return { x: d.at, z: w.az, ux: 1, uz: 0 };
  return { x: w.ax, z: d.at, ux: 0, uz: 1 };
}

export function buildLayout() {
  const doors = [], hides = [], vaults = [], zones = [], walls = [], solids = [];
  for (const b of BUILDINGS) {
    const t = TEMPLATES[b.template];
    for (const s of templateWallSegments(t)) {
      const [x1, z1] = localToWorld(b, s.x1, s.z1);
      const [x2, z2] = localToWorld(b, s.x2, s.z2);
      walls.push({ x1, z1, x2, z2, building: b.id });
    }
    (t.doors || []).forEach((d, i) => {
      const p = templateDoorPose(t, d);
      const half = d.width / 2;
      const [x, z] = localToWorld(b, p.x, p.z);
      const [hx, hz] = localToWorld(b, p.x - p.ux * half, p.z - p.uz * half); // hinge end
      const [ex, ez] = localToWorld(b, p.x + p.ux * half, p.z + p.uz * half); // latch end
      doors.push({ id: `${b.id}.d${i}`, building: b.id, x, z, hx, hz, ex, ez, width: d.width, open: false });
    });
    for (const s of t.solids || []) {
      const [x, z] = localToWorld(b, s.x, s.z);
      solids.push({ x, z, hx: s.hx, hz: s.hz, rot: b.rot, h: s.h, kind: s.kind, building: b.id });
    }
    for (const h of t.hide || []) {
      const [sx, sz] = localToWorld(b, h.stand[0], h.stand[1]);
      const [px, pz] = localToWorld(b, h.view.pos[0], h.view.pos[2]);
      const [lx, lz] = localToWorld(b, h.view.look[0], h.view.look[2]);
      hides.push({
        id: `${b.id}.${h.id}`, type: h.type, building: b.id, x: sx, z: sz,
        view: { pos: [px, h.view.pos[1], pz], look: [lx, h.view.look[1], lz] },
      });
    }
    for (const v of t.vault || []) {
      const [ix, iz] = localToWorld(b, v.inside[0], v.inside[1]);
      const [ox, oz] = localToWorld(b, v.outside[0], v.outside[1]);
      vaults.push({ id: `${b.id}.vault`, building: b.id, ix, iz, ox, oz });
    }
    for (const c of t.cams || []) {
      const [px, pz] = localToWorld(b, c.pos[0], c.pos[2]);
      const [lx, lz] = localToWorld(b, c.look[0], c.look[2]);
      zones.push({
        id: `${b.id}.${c.id}`, building: b.id, rect: c.rect, fov: c.fov,
        pos: [px, c.pos[1], pz], look: [lx, c.look[1], lz],
      });
    }
  }
  const searches = SEARCH_SPOTS.map((s) => {
    if (!s.building) return { ...s, wx: s.x, wz: s.z };
    const b = BUILDINGS.find((q) => q.id === s.building);
    const [wx, wz] = localToWorld(b, s.x, s.z);
    return { ...s, wx, wz };
  });
  const bushes = BUSH_HIDES.map((h) => ({ ...h, type: 'bush', view: { pos: [h.x, 0.75, h.z], look: [h.x + 3, 0.9, h.z] } }));
  return { doors, hides: hides.concat(bushes), vaults, zones, walls, solids, searches };
}

export const LAYOUT = buildLayout();
