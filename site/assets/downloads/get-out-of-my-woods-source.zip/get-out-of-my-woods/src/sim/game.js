// The game itself, with no pictures or sound: the player, the killer, the objectives, the clock.
// Everything the screen and speakers do is driven by the events this emits. It also runs in Node,
// which is how the bots play thousands of nights.
import { BUILDINGS, CAR, KILLER_START, LAYOUT, LIGHTS, PLAYER_START, SIGNS, TEMPLATES, WORLD_HALF, worldToLocal, CLEARINGS } from './layout.js';
import { generateForest } from './forest.js';
import { Collision } from './collision.js';
import { doorwaySteer, doorStepBack, doorStepClear, doorwayStand, doorDepth, doorFrame, headedThrough } from './doorways.js';
import { Nav } from './nav.js';
import { heightAt, nearestTrail, surfaceY, waterDepth } from './terrain.js';
import { makeRng } from '../core/rng.js';
import { FOUND_LINES, nothingLine, placeItems } from './objectives.js';
import { Killer } from '../ai/killer.js';
import { Director } from '../ai/director.js';
import { DIFFICULTY, PLAYER, KILLER } from '../ai/tuning.js';

const SEARCH_HOLD = 1.0;
const BATTERY_HOLD = 2.0;
// The opening ends early only after introGrace seconds spent not getting closer to the car. A player who
// keeps closing in still gets the car reveal, up to this ceiling: long enough to sneak the whole road (about
// 61 s at sneak speed), short enough that circling the car at a distance cannot hold the hunt off for long.
const INTRO_MIN_CEILING = 90;
// The longest she steps back for one door opening toward her. A door that cannot finish its swing
// (something is in its way) must never hold her in place.
const DOOR_YIELD_MAX = 0.7;
// The longest she moves aside for one door she is closing on herself.
const DOOR_CLEAR_MAX = 0.8;

// Heavy shared structures, built once per page.
let shared = null;
export function sharedWorld() {
  if (shared) return shared;
  const forest = generateForest();
  const collision = new Collision(forest);
  const nav = new Nav(collision);
  shared = { forest, collision, nav };
  return shared;
}

export class GameSim {
  static searchSpots() {
    return LAYOUT.searches; // used by the automated browser tests
  }

  constructor(opts = {}) {
    const { forest, collision, nav } = sharedWorld();
    this.forest = forest;
    this.collision = collision;
    this.nav = nav;
    this.difficulty = opts.difficulty || 'normal';
    this.tune = DIFFICULTY[this.difficulty];
    this.seed = opts.seed ?? Math.floor(Math.random() * 1e9);
    this.rng = makeRng(this.seed);
    for (const d of collision.doors) { d.open = false; d.motion = null; d.latched = false; }
    this.hides = LAYOUT.hides;
    this.items = placeItems(this.rng);
    this.searched = new Set();
    this.events = [];
    this.time = 0;
    this.phase = opts.skipIntro ? 'play' : 'intro';
    this.act = 0;
    this.storm = 0;
    this.has = { keys: false, battery: false };
    this.batteryIn = false;
    this.closeCalls = 0;
    this.stats = { seen: 0, killerStuck: 0 };
    this.deathKind = null;
    this.holdT = 0;
    this.holdTarget = null;
    this.introGraceT = 0;
    this.lightningT = 30;
    this.scareT = 25 + this.rng() * 30;
    this.car = { tries: 0, need: 2 + Math.floor(this.rng() * 2), crank: 0, buffered: false, threat: 0, done: false };
    this.player = {
      x: PLAYER_START.x, z: PLAYER_START.z, y: surfaceY(PLAYER_START.x, PLAYER_START.z), yaw: PLAYER_START.yaw,
      vx: 0, vz: 0, stamina: 1, winded: false, flashlight: true, moveMode: 'idle', speed: 0,
      hidden: null, hiddenAt: undefined, seenEntering: false, inBrush: false, nearLight: false, inCar: false, stepAcc: 0, vaultT: 0,
      building: null, wounded: false,
    };
    this.director = new Director(this.rng, this.tune);
    this.killer = new Killer(this, this.tune, this.rng, KILLER_START);
    this.prompt = null;
    this.reached = { car: false };
    this.empties = 0;
    this.dropAfter = 1 + Math.floor(this.rng() * 2);
    this.dropT = 0;
    this.screamT = 0;
    this.dropped = false;
    this.follower = { on: 0, wait: 70 + this.rng() * 60, uses: 0, echo: 0 };
    this.revealT = 30;
    if (this.phase === 'play') this.beginHunt();
    else this.killer.startLurk();
  }

  // The opening ends without the car reveal: she wandered off, or started searching.
  endOpening() {
    // Never move him to start an encounter: a visible roadside watcher walks from here.
    this.beginHunt({ fromHere: true });
    this.emit({ t: 'huntStarted' });
  }

  emit(e) {
    if (['doorOpen', 'doorClose', 'doorSlam', 'doorBash'].includes(e.t)) {
      const d = this.collision.doors.find(d => d.id === e.id);
      if (d) {
        const opening = e.t !== 'doorClose';
        const speed = e.t === 'doorBash' ? 12 : e.t === 'doorSlam' ? 9 : e.killer ? 2.4 : 3.5;
        d.motion = { amount: d.motion?.amount ?? (opening ? 0 : 1), target: opening ? 1 : 0, speed };
      }
    }
    this.events.push(e);
    switch (e.t) {
      case 'spotted': this.stats.seen++; break;
      default: break;
    }
  }

  drainEvents() {
    const e = this.events;
    this.events = [];
    return e;
  }

  // The car reveal starts the hunt early; explorers get a bounded introduction.
  beginHunt({ fromHere = false } = {}) {
    this.phase = 'play';
    if (!fromHere && this.killer.state === 'lurk') this.killer.vanish();
    this.killer.go('patrol', 2);
    this.killer.path = null;
    this.reached.car = !fromHere;
  }

  kill(kind) {
    if (this.phase === 'dead' || this.phase === 'escaped') return;
    this.deathKind = kind;
    this.phase = 'dead';
    this.killer.state = 'kill';
    this.killer.speed = 0;
    this.deathLocation = this.locationKind();
    this.emit({ t: 'death', kind, location: this.deathLocation, x: this.player.x, z: this.player.z });
  }

  // Existing places give the death film its setting without adding objectives.
  locationKind() {
    const p = this.player;
    if (p.inCar) return 'car';
    if (p.building || this.buildingAt(p.x, p.z)) return 'cabin';
    if (this.surfaceKind(p.x, p.z) === 'wood' || waterDepth(p.x, p.z) > 0.05) return 'lakeside';
    return 'woods';
  }

  pursuitStatus() {
    const k = this.killer;
    if (this.player.hidden) return this.player.seenEntering ? 'pursuit' : 'hidden';
    if (k.state === 'strike' || (k.state === 'chase' && k.sees)) return 'pursuit';
    if (k.state === 'notice' && k.sees) return 'spotted';
    if (k.pursuitActive && ['chase', 'search', 'checkhide', 'investigate', 'notice'].includes(k.state)) return 'searching';
    return 'clear';
  }

  buildingAt(x, z) {
    for (const b of BUILDINGS) {
      const t = TEMPLATES[b.template];
      if (Math.abs(x - b.x) > 14 || Math.abs(z - b.z) > 14) continue;
      const [lx, lz] = worldToLocal(b, x, z);
      if (Math.abs(lx) < t.hx && Math.abs(lz) < t.hz) return b;
    }
    return null;
  }

  noise(x, z, radius, what) {
    this.killer.hear(x, z, radius, what);
  }

  nearSolidBehindPlayer() {
    const p = this.player, k = this.killer;
    const dx = p.x - k.x, dz = p.z - k.z;
    const d = Math.hypot(dx, dz) || 1;
    for (let t = 0.6; t <= 2.4; t += 0.6) {
      const x = p.x + (dx / d) * t, z = p.z + (dz / d) * t;
      if (this.collision.blocked(x, z, 0.2, true)) {
        // Walk back out to the surface so she ends up against it, not inside it.
        let lo = t - 0.6, hi = t;
        for (let i = 0; i < 4; i++) {
          const m = (lo + hi) / 2;
          if (this.collision.blocked(p.x + (dx / d) * m, p.z + (dz / d) * m, 0.2, true)) hi = m;
          else lo = m;
        }
        const pinAt = { x: p.x + (dx / d) * hi, z: p.z + (dz / d) * hi };
        const trunk = this.collision.trunkAt(pinAt.x, pinAt.z, 0.25);
        const tree = trunk && this.forest.trees.some((t) => t.solid && t.x === trunk.x && t.z === trunk.z);
        const againstSegment = (w) => {
          const ax = w.x1 ?? w.hx, az = w.z1 ?? w.hz;
          const bx = w.x2 ?? w.ex, bz = w.z2 ?? w.ez;
          const ex = bx - ax, ez = bz - az;
          const along = Math.max(0, Math.min(1, ((pinAt.x - ax) * ex + (pinAt.z - az) * ez) / (ex * ex + ez * ez)));
          return Math.hypot(pinAt.x - ax - along * ex, pinAt.z - az - along * ez) < 0.36;
        };
        const wall = this.collision.walls.some(againstSegment) ||
          this.collision.doors.some((door) => !door.open && againstSegment(door));
        // Tables, rocks, benches and car bumpers cannot pin an upright torso.
        if (!tree && !wall) return false;
        this.pinAt = pinAt;
        this.pinTrunk = tree ? trunk : null;
        return true;
      }
    }
    return false;
  }

  setDoor(d, open) {
    d.open = open;
    d.latched = !open; // shut by her own hand: see the bump rule in updatePlayer
    this.emit({ t: open ? 'doorOpen' : 'doorClose', id: d.id, x: d.x, z: d.z });
    this.noise(d.x, d.z, 7, 'door');
  }

  killerDoor(door, burst) {
    door.open = true;
    door.latched = false;
    this.emit({ t: burst ? 'doorBash' : 'doorOpen', id: door.id, x: door.x, z: door.z, killer: true });
  }

  get introCeiling() {
    return Math.max(this.tune.introGrace * 2, INTRO_MIN_CEILING);
  }

  // ---- one step of the night ---------------------------------------------------------------
  // input: {moveX, moveY, camYaw, run, sneak, action (pressed), actionHeld, flashlight (pressed)}
  step(dt, input) {
    this.time += dt;
    if (this.phase === 'car') {
      this.updateCar(dt, input);
      this.killer.anim = 'walk';
      return;
    }
    if (this.phase !== 'play' && this.phase !== 'intro') return;
    this.updateDoors(dt);
    this.director.update(dt, this.player);
    // E accepts an available hiding place at the position where it was pressed.
    // Otherwise this frame's movement/inertia can cross the exact prompt edge
    // before the press is read. Consume that edge once so it cannot also leave.
    let enteredHide = false;
    if (input.action && this.findInteraction()?.kind === 'hide') {
      this.updateInteraction(0, input);
      enteredHide = !!this.player.hidden;
    }
    const carDistance = Math.hypot(this.player.x - CAR.x, this.player.z - CAR.z);
    this.updatePlayer(dt, input);
    this.updateInteraction(dt, enteredHide ? { ...input, action: false } : input);
    if (this.phase === 'play') {
      this.killer.update(dt);
      this.updateNight(dt);
      this.updateFollower(dt);
    }
    if (this.phase === 'intro' && this.killer.state === 'lurk') this.killer.update(dt);
    const nextCarDistance = Math.hypot(this.player.x - CAR.x, this.player.z - CAR.z);
    if (this.phase === 'intro' && nextCarDistance < 8.5) {
      this.emit({ t: 'carFound' });
      this.phase = 'cutscene';
    } else if (this.phase === 'intro') {
      if (nextCarDistance >= carDistance) this.introGraceT += dt;
      if (this.introGraceT >= this.tune.introGrace || this.time >= this.introCeiling) this.endOpening();
    }
  }

  updateDoors(dt) {
    const p = this.player, k = this.killer;
    const bodies = [{ body: k, radius: KILLER.radius }];
    if (!p.hidden && !p.inCar && p.vaultT <= 0) bodies.push({ body: p, radius: PLAYER.radius });
    this.collision.updateDoors(dt, bodies);
  }

  moveKiller(ax, az, bx, bz) {
    const p = this.player;
    const other = !p.hidden && !p.inCar && p.vaultT <= 0 ? p : null;
    return this.collision.moveWithActor(ax, az, bx, bz, KILLER.radius, other, PLAYER.radius);
  }

  updatePlayer(dt, input) {
    const p = this.player;
    if (input.flashlight) {
      p.flashlight = !p.flashlight;
      this.emit({ t: 'flashlight', on: p.flashlight });
    }
    if (p.hidden) {
      // Catching your breath is the payoff for breaking sight before hiding.
      p.stamina = Math.min(1, p.stamina + PLAYER.staminaBackStill * dt);
      if (p.stamina >= PLAYER.windedUntil) p.winded = false;
      p.speed = 0;
      p.moveMode = 'idle';
      return;
    }
    if (p.inCar) return;
    if (p.vaultT > 0) {
      p.vaultT -= dt;
      const t = 1 - Math.max(0, p.vaultT) / 0.7;
      p.x = p.vaultFrom[0] + (p.vaultTo[0] - p.vaultFrom[0]) * t;
      p.z = p.vaultFrom[1] + (p.vaultTo[1] - p.vaultFrom[1]) * t;
      p.y = surfaceY(p.x, p.z) + Math.sin(t * Math.PI) * 0.7;
      p.speed = 2;
      return;
    }
    const mag = Math.min(1, Math.hypot(input.moveX, input.moveY));
    const fx = Math.sin(input.camYaw), fz = Math.cos(input.camYaw);
    let dx = fx * input.moveY - fz * input.moveX;
    let dz = fz * input.moveY + fx * input.moveX;
    const len = Math.hypot(dx, dz);
    if (len > 0) {
      dx /= len;
      dz /= len;
    }

    let mode = 'idle', target = 0;
    if (mag > 0.05) {
      const canRun = input.run && !p.winded && p.stamina > 0;
      if (canRun && mag > 0.5) {
        mode = 'run';
        target = PLAYER.run;
      } else if (p.winded) {
        mode = 'walk';
        target = PLAYER.winded;
      } else if (input.sneak || mag < 0.5) {
        mode = 'sneak';
        target = PLAYER.sneak;
      } else {
        mode = 'walk';
        target = PLAYER.walk;
      }
    }
    // Doorways: bend her path into the opening, and let a door that opens toward her swing first.
    if (this.doorIntent && (this.time > this.doorIntent.until || mag < 0.05)) this.doorIntent = null;
    if (len > 0) [dx, dz] = doorwaySteer(this.collision.doors, p.x, p.z, dx, dz, PLAYER.radius, this.doorIntent?.door);
    const stepBack = mag > 0.05 ? doorStepBack(this.collision.doors, p.x, p.z, PLAYER.radius, dt, DOOR_YIELD_MAX) : null;
    // A door she is closing with herself in its way: she steps clear, stick or no stick, so it shuts.
    let stepClear = stepBack ? null : doorStepClear(this.collision.doors, p.x, p.z, PLAYER.radius, dt, DOOR_CLEAR_MAX);
    // She pressed CLOSE in the doorway meaning to be inside: she walks in first, then it shuts behind her.
    const pend = this.closeBehind;
    if (pend) {
      pend.t += dt;
      const d = pend.door, depth = doorDepth(d, p.x, p.z);
      if (!d.open || this.phase !== 'play' && this.phase !== 'intro') this.closeBehind = null;
      else if (depth >= 0.45 || depth < -0.6 || pend.t > 1) {
        this.closeBehind = null;
        this.setDoor(d, false);
      } else if (!stepBack) {
        const f = doorFrame(d);
        stepClear = [f.nx, f.nz];
      }
    }
    let ownWay = false;
    const backing = () => !!(stepBack || stepClear) && !ownWay;
    if (stepBack) {
      [dx, dz] = stepBack;
      target = Math.min(Math.max(target, PLAYER.sneak), PLAYER.walk);
    } else if (stepClear) {
      // If the stick is already taking her out of the door's way, it stays hers.
      const own = len > 0 && mag > 0.2 && dx * stepClear[0] + dz * stepClear[1] > 0.2;
      if (own) ownWay = true;
      else {
        [dx, dz] = stepClear;
        if (mode !== 'sneak') mode = 'walk'; // a sneaking player stays quiet and low while she steps aside
        target = mode === 'sneak' ? PLAYER.sneak : PLAYER.walk;
      }
    }
    const depth = waterDepth(p.x, p.z);
    if (depth > 0.05) target *= 0.65;
    if (this.has.battery && !this.batteryIn) target *= 0.92;

    if (mode === 'run') {
      const drain = this.has.battery && !this.batteryIn ? PLAYER.batteryDrain : 1;
      p.stamina = Math.max(0, p.stamina - (dt / (PLAYER.staminaSeconds * (this.tune.stamina || 1))) * drain);
      if (p.stamina <= 0) {
        p.winded = true;
        this.emit({ t: 'winded' });
      }
    } else {
      p.stamina = Math.min(1, p.stamina + (mode === 'idle' ? PLAYER.staminaBackStill : PLAYER.staminaBack) * dt);
      if (p.winded && p.stamina >= PLAYER.windedUntil) p.winded = false;
    }

    const accel = 1 - Math.exp(-dt * 11);
    p.vx += (dx * target - p.vx) * accel;
    p.vz += (dz * target - p.vz) * accel;
    const nx0 = p.x + p.vx * dt, nz0 = p.z + p.vz * dt;
    let [nx, nz] = this.collision.moveWithActor(p.x, p.z, nx0, nz0, PLAYER.radius, this.killer, KILLER.radius);
    nx = Math.max(-WORLD_HALF, Math.min(WORLD_HALF, nx));
    nz = Math.max(-WORLD_HALF, Math.min(WORLD_HALF, nz));
    // Deep water turns you back.
    if (waterDepth(nx, nz) > 0.8) {
      if (waterDepth(nx, p.z) <= 0.8) nz = p.z;
      else if (waterDepth(p.x, nz) <= 0.8) nx = p.x;
      else {
        nx = p.x;
        nz = p.z;
      }
      // Dropping just one component of a diagonal step can undo body/wall
      // clearance. Sweep that shoreline slide too, keeping the same depth limit.
      [nx, nz] = this.collision.moveWithActor(p.x, p.z, nx, nz, PLAYER.radius, this.killer, KILLER.radius);
      if (waterDepth(nx, nz) > .8) { nx = p.x; nz = p.z; }
      if (this.time - (this.deepToast ?? -99) > 6) {
        this.deepToast = this.time;
        this.emit({ t: 'line', text: 'Too deep. You are not going in there.' });
      }
    }
    // Bump a closed door and it opens.
    for (const d of this.collision.doors) {
      // A door that is still swinging shut is not bumped open again, and neither is one she is
      // being stepped clear of: her own close must finish.
      if (d.open || d.motion || stepClear) continue;
      // A door she shut herself stays shut until she opens it (E) or has gone a few steps away:
      // walking past it, or sliding along it to a corner, must not swing it open again.
      if (d.latched) {
        if (Math.hypot(d.x - nx, d.z - nz) > d.width / 2 + 2.2) d.latched = false;
        continue;
      }
      if (Math.hypot(d.x - nx, d.z - nz) < 0.85 && mag > 0.2) {
        const toward = (d.x - p.x) * dx + (d.z - p.z) * dz > 0 && headedThrough(d, p.x, p.z, dx, dz);
        if (toward) {
          this.doorIntent = { door: d, until: this.time + 1.6 }; // she means to go through it
          d.open = true;
          const loud = mode === 'run';
          this.emit({ t: loud ? 'doorSlam' : 'doorOpen', id: d.id, x: d.x, z: d.z });
          this.noise(d.x, d.z, loud ? 24 : 9, 'door');
        }
      }
    }
    const moved = Math.hypot(nx - p.x, nz - p.z);
    p.x = nx;
    p.z = nz;
    p.y = surfaceY(nx, nz);
    p.speed = moved / Math.max(dt, 1e-4);
    p.moveMode = p.speed < 0.15 ? 'idle' : mode;
    if (len > 0 && !backing()) { // stepping back from a door, she keeps facing it
      const want = Math.atan2(dx, dz);
      let diff = want - p.yaw;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      p.yaw += diff * (1 - Math.exp(-dt * 10));
    }
    const b = this.buildingAt(p.x, p.z);
    if ((b?.id ?? null) !== (p.building?.id ?? null)) {
      p.building = b;
      this.emit({ t: 'indoors', building: b?.id ?? null });
    }

    p.inBrush = this.hides.some((h) => h.type === 'bush' && Math.hypot(h.x - p.x, h.z - p.z) < 2);
    p.nearLight = LIGHTS.some((l) => Math.hypot(l.x - p.x, l.z - p.z) < 9);

    // Footsteps are both sound and information for the killer.
    p.stepAcc += moved;
    const stride = mode === 'run' ? PLAYER.stepRun : mode === 'sneak' ? PLAYER.stepSneak : PLAYER.stepWalk;
    if (p.stepAcc >= stride) {
      p.stepAcc %= stride;
      const surface = this.surfaceKind(p.x, p.z);
      let radius = mode === 'run' ? PLAYER.noiseRun : mode === 'sneak' ? PLAYER.noiseSneak : PLAYER.noiseWalk;
      if (surface === 'wood' || surface === 'water') radius *= 1.35;
      if (surface === 'leaf') radius *= 1.15;
      this.emit({ t: 'step', surface, mode, x: p.x, z: p.z });
      if (this.follower.on > 0) this.follower.echo = 0.24;
      this.noise(p.x, p.z, radius, 'step');
      if (mode === 'run' && surface === 'leaf' && this.rng() < 0.07) {
        this.emit({ t: 'branch', x: p.x, z: p.z });
        this.noise(p.x, p.z, 26, 'branch');
      }
    }
  }

  surfaceKind(x, z) {
    if (waterDepth(x, z) > 0.05) return 'water';
    const s = surfaceY(x, z);
    if (s - heightAt(x, z) > 0.05) return 'wood';
    if (Math.hypot(x - 92, z - 0) < 16) return 'gravel';
    const t = nearestTrail(x, z);
    if (t.trail && t.dist < t.trail.width * 0.55) return 'dirt';
    if (CLEARINGS.some((c) => Math.hypot(x - c.x, z - c.z) < c.r * 0.7)) return 'dirt';
    return 'leaf';
  }

  // What the action button does right here. Returns {kind,label,...} or null.
  findInteraction() {
    const p = this.player;
    if (p.hidden) return { kind: 'leave', label: 'LEAVE' };
    if (p.vaultT > 0) return null;
    if (this.phase === 'play' || this.phase === 'intro') {
      if (this.phase === 'play') {
        if (Math.hypot(p.x - CAR.hood.x, p.z - CAR.hood.z) < 2.3 && this.has.battery && !this.batteryIn) {
          return { kind: 'battery', label: 'INSTALL BATTERY', hold: BATTERY_HOLD };
        }
        if (Math.hypot(p.x - CAR.door.x, p.z - CAR.door.z) < 2) {
          if (this.has.keys && this.batteryIn) return { kind: 'car', label: 'GET IN' };
          if (Math.hypot(p.x - CAR.door.x, p.z - CAR.door.z) < 1.8) {
            return { kind: 'carlook', label: 'LOOK', text: !this.has.keys && this.has.battery && !this.batteryIn ? 'No keys. The battery goes under the hood.' : !this.has.keys && !this.batteryIn ? 'No keys. No battery.' : !this.has.keys ? 'You need the keys.' : 'It needs the battery. The hood is up.' };
          }
        }
      }
      let best = null, bestD = 1.7;
      // A container can be searched from the first step of the night. Starting a search during the
      // opening ends the opening (see updateInteraction): the offer used to wait for the opening to
      // end, so a cabin entered straight away showed no SEARCH and no cross on the map.
      for (const s of LAYOUT.searches) {
        if (this.searched.has(s.id)) continue;
        const d = Math.hypot(s.wx - p.x, s.wz - p.z);
        if (d < bestD && !this.collision.wallBetween(p.x, p.z, s.wx, s.wz)) {
          best = { kind: 'search', label: 'SEARCH', spot: s, hold: SEARCH_HOLD };
          bestD = d;
        }
      }
      // While he is after her, a hiding place or a window right here wins over a container: a tap
      // must hide her, not start a search. Otherwise the container comes first, as it always has.
      const hunted = ['chase', 'strike'].includes(this.killer?.state);
      // A hiding place, a window and a door can all be in reach at once (a closet beside a cabin
      // door). The button takes the one she is facing: nearest first, turned-away ones marked down.
      // That holds in a chase too: facing the door she means to shut it on him, not to hide.
      const fx = Math.sin(p.yaw), fz = Math.cos(p.yaw);
      const rank = (x, z) => {
        const d = Math.hypot(x - p.x, z - p.z);
        if (d < 0.3) return d;
        return d + 0.9 * Math.acos(Math.max(-1, Math.min(1, ((x - p.x) * fx + (z - p.z) * fz) / d)));
      };
      let pick = null, pickScore = Infinity;
      const offer = (score, make) => { if (score < pickScore) { pickScore = score; pick = make; } };
      for (const h of this.hides) {
        const reach = h.type === 'bush' ? 1.9 : 1.15;
        if (Math.hypot(h.x - p.x, h.z - p.z) < reach) offer(rank(h.x, h.z), () => ({ kind: 'hide', label: 'HIDE', spot: h }));
      }
      for (const v of LAYOUT.vaults) {
        if (Math.hypot(v.ix - p.x, v.iz - p.z) < 1.05) offer(rank(v.ix, v.iz), () => ({ kind: 'vault', label: 'CLIMB OUT', from: [v.ix, v.iz], to: [v.ox, v.oz] }));
        if (Math.hypot(v.ox - p.x, v.oz - p.z) < 1.05) offer(rank(v.ox, v.oz), () => ({ kind: 'vault', label: 'CLIMB IN', from: [v.ox, v.oz], to: [v.ix, v.iz] }));
      }
      const refuge = pick; // a hide or a window, before any door is weighed
      // Reach grows with the door, so she can work it from beyond the leaf's swing rather than
      // only from inside it (the mess hall's 1.6 m door could not be shut without standing in its way).
      let door = null, dd = Infinity;
      for (const d of this.collision.doors) {
        const dist = Math.hypot(d.x - p.x, d.z - p.z);
        if (dist < Math.max(1.5, d.width + 0.95) && dist < dd) {
          dd = dist;
          door = d;
        }
      }
      if (door) offer(rank(door.x, door.z), () => ({ kind: 'door', label: door.open ? 'CLOSE DOOR' : 'OPEN DOOR', door }));
      if (best && !(hunted && refuge)) return best;
      if (pick) return pick();
    }
    return null;
  }

  updateInteraction(dt, input) {
    const p = this.player;
    const it = this.findInteraction();
    this.prompt = it;
    if (!it) {
      this.holdT = 0;
      this.holdTarget = null;
      return;
    }
    if (it.hold) {
      const target = it.kind === 'battery' ? 'battery:hood' : `search:${it.spot.id}`;
      if (this.holdTarget !== target) {
        this.holdT = 0;
        this.holdTarget = target;
      }
      if (input.actionHeld) {
        if (this.holdT === 0) {
          // She went looking before she reached the car: the night starts here, as it does when
          // the opening runs out, so everything a search leads to happens in the hunt proper.
          if (this.phase === 'intro') this.endOpening();
          this.emit({ t: it.kind === 'battery' ? 'batteryStart' : 'searchStart', x: p.x, z: p.z });
          this.noise(p.x, p.z, it.kind === 'battery' ? 16 : 7, 'rummage');
        }
        this.holdT += dt;
        if (it.kind === 'battery' && p.speed < 0.15) {
          // Face the engine while the battery goes in; the camera follows (F10).
          let diff = Math.atan2(CAR.hood.x - p.x, CAR.hood.z - p.z) - p.yaw;
          while (diff > Math.PI) diff -= Math.PI * 2;
          while (diff < -Math.PI) diff += Math.PI * 2;
          p.yaw += diff * (1 - Math.exp(-dt * 10));
        }
        if (this.holdT >= it.hold) {
          this.holdT = 0;
          this.holdTarget = null;
          if (it.kind === 'search') this.finishSearch(it.spot);
          else if (it.kind === 'battery') this.finishBattery();
        }
      } else {
        this.holdT = 0;
        this.holdTarget = null;
      }
      return;
    }
    this.holdT = 0;
    this.holdTarget = null;
    if (!input.action) return;
    switch (it.kind) {
      case 'hide': {
        // Check visibility at the actual entry position, whether E accepted a
        // current prompt or movement brought a new hiding place into reach.
        const k = this.killer;
        p.seenEntering = !['wait', 'lurk', 'kill'].includes(k.state) && k.observe().visible;
        p.hidden = it.spot;
        p.hiddenAt = this.time;
        if (p.seenEntering) {
          k.lastSeen = { x: p.x, z: p.z, vx: 0, vz: 0, t: this.time };
          k.beginChase();
          this.emit({ t: 'hideSeen', id: it.spot.id });
        }
        p.x = it.spot.x;
        p.z = it.spot.z;
        p.vx = p.vz = 0;
        this.emit({ t: 'hide', spot: it.spot });
        this.noise(p.x, p.z, it.spot.type === 'bush' ? 4 : 7, 'hide');
        break;
      }
      case 'leave':
        // Out of brush she steps the way she was looking, so she can turn round in it first.
        if (p.hidden.type === 'bush' && Number.isFinite(input.leaveYaw)) p.yaw = input.leaveYaw;
        this.emit({ t: 'unhide', spot: p.hidden });
        p.hidden = null;
        p.seenEntering = false;
        break;
      case 'vault':
        p.vaultT = 0.7;
        p.vaultFrom = it.from;
        p.vaultTo = it.to;
        this.emit({ t: 'vault', x: p.x, z: p.z });
        this.noise(p.x, p.z, 8, 'vault');
        break;
      case 'door': {
        const d = it.door;
        if (this.closeBehind?.door === d) break; // already on its way shut
        if (d.open) {
          // In the doorway itself the leaf would stop against her. If she means to be inside (the
          // stick, or where he is, says so; else she is already over the line) she steps in first
          // and it shuts behind her.
          const mag = Math.hypot(input.moveX || 0, input.moveY || 0);
          const fx = Math.sin(input.camYaw || 0), fz = Math.cos(input.camYaw || 0);
          const side = doorwayStand(d, p.x, p.z, PLAYER.radius, {
            dx: mag > 0.2 ? (fx * input.moveY - fz * input.moveX) / mag : 0,
            dz: mag > 0.2 ? (fz * input.moveY + fx * input.moveX) / mag : 0,
            avoid: ['wait', 'lurk'].includes(this.killer.state) ? null : this.killer,
          });
          if (side > 0) { this.closeBehind = { door: d, t: 0 }; break; }
        }
        this.setDoor(d, !d.open);
        break;
      }
      case 'car':
        p.inCar = true;
        this.phase = 'car';
        // If he is already close, the clock is shorter.
        this.car.threat = Math.hypot(this.killer.x - p.x, this.killer.z - p.z) < 18 ? 3 : 0;
        this.emit({ t: 'carEnter' });
        break;
      case 'carlook':
        this.emit({ t: 'line', text: it.text });
        break;
      default:
        break;
    }
  }

  finishSearch(spot) {
    this.searched.add(spot.id);
    const hasKeys = this.items.keys === spot.id;
    const hasBatt = this.items.battery === spot.id;
    if (hasKeys || hasBatt) {
      const what = hasKeys ? 'keys' : 'battery';
      this.has[what] = true;
      this.act = (this.has.keys ? 1 : 0) + (this.has.battery ? 1 : 0);
      this.director.sinceContact = this.tune.pressure; // finding it wakes the night up
      if (this.act === 1) this.screamT = 7 + this.rng() * 5;
      this.emit({ t: 'found', what, text: FOUND_LINES[what], x: spot.wx, z: spot.wz, spot: spot.id });
      this.noise(this.player.x, this.player.z, 20, 'found');
    } else {
      this.emit({ t: 'nothing', text: nothingLine(spot.id), x: spot.wx, z: spot.wz, spot: spot.id });
      this.empties++;
      if (!this.dropped && spot.building && this.empties >= this.dropAfter) {
        this.dropped = true;
        this.dropT = 1.5;
        this.dropSpot = spot;
      }
    }
  }

  finishBattery() {
    this.batteryIn = true;
    this.emit({ t: 'batteryIn' });
    this.noise(this.player.x, this.player.z, 22, 'battery');
  }

  updateCar(dt, input) {
    const c = this.car;
    c.threat += dt;
    if (c.crank > 0) {
      if (input.action) c.buffered = true;
      c.crank -= dt;
      if (c.crank <= 0) {
        if (c.tries >= c.need) {
          this.phase = 'escaped';
          this.emit({ t: 'engineStart' });
          return;
        }
        this.emit({ t: 'crankFail', tries: c.tries, need: c.need });
      }
    }
    if (c.crank <= 0 && (input.action || c.buffered)) {
      c.buffered = false;
      c.tries++;
      c.crank = 1.3;
      this.emit({ t: 'crank', tries: c.tries, need: c.need });
      if (c.tries === c.need) c.threat = Math.min(c.threat, 8); // the last try always gets its chance
    }
    if (c.threat > 13) this.kill('car');
  }

  // The night turns: wind, then storm, once you have something he wants to keep from you.
  updateNight(dt) {
    const target = this.act === 0 ? Math.min(0.25, this.time / 500) : this.act === 1 ? 0.55 : 1;
    this.storm += (target - this.storm) * (1 - Math.exp(-dt * 0.04));
    this.lightningT -= dt;
    if (this.lightningT <= 0 && this.storm > 0.3) {
      this.lightningT = 11 + this.rng() * (30 - this.storm * 16);
      this.emit({ t: 'lightning', strength: 0.5 + this.rng() * 0.5 });
    }
    if (this.dropT > 0) {
      this.dropT -= dt;
      if (this.dropT <= 0) {
        if (this.player.hidden) this.dropT = 0.2; // not while she is shut in a hiding place
        else this.dropBody();
      }
    }
    // Somebody else is still out here. For a moment.
    if (this.screamT > 0) {
      this.screamT -= dt;
      if (this.screamT <= 0) this.emit({ t: 'scream', x: -40, z: 70 });
    }
    // If he is really out there in front of you, the sky shows you.
    this.revealT -= dt;
    if (this.revealT <= 0 && this.storm > 0.3 && this.inViewAtDistance()) {
      this.revealT = 70;
      this.lightningT = 12 + this.rng() * 10;
      this.emit({ t: 'lightning', strength: 0.95, reveal: true });
    }
    this.scareT -= dt;
    if (this.scareT <= 0) {
      this.scareT = 38 + this.rng() * 50;
      const d = this.collision.doors[Math.floor(this.rng() * this.collision.doors.length)];
      const pick = this.rng();
      if (pick < 0.4 && Math.hypot(d.x - this.player.x, d.z - this.player.z) < 60) {
        // A door slams somewhere in the dark. It may even have been him.
        this.emit({ t: 'distantDoor', x: d.x, z: d.z });
      } else if (pick < 0.75) {
        this.emit({ t: 'branchNear', x: this.player.x + (this.rng() - 0.5) * 30, z: this.player.z + (this.rng() - 0.5) * 30 });
      }
    }
    const p = this.player;
    this.signText = null;
    for (const s of SIGNS) if (Math.hypot(s.x - p.x, s.z - p.z) < 3.2) this.signText = s.text;
  }

  // Close enough to see, and to one side so she is not standing in front of it.
  dropBody() {
    const p = this.player, s = this.dropSpot, c = this.collision;
    const near = Math.hypot(p.x - s.wx, p.z - s.wz) < 5;
    let x = s.wx, z = s.wz;
    if (near) {
      x = (p.x + s.wx) / 2;
      z = (p.z + s.wz) / 2;
      const fx = Math.sin(p.yaw), fz = Math.cos(p.yaw);
      for (const [f, r] of [[1.35, 0.5], [1.35, -0.5], [1.1, 0.7], [1.1, -0.7]]) {
        const tx = p.x + fx * f - fz * r, tz = p.z + fz * f + fx * r;
        if (!c.blocked(tx, tz, 0.3) && !c.wallBetween(p.x, p.z, tx, tz) && this.buildingAt(tx, tz)?.id === this.buildingAt(s.wx, s.wz)?.id) {
          x = tx;
          z = tz;
          break;
        }
      }
    }
    this.emit({ t: 'body', x, z, yaw: Math.atan2(p.x - x, p.z - z), near });
    this.noise(x, z, 14, 'body');
  }

  inViewAtDistance() {
    const p = this.player, k = this.killer;
    if (p.hidden || k.state === 'chase' || k.state === 'strike' || k.state === 'wait') return false;
    const dx = k.x - p.x, dz = k.z - p.z, d = Math.hypot(dx, dz);
    if (d < 9 || d > 38) return false;
    let off = Math.atan2(dx, dz) - p.yaw;
    while (off > Math.PI) off -= Math.PI * 2;
    while (off < -Math.PI) off += Math.PI * 2;
    return Math.abs(off) < 0.7 && this.collision.sightOpacity(p.x, p.z, k.x, k.z) < 0.8;
  }

  // Twice a night at most, out in the open, something keeps step behind you. When you stop, it takes
  // one more step and stops too. It is never him, and it never sounds like him: his steps stay honest.
  updateFollower(dt) {
    const f = this.follower, p = this.player, k = this.killer;
    if (f.echo > 0) {
      f.echo -= dt;
      if (f.echo <= 0) this.emit({ t: 'followStep', x: p.x - Math.sin(p.yaw) * 8, z: p.z - Math.cos(p.yaw) * 8 });
    }
    if (f.on > 0) {
      f.on -= dt;
      if (p.speed < 0.3) {
        f.on = 0;
        f.echo = 0.85;
      }
      return;
    }
    f.wait -= dt;
    if (f.wait > 0 || f.uses >= 2) return;
    if (p.speed > 1 && !p.building && !p.hidden && k.state !== 'chase' && Math.hypot(k.x - p.x, k.z - p.z) > 38) {
      f.uses++;
      f.on = 7 + this.rng() * 5;
      f.wait = 90 + this.rng() * 60;
    }
  }

  // 0 calm .. 1 he is on top of you. Drives heartbeat, music and the red at the edge of the screen.
  intensity() {
    const k = this.killer;
    if (k.state === 'wait' || k.state === 'lurk' || k.state === 'kill') return 0;
    const d = Math.hypot(k.x - this.player.x, k.z - this.player.z);
    const near = Math.max(0, 1 - d / 26);
    let v = near * near * 0.75;
    if (k.state === 'chase' || k.state === 'strike') v = Math.max(v, 0.6 + near * 0.4);
    else if (k.state === 'investigate' || k.state === 'notice') v = Math.max(v, 0.3 + near * 0.35);
    else if (k.state === 'search' || k.state === 'checkhide') v = Math.max(v, 0.22 + near * 0.4);
    return Math.min(1, v);
  }
}
