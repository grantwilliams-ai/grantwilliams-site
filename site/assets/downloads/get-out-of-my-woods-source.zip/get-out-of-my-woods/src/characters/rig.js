// Bone hierarchy, the pose system with crossfade, and the two bits of IK that keep figures honest:
// planar two-bone leg IK (feet planted, no skating) and arm IK onto the pitchfork handle.
import * as THREE from 'three';

const DOWN = new THREE.Vector3(0, -1, 0);
const ORDER = 'YXZ';

// def.bones: [name, parent|null, [x,y,z] joint position in model space at bind pose]
export class Rig {
  constructor(def) {
    this.root = new THREE.Group();
    this.names = def.bones.map((b) => b[0]);
    this.idx = {};
    this.bones = [];
    this.at = [];
    def.bones.forEach(([name, parent, at], i) => {
      this.idx[name] = i;
      const bone = new THREE.Bone();
      bone.name = name;
      const pa = parent ? def.bones[this.idx[parent]][2] : [0, 0, 0];
      bone.position.set(at[0] - pa[0], at[1] - pa[1], at[2] - pa[2]);
      (parent ? this.bones[this.idx[parent]] : this.root).add(bone);
      this.bones.push(bone);
      this.at.push(at);
    });
    this.root.updateMatrixWorld(true); // the inverse bind matrices are taken from this pose
    this.skeleton = new THREE.Skeleton(this.bones);
    this.rest = this.bones.map((b) => b.position.clone());
    this.dims = def.dims;
  }
  b(name) {
    return this.bones[this.idx[name]];
  }
  // Skinned mesh sharing this skeleton. frustumCulled is off: bounds are for the bind pose.
  skinned(geometry, material) {
    const m = new THREE.SkinnedMesh(geometry, material);
    m.frustumCulled = false;
    m.castShadow = true;
    this.root.add(m);
    m.bind(this.skeleton, new THREE.Matrix4());
    return m;
  }
}

const OFF_FORK_P = 3, OFF_FORK_R = 6, OFF_GRIP = 9, OFF_EX = 13, OFF_ROT = 17;

export class Pose {
  constructor(idx, nb) {
    this.idx = idx;
    this.nb = nb;
    this.a = new Float32Array(OFF_ROT + nb * 3);
  }
  clear() {
    this.a.fill(0);
    return this;
  }
  rot(name, x, y, z) {
    const o = OFF_ROT + this.idx[name] * 3;
    this.a[o] = x; this.a[o + 1] = y; this.a[o + 2] = z;
    return this;
  }
  addRot(name, x, y, z) {
    const o = OFF_ROT + this.idx[name] * 3;
    this.a[o] += x; this.a[o + 1] += y; this.a[o + 2] += z;
    return this;
  }
  pel(x, y, z) {
    this.a[0] = x; this.a[1] = y; this.a[2] = z;
    return this;
  }
  fork(px, py, pz, rx, ry, rz) {
    const a = this.a;
    a[OFF_FORK_P] = px; a[OFF_FORK_P + 1] = py; a[OFF_FORK_P + 2] = pz;
    a[OFF_FORK_R] = rx; a[OFF_FORK_R + 1] = ry; a[OFF_FORK_R + 2] = rz;
    return this;
  }
  // hand IK onto the fork: weight and distance along the handle (m from the fork origin)
  grip(wR, uR, wL = 0, uL = 0) {
    const a = this.a;
    a[OFF_GRIP] = wR; a[OFF_GRIP + 1] = wL; a[OFF_GRIP + 2] = uR; a[OFF_GRIP + 3] = uL;
    return this;
  }
  ex(i, v) {
    this.a[OFF_EX + i] = v;
    return this;
  }
  getEx(i) {
    return this.a[OFF_EX + i];
  }
  copy(o) {
    this.a.set(o.a);
    return this;
  }
  lerp(b, w) {
    const a = this.a, c = b.a;
    for (let i = 0; i < a.length; i++) a[i] += (c[i] - a[i]) * w;
    return this;
  }
}

// ---- legs ---------------------------------------------------------------------------------
// Planar two-bone IK. Target is where the ankle should be relative to the hip joint:
// x sideways (outward positive), y up (negative = below hip), z forward. Returns thigh/shin angles.
const _leg = { a: 0, k: 0, abd: 0 };
export function solveLeg(L1, L2, x, y, z) {
  const g0 = Math.hypot(x, y);
  const abd = Math.atan2(x, Math.max(0.01, -y));
  let f = z, g = g0;
  let d = Math.hypot(f, g);
  const max = (L1 + L2) * 0.9995, min = Math.abs(L1 - L2) + 0.02;
  if (d > max) { const s = max / d; f *= s; g *= s; d = max; }
  if (d < min) { const s = min / d; f *= s; g *= s; d = min; }
  const cosK = (d * d - L1 * L1 - L2 * L2) / (2 * L1 * L2);
  const k = Math.acos(Math.max(-1, Math.min(1, cosK)));
  const phi = Math.atan2(L2 * Math.sin(k), L1 + L2 * Math.cos(k));
  _leg.a = Math.atan2(f, g) + phi; // thigh forward angle
  _leg.k = k;
  _leg.abd = abd;
  return _leg;
}

// Foot trajectory in the pelvis frame. phase 0..1: stance (foot slides back at exactly body speed,
// so it cannot skate) for `duty`, then swing. Returns z offset and lift via the shared object.
const _foot = { z: 0, lift: 0, psi: 0, stance: true };
export function gaitFoot(ph, g) {
  ph -= Math.floor(ph);
  if (ph < g.duty) {
    const s = ph / g.duty;
    _foot.z = g.S * (0.5 - s) + (g.zOff || 0);
    _foot.lift = 0;
    // heel strike, flat, then the heel peels up: weight rolls from heel to toe
    _foot.psi = s < 0.3 ? g.toe * (1 - s / 0.3) : -g.roll * Math.pow((s - 0.3) / 0.7, 1.6);
    _foot.stance = true;
  } else {
    const s = (ph - g.duty) / (1 - g.duty);
    const e = 0.5 - 0.5 * Math.cos(Math.PI * s);
    _foot.z = g.S * (-0.5 + e) + (g.zOff || 0);
    _foot.lift = g.lift * Math.sin(Math.PI * Math.pow(s, 0.85));
    _foot.psi = -g.roll * (1 - s) + g.toe * s * 0.5;
    _foot.stance = false;
  }
  return _foot;
}

// Aim one leg. (tx,ty,tz): ankle target relative to the hip in the pelvis frame.
// pr: pelvis rotation already applied (x,y,z), cancelled so the foot lands where asked.
export function legTo(P, side, D, tx, ty, tz, psi, pr = [0, 0, 0]) {
  const r = solveLeg(D.L1, D.L2, tx, ty, tz);
  const t = side === 'L' ? 'thighL' : 'thighR';
  const s = side === 'L' ? 'shinL' : 'shinR';
  const f = side === 'L' ? 'footL' : 'footR';
  const b = r.a - r.k; // shin forward angle in the pelvis frame
  const sg = side === 'L' ? 1 : -1;
  P.rot(t, -r.a - pr[0], -pr[1], sg * r.abd - pr[2]);
  P.rot(s, r.k, 0, 0);
  P.rot(f, b - psi, 0, 0);
}

// ---- the animator -------------------------------------------------------------------------
// anims: { name: { fn(P, st), rate(speed, st) -> cycles/s, fade, loop } }
export class Animator {
  constructor(rig, anims, opts = {}) {
    this.rig = rig;
    this.anims = anims;
    this.P = new Pose(rig.idx, rig.bones.length);
    this.Q = new Pose(rig.idx, rig.bones.length);
    this.transitionPose = new Pose(rig.idx, rig.bones.length);
    this.appliedPose = null;
    this.holdPreviousPose = false;
    this.cur = null;
    this.prev = null;
    this.fade = 1;
    this.fadeT = 0.2;
    this.speed = 0;
    this.lookYaw = 0;
    this.lookPitch = 0;
    this.lookWeight = opts.lookWeight ?? 1;
    this.head = rig.b('head');
    this.pelvis = rig.b('pelvis');
    this.fork = rig.idx.fork !== undefined ? rig.b('fork') : null;
    this.arms = opts.arms || null; // IK description
    this.post = opts.post || null; // function(rig, pose, dt) called after pose is applied (secondary motion)
    this.name = null;
    this._tmp = { q: new THREE.Quaternion(), q2: new THREE.Quaternion(), v: new THREE.Vector3(), v2: new THREE.Vector3(), v3: new THREE.Vector3(), m: new THREE.Matrix4() };
    this.extra = {}; // per-frame values the anim functions export (e.g. light arm weight)
    // Only declared animation outputs blend. Live inputs such as light/aim must
    // keep responding immediately instead of being restored from an old pose.
    this.blendExtras = opts.blendExtras || [];
    this.transitionExtra = {};
    this.appliedExtra = {};
    this.currentExtra = {};
  }

  has(name) {
    return !!this.anims[name];
  }

  setAnim(name, opts = {}) {
    const def = this.anims[name];
    if (!def) return;
    if (this.cur && this.cur.name === name && !opts.restart) {
      this.cur.opts = opts;
      return;
    }
    // A new request can arrive before the previous blend finishes. Start from
    // the pose the viewer actually saw, not that blend's unreached destination.
    // Capture the base pose only: look/IK/contact corrections are reapplied once.
    this.holdPreviousPose = !!(this.prev && this.fade < 1 && this.appliedPose);
    if (this.holdPreviousPose) {
      this.transitionPose.copy(this.appliedPose);
      for (const key of this.blendExtras) this.transitionExtra[key] = this.appliedExtra[key];
    }
    this.prev = this.cur;
    this.cur = { name, def, t: 0, phase: this.cur ? this.cur.phase : 0, opts };
    this.name = name;
    this.fade = 0;
    this.fadeT = Math.max(0.001, opts.fade ?? def.fade ?? 0.22);
    if (opts.phase !== undefined) this.cur.phase = opts.phase;
  }

  _eval(a, P, dt, speed) {
    a.t += dt;
    const rate = a.def.rate ? a.def.rate(speed, a) : 0;
    a.phase += rate * dt;
    a.speed = speed;
    P.clear();
    a.def.fn(P, a, this.extra);
  }

  update(dt, o = {}) {
    const speed = o.speed || 0;
    if (o.anim && o.anim !== this.name) this.setAnim(o.anim, o.opts || {});
    if (!this.cur) return;
    this.speed = speed;
    this._eval(this.cur, this.P, dt, speed);
    if (this.prev && this.fade < 1) {
      for (const key of this.blendExtras) this.currentExtra[key] = this.extra[key];
      this.fade = Math.min(1, this.fade + dt / this.fadeT);
      if (this.holdPreviousPose) this.Q.copy(this.transitionPose);
      else this._eval(this.prev, this.Q, dt, speed);
      const w = this.fade * this.fade * (3 - 2 * this.fade);
      this.Q.lerp(this.P, w);
      for (const key of this.blendExtras) {
        const from = this.holdPreviousPose ? this.transitionExtra[key] : this.extra[key];
        const to = this.currentExtra[key];
        if (Number.isFinite(from) && Number.isFinite(to)) this.extra[key] = from + (to - from) * w;
      }
      this.appliedPose = this.Q;
      for (const key of this.blendExtras) this.appliedExtra[key] = this.extra[key];
      this.apply(this.Q, dt, o);
      if (this.fade >= 1) this.prev = null;
    } else {
      this.appliedPose = this.P;
      for (const key of this.blendExtras) this.appliedExtra[key] = this.extra[key];
      this.apply(this.P, dt, o);
    }
  }

  apply(P, dt, o) {
    const rig = this.rig, a = P.a, t = this._tmp;
    const e = new THREE.Euler(0, 0, 0, ORDER);
    for (let i = 0; i < rig.bones.length; i++) {
      const b = rig.bones[i];
      const k = OFF_ROT + i * 3;
      e.set(a[k], a[k + 1], a[k + 2], ORDER);
      b.quaternion.setFromEuler(e);
    }
    // head look: additive, smoothed, clamped, only as far as the neck can go
    let ty = 0, tp = 0;
    if (o.lookAt && this.lookWeight > 0) {
      this.rig.root.updateWorldMatrix(true, false);
      t.v.copy(o.lookAt);
      this.head.getWorldPosition(t.v2);
      t.v.sub(t.v2);
      t.m.copy(rig.root.matrixWorld).invert();
      t.v.transformDirection(t.m);
      ty = Math.max(-1.0, Math.min(1.0, Math.atan2(t.v.x, t.v.z))) * this.lookWeight;
      tp = Math.max(-0.45, Math.min(0.45, -Math.atan2(t.v.y, Math.hypot(t.v.x, t.v.z)))) * this.lookWeight;
    }
    const k = 1 - Math.exp(-5 * dt);
    this.lookYaw += (ty - this.lookYaw) * k;
    this.lookPitch += (tp - this.lookPitch) * k;
    if (Math.abs(this.lookYaw) + Math.abs(this.lookPitch) > 0.001) {
      const hi = this.rig.idx.head * 3 + OFF_ROT;
      e.set(a[hi] + this.lookPitch, a[hi + 1] + this.lookYaw, a[hi + 2], ORDER);
      this.head.quaternion.setFromEuler(e);
    }
    this.pelvis.position.set(rig.rest[rig.idx.pelvis].x + a[0], rig.rest[rig.idx.pelvis].y + a[1], rig.rest[rig.idx.pelvis].z + a[2]);
    if (this.fork) {
      this.fork.position.set(a[OFF_FORK_P], a[OFF_FORK_P + 1], a[OFF_FORK_P + 2]);
      e.set(a[OFF_FORK_R], a[OFF_FORK_R + 1], a[OFF_FORK_R + 2], ORDER);
      this.fork.quaternion.setFromEuler(e);
    }
    rig.root.updateMatrixWorld(true);
    if (this.arms && this.fork) {
      if (a[OFF_GRIP] > 0.001) this._arm('R', a[OFF_GRIP], a[OFF_GRIP + 2]);
      if (a[OFF_GRIP + 1] > 0.001) this._arm('L', a[OFF_GRIP + 1], a[OFF_GRIP + 3]);
    }
    if (this.post) this.post(rig, P, dt, this);
  }

  // Put one hand on the handle: two-bone IK, blended against the FK arm by weight w.
  _arm(side, w, u) {
    const A = this.arms[side], rig = this.rig, t = this._tmp;
    const upper = rig.b(A.upper), fore = rig.b(A.fore), hand = rig.b(A.hand), chest = rig.b('chest');
    const L1 = A.L1, L2 = A.L2;
    const S = t.v, T = t.v2, D = t.v3;
    upper.getWorldPosition(S);
    T.set(0, u, 0).applyMatrix4(this.fork.matrixWorld);
    D.copy(T).sub(S);
    let dist = D.length();
    D.divideScalar(dist || 1);
    dist = Math.min(dist, (L1 + L2) * 0.998);
    const cosA = (L1 * L1 + dist * dist - L2 * L2) / (2 * L1 * dist);
    const ang = Math.acos(Math.max(-1, Math.min(1, cosA)));
    // elbow hint lives in chest space so elbows stay out and down, never through the ribs
    const pole = new THREE.Vector3(A.pole[0], A.pole[1], A.pole[2]).applyQuaternion(chest.getWorldQuaternion(t.q));
    pole.addScaledVector(D, -pole.dot(D)).normalize();
    const elbow = S.clone().addScaledVector(D, Math.cos(ang) * L1).addScaledVector(pole, Math.sin(ang) * L1);
    const wrist = S.clone().addScaledVector(D, dist);
    const uDir = elbow.clone().sub(S).normalize();
    const fDir = wrist.clone().sub(elbow).normalize();

    // upper arm
    const pq = upper.parent.getWorldQuaternion(new THREE.Quaternion());
    const qU = new THREE.Quaternion().setFromUnitVectors(DOWN, uDir);
    const fkU = upper.quaternion.clone();
    upper.quaternion.copy(pq.clone().invert().multiply(qU));
    upper.quaternion.copy(fkU.slerp(upper.quaternion, w));
    upper.updateMatrixWorld(true);
    // forearm
    const uq = upper.getWorldQuaternion(new THREE.Quaternion());
    const qF = new THREE.Quaternion().setFromUnitVectors(DOWN, fDir);
    const fkF = fore.quaternion.clone();
    fore.quaternion.copy(uq.clone().invert().multiply(qF));
    fore.quaternion.copy(fkF.slerp(fore.quaternion, w));
    fore.updateMatrixWorld(true);
    // hand wraps the handle: knuckle line along the fork, fingers carrying on from the forearm
    const fq = fore.getWorldQuaternion(new THREE.Quaternion());
    const ax = new THREE.Vector3(0, 1, 0).transformDirection(this.fork.matrixWorld);
    const fwd = new THREE.Vector3(0, -1, 0).applyQuaternion(fq);
    const chestX = new THREE.Vector3(1, 0, 0).applyQuaternion(chest.getWorldQuaternion(new THREE.Quaternion()));
    if (ax.dot(chestX) < 0) ax.negate();
    const yy = fwd.addScaledVector(ax, -fwd.dot(ax)).negate();
    if (yy.lengthSq() < 1e-4) yy.set(0, 1, 0);
    yy.normalize();
    const zz = new THREE.Vector3().crossVectors(ax, yy);
    const qH = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(ax, yy, zz));
    const fkH = hand.quaternion.clone();
    hand.quaternion.copy(fq.invert().multiply(qH));
    hand.quaternion.copy(fkH.slerp(hand.quaternion, w));
    hand.updateMatrixWorld(true);
  }
}

export const smooth = (a, b, x) => {
  const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};
export const clamp01 = (x) => Math.max(0, Math.min(1, x));
