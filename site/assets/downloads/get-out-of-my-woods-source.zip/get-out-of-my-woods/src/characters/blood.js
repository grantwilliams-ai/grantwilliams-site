// Stylised blood: bright arterial droplets (instanced crossed quads, stretched along their velocity)
// that fall under gravity, and dark pooling decals on the ground that spread as they settle.
// Everything is pooled and preallocated; nothing is created inside burst() or update().
import * as THREE from 'three';
import { PALETTE } from '../render/palette.js';
import { heightAt } from '../sim/terrain.js';

const MAX_DROPS = 360;
const MAX_POOLS = 56;
const GRAVITY = -9.8;

export function createBlood(scene) {
  // droplet: two crossed thin quads along +y, so it reads from any angle
  const dg = new THREE.BufferGeometry();
  const w = 0.5, h = 0.5;
  const dpos = new Float32Array([
    -w * 0.5, -h, 0, w * 0.5, -h, 0, w * 0.5, h, 0, -w * 0.5, -h, 0, w * 0.5, h, 0, -w * 0.5, h, 0,
    0, -h, -w * 0.5, 0, -h, w * 0.5, 0, h, w * 0.5, 0, -h, -w * 0.5, 0, h, w * 0.5, 0, h, -w * 0.5,
  ]);
  dg.setAttribute('position', new THREE.BufferAttribute(dpos, 3));
  const dmat = new THREE.MeshBasicMaterial({ color: PALETTE.bloodBright, side: THREE.DoubleSide });
  const drops = new THREE.InstancedMesh(dg, dmat, MAX_DROPS);
  drops.frustumCulled = false;
  drops.count = 0;
  drops.renderOrder = 3;
  scene.add(drops);

  // pool decal: an irregular flat blob
  const pg = new THREE.BufferGeometry();
  const n = 9, pp = [];
  for (let i = 0; i < n; i++) {
    const a0 = (i / n) * Math.PI * 2, a1 = ((i + 1) / n) * Math.PI * 2;
    const r0 = 0.7 + 0.3 * Math.abs(Math.sin(i * 2.7 + 1)), r1 = 0.7 + 0.3 * Math.abs(Math.sin((i + 1) * 2.7 + 1));
    pp.push(0, 0, 0, Math.cos(a0) * r0, 0, -Math.sin(a0) * r0, Math.cos(a1) * r1, 0, -Math.sin(a1) * r1);
  }
  pg.setAttribute('position', new THREE.Float32BufferAttribute(pp, 3));
  const pmat = new THREE.MeshBasicMaterial({
    color: 0x3c0606, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4, depthWrite: false,
  });
  const pools = new THREE.InstancedMesh(pg, pmat, MAX_POOLS);
  pools.frustumCulled = false;
  pools.count = 0;
  pools.renderOrder = 1;
  scene.add(pools);

  // particle state
  const P = new Float32Array(MAX_DROPS * 9); // x y z vx vy vz life size floor
  const poolS = new Float32Array(MAX_POOLS * 6); // x y z target age rot
  let dHead = 0, pHead = 0, pCount = 0;
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), pos = new THREE.Vector3(), sc = new THREE.Vector3();
  const up = new THREE.Vector3(0, 1, 0), vd = new THREE.Vector3();
  const qy = new THREE.Quaternion(), yAxis = new THREE.Vector3(0, 1, 0);

  const api = {
    meshes: [drops, pools],
    ground: heightAt, // (x,z) -> ground height; the debug page swaps it for a flat floor
    // n droplets thrown from pos, mostly along dir (unit vector), with spread and a little lift
    burst(p, dir, count = 20, speed = 5) {
      for (let k = 0; k < count; k++) {
        const i = dHead;
        dHead = (dHead + 1) % MAX_DROPS;
        const o = i * 9;
        const s = speed * (0.35 + Math.random() * 0.9);
        const sx = (Math.random() - 0.5) * 0.9, sy = (Math.random() - 0.3) * 0.8, sz = (Math.random() - 0.5) * 0.9;
        P[o] = p.x; P[o + 1] = p.y; P[o + 2] = p.z;
        P[o + 3] = (dir.x + sx) * s; P[o + 4] = (dir.y + sy) * s + 1.2; P[o + 5] = (dir.z + sz) * s;
        P[o + 6] = 0.7 + Math.random() * 1.1; // life
        P[o + 7] = 0.025 + Math.random() * 0.05; // size
        P[o + 8] = api.ground(p.x, p.z);
      }
      if (drops.count < MAX_DROPS) drops.count = Math.min(MAX_DROPS, Math.max(drops.count, dHead || MAX_DROPS));
      if (count > 6) drops.count = MAX_DROPS;
    },
    // a single slow drop falling from pos (dripping off the fork, the body, the sack)
    drip(p) {
      const i = dHead;
      dHead = (dHead + 1) % MAX_DROPS;
      const o = i * 9;
      P[o] = p.x + (Math.random() - 0.5) * 0.04; P[o + 1] = p.y; P[o + 2] = p.z + (Math.random() - 0.5) * 0.04;
      P[o + 3] = 0; P[o + 4] = -0.3; P[o + 5] = 0;
      P[o + 6] = 3; P[o + 7] = 0.03; P[o + 8] = api.ground(p.x, p.z);
      drops.count = MAX_DROPS;
    },
    // a dark pool on the ground that spreads as it settles
    decal(p, size = 0.6) {
      const i = pHead;
      pHead = (pHead + 1) % MAX_POOLS;
      pCount = Math.min(MAX_POOLS, pCount + 1);
      const o = i * 6;
      poolS[o] = p.x; poolS[o + 1] = Number.isFinite(p.y) ? p.y : api.ground(p.x, p.z);
      poolS[o + 2] = p.z; poolS[o + 3] = size * (0.8 + Math.random() * 0.5); poolS[o + 4] = 0; poolS[o + 5] = Math.random() * 6.28;
      pools.count = pCount;
    },
    update(dt) {
      let alive = 0;
      for (let i = 0; i < MAX_DROPS; i++) {
        const o = i * 9;
        if (P[o + 6] <= 0) {
          sc.set(0, 0, 0);
          m4.makeScale(0, 0, 0);
          drops.setMatrixAt(i, m4);
          continue;
        }
        P[o + 6] -= dt;
        P[o + 4] += GRAVITY * dt;
        P[o + 3] *= 1 - 0.6 * dt; P[o + 5] *= 1 - 0.6 * dt;
        P[o] += P[o + 3] * dt; P[o + 1] += P[o + 4] * dt; P[o + 2] += P[o + 5] * dt;
        if (P[o + 1] <= P[o + 8]) {
          P[o + 6] = 0;
          if (Math.random() < 0.28) api.decal({ x: P[o], y: P[o + 8] + 0.015, z: P[o + 2] }, 0.07 + P[o + 7] * 4);
          m4.makeScale(0, 0, 0);
          drops.setMatrixAt(i, m4);
          continue;
        }
        alive++;
        vd.set(P[o + 3], P[o + 4], P[o + 5]);
        const sp = vd.length();
        const len = Math.min(0.22, 0.02 + sp * 0.016) * (P[o + 7] / 0.05);
        if (sp > 0.001) q.setFromUnitVectors(up, vd.multiplyScalar(1 / sp));
        else q.identity();
        qy.setFromAxisAngle(yAxis, i * 1.7);
        pos.set(P[o], P[o + 1], P[o + 2]);
        sc.set(P[o + 7] * 1.1, len, P[o + 7] * 1.1);
        m4.compose(pos, q, sc);
        drops.setMatrixAt(i, m4);
      }
      drops.instanceMatrix.needsUpdate = true;
      if (alive === 0 && drops.count > 0) drops.count = 0;
      for (let i = 0; i < pCount; i++) {
        const o = i * 6;
        poolS[o + 4] += dt;
        const s = poolS[o + 3] * (1 - Math.exp(-poolS[o + 4] * 1.6));
        pos.set(poolS[o], poolS[o + 1] + 0.012 + i * 0.0004, poolS[o + 2]);
        qy.setFromAxisAngle(yAxis, poolS[o + 5]);
        sc.set(s, 1, s);
        m4.compose(pos, qy, sc);
        pools.setMatrixAt(i, m4);
      }
      pools.instanceMatrix.needsUpdate = true;
    },
    clear() {
      P.fill(0);
      poolS.fill(0);
      pCount = 0; pHead = 0; dHead = 0;
      drops.count = 0;
      pools.count = 0;
    },
    dispose() {
      scene.remove(drops, pools);
      drops.dispose();
      pools.dispose();
      dg.dispose(); pg.dispose(); dmat.dispose(); pmat.dispose();
    },
  };
  api.clear();
  return api;
}
