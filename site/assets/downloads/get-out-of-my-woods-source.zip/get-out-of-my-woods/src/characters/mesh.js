// Low-poly mesh builder for the rigid-segment characters. Every part is a "loft": a stack of
// rounded-square rings joined into a tapered, bevelled solid. All parts are written into one
// geometry per material, bound rigidly (weight 1) to one bone each, so a whole figure costs a
// handful of draw calls.
import * as THREE from 'three';

const _c = new THREE.Color();
export function rgb(hex) {
  _c.setHex(hex); // converts sRGB to the linear working space, which is what vertex colours expect
  return [_c.r, _c.g, _c.b];
}
const mulc = (a, b) => [a[0] * b[0], a[1] * b[1], a[2] * b[2]];
const lerpc = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

export class MeshBuilder {
  constructor() {
    this.pos = [];
    this.uv = [];
    this.col = [];
    this.skin = [];
    this.mat = new THREE.Matrix4();
    this.bone = 0;
    this.uvScale = 3.2; // texture repeats per metre
    this.tint = [1, 1, 1];
    this._v = new THREE.Vector3();
  }

  // Place the following parts: attached to bone index `bone`, with origin at model-space `at`.
  part(bone, at, rot = [0, 0, 0]) {
    this.bone = bone;
    this.mat.compose(
      new THREE.Vector3(at[0], at[1], at[2]),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(rot[0], rot[1], rot[2], 'YXZ')),
      new THREE.Vector3(1, 1, 1),
    );
    return this;
  }

  vert(x, y, z, u, v, c) {
    this._v.set(x, y, z).applyMatrix4(this.mat);
    this.pos.push(this._v.x, this._v.y, this._v.z);
    this.uv.push(u, v);
    this.col.push(c[0], c[1], c[2]);
    this.skin.push(this.bone);
  }

  tri(a, b, c, ca, cb = ca, cc = ca) {
    this.vert(a[0], a[1], a[2], a[3] || 0, a[4] || 0, ca);
    this.vert(b[0], b[1], b[2], b[3] || 0, b[4] || 0, cb);
    this.vert(c[0], c[1], c[2], c[3] || 0, c[4] || 0, cc);
  }

  // Polygon fan around its centroid (stains, holes, patches, blades).
  // pts: [[x,y,z],...] in part-local space, counter-clockwise seen from the outside.
  // edge: optional colour at the rim, so the middle fades out (soft shadows, sunken sockets).
  fan(pts, color, edge) {
    const cx = pts.reduce((s, p) => s + p[0], 0) / pts.length;
    const cy = pts.reduce((s, p) => s + p[1], 0) / pts.length;
    const cz = pts.reduce((s, p) => s + p[2], 0) / pts.length;
    const k = this.uvScale;
    const e = edge || color;
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i], b = pts[(i + 1) % pts.length];
      this.tri([cx, cy, cz, cx * k, cy * k], [a[0], a[1], a[2], a[0] * k, a[1] * k], [b[0], b[1], b[2], b[0] * k, b[1] * k], color, e, e);
    }
  }

  // A stack of rings, bottom to top, each {y, rx, rz, ox, oz, c(hex), lump}.
  // opts: sides, sq (1 round .. 0.5 squarish), phase, capTop, capBot, color (hex multiplier)
  loft(rings, opts = {}) {
    // Limbs are authored shoulder-to-wrist; wind every loft outward regardless of order.
    const ordered = rings[0].y > rings[rings.length - 1].y ? [...rings].reverse() : rings;
    const g = ringGrid(ordered, opts);
    const n = g.n;
    const k = this.uvScale;
    const base = opts.color !== undefined ? rgb(opts.color) : this.tint;
    const rc = g.rings.map((r) => (r.c !== undefined ? mulc(base, rgb(r.c)) : base));
    let vAcc = 0;
    const vs = [0];
    for (let i = 1; i < g.rings.length; i++) {
      const a = g.rings[i - 1], b = g.rings[i];
      vAcc += Math.hypot(b.y - a.y, (b.rx - a.rx) * 0.5);
      vs.push(vAcc);
    }
    for (let i = 0; i < g.rings.length - 1; i++) {
      for (let j = 0; j < n; j++) {
        const j2 = (j + 1) % n;
        const a = g.p[i][j], b = g.p[i][j2], c = g.p[i + 1][j2], d = g.p[i + 1][j];
        const u0 = (j / n) * g.circ[i] * k, u1 = ((j + 1) / n) * g.circ[i] * k;
        const w0 = (j / n) * g.circ[i + 1] * k, w1 = ((j + 1) / n) * g.circ[i + 1] * k;
        const A = [...a, u0, vs[i] * k], B = [...b, u1, vs[i] * k], C = [...c, w1, vs[i + 1] * k], D = [...d, w0, vs[i + 1] * k];
        this.tri(A, B, C, rc[i], rc[i], rc[i + 1]);
        this.tri(A, C, D, rc[i], rc[i + 1], rc[i + 1]);
      }
    }
    const cap = (i, up) => {
      const r = g.rings[i];
      const cen = [r.ox || 0, r.y, r.oz || 0, (r.ox || 0) * k, (r.oz || 0) * k];
      for (let j = 0; j < n; j++) {
        const pa = g.p[i][j], pb = g.p[i][(j + 1) % n];
        const a = [pa[0], pa[1], pa[2], pa[0] * k, pa[2] * k];
        const b = [pb[0], pb[1], pb[2], pb[0] * k, pb[2] * k];
        if (up) this.tri(cen, a, b, rc[i]);
        else this.tri(cen, b, a, rc[i]);
      }
    };
    if (opts.capTop !== false) cap(g.rings.length - 1, true);
    if (opts.capBot !== false) cap(0, false);
    return g;
  }
}

// Ring vertex positions. Shared by loft() and the surface-conforming decals.
export function ringGrid(rings, opts = {}) {
  const n = opts.sides || 8;
  const sq = opts.sq === undefined ? 0.8 : opts.sq;
  const phase = opts.phase || 0;
  const p = [];
  const circ = [];
  for (const r of rings) {
    const row = [];
    for (let j = 0; j < n; j++) {
      const a = (j / n) * Math.PI * 2 + phase;
      // angle 0 faces +z; x = sin a. sq < 1 flattens the round section toward a bevelled box.
      const s = Math.sin(a), c = Math.cos(a);
      const sx = Math.sign(s) * Math.pow(Math.abs(s), sq);
      const cz = Math.sign(c) * Math.pow(Math.abs(c), sq);
      let m = 1;
      if (r.lump) m += r.lump * (Math.sin(a * 3 + r.y * 17) * 0.6 + Math.sin(a * 2 - r.y * 23 + 1.3) * 0.4);
      row.push([(r.ox || 0) + r.rx * sx * m, r.y, (r.oz || 0) + r.rz * cz * m]);
    }
    p.push(row);
    circ.push(Math.PI * (r.rx + r.rz));
  }
  return { n, rings, p, circ, sq, phase };
}

// Point on the lofted surface at angle `a` (0 = front, x = sin a) and height y, pushed out by `off`.
// Used so decals (eye holes, stains, STAFF letters) sit on the faceted skin without floating.
export function surfaceAt(g, a, y, off = 0.006) {
  const { n, rings, p } = g;
  let i = 0;
  while (i < rings.length - 2 && y > rings[i + 1].y) i++;
  const ty = Math.max(0, Math.min(1, (y - rings[i].y) / (rings[i + 1].y - rings[i].y)));
  let f = ((a - g.phase) / (Math.PI * 2)) * n;
  f = ((f % n) + n) % n;
  const j = Math.floor(f), j2 = (j + 1) % n, tx = f - j;
  const v = (r, c) => p[r][c];
  const lerp3 = (A, B, t) => [A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t];
  const lo = lerp3(v(i, j), v(i, j2), tx), hi = lerp3(v(i + 1, j), v(i + 1, j2), tx);
  const P = lerp3(lo, hi, ty);
  const e1 = [v(i, j2)[0] - v(i, j)[0], v(i, j2)[1] - v(i, j)[1], v(i, j2)[2] - v(i, j)[2]];
  const e2 = [v(i + 1, j)[0] - v(i, j)[0], v(i + 1, j)[1] - v(i, j)[1], v(i + 1, j)[2] - v(i, j)[2]];
  let nx = e1[1] * e2[2] - e1[2] * e2[1], ny = e1[2] * e2[0] - e1[0] * e2[2], nz = e1[0] * e2[1] - e1[1] * e2[0];
  const l = Math.hypot(nx, ny, nz) || 1;
  nx /= l; ny /= l; nz /= l;
  return { p: [P[0] + nx * off, P[1] + ny * off, P[2] + nz * off], n: [nx, ny, nz] };
}

export function toGeometry(mb, morphs, smooth = false) {
  const g = new THREE.BufferGeometry();
  const count = mb.pos.length / 3;
  g.setAttribute('position', new THREE.Float32BufferAttribute(mb.pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(mb.uv, 2));
  g.setAttribute('color', new THREE.Float32BufferAttribute(mb.col, 3));
  const si = new Uint16Array(count * 4);
  const sw = new Float32Array(count * 4);
  for (let i = 0; i < count; i++) {
    si[i * 4] = mb.skin[i];
    sw[i * 4] = 1;
  }
  g.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(si, 4));
  g.setAttribute('skinWeight', new THREE.Float32BufferAttribute(sw, 4));
  g.computeVertexNormals();
  if (smooth) {
    // Average only coincident vertices on the same rigid bone. UV seams no longer make a
    // cylinder look like a stack of disconnected triangles; flat decals keep their own normal.
    const normals = g.attributes.normal.array;
    const sums = new Map();
    const keys = [];
    for (let i = 0; i < count; i++) {
      const key = `${mb.skin[i]}:${mb.pos.slice(i * 3, i * 3 + 3).map(v => v.toFixed(5)).join(':')}`;
      keys.push(key);
      const v = sums.get(key) || [0, 0, 0];
      for (let j = 0; j < 3; j++) v[j] += normals[i * 3 + j];
      sums.set(key, v);
    }
    for (let i = 0; i < count; i++) {
      const v = sums.get(keys[i]), n = Math.hypot(...v) || 1;
      for (let j = 0; j < 3; j++) normals[i * 3 + j] = v[j] / n;
    }
  }
  g.computeBoundingSphere();
  if (morphs) {
    g.morphAttributes.position = morphs.map((m) => new THREE.Float32BufferAttribute(m, 3));
    g.morphTargetsRelative = true;
  }
  return g;
}

export { lerpc, mulc };
