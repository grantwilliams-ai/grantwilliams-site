// Render-only contact restraint. The AI root, reach, speed and navigation radius
// stay unchanged. Near opaque walls, door leaves and furniture the rig gathers
// its stride and draws the fork in across his body, instead of letting the
// authored metre-long lunge cross a panel.
import * as THREE from 'three';
import { Pose, legTo } from './rig.js';
import { doorSegment } from '../sim/collision.js';

const MAX_SHIFT = .32;
// A doorway's head frame hangs 2.12 m over the floor and the fork is 2.13 m
// long. While anything stands above DOOR_HEAD in an opening he gathers the fork
// right in; the limit eases up with distance from the wall line so the fork tips
// over a stride, not a frame. His hood is itself taller than a door (2.26 m),
// so in practice he carries the fork across his body through every doorway.
// (Testing the fork alone gathered less and let it catch the head frame when
// he turned in a doorway.)
const DOOR_HEAD = 2.07, HEAD_EASE = .25;
// Closet frames, louvres and bunk rails stand up to 9 cm proud of their collision box.
const FURNITURE_GAP = .12;
const HEAD_ROT = 17; // Pose keeps bone rotations from index 17 (see rig.js)
const DIRECTIONS = [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1],
  ...[-1,1].flatMap(x=>[-1,1].flatMap(y=>[-1,1].map(z=>[x,y,z]))),
  ...[-1,1].flatMap(a=>[-1,1].flatMap(b=>[[a,b,0],[a,0,b],[0,a,b]]))];
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));

// A fixed skin-envelope sample, selected once after tailoring. Extremes are
// retained for each dominant bone; no full-mesh scan runs in the frame loop.
function envelope(figure) {
  const probes=[];
  for(const mesh of figure.meshes){
    const pos=mesh.geometry.attributes.position,skin=mesh.geometry.attributes.skinIndex;
    const groups=new Map();
    for(let i=0;i<pos.count;i++){
      const bone=skin.getX(i);let group=groups.get(bone);
      if(!group){group=DIRECTIONS.map(()=>({score:-Infinity,index:0}));groups.set(bone,group);}
      for(let d=0;d<DIRECTIONS.length;d++){
        const axis=DIRECTIONS[d],score=pos.getX(i)*axis[0]+pos.getY(i)*axis[1]+pos.getZ(i)*axis[2];
        if(score>group[d].score)group[d]={score,index:i};
      }
    }
    const indices=new Set([...groups.values()].flatMap(group=>group.map(p=>p.index)));
    // The fork is one long thin bone. Its extremes alone let a door jamb, a bunk
    // post or a closet edge pass between two probes, so sample its whole length:
    // one vertex for each 9 cm of handle and of every tine.
    const fork=figure.rig.idx.fork,cells=new Set();
    for(let i=0;i<pos.count;i++){
      if(skin.getX(i)!==fork)continue;
      const cell=Math.round(pos.getX(i)/.06)+':'+Math.round(pos.getY(i)/.09);
      if(!cells.has(cell)){cells.add(cell);indices.add(i);}
    }
    for(const index of indices)probes.push({mesh,index});
  }
  return probes;
}

// A solid box seen from where he stands (root): null when out of reach or when
// the root is inside it. sx/sz name the faces he can stand in front of.
function boxNear(x,z,hx,hz,yaw,top,bottom,root,reach,gap) {
  const c=Math.cos(yaw),sn=Math.sin(yaw),dx=root.x-x,dz=root.z-z,lx=dx*c-dz*sn,lz=dx*sn+dz*c;
  const distance=Math.hypot(Math.max(0,Math.abs(lx)-hx),Math.max(0,Math.abs(lz)-hz));
  if(distance>reach||distance===0)return {distance,box:null};
  return {distance,box:{box:true,x,z,c,sn,hx:hx+gap,hz:hz+gap,top,bottom,sx:lx>hx?1:lx<-hx?-1:0,sz:lz>hz?1:lz<-hz?-1:0}};
}
// How far a point inside the box must travel to leave by a face he can stand
// in front of; the shorter way when he stands off a corner. 0 = not inside.
function boxExit(box,x,z,y,rootY,out) {
  if(y<rootY+Math.max(.08,box.bottom)||y>rootY+box.top)return 0;
  const dx=x-box.x,dz=z-box.z,lx=dx*box.c-dz*box.sn,lz=dx*box.sn+dz*box.c;
  if(Math.abs(lx)>=box.hx||Math.abs(lz)>=box.hz)return 0;
  const ex=box.sx?box.hx-box.sx*lx:Infinity,ez=box.sz?box.hz-box.sz*lz:Infinity;
  if(out){if(ex<=ez)out.x=Math.max(out.x,ex);else out.z=Math.max(out.z,ez);}
  return Math.min(ex,ez);
}
const exit={x:0,z:0};
function pushFromBox(box,points,offset,rootY) {
  exit.x=exit.z=0;
  for(let i=0;i<points.length;i+=3)boxExit(box,points[i]+offset.x,points[i+2]+offset.z,points[i+1],rootY,exit);
  // The box's own +x is (c,-sn) in the world and its +z is (sn,c).
  offset.x+=box.sx*exit.x*box.c+box.sz*exit.z*box.sn;
  offset.z+=-box.sx*exit.x*box.sn+box.sz*exit.z*box.c;
}

export function createWallClearance(figure) {
  const a=figure.animator,rig=figure.rig,base=new Pose(rig.idx,rig.bones.length),compact=new Pose(rig.idx,rig.bones.length),pose=new Pose(rig.idx,rig.bones.length);
  const probes=envelope(figure),points=new Float32Array(probes.length*3),point=new THREE.Vector3(),root=new THREE.Vector3(),offset=new THREE.Vector3(),local=new THREE.Vector3(),inverse=new THREE.Quaternion();
  let releasedWeight=0;
  function upright() {
    // He still turns and tilts his head the way the moment asks; only its
    // forward reach is taken back with the rest of him.
    const head=HEAD_ROT+rig.idx.head*3;
    compact.clear().pel(0,-.05,0).rot('spine',.03,0,0).rot('chest',.02,0,0).rot('head',-.05,base.a[head+1],base.a[head+2])
      .rot('uarmL',-.1,0,-.16).rot('uarmR',-.1,0,.16).rot('farmL',-.25,0,0).rot('farmR',-.25,0,0);
    for(const side of ['L','R'])legTo(compact,side,rig.dims,.02,-(.95-rig.dims.ankle),side==='L'?.04:-.04,0);
    // Keep the right-hand IK attachment throughout every intermediate blend.
    // The other hand may release its support as the fork gathers in.
    // Held across his body, butt by the right boot and tines over the left
    // shoulder: 0.35 rad of lean keeps the whole fork inside his own width and
    // under 2.06 m. Stood straight up it reached 2.21 m, into every door head.
    compact.fork(-.35,-.79,.27,0,0,-.35).grip(1,.75);
  }
  function wallsNear(collision){
    const walls=[],heads=[];let nearestWallDistance=Infinity;
    const add=(x1,z1,x2,z2,thickness,top=2.8,list=walls)=>{
      const dx=x2-x1,dz=z2-z1,length=Math.hypot(dx,dz);if(length<1e-6)return;
      const ux=dx/length,uz=dz/length,t=clamp((root.x-x1)*ux+(root.z-z1)*uz,0,length);
      const distance=Math.hypot(root.x-x1-ux*t,root.z-z1-uz*t);
      if(list===walls)nearestWallDistance=Math.min(nearestWallDistance,distance);
      if(distance>2.7)return;
      let nx=-uz,nz=ux;if((root.x-x1)*nx+(root.z-z1)*nz<0){nx=-nx;nz=-nz;}
      list.push({x1,z1,length,ux,uz,nx,nz,thickness,top});
    };
    for(const w of collision.walls||[])add(w.x1,w.z1,w.x2,w.z2,w.t??.13);
    for(const d of collision.doors||[]){
      const leaf=doorSegment(d);add(leaf.x1,leaf.z1,leaf.x2,leaf.z2,.09);
      // The opening itself, hinge to latch: only its head frame is solid.
      add(d.hx,d.hz,d.ex,d.ez,.13,2.8,heads);
    }
    // Furniture: bunks, closets, lockers, tables. A box is solid only up to its
    // own height, and the fork is pushed out through the side he stands on.
    // Boxes are solved before the walls in every pass, so where a bunk and a
    // wall leave him no room it is the wall that is kept clear.
    const boxes=[];
    for(const s of collision.solids||[]){
      const {distance,box}=boxNear(s.x,s.z,s.hx,s.hz,s.rot||0,s.h??2.8,0,root,2.7,FURNITURE_GAP);
      nearestWallDistance=Math.min(nearestWallDistance,distance);
      if(box)boxes.push(box);
    }
    return {walls:boxes.concat(walls),heads,nearestWallDistance};
  }
  function applyPose(weight){
    pose.copy(base).lerp(compact,weight);a.apply(pose,0,{});
    rig.root.updateMatrixWorld(true);rig.skeleton.update();
    for(let i=0;i<probes.length;i++){
      const probe=probes[i];probe.mesh.getVertexPosition(probe.index,point).applyMatrix4(probe.mesh.matrixWorld);
      points[i*3]=point.x;points[i*3+1]=point.y;points[i*3+2]=point.z;
    }
  }
  function project(walls){
    offset.set(0,0,0);
    // Finite wall faces: do not extend an imaginary plane across open doorways.
    // The small margin covers probe sparsity and raised plank/trim detail.
    for(let pass=0;pass<3;pass++)for(const wall of walls){
      if(wall.box){pushFromBox(wall,points,offset,root.y);continue;}
      let push=0;
      for(let i=0;i<points.length;i+=3){
        if(points[i+1]<root.y+.08||points[i+1]>root.y+wall.top)continue;
        const x=points[i]+offset.x,z=points[i+2]+offset.z;
        const along=(x-wall.x1)*wall.ux+(z-wall.z1)*wall.uz;
        if(along<0||along>wall.length)continue;
        const distance=(x-wall.x1)*wall.nx+(z-wall.z1)*wall.nz;
        push=Math.max(push,wall.thickness+.06-distance);
      }
      if(push>0){offset.x+=wall.nx*push;offset.z+=wall.nz*push;}
    }
    return offset.length();
  }
  function unresolved(walls){
    for(const wall of walls)for(let i=0;i<points.length;i+=3){
      const x=points[i]+offset.x,z=points[i+2]+offset.z;
      if(wall.box){if(boxExit(wall,x,z,points[i+1],root.y)>.02)return true;continue;}
      if(points[i+1]<root.y+.08||points[i+1]>root.y+wall.top)continue;
      const along=(x-wall.x1)*wall.ux+(z-wall.z1)*wall.uz;
      if(along<0||along>wall.length)continue;
      if((x-wall.x1)*wall.nx+(z-wall.z1)*wall.nz<wall.thickness+.04)return true;
    }
    return false;
  }
  // Is anything standing taller than a door head inside (or closing on) an opening?
  function underDoorHead(heads){
    for(const head of heads)for(let i=0;i<points.length;i+=3){
      const over=points[i+1]-root.y-DOOR_HEAD;if(over<=0)continue;
      const x=points[i]+offset.x,z=points[i+2]+offset.z;
      const along=(x-head.x1)*head.ux+(z-head.z1)*head.uz;
      if(along<-.1||along>head.length+.1)continue;
      const distance=Math.abs((x-head.x1)*head.nx+(z-head.z1)*head.nz);
      if(over>Math.max(0,distance-head.thickness-.06)*HEAD_EASE)return true;
    }
    return false;
  }
  return {
    get probeCount(){return probes.length;},
    // Call after figure.update(), only for live gameplay (not death/escape films).
    apply(collision,dt=1/60){
      rig.root.updateWorldMatrix(true,true);rig.root.getWorldPosition(root);
      const {walls,heads,nearestWallDistance}=wallsNear(collision);base.copy(a.prev&&a.fade<1?a.Q:a.P);upright();
      // Release gradually, but test the released pose too: arm IK and the fork's
      // rotation can sweep through a wall between two individually clear poses.
      let weight=Math.max(0,releasedWeight-Math.max(0,dt)*3);
      if(!walls.length&&weight===0){releasedWeight=0;return {weight:0,shift:0,limited:false,nearWalls:false,nearestWallDistance};}
      // Gather further whenever a sideways step alone cannot clear him: too far to
      // step, pinned between two faces (a bunk and a wall), or under a door head.
      const blocked=w=>{applyPose(w);return project(walls)>MAX_SHIFT||unresolved(walls)||underDoorHead(heads);};
      if(blocked(weight)){
        let low=weight,high=1;
        for(let i=0;i<5;i++){
          const mid=(low+high)/2;
          if(blocked(mid))low=mid;else high=mid;
        }
        weight=high;
      }
      releasedWeight=weight;applyPose(weight);const need=project(walls);offset.clampLength(0,MAX_SHIFT);
      // Impossible/invalid spaces retain the bound and report residual contact;
      // never solve a tight corner by teleporting the visible actor through it.
      const limited=need>MAX_SHIFT+.001||unresolved(walls);
      // Translate the posed skeleton a bounded amount on its current side. The
      // actor root and simulation remain identical; never relocate across a wall.
      rig.root.getWorldQuaternion(inverse).invert();local.copy(offset).applyQuaternion(inverse);
      rig.b('pelvis').position.add(local);rig.root.updateMatrixWorld(true);rig.skeleton.update();
      return {weight:releasedWeight,shift:offset.length(),limited,nearWalls:walls.length>0,nearestWallDistance};
    },
    reset(){releasedWeight=0;},
  };
}

// Act II. The camp's obstacles are plain boxes and his carry already stands
// upright, but it stands outside his 0.42 m body circle: brushing a cabin wall,
// a door jamb or the wardrobe put the tines and his right elbow inside it.
// The drawn figure takes a bounded step off the box; the simulation is untouched.
// obstacles: {minX,maxX,minZ,maxZ} or {x,z,halfX,halfZ,yaw}, optional height/minHeight.
export function createBoxClearance(figure,{maxShift=.3,gap=.04,reach=1.5}={}) {
  const rig=figure.rig,probes=envelope(figure),points=new Float32Array(probes.length*3);
  const point=new THREE.Vector3(),root=new THREE.Vector3(),offset=new THREE.Vector3(),kept=new THREE.Vector3(),inverse=new THREE.Quaternion();
  const place=()=>{
    rig.root.parent.getWorldQuaternion(inverse).invert();rig.root.position.copy(kept).applyQuaternion(inverse);rig.root.updateMatrixWorld(true);
    return {shift:kept.length(),limited:false};
  };
  return {
    get probeCount(){return probes.length;},
    // Call once the figure is posed, with rig.root at its parent's origin.
    // hold: keep the last step as it is (a strike must not slide sideways).
    apply(obstacles,hold=false){
      if(hold)return place();
      rig.root.updateWorldMatrix(true,true);rig.root.getWorldPosition(root);
      const boxes=[];
      for(const o of obstacles||[]){
        const turned=Number.isFinite(o.yaw);
        const {box}=boxNear(turned?o.x:(o.minX+o.maxX)/2,turned?o.z:(o.minZ+o.maxZ)/2,turned?o.halfX:(o.maxX-o.minX)/2,turned?o.halfZ:(o.maxZ-o.minZ)/2,
          turned?o.yaw:0,o.height??Infinity,o.minHeight??0,root,reach,gap);
        if(box)boxes.push(box);
      }
      kept.set(0,0,0);if(!boxes.length)return {shift:0,limited:false};
      rig.skeleton.update();
      for(let i=0;i<probes.length;i++){
        const probe=probes[i];probe.mesh.getVertexPosition(probe.index,point).applyMatrix4(probe.mesh.matrixWorld);
        points[i*3]=point.x;points[i*3+1]=point.y;points[i*3+2]=point.z;
      }
      offset.set(0,0,0);
      for(let pass=0;pass<3;pass++)for(const box of boxes)pushFromBox(box,points,offset,root.y);
      const need=offset.length();kept.copy(offset).clampLength(0,maxShift);
      const result=place();result.limited=need>maxShift+.001;return result;
    },
    reset(){kept.set(0,0,0);rig.root.position.set(0,0,0);},
  };
}
