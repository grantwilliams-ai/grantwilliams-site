// Small shared helpers for the procedural animations.
import { gaitFoot, legTo } from './rig.js';

export const TAU = Math.PI * 2;
export const lerp = (a, b, t) => a + (b - a) * t;
export const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
export const sstep = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};
export const easeOut = (t) => 1 - Math.pow(1 - clamp(t, 0, 1), 3);
export const easeIn = (t) => Math.pow(clamp(t, 0, 1), 2.4);

// Walk, run or sneak: both legs on the planted-foot gait, plus the pelvis motion that goes with it.
// G: {S, duty, lift, hip (hip height), foot (half stance width), toe, roll, sway, yaw, bob, rollP, zOff, lean}
// D: leg dimensions {L1, L2, ankle, hipX, hipY}
// Returns {pyaw, proll, y} so callers can counter-rotate the torso and head.
export function locomote(P, ph, G, D) {
  const c = Math.cos(TAU * (ph - G.duty / 2));
  const sway = (G.sway || 0) * c;
  const dy = (G.bob || 0) * Math.cos(TAU * 2 * (ph - G.duty / 2));
  const proll = (G.rollP || 0) * c;
  const pyaw = -(G.yaw || 0) * Math.cos(TAU * ph);
  const ppitch = G.pitch || 0;
  const hip = G.hip + dy;
  P.pel(sway, hip - D.hipY, 0);
  P.rot('pelvis', ppitch, pyaw, proll);
  const pr = [ppitch, pyaw, proll];
  for (const side of ['L', 'R']) {
    const s = side === 'L' ? 1 : -1;
    const f = gaitFoot(ph + (side === 'L' ? 0 : 0.5), G);
    const heel = G.heel || 0.14;
    const rollRaise = f.psi < 0 ? heel * Math.sin(-f.psi) : 0;
    legTo(P, side, D, G.foot - s * sway - D.hipX, -(hip - D.ankle - f.lift - rollRaise), f.z, f.psi, pr);
  }
  return { pyaw, proll, dy };
}

// Plant one foot at a world-space spot while the pelvis sits at pel {x,y,z} pitched by rx.
// World x/z are relative to the figure root; fy is the ankle height above the ground.
export function legWorld(P, side, D, pel, rx, fx, fy, fz, psi = 0, rz = 0) {
  const s = side === 'L' ? 1 : -1;
  const vx = fx - (pel.x + s * D.hipX), vy = fy - pel.y, vz = fz - pel.z;
  const c = Math.cos(rx), sn = Math.sin(rx);
  const ty = vy * c + vz * sn, tz = -vy * sn + vz * c;
  legTo(P, side, D, s * vx, ty, tz, psi, [rx, 0, rz]);
}

// Slow breathing: 0..1, sharp in, long out.
export function breath(t, period = 4.2) {
  const x = (t % period) / period;
  return x < 0.35 ? Math.sin((x / 0.35) * Math.PI * 0.5) : 0.5 + 0.5 * Math.cos(((x - 0.35) / 0.65) * Math.PI);
}
