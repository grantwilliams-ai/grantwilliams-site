// A small, live-only leg presentation layer. Root motion and the authored pose
// remain authoritative; support anchors reduce skating during turns without
// locking the entire foot or moving the character's collision body.
import * as THREE from 'three';

const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const smooth=(a,b,v)=>{const t=clamp((v-a)/(b-a),0,1);return t*t*(3-2*t);};
const RELEASE = [.68,1];
const SETTLE = new Set(['idle','standStill','winded','search','listen','lookAround','searchCloset','openDoor','raise','strike','previewAttack']);

export function createStanceStabilizer(rig,animator,{gaits,release={},maxOffset=.12,maxWidth=.25,maxForward=.64}={}) {
  const root=rig.root,feet=['L','R'].map((side,index)=>({
    side,offset:index*.5,sign:side==='L'?1:-1,thigh:rig.b('thigh'+side),shin:rig.b('shin'+side),foot:rig.b('foot'+side),
    anchor:new THREE.Vector3(),lastOffset:new THREE.Vector3(),lastRaw:new THREE.Vector3(),lastPoint:new THREE.Vector3(),cycle:null,supported:false,weight:0,
  }));
  const position=new THREE.Vector3(),previousRoot=new THREE.Vector3();let seeded=false,lastName=null;
  const hip=new THREE.Vector3(),knee=new THREE.Vector3(),ankle=new THREE.Vector3(),target=new THREE.Vector3(),local=new THREE.Vector3(),delta=new THREE.Vector3();
  const direction=new THREE.Vector3(),pole=new THREE.Vector3(),newKnee=new THREE.Vector3(),oldUpper=new THREE.Vector3(),oldLower=new THREE.Vector3(),newUpper=new THREE.Vector3(),newLower=new THREE.Vector3();
  const qUpper=new THREE.Quaternion(),qLower=new THREE.Quaternion(),qFoot=new THREE.Quaternion(),parentQ=new THREE.Quaternion(),rotation=new THREE.Quaternion(),inverseRoot=new THREE.Matrix4();
  const fullTarget=new THREE.Vector3(),limitedRequest=new THREE.Vector3(),candidateStep=new THREE.Vector3();
  const status={active:false,maxCorrection:0};

  function reset(){seeded=false;lastName=null;for(const f of feet){f.supported=false;f.cycle=null;f.weight=0;f.lastOffset.set(0,0,0);}status.active=false;status.maxCorrection=0;}

  function constrain(f,requested,maxReach) {
    target.copy(ankle).add(requested);target.y=ankle.y;
    // Stay within the established body silhouette and on the leg's own side.
    local.copy(target).applyMatrix4(inverseRoot);
    const baseLocal=delta.copy(ankle).applyMatrix4(inverseRoot);
    local.x=f.sign*clamp(f.sign*local.x,Math.min(.025,f.sign*baseLocal.x),Math.max(maxWidth,f.sign*baseLocal.x));
    local.z=clamp(local.z,-Math.max(maxForward,-baseLocal.z),Math.max(maxForward,baseLocal.z));
    target.copy(local).applyMatrix4(root.matrixWorld);target.y=ankle.y;
    delta.copy(target).sub(ankle);delta.y=0;delta.clampLength(0,maxOffset);target.copy(ankle).add(delta);
    // Keep the authored ankle height, shortening only the horizontal correction
    // when a long stride leaves too little reach for the support anchor.
    if(hip.distanceTo(target)>maxReach){
      // Project onto the reachable horizontal circle rather than collapsing the
      // whole offset toward the raw ankle when a long stride straightens out.
      const reachXZ=Math.sqrt(Math.max(0,maxReach*maxReach-(hip.y-ankle.y)**2));
      local.copy(target).sub(hip);local.y=0;local.clampLength(0,reachXZ);
      target.x=hip.x+local.x;target.z=hip.z+local.z;
      delta.copy(target).sub(ankle);delta.y=0;
    }
  }

  function solve(f,requested,dt=0,adaptive=false) {
    f.thigh.getWorldPosition(hip);f.shin.getWorldPosition(knee);f.foot.getWorldPosition(ankle);
    oldUpper.copy(knee).sub(hip);oldLower.copy(ankle).sub(knee);
    const upperLength=oldUpper.length(),lowerLength=oldLower.length();
    const maxReach=Math.max(hip.distanceTo(ankle),(upperLength+lowerLength)*.998);
    limitedRequest.copy(requested);
    constrain(f,limitedRequest,maxReach);fullTarget.copy(target);
    if(adaptive&&dt>0){
      candidateStep.copy(limitedRequest).sub(f.lastOffset).clampLength(0,1.2*dt);
      limitedRequest.copy(f.lastOffset).add(candidateStep);
      constrain(f,limitedRequest,maxReach);
      // A sharp root turn can move the raw ankle much farther than a normal
      // step. Fast counter-correction is allowed only when its *feasible* foot
      // position reduces the visible world step versus both raw and slow cases.
      const fullStep=fullTarget.distanceToSquared(f.lastPoint);
      if(fullStep<=target.distanceToSquared(f.lastPoint)+1e-12&&fullStep<=ankle.distanceToSquared(f.lastRaw)+1e-12){target.copy(fullTarget);delta.copy(target).sub(ankle);delta.y=0;}
    }
    f.lastOffset.copy(delta);
    if(dt>0){f.lastRaw.copy(ankle);f.lastPoint.copy(target);}
    if(delta.lengthSq()<1e-12)return;
    f.thigh.getWorldQuaternion(qUpper);f.shin.getWorldQuaternion(qLower);f.foot.getWorldQuaternion(qFoot);
    direction.copy(target).sub(hip);const distance=direction.length();direction.divideScalar(distance||1);
    pole.copy(oldUpper).addScaledVector(direction,-oldUpper.dot(direction));
    if(pole.lengthSq()<1e-10){pole.set(0,0,1).transformDirection(root.matrixWorld);pole.addScaledVector(direction,-pole.dot(direction));}
    if(pole.lengthSq()<1e-10){pole.set(1,0,0);pole.addScaledVector(direction,-pole.dot(direction));}
    pole.normalize();
    const along=clamp((upperLength*upperLength+distance*distance-lowerLength*lowerLength)/(2*Math.max(distance,1e-8)),-upperLength,upperLength);
    newKnee.copy(hip).addScaledVector(direction,along).addScaledVector(pole,Math.sqrt(Math.max(0,upperLength*upperLength-along*along)));
    newUpper.copy(newKnee).sub(hip).normalize();newLower.copy(target).sub(newKnee).normalize();
    rotation.setFromUnitVectors(oldUpper.normalize(),newUpper);qUpper.premultiply(rotation);
    f.thigh.parent.getWorldQuaternion(parentQ);f.thigh.quaternion.copy(parentQ.invert().multiply(qUpper));f.thigh.updateMatrixWorld(true);
    rotation.setFromUnitVectors(oldLower.normalize(),newLower);qLower.premultiply(rotation);
    f.shin.parent.getWorldQuaternion(parentQ);f.shin.quaternion.copy(parentQ.invert().multiply(qLower));f.shin.updateMatrixWorld(true);
    // The shoe follows the authored facing/roll: turning can pivot naturally
    // instead of twisting a planted toe against an independently rotating body.
    f.foot.parent.getWorldQuaternion(parentQ);f.foot.quaternion.copy(parentQ.invert().multiply(qFoot));f.foot.updateMatrixWorld(true);
    status.maxCorrection=Math.max(status.maxCorrection,delta.length());
  }

  return {
    reset,
    update(dt,{enabled=false,strength=1}={}) {
      status.active=false;status.maxCorrection=0;
      if(!enabled||!Number.isFinite(dt)||dt<0){reset();return status;}
      root.updateWorldMatrix(true,true);root.getWorldPosition(position);inverseRoot.copy(root.matrixWorld).invert();
      const name=animator.cur?.name,gait=gaits?.[name];
      const moved=seeded?Math.hypot(position.x-previousRoot.x,position.z-previousRoot.z):0;
      if(!seeded||moved>Math.max(.75,dt*12)||dt>.15||(dt===0&&moved>.0001)){
        reset();seeded=true;previousRoot.copy(position);lastName=name;for(const f of feet){f.foot.getWorldPosition(f.lastRaw);f.lastPoint.copy(f.lastRaw);}return status;
      }
      // A paused map redraw reapplies the last correction to its fresh raw pose,
      // without advancing support history or accumulating another correction.
      if(dt===0){if(name===lastName)for(const f of feet)solve(f,f.lastOffset);status.active=status.maxCorrection>0;return status;}
      strength=Number.isFinite(strength)?clamp(strength,0,1):0;
      const moving=!!gait&&moved/dt>.025;
      const maySettle=SETTLE.has(name);
      if(!gait&&!maySettle){reset();seeded=true;previousRoot.copy(position);lastName=name;for(const f of feet){f.foot.getWorldPosition(f.lastRaw);f.lastPoint.copy(f.lastRaw);}return status;}
      for(const f of feet){
        f.foot.getWorldPosition(ankle);
        const phase=(animator.cur?.phase||0)+f.offset,cycle=Math.floor(phase),part=phase-cycle;
        const supported=moving&&animator.fade>=1&&part<gait.duty;
        if(supported){
          if(!f.supported||f.cycle!==cycle){f.anchor.copy(ankle).add(f.lastOffset);f.cycle=cycle;}
          const end=release[name]||RELEASE;
          const support=smooth(.02,.16,part/gait.duty)*(1-smooth(end[0],end[1],part/gait.duty));
          f.weight+=(support-f.weight)*(1-Math.exp(-30*dt));
          delta.copy(f.anchor).sub(ankle);delta.y=0;delta.clampLength(0,maxOffset).multiplyScalar(f.weight);
        }else{
          f.weight*=Math.exp(-30*dt);
          // A released support foot settles at a bounded speed, including the
          // live walk-to-raise/search blend. Vaults and authored films opt out.
          const length=f.lastOffset.length();
          delta.copy(f.lastOffset).multiplyScalar(length>0?Math.max(0,1-.6*dt/length):0);
        }
        f.supported=supported;
        delta.multiplyScalar(strength);
        solve(f,delta,dt,supported);
      }
      previousRoot.copy(position);lastName=name;status.active=status.maxCorrection>0;return status;
    },
  };
}
