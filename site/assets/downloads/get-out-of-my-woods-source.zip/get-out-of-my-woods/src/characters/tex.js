// The characters' small canvas textures. They are mostly neutral weaves: the colour comes from vertex
// colours, so one weave serves denim, work shirt and windbreaker.
import { canvasTexture, speckle } from '../render/textures.js';
import { makeRng } from '../core/rng.js';

const cache = {};
const once = (k, f) => cache[k] || (cache[k] = f());

// Woven cloth, neutral grey so vertex colours do the tinting. Twill diagonal reads as denim.
export function clothTexture() {
  return once('cloth', () =>
    canvasTexture(128, (c, s) => {
      const rng = makeRng(31);
      c.fillStyle = '#b4b4b4';
      c.fillRect(0, 0, s, s);
      for (let i = 0; i < s; i += 2) {
        c.fillStyle = i % 4 ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.15)';
        for (let j = 0; j < s; j += 2) c.fillRect(j, (i + j / 2) % s, 2, 2); // diagonal twill
      }
      speckle(c, s, rng, ['rgba(0,0,0,0.18)', 'rgba(255,255,255,0.08)'], 350, 1, 3);
      // grime blotches
      for (let i = 0; i < 10; i++) {
        c.fillStyle = `rgba(20,14,8,${0.03 + rng() * 0.04})`;
        c.beginPath();
        c.ellipse(rng() * s, rng() * s, 4 + rng() * 14, 2 + rng() * 5, rng() * 3, 0, 7);
        c.fill();
      }
    }),
  );
}

// Coarse feed-sack burlap: a regular, readable weave with only faint dirt in the tile. Larger stains
// are placed on the mesh so they do not repeat across the face.
export function burlapTexture() {
  return once('burlap', () =>
    canvasTexture(128, (c, s) => {
      const rng = makeRng(77);
      c.fillStyle = '#918b7b';
      c.fillRect(0, 0, s, s);
      const cell = 8;
      for (let y = 0; y < s; y += cell) {
        c.fillStyle = 'rgba(225,216,192,0.13)';
        c.fillRect(0, y + 1, s, 4);
        c.fillStyle = 'rgba(35,30,21,0.11)';
        c.fillRect(0, y + 6, s, 1);
      }
      for (let x = 0; x < s; x += cell) {
        c.fillStyle = 'rgba(220,211,188,0.1)';
        c.fillRect(x + 1, 0, 3, s);
        c.fillStyle = 'rgba(35,30,21,0.13)';
        c.fillRect(x + 6, 0, 1, s);
      }
      for (let y = 0; y < s; y += cell) {
        for (let x = 0; x < s; x += cell) {
          c.fillStyle = `rgba(20,17,11,${0.1 + rng() * 0.07})`;
          c.fillRect(x + 5, y + 5, 2, 2);
        }
      }
      // Slubs and old handling marks stay below the contrast of the eye cuts.
      for (let i = 0; i < 10; i++) {
        c.fillStyle = `rgba(38,32,23,${0.1 + rng() * 0.08})`;
        if (rng() < 0.5) c.fillRect(0, Math.floor(rng() * s), s, 1);
        else c.fillRect(Math.floor(rng() * s), 0, 1, s);
      }
      for (let i = 0; i < 7; i++) {
        const x = rng() * s, y = rng() * s, rx = 7 + rng() * 18, ry = 5 + rng() * 13;
        c.fillStyle = `rgba(35,30,21,${0.045 + rng() * 0.055})`;
        c.beginPath();
        c.ellipse(x, y, rx, ry, rng() * 3, 0, 7);
        c.fill();
      }
      speckle(c, s, rng, ['rgba(0,0,0,0.16)', 'rgba(220,215,200,0.07)'], 220, 1, 2);
    }),
  );
}

// Rubber, leather, wood and rusted iron: dark mottled noise, tinted by vertex colour.
export function hardTexture() {
  return once('hard', () =>
    canvasTexture(64, (c, s) => {
      const rng = makeRng(5);
      c.fillStyle = '#9c9c9c';
      c.fillRect(0, 0, s, s);
      speckle(c, s, rng, ['rgba(0,0,0,0.3)', 'rgba(255,255,255,0.14)', 'rgba(70,35,10,0.3)'], 360, 1, 3);
      for (let i = 0; i < 9; i++) {
        c.fillStyle = 'rgba(0,0,0,0.12)';
        c.fillRect(0, rng() * s, s, 1 + rng() * 2); // wood grain / scuff lines
      }
    }),
  );
}

// Worn white block letters, "STAFF", for the back of the windbreaker. Transparent background.
export function staffTexture() {
  return once('staff', () =>
    canvasTexture(
      128,
      (c, s) => {
        const rng = makeRng(9);
        const FONT = {
          S: ['01111', '10000', '10000', '01110', '00001', '00001', '11110'],
          T: ['11111', '00100', '00100', '00100', '00100', '00100', '00100'],
          A: ['01110', '10001', '10001', '11111', '10001', '10001', '10001'],
          F: ['11111', '10000', '10000', '11110', '10000', '10000', '10000'],
        };
        const word = 'STAFF';
        const cw = 24.4, ch = 124, px = cw / 6, py = ch / 7.4;
        c.fillStyle = '#e9e3cf';
        for (let k = 0; k < word.length; k++) {
          const g = FONT[word[k]];
          for (let r = 0; r < 7; r++) {
            for (let q = 0; q < 5; q++) {
              if (g[r][q] === '1') c.fillRect(k * cw + 1 + q * px, 2 + r * py, px + 0.6, py + 0.6);
            }
          }
        }
        // worn: knock holes and scratches out of the paint without erasing the letterforms at distance
        c.globalCompositeOperation = 'destination-out';
        for (let i = 0; i < 150; i++) {
          c.fillStyle = `rgba(0,0,0,${0.4 + rng() * 0.6})`;
          c.fillRect(rng() * s, rng() * s, 1 + rng() * 2, 1 + rng() * 3);
        }
        for (let i = 0; i < 3; i++) c.fillRect(0, rng() * s, s, 1);
        c.globalCompositeOperation = 'source-over';
      },
      { nearest: true },
    ),
  );
}

// Fine, softly filtered grain avoids large square patches in close hiding shots.
export function skinTexture() {
  return once('skin', () =>
    canvasTexture(128, (c, s) => {
      const rng = makeRng(3);
      c.fillStyle = '#c8c8c8';
      c.fillRect(0, 0, s, s);
      speckle(c, s, rng, ['rgba(0,0,0,0.035)', 'rgba(255,255,255,0.025)'], 1800, 1, 1.5);
    }, { nearest: false }),
  );
}
