// Characters: the killer, the player figure, blood, and the death sequences. See docs/reports/characters.md.
export { createKiller } from './killer.js';
export { createPlayer, createVictim } from './player.js';
export { createBlood } from './blood.js';
export { playDeath } from './death.js';
