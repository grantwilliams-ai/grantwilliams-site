// Death sequences, each a short film driven from update(dt):
// camera, both figures, blood and the post uniforms. Nothing lingers on anatomy: the camera looks at
// the killer, at the shape of what he is doing, and then the picture goes red.
//
// Conventions (also in docs/reports/characters.md):
//   at.yaw is the direction the PLAYER faces (impale, pinned: toward the killer; closet, car: out of
//   the hiding place / along the car). forward(yaw) = (sin yaw, cos yaw), left(yaw) = (cos yaw, -sin yaw).
//   The killer's strike is measured, not guessed: he is placed so the tines land where they should.
import * as THREE from 'three';
import { canvasTexture } from '../render/textures.js';
import { makeRng } from '../core/rng.js';
import { createBlood } from './blood.js';
import { lerp, clamp, sstep, easeOut } from './anim.js';
import { Pose, legTo } from './rig.js';

const PI = Math.PI;
const V1 = new THREE.Vector3(), V2 = new THREE.Vector3(), V3 = new THREE.Vector3(), V4 = new THREE.Vector3();
const M1 = new THREE.Matrix4(), M2 = new THREE.Matrix4(), Q1 = new THREE.Quaternion();
const E1 = new THREE.Euler();

// R_y(yaw) applied to (x, z): where a point in a figure's local frame lands in the world, horizontally
const wx = (x, z, yaw) => x * Math.cos(yaw) + z * Math.sin(yaw);
const wz = (x, z, yaw) => -x * Math.sin(yaw) + z * Math.cos(yaw);
const sstepc = (a, b, x) => sstep(a, b, x);

// tines centre in the killer's local frame at the end of a thrust anim
function probe(killer, anim) {
  killer.setAnim(anim, { restart: true, fade: 0.001 });
  killer.update(0.6, { speed: 0 });
  killer.update(0.001, { speed: 0 });
  killer.root.updateMatrixWorld(true);
  const v = new THREE.Vector3();
  killer.forkTines.getWorldPosition(v);
  killer.root.worldToLocal(v);
  return v;
}

// the red mess on the lens: drawn once, seeded
function splatterTexture() {
  return canvasTexture(256, (c, s) => {
    const rng = makeRng(404);
    c.clearRect(0, 0, s, s);
    const blob = (x, y, r, a) => {
      c.fillStyle = `rgba(${80 + (rng() * 30) | 0},4,4,${a})`;
      c.beginPath();
      const n = 9;
      for (let i = 0; i <= n; i++) {
        const an = (i / n) * PI * 2, rr = r * (0.7 + rng() * 0.5);
        c[i ? 'lineTo' : 'moveTo'](x + Math.cos(an) * rr, y + Math.sin(an) * rr);
      }
      c.fill();
    };
    for (let i = 0; i < 6; i++) blob(rng() * s, rng() * s * 0.6, 14 + rng() * 30, 0.93);
    for (let i = 0; i < 60; i++) blob(rng() * s, rng() * s * 0.8, 2 + rng() * 9, 0.9);
    // wet highlights
    for (let i = 0; i < 22; i++) {
      c.fillStyle = 'rgba(170,30,25,0.45)';
      c.beginPath();
      c.arc(rng() * s, rng() * s * 0.7, 1.5 + rng() * 4, 0, 7);
      c.fill();
    }
    // runs
    for (let i = 0; i < 9; i++) {
      const x = rng() * s, y = rng() * s * 0.5, len = 20 + rng() * 110, w = 1.5 + rng() * 3.5;
      c.fillStyle = 'rgba(100,5,5,0.92)';
      c.fillRect(x - w / 2, y, w, len);
      blob(x, y + len, w * 0.9, 0.92);
    }
  });
}

class Session {
  constructor(ctx) {
    this.ctx = ctx;
    this.scene = ctx.scene;
    this.camera = ctx.camera;
    this.killer = ctx.killer;
    this.player = ctx.player;
    this.post = ctx.post || {};
    this.ground = ctx.ground || (() => 0);
    this.t = 0;
    this.shotId = null;
    this.tear = 0; this.flash = 0;
    this.shake = 0;
    // blood belongs to the sequence and stays after it
    this.blood = createBlood(ctx.scene);
    this.blood.ground = this.ground;
    this.fov0 = this.camera.fov;
    this.camParent = this.camera.parent;
    if (this.camera.parent !== this.scene) this.scene.attach(this.camera); // world space; also lets lens children render
    this.hidden = [];
    this.kSpeed = 0;
    this.kDir = new THREE.Vector2(0, 0); // root motion direction (x, z)
    this.kYaw = 0; this.kYawTarget = null;
    this.frozen = null;
    this.extra = []; // things to dispose
    this.splat = null;
    this.shards = null;
  }
  u(name, v) { const o = this.post[name]; if (o) o.value = v; }
  gu(name) { return this.post[name] ? this.post[name].value : 0; }
  audio(n) { if (this.ctx.audioCue) this.ctx.audioCue(n); }
  hide(obj) { if (obj && obj.root.visible) { obj.root.visible = false; this.hidden.push(obj); } }
  groundY(x, z) { return this.ground(x, z); }

  placeKiller(x, z, yaw) {
    const r = this.killer.root;
    r.position.set(x, this.groundY(x, z), z);
    r.rotation.set(0, yaw, 0);
    this.kYaw = yaw;
  }
  // killer root position that puts his tines centre (local lt) at world (tx, tz) when he faces yk
  rootFor(tx, tz, yk, lt) {
    return [tx - wx(lt.x, lt.z, yk), tz - wz(lt.x, lt.z, yk)];
  }
  tines(out) {
    this.killer.root.updateMatrixWorld(true);
    return this.killer.forkTines.getWorldPosition(out);
  }
  head(out) {
    this.killer.root.updateMatrixWorld(true);
    this.killer.headTop.getWorldPosition(out);
    out.y -= 0.24; // middle of the sack
    return out;
  }
  freezeFork() {
    const f = this.killer.rig.b('fork');
    this.killer.root.updateMatrixWorld(true);
    this.frozen = f.matrixWorld.clone();
  }
  stepKiller(dt) {
    const k = this.killer, r = k.root;
    if (this.kSpeed > 0) {
      r.position.x += this.kDir.x * this.kSpeed * dt;
      r.position.z += this.kDir.y * this.kSpeed * dt;
      r.position.y = this.groundY(r.position.x, r.position.z);
    }
    if (this.kYawTarget !== null) {
      let d = this.kYawTarget - this.kYaw;
      d = Math.atan2(Math.sin(d), Math.cos(d));
      this.kYaw += d * (1 - Math.exp(-2.6 * dt));
      r.rotation.y = this.kYaw;
    }
    k.update(dt, { speed: this.kSpeed });
    r.updateMatrixWorld(true);
    if (this.frozen) {
      const f = k.rig.b('fork');
      M1.copy(f.parent.matrixWorld).invert().multiply(this.frozen);
      M1.decompose(f.position, f.quaternion, V4);
      f.updateMatrixWorld(true);
    }
  }
  // camera in world space. cut: an id; a new id is a hard cut (tracking tear on the post pass)
  cam(id, px, py, pz, tx, ty, tz, fov, roll = 0) {
    const c = this.camera;
    // The same short, readable action is filmed differently at the water and indoors.
    // Closet/car POV stays exact; these adjustments only affect the two exterior-style films.
    if (this.kind === 'impale' || this.kind === 'pinned') {
      if ((this.ctx.location === 'lake' || this.ctx.location === 'lakeside')) {
        py = lerp(py, this.groundY(this.ctx.at.x,this.ctx.at.z) + 0.5, 0.22);
        fov += 4; // more shoreline in the frame, low water-level perspective
      } else if (this.ctx.location === 'cabin') {
        px = lerp(tx,px,0.88); pz = lerp(tz,pz,0.88);
        fov += 5; // cramped shoulder-height framing, then the normal wall-clearance test
      }
    }
    // Indoors the shot may want to stand outside the room: pull in along the line to the subject.
    const fixedHide = this.kind === 'bed' || this.kind === 'canoe' || this.kind === 'outhouse';
    const room = !fixedHide && this.ctx.clearLine ? this.ctx.clearLine(tx, tz, px, pz) : 1;
    if (room < 1) {
      px = tx + (px - tx) * room;
      pz = tz + (pz - tz) * room;
      fov = Math.min(80, fov / Math.max(0.55, room));
    }
    if (id !== this.shotId) {
      this.shotId = id;
      this.tear = 1;
    }
    const s = this.shake, t = this.t;
    c.position.set(
      px + s * 0.03 * (Math.sin(t * 61) + Math.sin(t * 37.7)),
      py + s * 0.03 * (Math.sin(t * 53.1) + Math.sin(t * 29.3)),
      pz + s * 0.03 * (Math.sin(t * 47.9) + Math.sin(t * 33.1)),
    );
    c.up.set(0, 1, 0);
    c.lookAt(tx, ty, tz);
    if (roll || s) c.rotateZ(roll + s * 0.02 * Math.sin(t * 43));
    if (Math.abs(c.fov - fov) > 1e-4) { c.fov = fov; c.updateProjectionMatrix(); }
  }
  // Her flashlight, where it fell, a pace in front of her and a little to one side. It lights him from
  // below, which is the only way anyone should ever see him.
  dropLamp(yaw) {
    const k = this.killer.root.position;
    this.lamp = { x: lerp(this.ctx.at.x, k.x, -0.25) + Math.cos(yaw) * 0.8, z: lerp(this.ctx.at.z, k.z, -0.25) - Math.sin(yaw) * 0.8 };
    this.lamp.y = this.groundY(this.lamp.x, this.lamp.z) + 0.08;
  }
  aimLamp(dt) {
    if (!this.lamp || !this.ctx.lamp) return;
    this.head(V3);
    V3.y -= 0.45;
    this.ctx.lamp(this.lamp, V3, dt, this.t > 4.9);
  }

  // lens splatter, a plane in front of the camera
  showSplat(on, a = 1) {
    if (!this.splat) {
      const m = new THREE.MeshBasicMaterial({ map: splatterTexture(), transparent: true, depthTest: false, depthWrite: false, fog: false, opacity: 1 });
      this.splat = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), m);
      this.splat.renderOrder = 100;
      this.splat.frustumCulled = false;
      this.camera.add(this.splat);
      this.extra.push(() => { this.camera.remove(this.splat); this.splat.geometry.dispose(); m.map.dispose(); m.dispose(); });
    }
    this.splat.visible = on;
    this.splat.material.opacity = a;
    // fill the view at 0.3 m with a little overscan, and drag it down slowly so the runs run
    const d = 0.3, h = 2 * Math.tan((this.camera.fov * PI) / 360) * d * 1.15, w = h * this.camera.aspect;
    this.splat.scale.set(w, h, 1);
    this.splat.position.set(0, -h * 0.04 * clamp(this.t - this.splatT, 0, 3) * 0.3, -d);
  }
}

// ------------------------------------------------------------------------------------------
// Glass: small bright shards thrown at the lens (car window)

function makeShards(S, n = 56) {
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute([0, 0.5, 0, -0.3, -0.4, 0, 0.35, -0.3, 0], 3));
  const m = new THREE.MeshBasicMaterial({ color: 0xeaf4ff, side: THREE.DoubleSide, transparent: true, opacity: 0.9, fog: false });
  const mesh = new THREE.InstancedMesh(g, m, n);
  mesh.frustumCulled = false;
  mesh.count = 0;
  S.scene.add(mesh);
  S.extra.push(() => { S.scene.remove(mesh); g.dispose(); m.dispose(); });
  const st = new Float32Array(n * 10); // pos3 vel3 spin3 size
  const rng = makeRng(808);
  return {
    mesh,
    fire(cx, cy, cz, dx, dz, lx, lz) {
      // spawn across a window-sized patch at (cx,cy,cz); velocity inward (-d) with spread
      for (let i = 0; i < n; i++) {
        const o = i * 10, a = (rng() - 0.5) * 0.9, b = (rng() - 0.5) * 0.55;
        st[o] = cx + lx * a; st[o + 1] = cy + b; st[o + 2] = cz + lz * a;
        const sp = 1.5 + rng() * 4.5;
        st[o + 3] = -dx * sp + lx * (rng() - 0.5) * 2; st[o + 4] = (rng() - 0.3) * 2; st[o + 5] = -dz * sp + lz * (rng() - 0.5) * 2;
        st[o + 6] = rng() * 6; st[o + 7] = rng() * 6; st[o + 8] = (rng() - 0.5) * 18;
        st[o + 9] = 0.04 + rng() * rng() * 0.2;
      }
      mesh.count = n;
    },
    update(dt) {
      if (!mesh.count) return;
      for (let i = 0; i < n; i++) {
        const o = i * 10;
        st[o + 4] -= 9.8 * dt;
        st[o] += st[o + 3] * dt; st[o + 1] += st[o + 4] * dt; st[o + 2] += st[o + 5] * dt;
        st[o + 6] += st[o + 8] * dt; st[o + 7] += st[o + 8] * 0.6 * dt;
        V1.set(st[o], st[o + 1], st[o + 2]);
        E1.set(st[o + 6], st[o + 7], 0);
        Q1.setFromEuler(E1);
        V2.setScalar(st[o + 9]);
        M2.compose(V1, Q1, V2);
        mesh.setMatrixAt(i, M2);
      }
      mesh.instanceMatrix.needsUpdate = true;
    },
  };
}

// ------------------------------------------------------------------------------------------
// Sequences. Each returns {duration, events: [[t, fn]...], figures(t, dt), frame(t, dt)}.

const SEQ = {};

// the player hangs from the fork: root placed so the chest sits on the tines
const CHEST = { x: 0, y: 1.22, z: 0.06 };
function attachPlayer(S, yaw, base, w) {
  const p = S.player;
  if (!p) return;
  S.tines(V1);
  const px = V1.x - wx(CHEST.x, CHEST.z, yaw), pz = V1.z - wz(CHEST.x, CHEST.z, yaw), py = V1.y - CHEST.y;
  p.root.position.set(lerp(base.x, px, w), lerp(base.y, py, w), lerp(base.z, pz, w));
  p.root.rotation.set(0, yaw, 0);
}

SEQ.impale = (S) => {
  const { killer, player, ctx } = S;
  const at = ctx.at, yaw = at.yaw || 0, yk = yaw + PI;
  const gy = S.groundY(at.x, at.z);
  const base = { x: at.x, y: gy, z: at.z };
  const lt = probe(killer, 'strike');
  const T = { x: at.x + wx(0, CHEST.z, yaw), z: at.z + wz(0, CHEST.z, yaw) };
  const [kx, kz] = S.rootFor(T.x, T.z, yk, lt);
  const kf = { x: Math.sin(yk), z: Math.cos(yk) }, kl = { x: Math.cos(yk), z: -Math.sin(yk) };
  const tRaise = 1.3, tStrike = 1.95, tHit = tStrike + 0.2, tLift = tHit + 0.3, tRed = 5.0, dur = 5.8;
  let dripT = 0;
  return {
    duration: dur,
    setup() {
      S.placeKiller(kx, kz, yk);
      killer.setAnim('idle', { restart: true, fade: 0.001 });
      killer.setBloody(0);
      killer.setEyeGlint(1);
      if (player) {
        player.root.position.set(base.x, base.y, base.z);
        player.root.rotation.set(0, yaw, 0);
        player.setAnim('idle', { restart: true, fade: 0.001 });
        player.setFlashlight(false);
      }
      S.dropLamp(yaw);
      S.u('uLetterbox', 0);
    },
    events: [
      [tRaise, () => killer.setAnim('raise')],
      [tRaise + 0.3, () => player && player.setAnim('flinch')],
      [tStrike, () => { killer.setAnim('strike'); S.audio('fork_swing'); }],
      [tHit, () => {
        S.audio('fork_stab');
        S.tines(V1);
        V2.set(kf.x * 0.8, 0.45, kf.z * 0.8);
        S.blood.burst(V1, V2, 46, 5.5);
        V2.set(-kf.x * 0.3, 0.6, -kf.z * 0.3);
        S.blood.burst(V1, V2, 24, 3);
        killer.setBloody(1);
        player && player.setAnim('impaled', { restart: true });
        S.flash = 0.45; S.shake = 1;
      }],
      [tHit + 0.1, () => S.audio('scream_death')],
      [tLift, () => killer.setAnim('lift', { restart: true })],
      [tLift + 0.9, () => { S.blood.decal({ x: at.x, y: gy, z: at.z }, 0.5); }],
      [tLift + 1.8, () => { S.blood.decal({ x: at.x + 0.2, y: gy, z: at.z + 0.1 }, 0.35); }],
      [tRed, () => { S.audio('stinger_jump'); S.u('uRed', 1); S.flash = 0.8; killer.setEyeGlint(1); }],
    ],
    figures(t, dt) {
      if (!player) return;
      if (t >= tHit) {
        attachPlayer(S, yaw, base, sstepc(tHit, tHit + 0.18, t));
        // blood runs off the hanging body
        dripT -= dt;
        if (dripT <= 0 && t < tRed) {
          dripT = 0.09;
          player.rig.b('pelvis').getWorldPosition(V1);
          V1.y -= 0.15;
          S.blood.drip(V1);
          if (Math.random() < 0.5) { S.tines(V1); V1.y -= 0.15; S.blood.drip(V1); }
        }
      }
      S.shake = Math.max(0, S.shake - dt * 1.4);
    },
    frame(t) {
      S.head(V1);
      if (t < 1.75) {
        // A: the sack, close, from where the player stands. Slow push; he rises into the frame.
        const d = lerp(1.35, 1.0, t / 1.75);
        S.cam('A', V1.x + kf.x * d, gy + 0.5, V1.z + kf.z * d, V1.x, V1.y + 0.04 + 0.08 * sstepc(1.3, 1.75, t), V1.z, 42);
      } else if (t < 2.75) {
        // B: low, from the side, the thrust crosses the frame
        const mx = (kx + T.x) / 2, mz = (kz + T.z) / 2;
        const k = (t - 1.75) / 1.0;
        S.cam('B', mx + kl.x * 3.1, gy + 0.42, mz + kl.z * 3.1, mx + kf.x * 0.2, gy + 1.3, mz + kf.z * 0.2, lerp(56, 50, k));
      } else if (t < tRed) {
        // C: three-quarter, slow push in on the fork and what is on it
        // frames the body and his head together, and closes on them
        S.tines(V2);
        const k = (t - 2.75) / (tRed - 2.75);
        const d = lerp(1.0, 0.66, k);
        const mx = (V1.x + V2.x) / 2, my = (V1.y + V2.y) / 2 - 0.1 * k, mz = (V1.z + V2.z) / 2;
        S.cam('C', mx + kl.x * 4.2 * d + kf.x * 1.0 * d, gy + lerp(0.6, 1.0, k), mz + kl.z * 4.2 * d + kf.z * 1.0 * d, mx, my, mz, 44);
      } else {
        // D: red. The sack, very close. Both eyes.
        const k = (t - tRed) / (dur - tRed);
        const d = lerp(1.25, 1.05, k);
        S.cam('D', V1.x + kf.x * d, V1.y + 0.02, V1.z + kf.z * d, V1.x, V1.y + 0.02, V1.z, 36);
      }
    },
  };
};

SEQ.pinned = (S) => {
  const { killer, player, ctx } = S;
  const at = ctx.at, yaw = at.yaw || 0, yk = yaw + PI;
  const f = { x: Math.sin(yaw), z: Math.cos(yaw) }, l = { x: Math.cos(yaw), z: -Math.sin(yaw) };
  const ax = at.x + f.x * 0.3, az = at.z + f.z * 0.3; // body axis, back to the trunk
  const gy = S.groundY(ax, az);
  const base = { x: ax, y: gy, z: az };
  const lt = probe(killer, 'strike');
  const T = { x: ax + wx(0, CHEST.z, yaw), z: az + wz(0, CHEST.z, yaw) };
  const [kx, kz] = S.rootFor(T.x, T.z, yk, lt);
  const kf = { x: Math.sin(yk), z: Math.cos(yk) };
  const walkT = 1.5, tStrike = walkT + 0.35, tHit = tStrike + 0.2, tFreeze = tHit + 0.15, tRelease = 3.0, tLeave = 4.3, tRed = 5.5, dur = 6.0;
  const walkSpeed = 1.2;
  const K0 = [kx + f.x * walkSpeed * walkT, kz + f.z * walkSpeed * walkT];
  let dripT = 0;
  return {
    duration: dur,
    setup() {
      S.placeKiller(K0[0], K0[1], yk);
      S.kDir.set(-f.x, -f.z);
      S.kSpeed = walkSpeed;
      killer.setAnim('walk', { restart: true, fade: 0.001 });
      killer.setBloody(0);
      killer.setEyeGlint(1);
      if (player) {
        player.root.position.set(base.x, base.y, base.z);
        player.root.rotation.set(0, yaw, 0);
        player.setAnim('idle', { restart: true, fade: 0.001 });
        player.setFlashlight(false);
      }
      S.dropLamp(yaw);
      S.u('uLetterbox', 0);
    },
    events: [
      [0.8, () => player && player.setAnim('flinch')],
      [walkT, () => { S.kSpeed = 0; killer.setAnim('raise'); }],
      [tStrike, () => { killer.setAnim('strike'); S.audio('fork_swing'); }],
      [tHit, () => {
        S.audio('fork_stab'); S.audio('wood_crack');
        S.tines(V1);
        V2.set(kf.x * 0.6, 0.3, kf.z * 0.6);
        S.blood.burst(V1, V2, 44, 5);
        killer.setBloody(1);
        player && player.setAnim('pinned', { restart: true });
        S.flash = 0.4; S.shake = 1;
      }],
      [tHit + 0.12, () => S.audio('scream_death')],
      [tFreeze, () => S.freezeFork()],
      [tRelease, () => killer.setAnim('release', { restart: true })],
      [tRelease + 0.6, () => S.blood.decal({ x: ax, y: gy, z: az }, 0.45)],
      [tLeave - 0.2, () => {
        // he turns away from what he has done and walks off along the way he came
        S.kYawTarget = yaw;
        S.kDir.set(f.x, f.z);
        S.kSpeed = 0;
        killer.setAnim('walkFree');
      }],
      [tLeave + 0.5, () => { S.kSpeed = 1.05; }],
      [tLeave + 1.0, () => S.blood.decal({ x: ax + 0.15, y: gy, z: az + 0.1 }, 0.3)],
      [tRed, () => { S.audio('stinger_jump'); S.u('uRed', 1); S.flash = 0.8; }],
    ],
    figures(t, dt) {
      if (player && t >= tHit) {
        attachPlayer(S, yaw, base, sstepc(tHit, tHit + 0.15, t));
        // pushed against the trunk by the fork: keep the body from sinking into it
        dripT -= dt;
        if (dripT <= 0 && t < tRed) {
          dripT = 0.12;
          player.rig.b('pelvis').getWorldPosition(V1);
          V1.y -= 0.2;
          S.blood.drip(V1);
        }
      }
      S.shake = Math.max(0, S.shake - dt * 1.4);
    },
    frame(t) {
      if (t < 1.65) {
        // A: wide from the side, he comes out of the fog
        const mx = (kx + ax + f.x * 1.0) / 2, mz = (kz + az + f.z * 1.0) / 2;
        S.cam('A', mx + l.x * 6.2 + f.x * 0.5, gy + 1.35, mz + l.z * 6.2 + f.z * 0.5, mx, gy + 1.15, mz, 40);
      } else if (t < 2.6) {
        // B: low, beside the tree, looking up at the thrust
        S.cam('B', T.x + l.x * 1.7 + f.x * 1.1, gy + 0.45, T.z + l.z * 1.7 + f.z * 1.1, T.x + f.x * 0.9, gy + 1.35, T.z + f.z * 0.9, 52);
      } else if (t < tLeave) {
        // C: his sack, close, from the front and a little to the side: he stands and watches
        S.head(V1);
        const k = (t - 2.6) / (tLeave - 2.6);
        const d = lerp(1.35, 1.05, k);
        S.cam('C', V1.x + kf.x * d + l.x * 0.55, V1.y - 0.32, V1.z + kf.z * d + l.z * 0.55, V1.x, V1.y + 0.02, V1.z, 40);
      } else if (t < tRed) {
        // D: the body on the tree from the side; he walks out of the frame
        S.tines(V2);
        S.cam('D', V2.x + l.x * 3.8 + f.x * 1.0, gy + 1.25, V2.z + l.z * 3.8 + f.z * 1.0, V2.x + f.x * 0.9, gy + 1.25, V2.z + f.z * 0.9, 38);
      } else {
        S.tines(V2);
        const k = (t - tRed) / (dur - tRed);
        S.cam('E', V2.x + l.x * 2.4 + f.x * 0.8, gy + 1.25, V2.z + l.z * 2.4 + f.z * 0.8, V2.x, V2.y, V2.z, lerp(34, 30, k));
      }
    },
  };
};

// POV from where the player is hiding: camera at the eye, the killer comes to him
function povSequence(S, o) {
  const { killer, player, ctx } = S;
  const at = ctx.at, yaw = at.yaw || 0;
  const lt = probe(killer, 'jab');
  const gy = at.y !== undefined && Number.isFinite(at.y) ? at.y : S.groundY(at.x, at.z);
  // the camera, then the direction it ends up facing (d), then where the killer must stand
  const dYaw = yaw + (o.look || 0); // facing of the final shot
  const d = { x: Math.sin(dYaw), z: Math.cos(dYaw) };
  const eye = { x: at.x, z: at.z };
  const yk = dYaw + PI;
  const kf = { x: Math.sin(yk), z: Math.cos(yk) };
  const reachAhead = 0.72;
  const T = { x: eye.x + d.x * reachAhead, z: eye.z + d.z * reachAhead };
  const [kx, kz] = S.rootFor(T.x, T.z, yk, lt);
  // eye height: tines are level at lt.y; the eye sits a little above them so they enter low in the frame
  const ky = S.groundY(kx, kz);
  const eyeY = ky + lt.y + 0.1;
  const ex = o.approach;
  const K0 = [kx - kf.x * ex.dist, kz - kf.z * ex.dist];
  return {
    d, dYaw, T, kx, kz, yk, kf, K0, eyeY, eye,
  };
}

// The counselor stays under the same bunk. Boots stop in the aisle; he lowers
// himself to look beneath it, then threads the fork horizontally through the gap.
// This is an authored fatality pose only, with no new AI/search behavior.
SEQ.bed = (S) => {
  const { killer, player, ctx } = S, rig = killer.rig;
  const at = ctx.at, entry = ctx.entryView;
  const eye = entry?.position.clone() || new THREE.Vector3(at.x, at.y, at.z);
  const stand = ctx.hiding || { x: at.x + Math.sin(at.yaw), z: at.z + Math.cos(at.yaw) };
  const yaw = Math.atan2(eye.x - stand.x, eye.z - stand.z);
  const f = { x: Math.sin(yaw), z: Math.cos(yaw) };
  const kx = stand.x - f.x * .4, kz = stand.z - f.z * .4;
  const floor = S.groundY(kx, kz), distance = Math.hypot(eye.x - kx, eye.z - kz);
  const initial = entry?.direction || new THREE.Vector3(Math.sin(at.yaw), .025, Math.cos(at.yaw));
  const eyeMarkers = [];
  rig.b('head').traverse(obj => { if(obj.isMesh && obj.geometry.type === 'CircleGeometry') eyeMarkers.push(obj); });
  const gaze = new THREE.Vector3(),mark = new THREE.Vector3(),entryTarget=eye.clone().addScaledVector(initial,distance);
  const P = new Pose(rig.idx, rig.bones.length), standing = new Pose(rig.idx, rig.bones.length), mixed = new Pose(rig.idx, rig.bones.length);
  const tLower = .7, tLow = 2.0, tDraw = 2.8, tJab = 3.5, tHit = 3.72, dur = 5.4;
  function pose(t) {
    const down = sstepc(tLower, tLow, t), pull = sstepc(tDraw, tJab, t), jab = easeOut(clamp((t - tJab) / (tHit - tJab), 0, 1));
    const hip = .28, tipAhead = distance - .8 - .12 * pull + .92 * jab;
    // He tilts the sack sideways to look through the low opening. Upright eyes
    // sit above the mattress underside even though the neck itself is low.
    P.clear().pel(0, hip - 1, 0).rot('spine', 1, 0, 0).rot('chest', 1.1, 0, 0).rot('head', -1.9, .03 * Math.sin(t * 2), 1.57);
    for (const side of ['L','R']) legTo(P, side, rig.dims, 0, -(hip - rig.dims.ankle), side === 'L' ? .42 : .54, 0);
    P.rot('uarmL', -.4, 0, .2).rot('uarmR', -.4, 0, -.2).rot('farmL', -.5, 0, 0).rot('farmR', -.5, 0, 0);
    // forkTines is 1.76m along the tool. At contact it reaches the original
    // hiding eye, below the bunk's .36m underside, without a standing thrust.
    P.fork(0, eye.y - floor - .03 - hip + .01, tipAhead - 1.76, PI / 2, 0, 0).grip(1, 1.05, 1, 1.3);
    mixed.copy(standing).lerp(P, down);
    // Solve feet against the floor throughout the descent. Blending the two
    // endpoint knee angles alone makes the boots dip through the floor halfway.
    for(const side of ['L','R']) legTo(mixed, side, rig.dims, .035*(1-down), -(1+mixed.a[1]-rig.dims.ankle),
      lerp(side==='L'?.07:-.07,side==='L'?.42:.54,down),0,[.05*(1-down),0,0]);
    killer.animator.apply(mixed, 0, {});
    rig.root.updateMatrixWorld(true);rig.skeleton.update();
  }
  return {
    duration: dur,
    setup() {
      S.placeKiller(kx, kz, yaw);S.kSpeed = 0;
      killer.setAnim('idle', { restart: true, fade: .001 });killer.update(.001, {speed:0});
      standing.copy(killer.animator.P);
      const lookYaw = killer.animator.lookYaw, lookPitch = killer.animator.lookPitch;
      killer.animator.lookYaw = killer.animator.lookPitch = 0;
      S.extra.push(() => { killer.animator.lookYaw = lookYaw; killer.animator.lookPitch = lookPitch; });
      killer.setBloody(0);killer.setEyeGlint(1);S.hide(player);
      S.u('uLetterbox', 0);S.splatT = 1e9;
      S.lamp = {x:eye.x-f.x*.2, y:floor+.08, z:eye.z-f.z*.2};
    },
    events: [
      [.45, () => S.audio('killer_step_wood')],
      [1.1, () => ctx.onReveal?.()],
      [tJab, () => S.audio('fork_swing')],
      [tHit, () => { S.audio('fork_stab');S.splatT=S.t;S.flash=.7;S.shake=.8;killer.setBloody(1); }],
      [tHit+.12, () => S.audio('scream_death')],
      [tHit+.35, () => S.audio('stinger_jump')],
    ],
    figures(t, dt) { pose(t);S.shake=Math.max(0,S.shake-dt*1.1); },
    frame(t) {
      const reveal=sstepc(.65,2.1,t),br=Math.sin(t*3.2)*.004;
      // Frame the actual eyes, rather than the neck joint or standing torso.
      // Both eyes remain below the bunk edge; the crown stays in the aisle.
      gaze.set(-.245,.28,.73).applyMatrix4(rig.root.matrixWorld);
      if(eyeMarkers.length){gaze.set(0,0,0);for(const marker of eyeMarkers)gaze.add(marker.getWorldPosition(mark));gaze.multiplyScalar(1/eyeMarkers.length);}
      gaze.lerp(entryTarget,1-reveal);
      S.cam('bed',eye.x,eye.y+br,eye.z,gaze.x,gaze.y,gaze.z,lerp(entry?.fov||62,56,reveal));
      S.u('uDesat',.25*reveal);
      if(t>=tHit){const a=t-tHit;S.showSplat(true,clamp(a*10,0,1));S.u('uRed',clamp(a/.9,0,1));}
    },
  };
};

// These hides already establish a restricted first-person view. Keep that eye
// inside the same slit / crescent until contact, rather than cutting to a
// standing counselor. The canoe is approached from its clear aisle; the stall
// from outside its front. Neither scene moves or removes the surrounding prop.
function coveredHideSequence(S, canoe) {
  const { killer, player, ctx } = S, rig = killer.rig, at = ctx.at, entry = ctx.entryView;
  const eye = entry?.position.clone() || new THREE.Vector3(at.x, at.y, at.z);
  const d = new THREE.Vector3(Math.sin(at.yaw), 0, Math.cos(at.yaw));
  const stand = canoe && ctx.hiding ? new THREE.Vector3(ctx.hiding.x, 0, ctx.hiding.z) : eye.clone().addScaledVector(d, 1.45);
  const yaw = Math.atan2(eye.x - stand.x, eye.z - stand.z), f = { x: Math.sin(yaw), z: Math.cos(yaw) };
  const kx = stand.x - (canoe ? .4 : 0) * f.x, kz = stand.z - (canoe ? .4 : 0) * f.z;
  const floor = S.groundY(kx, kz), distance = Math.hypot(eye.x - kx, eye.z - kz);
  const initial = entry?.direction || d;
  const entryTarget = eye.clone().addScaledVector(initial, distance), gaze = new THREE.Vector3(), marker = new THREE.Vector3();
  const viewForward = new THREE.Vector3(), viewRight = new THREE.Vector3(), viewUp = new THREE.Vector3();
  const eyeMarkers = [];
  rig.b('head').traverse(obj => { if (obj.isMesh && obj.geometry.type === 'CircleGeometry') eyeMarkers.push(obj); });
  const P = new Pose(rig.idx, rig.bones.length), standing = new Pose(rig.idx, rig.bones.length), mixed = new Pose(rig.idx, rig.bones.length);
  const tSettle = canoe ? 1.65 : 1.3, tDraw = 2.65, tJab = 3.45, tHit = 3.72, duration = 5.4;
  // Aim just above the canoe's .5m crown; the real hull remains under the
  // viewpoint. The stall strike meets the original eye in the crescent view.
  const targetY = eye.y + (canoe ? .035 : -.025), pitch = PI / 2 + (canoe ? .12 : -.025);
  // forkTines marks the middle of the tines for impalement. Here the actual
  // sharpened ends (1.98m, curved forward .05m) stop at the eye, so the tool
  // cannot pass through the hull or overshoot the camera before the hit.
  const tip = new THREE.Vector3(0, 1.98, .05).applyEuler(new THREE.Euler(pitch, 0, 0));
  function pose(t) {
    const down = sstepc(.15, tSettle, t), draw = sstepc(tDraw, tJab, t), jab = easeOut(clamp((t - tJab) / (tHit - tJab), 0, 1));
    const hip = canoe ? .47 : .96, ahead = distance - .78 - .14 * draw + .92 * jab;
    P.clear().pel(0, hip - 1, 0)
      .rot('spine', canoe ? .68 : .1, 0, 0).rot('chest', canoe ? .72 : .12, 0, 0)
      .rot('head', canoe ? -1.3 : -.22, .025 * Math.sin(t * 2), canoe ? 0 : -.08);
    P.rot('uarmL', -.4, 0, .2).rot('uarmR', -.4, 0, -.2).rot('farmL', -.5, 0, 0).rot('farmR', -.5, 0, 0);
    P.fork(-tip.x, targetY - floor - hip - tip.y, ahead - tip.z, pitch, 0, 0)
      .grip(1, 1.25 - .45 * jab, 1, 1.5 - .45 * jab);
    mixed.copy(standing).lerp(P, down);
    for (const side of ['L', 'R']) legTo(mixed, side, rig.dims, .035 * (1 - down), -(1 + mixed.a[1] - rig.dims.ankle),
      lerp(side === 'L' ? .07 : -.07, canoe ? (side === 'L' ? .25 : .45) : (side === 'L' ? .12 : -.08), down), 0, [.05 * (1 - down), 0, 0]);
    killer.animator.apply(mixed, 0, {});rig.root.updateMatrixWorld(true);rig.skeleton.update();
  }
  return {
    duration,
    setup() {
      S.placeKiller(kx, kz, yaw);S.kSpeed = 0;
      killer.setAnim('idle', { restart: true, fade: .001 });killer.update(.001, { speed: 0 });standing.copy(killer.animator.P);
      // His ordinary carry points down into low cover. Begin with the tool
      // already in both hands above the hull, then lower it with his shoulders.
      standing.fork(-tip.x, Math.max(1.05, targetY - floor) - (1 + standing.a[1]) - tip.y,
        distance - .78 - tip.z, pitch, 0, 0).grip(1, 1.25, 1, 1.5);
      const lookYaw = killer.animator.lookYaw, lookPitch = killer.animator.lookPitch;
      killer.animator.lookYaw = killer.animator.lookPitch = 0;
      S.extra.push(() => { killer.animator.lookYaw = lookYaw;killer.animator.lookPitch = lookPitch; });
      killer.setBloody(0);killer.setEyeGlint(1);S.hide(player);S.u('uLetterbox', 0);S.splatT = 1e9;
      S.lamp = { x: eye.x - f.x * .12, y: floor + .1, z: eye.z - f.z * .12 };
    },
    events: [
      [.2, () => S.audio(canoe ? 'killer_step_wood' : 'killer_step')],
      [tDraw, () => S.audio('fork_ting')],
      [tJab, () => S.audio('fork_swing')],
      [tHit, () => { ctx.onReveal?.();S.audio('wood_crack');S.audio('fork_stab');S.splatT = S.t;S.flash = .7;S.shake = .7;killer.setBloody(1); }],
      [tHit + .12, () => S.audio('scream_death')],
      [tHit + .35, () => S.audio('stinger_jump')],
    ],
    figures(t, dt) { pose(t);S.shake = Math.max(0, S.shake - dt * 1.1); },
    frame(t) {
      const reveal = sstepc(.25, tSettle + .25, t), breath = Math.sin(t * 3) * .003;
      const fov = lerp(entry?.fov || 62, canoe ? 60 : 55, reveal);
      S.head(gaze);
      if (eyeMarkers.length) {
        if (canoe) { gaze.set(0, 0, 0);for (const mesh of eyeMarkers) gaze.add(mesh.getWorldPosition(marker));gaze.multiplyScalar(1 / eyeMarkers.length); }
        else eyeMarkers[0].getWorldPosition(gaze);
      }
      if (!canoe) {
        // The stall mask's crescent is above and left of center. Keep one eye
        // in that actual aperture (also in portrait) instead of framing the
        // sack behind the opaque door at the center of the screen.
        viewForward.subVectors(gaze, eye);const span = viewForward.length() * Math.tan(fov * PI / 360);
        viewForward.normalize();viewRight.crossVectors(viewForward, S.camera.up).normalize();viewUp.crossVectors(viewRight, viewForward).normalize();
        gaze.addScaledVector(viewRight, .221 * Math.min(1, S.camera.aspect) * span).addScaledVector(viewUp, -.28 * span);
      }
      gaze.lerp(entryTarget, 1 - reveal);
      S.cam(canoe ? 'canoe' : 'outhouse', eye.x, eye.y + breath, eye.z, gaze.x, gaze.y, gaze.z, fov);
      if (canoe && eyeMarkers.length >= 2) {
        // At phone landscape heights the existing hull rim leaves only a few
        // clear pixels. A small cinematic head tilt levels the actual eye
        // openings within that slit, including the entry camera's breathing.
        S.camera.updateMatrixWorld(true);
        eyeMarkers[0].getWorldPosition(viewRight).project(S.camera);
        eyeMarkers[1].getWorldPosition(viewUp).project(S.camera);
        let roll = Math.atan2(viewUp.y - viewRight.y, (viewUp.x - viewRight.x) * S.camera.aspect);
        if (roll > PI / 2) roll -= PI;else if (roll < -PI / 2) roll += PI;
        S.camera.rotateZ(roll * reveal);S.camera.updateMatrixWorld(true);
      }
      S.u('uDesat', .2 * reveal);
      if (t >= tHit) { const a = t - tHit;S.showSplat(true, clamp(a * 10, 0, 1));S.u('uRed', clamp(a / .85, 0, 1)); }
    },
  };
}
SEQ.canoe = S => coveredHideSequence(S, true);
SEQ.outhouse = S => coveredHideSequence(S, false);

SEQ.closet = (S) => {
  const { killer, player } = S;
  const g = povSequence(S, { look: 0, approach: { dist: 2.0, speed: 0.85 } });
  const tArrive = 2.4, tRaise = 4.1, tJab = tRaise + 0.4, tHit = tJab + 0.2, dur = 5.6;
  const { d, eye, eyeY } = g;
  const dl = { x: Math.cos(g.yk + PI), z: -Math.sin(g.yk + PI) };
  return {
    duration: dur,
    setup() {
      S.placeKiller(g.K0[0], g.K0[1], g.yk);
      S.kDir.set(g.kf.x, g.kf.z);
      S.kSpeed = 0.85;
      killer.setAnim('stalk', { restart: true, fade: 0.001 });
      killer.setBloody(0);
      killer.setEyeGlint(1);
      S.hide(player);
      S.u('uLetterbox', 0);
      S.splatT = 1e9;
      // The flashlight went down just outside the door. Enough to see him come.
      S.lamp = { x: eye.x + d.x * 0.5, y: S.groundY(eye.x, eye.z) + 0.1, z: eye.z + d.z * 0.5 };
    },
    events: [
      [tArrive, () => { S.kSpeed = 0; killer.setAnim('searchCloset'); }],
      [tRaise, () => killer.setAnim('raise')],
      [tJab, () => { killer.setAnim('jab'); S.audio('fork_swing'); }],
      [tHit, () => {
        S.audio('wood_crack'); S.audio('fork_stab');
        S.splatT = S.t;
        S.flash = 0.9; S.shake = 1.4;
        S.tines(V1);
        V2.set(-g.kf.x, 0.1, -g.kf.z);
        S.blood.burst(V1, V2, 30, 3);
        killer.setBloody(1);
      }],
      [tHit + 0.15, () => S.audio('scream_death')],
      [tHit + 0.35, () => { S.audio('stinger_jump'); }],
    ],
    figures(t, dt) {
      S.shake = Math.max(0, S.shake - dt * 0.9);
    },
    frame(t) {
      const k = clamp(t / dur, 0, 1);
      // cramped, breathing, a slow involuntary lean toward the slats
      const br = Math.sin(t * 2.6) * 0.006;
      const sway = Math.sin(t * 0.7) * 0.015;
      const turn = 0.05 * Math.sin(t * 0.9);
      const dd = { x: Math.sin(g.dYaw + turn), z: Math.cos(g.dYaw + turn) };
      const px = eye.x - d.x * 0.0 + dl.x * sway - d.x * 0.1 * sstepc(0, 4, t);
      const pz = eye.z + dl.z * sway - d.z * 0.1 * sstepc(0, 4, t);
      const hit = t >= tHit;
      S.cam('A', px, eyeY + br, pz, px + dd.x * 3, eyeY + br + 0.22 * sstepc(1, 2.6, t) * (1 - sstepc(4.2, 4.6, t)) - 0.05, pz + dd.z * 3, lerp(46, 40, k));
      S.u('uLetterbox', sstepc(0, 0.5, t));
      S.u('uDesat', 0.25 * sstepc(1.0, 4, t));
      if (hit) {
        const a = t - tHit;
        S.showSplat(true, clamp(a * 12, 0, 1));
        S.u('uRed', clamp(a / 1.2, 0, 1));
      }
    },
  };
};

SEQ.car = (S) => {
  const { killer, player } = S;
  const g = povSequence(S, { look: PI / 2, approach: { dist: 2.2, speed: 1.0 } });
  const tWalk = 0.4, tArrive = tWalk + 2.2, tRaise = tArrive + 0.2, tJab = tRaise + 0.4, tHit = tJab + 0.2, dur = 4.9;
  const { d, eye, eyeY } = g;
  const fy = (S.ctx.at.yaw || 0);
  const fwd = { x: Math.sin(fy), z: Math.cos(fy) };
  const side = { x: -d.z, z: d.x }; // the lens's right hand when looking along d... used for the shard patch
  let shards = null;
  return {
    duration: dur,
    setup() {
      S.placeKiller(g.K0[0], g.K0[1], g.yk);
      S.kDir.set(g.kf.x, g.kf.z);
      S.kSpeed = 0;
      killer.setAnim('idle', { restart: true, fade: 0.001 });
      killer.setBloody(0);
      killer.setEyeGlint(1);
      S.hide(player);
      S.u('uLetterbox', 0);
      S.splatT = 1e9;
      shards = makeShards(S);
    },
    events: [
      [tWalk, () => { S.kSpeed = 1.0; killer.setAnim('stalk'); }],
      [tArrive, () => { S.kSpeed = 0; killer.setAnim('listen'); }],
      [tRaise, () => killer.setAnim('raise')],
      [tJab, () => { killer.setAnim('jab'); S.audio('fork_swing'); }],
      [tHit, () => {
        S.audio('wood_crack'); S.audio('fork_stab');
        S.splatT = S.t;
        S.flash = 1; S.shake = 1.6;
        // the window: shards thrown in from where the glass was, 0.6 m to the driver's side
        shards.fire(eye.x + d.x * 0.6, eyeY, eye.z + d.z * 0.6, d.x, d.z, side.x, side.z);
        S.tines(V1);
        V2.set(-g.kf.x, 0.1, -g.kf.z);
        S.blood.burst(V1, V2, 26, 3);
        killer.setBloody(1);
      }],
      [tHit + 0.12, () => S.audio('scream_death')],
      [tHit + 0.35, () => S.audio('stinger_jump')],
    ],
    figures(t, dt) {
      S.shake = Math.max(0, S.shake - dt * 0.9);
      shards && shards.update(dt);
    },
    frame(t) {
      // eyes front through the windscreen, then the head turns to the window
      const turn = sstepc(0.9, 1.7, t);
      const ya = lerp(fy, g.dYaw, turn) + 0.03 * Math.sin(t * 5) * (1 - turn);
      const px = eye.x, pz = eye.z, lean = Math.sin(t * 3.1) * 0.004;
      S.cam('A', px, eyeY + lean, pz, px + Math.sin(ya) * 3, eyeY - 0.03, pz + Math.cos(ya) * 3, lerp(58, 50, turn));
      S.u('uLetterbox', sstepc(0, 0.5, t));
      if (t >= tHit) {
        const a = t - tHit;
        S.showSplat(true, clamp((a - 0.2) * 10, 0, 1));
        S.u('uRed', clamp((a - 0.3) / 1.0, 0, 1));
      }
    },
  };
};

// ------------------------------------------------------------------------------------------

export function playDeath(kind, ctx) {
  const S = new Session(ctx);
  S.kind = kind;
  const seq = (SEQ[kind] || SEQ.impale)(S);
  S.splatT = S.splatT ?? 1e9;
  S.u('uRed', 0); S.u('uFlash', 0); S.u('uTear', 0); S.u('uDesat', 0);
  seq.setup();
  seq.figures(0, 0);
  S.killer.update(0.001, { speed: S.kSpeed });
  if (kind === 'bed' || kind === 'canoe' || kind === 'outhouse') { seq.figures(0, 0);seq.frame(0); }
  let ev = 0, finished = false, restored = false;
  const events = seq.events.slice().sort((a, b) => a[0] - b[0]);
  const api = {
    kind,
    duration: seq.duration,
    get time() { return S.t; },
    done: false,
    blood: S.blood,
    update(dt) {
      if (finished) return;
      dt = Math.min(dt, 0.1);
      S.t += dt;
      while (ev < events.length && events[ev][0] <= S.t) events[ev++][1]();
      S.stepKiller(dt);
      if (S.player && S.player.root.visible) S.player.update(dt, { speed: 0 });
      seq.figures(S.t, dt);
      seq.frame(S.t, dt);
      S.aimLamp(dt);
      if (S.splat && S.splat.visible) S.showSplat(true, S.splat.material.opacity);
      S.blood.update(dt);
      // post: cuts tear the picture, impacts flash it
      S.tear = Math.max(0, S.tear - dt * 7);
      S.flash = Math.max(0, S.flash - dt * 4.5);
      S.u('uTear', S.tear);
      S.u('uFlash', S.flash);
      if (kind === 'impale' || kind === 'pinned') S.u('uLetterbox', sstepc(0, 0.5, S.t));
      if (S.t >= seq.duration) {
        finished = true;
        api.done = true;
        if (S.ctx.onDone) S.ctx.onDone();
      }
    },
    // put the camera, the hidden figures and the lens back. The post uniforms are left alone (red stays on
    // until the game says otherwise); the caller resets them with the rest of the game state.
    restore() {
      if (restored) return;
      restored = true;finished = true;
      for (const o of S.hidden) o.root.visible = true;
      S.hidden.length = 0;
      S.frozen = null;
      S.camera.fov = S.fov0;
      S.camera.updateProjectionMatrix();
      S.camera.up.set(0, 1, 0);
      for (const f of S.extra) f();
      S.extra.length = 0;
      S.blood.clear();
      S.blood.dispose();
      if (S.camParent && S.camParent !== S.scene) S.camParent.attach(S.camera);
    },
  };
  return api;
}
