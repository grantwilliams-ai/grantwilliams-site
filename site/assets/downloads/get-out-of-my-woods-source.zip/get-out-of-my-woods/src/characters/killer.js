// The man in the sack. 2.15 m, heavy, hunched, arms too long. Burlap feed sack tied at the neck,
// filthy overalls over a stained shirt, work gloves, rubber boots, a long rusted three-tine pitchfork.
// Built as rigid segments on one skeleton, four draw calls (cloth, hard, burlap, eye glints).
import * as THREE from 'three';
import { lit } from '../render/materials.js';
import { Rig, Animator, legTo } from './rig.js';
import { MeshBuilder, toGeometry, surfaceAt, rgb } from './mesh.js';
import { clothTexture, burlapTexture, hardTexture } from './tex.js';
import { locomote, legWorld, breath, sstep, easeOut, lerp, clamp, TAU } from './anim.js';
import { createStanceStabilizer } from './stance.js';

const J = {
  pelvis: [0, 1.0, 0], spine: [0, 1.12, 0], chest: [0, 1.38, 0], head: [0, 1.8, 0.02],
  uarmL: [0.38, 1.68, 0], farmL: [0.38, 1.21, 0], handL: [0.38, 0.74, 0],
  uarmR: [-0.38, 1.68, 0], farmR: [-0.38, 1.21, 0], handR: [-0.38, 0.74, 0],
  thighL: [0.17, 1.0, 0], shinL: [0.17, 0.54, 0], footL: [0.17, 0.12, 0],
  thighR: [-0.17, 1.0, 0], shinR: [-0.17, 0.54, 0], footR: [-0.17, 0.12, 0],
  fork: [0, 1.0, 0],
};
const PARENT = {
  pelvis: null, spine: 'pelvis', chest: 'spine', head: 'chest', fork: 'pelvis',
  uarmL: 'chest', farmL: 'uarmL', handL: 'farmL', uarmR: 'chest', farmR: 'uarmR', handR: 'farmR',
  thighL: 'pelvis', shinL: 'thighL', footL: 'shinL', thighR: 'pelvis', shinR: 'thighR', footR: 'shinR',
};
const D = { L1: 0.46, L2: 0.42, ankle: 0.12, hipX: 0.17, hipY: 1.0 };
const ARM = { L1: 0.47, L2: 0.47 };

const DENIM = 0x40546a, DENIM_DIRT = 0x29343d, DENIM_SEAM = 0x70808c, SHIRT = 0x737566, SHIRT_DIRT = 0x484c42;
const GLOVE = 0x85785e, RUBBER = 0x1b1e1c, SOLE = 0x0c0e0f, RUST = 0x6e3a1c, ROPE = 0x6e6046;

function slab(mb, cx, cy, cz, hw, hh, hd, color, bev = 0.012) {
  bev = Math.min(bev, hw * 0.8, hh * 0.8, hd * 0.8);
  const S = Math.SQRT2;
  mb.loft(
    [
      { y: cy - hh, rx: (hw - bev) * S, rz: (hd - bev) * S, ox: cx, oz: cz },
      { y: cy - hh + bev, rx: hw * S, rz: hd * S, ox: cx, oz: cz },
      { y: cy + hh - bev, rx: hw * S, rz: hd * S, ox: cx, oz: cz },
      { y: cy + hh, rx: (hw - bev) * S, rz: (hd - bev) * S, ox: cx, oz: cz },
    ],
    { sides: 4, phase: Math.PI / 4, sq: 1, color },
  );
}

// ragged polygon on the sack, given in (angle, height) space and laid on the faceted surface
function sackPoly(mb, g, ac, yc, w, h, color, off, seed = 1, n = 7, rag = 0.3, tilt = 0, edge) {
  const pts = [];
  const ct = Math.cos(tilt), st = Math.sin(tilt);
  for (let i = 0; i < n; i++) {
    const th = (i / n) * TAU;
    const r = 1 + rag * Math.sin(seed * 12.9898 + i * 78.233) * 0.9;
    const dx = Math.cos(th) * w * r, dy = Math.sin(th) * h * r;
    // w and h are metres; the sack is about 0.3 m in radius, so x converts to an angle
    pts.push(surfaceAt(g, ac + (dx * ct - dy * st) / 0.3, yc + dx * st + dy * ct, off).p);
  }
  mb.fan(pts, color, edge);
  return pts;
}

function buildGeometry() {
  const mk = () => {
    const m = new MeshBuilder();
    return m;
  };
  const cloth = mk(), hard = mk(), burl = mk();
  burl.uvScale = 1.8;
  burl.tint = rgb(0xb4b1a6); // old grey-brown sacking, never bright or warm
  hard.uvScale = 4;
  const I = (n) => BONES.indexOf(n);
  const sides = (L) => ({ L, R: L });

  // ---- cloth: overalls, shirt ----  (a side of beef in overalls: wide, deep, a heavy gut)
  const c = cloth;
  c.part(I('pelvis'), J.pelvis);
  c.loft([
    { y: -0.22, rx: 0.27, rz: 0.2, c: DENIM_DIRT },
    { y: -0.08, rx: 0.35, rz: 0.27, oz: 0.01, c: DENIM },
    { y: 0.1, rx: 0.37, rz: 0.3, oz: 0.025, c: DENIM },
    { y: 0.12, rx: 0.37, rz: 0.3, oz: 0.025, c: DENIM },
  ], { sides: 12, sq: 0.85, capBot: false });
  c.part(I('spine'), J.spine);
  c.loft([
    { y: -0.02, rx: 0.37, rz: 0.3, oz: 0.025, c: DENIM },
    { y: 0.1, rx: 0.39, rz: 0.345, oz: 0.06, lump: 0.03, c: DENIM },
    { y: 0.27, rx: 0.41, rz: 0.32, oz: 0.035, c: SHIRT },
  ], { sides: 12, sq: 0.85, capBot: false });
  c.part(I('chest'), J.chest);
  const chestRings = [
    { y: -0.02, rx: 0.41, rz: 0.32, oz: 0.03, c: SHIRT },
    { y: 0.14, rx: 0.45, rz: 0.32, oz: 0.0, c: SHIRT },
    { y: 0.27, rx: 0.48, rz: 0.32, oz: -0.03, c: SHIRT_DIRT },
    { y: 0.36, rx: 0.43, rz: 0.285, oz: -0.06, c: SHIRT },
    { y: 0.43, rx: 0.31, rz: 0.22, oz: -0.06, c: SHIRT },
    { y: 0.48, rx: 0.22, rz: 0.19, oz: -0.04, c: SHIRT_DIRT },
    { y: 0.5, rx: 0.2, rz: 0.18, oz: -0.03, c: SHIRT_DIRT },
  ];
  const chestSurface = c.loft(chestRings, { sides: 12, sq: 0.8, capBot: false });
  // Crossed workwear straps make his rear silhouette as authored as the face.
  for (const side of [-1, 1]) {
    for (let i = 0; i < 5; i++) {
      const y0 = 0.02 + i * 0.072, y1 = y0 + 0.072;
      const a0 = Math.PI + side * (0.48 - i * 0.15), a1 = a0 - side * 0.15;
      c.fan([surfaceAt(chestSurface,a0-0.07,y0,0.01).p,surfaceAt(chestSurface,a0+0.07,y0,0.01).p,
        surfaceAt(chestSurface,a1+0.07,y1,0.01).p,surfaceAt(chestSurface,a1-0.07,y1,0.01).p],rgb(DENIM));
    }
  }
  // The bib follows the chest curvature; a flat slab intersected the shirt and left
  // jagged, floating edges at normal playing distance.
  const denimSeam = rgb(DENIM_SEAM);
  const patch = (a0,a1,y0,y1,color,offset=0.012) => {
    const cols=8, rows=4;
    for(let j=0;j<rows;j++)for(let i=0;i<cols;i++) {
      const aa=a0+(a1-a0)*i/cols, ab=a0+(a1-a0)*(i+1)/cols;
      const ya=y0+(y1-y0)*j/rows,yb=y0+(y1-y0)*(j+1)/rows;
      c.fan([surfaceAt(chestSurface,aa,ya,offset).p,surfaceAt(chestSurface,ab,ya,offset).p,
        surfaceAt(chestSurface,ab,yb,offset).p,surfaceAt(chestSurface,aa,yb,offset).p],rgb(color));
    }
  };
  patch(-0.57,0.57,-0.015,0.29,DENIM);
  patch(-0.54,0.54,0.277,0.286,DENIM_SEAM,0.015);
  patch(-0.56,-0.54,-0.012,0.277,DENIM_SEAM,0.015);
  patch(0.54,0.56,-0.012,0.277,DENIM_SEAM,0.015);
  patch(0.01,0.38,0.025,0.145,DENIM_DIRT,0.019);
  patch(0.025,0.365,0.133,0.14,DENIM_SEAM,0.022);
  // one strap over the left shoulder, the other twisted and hanging loose
  c.part(I('chest'), [J.chest[0] + 0.16, J.chest[1] + 0.36, J.chest[2] + 0.12], [-1.25, 0, 0.04]);
  slab(c, 0, 0, 0, 0.038, 0.23, 0.01, DENIM, 0.005);
  c.fan([[0.023, -0.19, 0.011], [0.028, -0.19, 0.011], [0.028, 0.19, 0.011], [0.023, 0.19, 0.011]], denimSeam);
  c.part(I('chest'), [J.chest[0] - 0.15, J.chest[1] + 0.25, J.chest[2] + 0.335], [0.05, 0.0, 0.1]);
  slab(c, 0, -0.1, 0, 0.034, 0.11, 0.008, DENIM, 0.005);
  c.part(I('chest'), [J.chest[0] - 0.17, J.chest[1] + 0.02, J.chest[2] + 0.33], [0.1, 1.2, 0.12]);
  slab(c, 0, -0.1, 0, 0.034, 0.11, 0.008, DENIM_DIRT, 0.005);
  // arms: thick sleeves with glove cuffs
  for (const s of ['L', 'R']) {
    c.part(I('uarm' + s), J['uarm' + s]);
    c.loft([
      { y: 0.1, rx: 0.15, rz: 0.145, c: SHIRT },
      { y: -0.04, rx: 0.175, rz: 0.165, c: SHIRT },
      { y: -0.22, rx: 0.15, rz: 0.145, c: SHIRT_DIRT },
      { y: -0.47, rx: 0.118, rz: 0.112, c: SHIRT },
    ], { sides: 8, sq: 0.9 });
    c.fan([[-0.085, -0.19, 0.151], [0.075, -0.225, 0.151], [0.075, -0.215, 0.153], [-0.085, -0.18, 0.153]], rgb(SHIRT_DIRT));
    c.part(I('farm' + s), J['farm' + s]);
    c.loft([
      { y: 0.04, rx: 0.118, rz: 0.112, c: SHIRT },
      { y: -0.15, rx: 0.135, rz: 0.125, c: SHIRT_DIRT },
      { y: -0.38, rx: 0.1, rz: 0.092, c: SHIRT },
      { y: -0.44, rx: 0.098, rz: 0.09, c: SHIRT_DIRT },
    ], { sides: 8, sq: 0.9 });
    c.fan([[-0.065, -0.28, 0.103], [0.06, -0.3, 0.103], [0.06, -0.291, 0.105], [-0.065, -0.271, 0.105]], rgb(SHIRT_DIRT));
    // overall legs
    c.part(I('thigh' + s), J['thigh' + s]);
    c.loft([
      { y: 0.08, rx: 0.2, rz: 0.2, c: DENIM },
      { y: -0.1, rx: 0.205, rz: 0.205, c: DENIM },
      { y: -0.3, rx: 0.165, rz: 0.17, c: DENIM },
      { y: -0.46, rx: 0.145, rz: 0.15, c: DENIM_DIRT },
    ], { sides: 8, sq: 0.9 });
    c.fan([[-0.006, 0.035, 0.203], [0.006, 0.035, 0.203], [0.005, -0.4, 0.154], [-0.005, -0.4, 0.154]], denimSeam);
    c.fan([[-0.1, -0.275, 0.174], [0.09, -0.3, 0.174], [0.09, -0.289, 0.176], [-0.1, -0.264, 0.176]], rgb(DENIM_DIRT));
    c.part(I('shin' + s), J['shin' + s]);
    c.loft([
      { y: 0.04, rx: 0.145, rz: 0.15, c: DENIM_DIRT },
      { y: -0.1, rx: 0.15, rz: 0.15, c: DENIM },
      { y: -0.2, rx: 0.155, rz: 0.155, c: DENIM_DIRT },
    ], { sides: 8, sq: 0.9 });
  }

  // ---- hard: boots, gloves, rope, fork ----
  const h = hard;
  for (const [x, y] of [[0.16, 0.245], [-0.15, 0.21]]) {
    h.part(I('chest'), [x, J.chest[1] + y, J.chest[2] + 0.342], [Math.PI / 2, 0, 0]);
    h.loft([
      { y: -0.006, rx: 0.018, rz: 0.018, c: 0x51452f },
      { y: 0, rx: 0.021, rz: 0.021, c: 0x9a8656 },
      { y: 0.006, rx: 0.016, rz: 0.016, c: 0x6f603f },
    ], { sides: 6, sq: 1 });
  }
  for (const s of ['L', 'R']) {
    h.part(I('shin' + s), J['shin' + s]);
    h.loft([
      { y: -0.145, rx: 0.157, rz: 0.162, c: 0x30342f },
      { y: -0.18, rx: 0.153, rz: 0.156, c: RUBBER },
      { y: -0.4, rx: 0.125, rz: 0.125, c: RUBBER },
      { y: -0.43, rx: 0.125, rz: 0.125, c: RUBBER },
    ], { sides: 8, sq: 0.9 });
    h.part(I('foot' + s), J['foot' + s]);
    slab(h, 0, -0.04, 0.07, 0.115, 0.04, 0.15, RUBBER, 0.02); // upper
    slab(h, 0, -0.085, 0.07, 0.125, 0.035, 0.22, SOLE, 0.02); // sole
    slab(h, 0, -0.02, 0.22, 0.095, 0.03, 0.055, 0x242824, 0.015); // toe
    h.part(I('hand' + s), J['hand' + s]);
    h.loft([
      { y: 0.02, rx: 0.1, rz: 0.092, c: GLOVE },
      { y: -0.06, rx: 0.108, rz: 0.1, c: 0x5a5040 },
      { y: -0.075, rx: 0.088, rz: 0.08, c: GLOVE },
    ], { sides: 6, sq: 0.9 });
    h.part(I('hand' + s), [J['hand' + s][0], J['hand' + s][1] - 0.11, J['hand' + s][2]], [0, 0, Math.PI / 2]);
    h.loft([
      { y: -0.1, rx: 0.07, rz: 0.075, c: GLOVE },
      { y: -0.06, rx: 0.085, rz: 0.09, c: GLOVE },
      { y: 0.06, rx: 0.085, rz: 0.09, c: 0x6b6050 },
      { y: 0.1, rx: 0.065, rz: 0.07, c: GLOVE },
    ], { sides: 6, sq: 0.9 });
  }
  // Ash and worn steel catch a little moonlight; only the last few millimetres are bright metal.
  const ASH = 0x9a865f, ASH_OLD = 0x6b573c, GRIP = 0x403226;
  h.part(I('fork'), J.fork);
  h.loft([
    { y: -0.15, rx: 0.026, rz: 0.026, c: GRIP },
    { y: -0.12, rx: 0.033, rz: 0.033, c: GRIP },
    { y: 0.1, rx: 0.031, rz: 0.031, c: ASH_OLD }, // the worn, hand-polished end
    { y: 0.5, rx: 0.028, rz: 0.028, c: ASH_OLD },
    { y: 0.85, rx: 0.027, rz: 0.027, c: ASH },
    { y: 1.3, rx: 0.026, rz: 0.026, c: ASH },
    { y: 1.46, rx: 0.027, rz: 0.027, c: 0x746047 },
  ], { sides: 8, sq: 1 });
  // the socket the handle is driven into, and the narrow bar the tines grow from
  h.loft([
    { y: 1.42, rx: 0.036, rz: 0.036, c: 0x443326 },
    { y: 1.5, rx: 0.038, rz: 0.038, c: RUST },
    { y: 1.57, rx: 0.027, rz: 0.027, c: 0x62503d },
  ], { sides: 8, sq: 1 });
  slab(h, 0, 1.585, 0, 0.112, 0.017, 0.013, 0x62503d, 0.008);
  const TIN = 0.38;
  for (const ox of [0.1, 0.034, -0.034, -0.1]) {
    const sp = Math.sign(ox) * 0.008; // the outer pair spreads a hair
    const ring = (t, rx, rz, c) => ({ y: 1.6 + TIN * t, rx, rz, ox: ox + sp * t, oz: 0.05 * t * t * (0.6 + 0.4 * t), c });
    h.loft([
      ring(0, 0.017, 0.013, 0x51402f),
      ring(0.3, 0.0135, 0.0105, 0x68513b),
      ring(0.62, 0.0105, 0.0085, 0x766552),
      ring(0.86, 0.0075, 0.006, 0x8d826e),
      ring(0.95, 0.005, 0.0045, 0xb4ac99),
      ring(1, 0.0014, 0.0014, 0xd0cabd),
    ], { sides: 4, sq: 1 });
  }

  // ---- burlap: the sack, its decals, the seam ----
  const b = burl;
  b.part(I('head'), J.head);
  // A tall, filled sack with a soft off-centre crown. The neck stays cinched and the loose bottom
  // still overlaps the rope, but the face is narrower than the shoulders of the sack.
  const rings = [
    { y: -0.1, rx: 0.25, rz: 0.235, lump: 0.06, c: 0x7a766d },
    { y: -0.04, rx: 0.215, rz: 0.205, lump: 0.06, c: 0x6a665e },
    { y: 0.03, rx: 0.168, rz: 0.16, c: 0x5c5850 }, // cinched by the rope
    { y: 0.11, rx: 0.25, rz: 0.23, lump: 0.055 },
    { y: 0.22, rx: 0.295, rz: 0.27, lump: 0.06 },
    { y: 0.35, rx: 0.305, rz: 0.28, lump: 0.065, oz: 0.005 },
    { y: 0.46, rx: 0.28, rz: 0.255, lump: 0.07, oz: 0.02, ox: -0.02 },
    { y: 0.52, rx: 0.22, rz: 0.205, lump: 0.08, oz: 0.04, ox: -0.055 },
    { y: 0.545, rx: 0.145, rz: 0.15, lump: 0.09, oz: 0.055, ox: -0.09 },
  ];
  const SACK_R = 0.305;
  const SX = 0.99, SZ = 1.03, SY = 1.16;
  const sy = (y) => (y > 0.03 ? 0.03 + (y - 0.03) * SY : y);
  const sackOpts = { sides: 14, sq: 0.95, capBot: false };
  const g = b.loft(rings.map((r) => ({ ...r, y: sy(r.y), rx: r.rx * SX, rz: r.rz * SZ, ox: (r.ox || 0) * SX })), sackOpts);
  // one top corner folded over and sagging down the side, lying against the cloth (not an ear)
  b.part(I('head'), [J.head[0] - 0.25, J.head[1] + sy(0.49), J.head[2] + 0.045], [0, 0, 2.95]);
  b.loft([
    { y: 0, rx: 0.045, rz: 0.13, c: 0x8a867c },
    { y: 0.075, rx: 0.05, rz: 0.13, lump: 0.07, c: 0x7a766d },
    { y: 0.16, rx: 0.044, rz: 0.105, lump: 0.07 },
    { y: 0.23, rx: 0.033, rz: 0.065, lump: 0.07, c: 0x6a665e },
    { y: 0.28, rx: 0.012, rz: 0.022, c: 0x5c5850 },
  ], { sides: 6, sq: 0.85, capBot: false });
  b.part(I('head'), J.head);
  const dark = rgb(0x000000), white = rgb(0xb4b1a6); // rim colour = the sack tint, so decals fade into the cloth
  // creases: dark seams in the cloth where the sack folds over the skull
  sackPoly(b, g, 0.15, 0.47, 0.12, 0.005, rgb(0x4b463c), 0.006, 21, 7, 0.25, -0.25, white);
  sackPoly(b, g, -0.55, 0.405, 0.09, 0.005, rgb(0x4b463c), 0.006, 22, 7, 0.25, 0.3, white);
  // eye holes: small rough knife-cuts, not circles. The left a little larger, the right clearly
  // lower; pure black, slightly puckered, with a few loose threads
  const holeA = [0.34, 0.31, 0.064, 0.02, -0.18], holeB = [-0.34, 0.23, 0.055, 0.017, 0.12];
  const pucker = rgb(0x625d52), rimc = rgb(0x302c25);
  for (const [i, H] of [holeA, holeB].entries()) {
    sackPoly(b, g, H[0], H[1], H[2] * 1.28, H[3] * 1.9, pucker, 0.004, 3 + i * 2, 9, 0.22, H[4], white);
    sackPoly(b, g, H[0], H[1], H[2] * 1.12, H[3] * 1.3, rimc, 0.007, 4 + i * 3, 9, 0.32, H[4]);
    sackPoly(b, g, H[0], H[1], H[2], H[3], dark, 0.011, 7 + i * 4, 10, 0.4, H[4]);
    // frayed ends: four loose threads
    const ct = Math.cos(H[4]), st = Math.sin(H[4]);
    for (let f = 0; f < 4; f++) {
      const side = f % 2 ? 1 : -1, d = H[2] * (0.9 + 0.12 * f);
      sackPoly(b, g, H[0] + (side * d * ct) / SACK_R, H[1] + side * d * st + (f - 1.5) * 0.004, 0.012 + f * 0.0025, 0.002, rgb(0x8a8474), 0.012, 31 + f + i * 5, 4, 0.25, H[4] + (f - 1.5) * 0.6, white);
    }
  }
  // crude seam down the left cheek with cross stitches
  const seamPts = [];
  for (let i = 0; i <= 9; i++) seamPts.push([1.12 - i * 0.045 + Math.sin(i * 1.7) * 0.03, 0.43 - i * 0.043]);
  for (let i = 0; i < 9; i++) {
    const [a0, y0] = seamPts[i + 1], [a1, y1] = seamPts[i];
    const da = 0.025;
    b.fan([
      surfaceAt(g, a0 - da, y0, 0.008).p, surfaceAt(g, a0 + da, y0, 0.008).p,
      surfaceAt(g, a1 + da, y1, 0.008).p, surfaceAt(g, a1 - da, y1, 0.008).p,
    ], rgb(0x5d5748));
  }
  for (let i = 0; i < 9; i += 2) {
    const [a0, y0] = seamPts[i];
    const t = i % 2 ? 0.01 : -0.012;
    b.fan([
      surfaceAt(g, a0 - 0.1, y0 - 0.005 + t, 0.011).p, surfaceAt(g, a0 + 0.1, y0 - 0.005 - t, 0.011).p,
      surfaceAt(g, a0 + 0.1, y0 + 0.007 - t, 0.011).p, surfaceAt(g, a0 - 0.1, y0 + 0.007 + t, 0.011).p,
    ], rgb(0x353027));
  }
  // Broad, faint handling stains live away from the eyes and fade fully into the weave.
  const stain = rgb(0x746e61);
  sackPoly(b, g, -1.0, 0.14, 0.05, 0.09, stain, 0.007, 2, 10, 0.18, 0, white);
  sackPoly(b, g, 1.15, 0.1, 0.07, 0.08, stain, 0.007, 17, 10, 0.18, 0, white);
  sackPoly(b, g, 0.0, 0.49, 0.1, 0.035, rgb(0x7b7568), 0.007, 3, 10, 0.18, 0, white);
  sackPoly(b, g, -1.35, 0.32, 0.06, 0.07, stain, 0.007, 15, 10, 0.18, 0, white);
  sackPoly(b, g, 0.0, 0.12, 0.065, 0.04, rgb(0x7a7569), 0.007, 4, 9, 0.18, 0, white); // where the breath wets it
  // dried blood: brown until he has killed, then wet red (see setBloody)
  const bloodStart = b.pos.length / 3;
  sackPoly(b, g, 0.42, 0.14, 0.06, 0.045, rgb(0x40240f), 0.009, 6, 11, 0.7, 0.5, white);
  sackPoly(b, g, 0.5, 0.17, 0.035, 0.03, rgb(0x40240f), 0.009, 7, 9, 0.7, 0, white);
  sackPoly(b, g, 0.5, 0.05, 0.014, 0.07, rgb(0x40240f), 0.009, 8, 7, 0.3, 0, white);
  sackPoly(b, g, 0.38, 0.03, 0.01, 0.045, rgb(0x40240f), 0.009, 11, 7, 0.3, 0, white);
  sackPoly(b, g, -0.9, 0.3, 0.04, 0.03, rgb(0x40240f), 0.009, 13, 10, 0.7, 0.9, white);
  sackPoly(b, g, -0.86, 0.22, 0.012, 0.055, rgb(0x40240f), 0.009, 14, 7, 0.3, 0, white);
  const bloodEnd = b.pos.length / 3;

  // the rope at the neck: two wraps, a knot and two frayed ends (hard material)
  h.part(I('head'), J.head);
  h.loft([
    { y: -0.005, rx: 0.22, rz: 0.21, c: ROPE },
    { y: 0.035, rx: 0.228, rz: 0.218, c: 0x544a34 },
    { y: 0.045, rx: 0.22, rz: 0.21, c: ROPE },
    { y: 0.068, rx: 0.225, rz: 0.215, c: ROPE },
  ], { sides: 10, sq: 0.95, capTop: false, capBot: false });
  h.part(I('head'), [J.head[0] + 0.07, J.head[1] + 0.035, J.head[2] + 0.225], [0, 0.4, 0]);
  slab(h, 0, 0, 0, 0.04, 0.034, 0.03, ROPE, 0.012);
  h.part(I('head'), [J.head[0] + 0.07, J.head[1] + 0.005, J.head[2] + 0.25], [0.1, 0.4, 0.15]);
  h.loft([{ y: 0, rx: 0.012, rz: 0.012, c: ROPE }, { y: -0.14, rx: 0.011, rz: 0.011, c: ROPE }, { y: -0.27, rx: 0.017, rz: 0.017, c: 0x8e8264 }], { sides: 4, sq: 1 });
  h.part(I('head'), [J.head[0] + 0.095, J.head[1] + 0.005, J.head[2] + 0.245], [0.1, 0.4, -0.2]);
  h.loft([{ y: 0, rx: 0.012, rz: 0.012, c: ROPE }, { y: -0.1, rx: 0.011, rz: 0.011, c: ROPE }, { y: -0.19, rx: 0.016, rz: 0.016, c: 0x8e8264 }], { sides: 4, sq: 1 });

  // ---- morph: the sack sucked in over the mouth ----
  const bg = toGeometry(burl);
  const morph = new Float32Array(bg.attributes.position.count * 3);
  const pa = bg.attributes.position.array;
  const mouth = new THREE.Vector3(J.head[0], J.head[1] + 0.16, J.head[2] + 0.3);
  const v = new THREE.Vector3(), d = new THREE.Vector3();
  for (let i = 0; i < pa.length / 3; i++) {
    v.set(pa[i * 3], pa[i * 3 + 1], pa[i * 3 + 2]);
    const dist = v.distanceTo(mouth);
    const f = clamp(1 - dist / 0.16, 0, 1);
    if (f <= 0 || v.z < J.head[2] + 0.05) continue;
    d.set(J.head[0] - v.x, 0, J.head[2] + 0.01 - v.z).normalize().multiplyScalar(0.05 * f * f * (3 - 2 * f));
    morph[i * 3] = d.x;
    morph[i * 3 + 1] = -0.012 * f; // the cloth is drawn down a little as well
    morph[i * 3 + 2] = d.z;
  }
  bg.morphAttributes.position = [new THREE.Float32BufferAttribute(morph, 3)];
  bg.morphTargetsRelative = true;
  return {
    cloth: toGeometry(cloth, null, true),
    hard: toGeometry(hard, null, true),
    burlap: bg,
    holes: { a: surfaceAt(g, holeA[0], holeA[1], 0.014), b: surfaceAt(g, holeB[0], holeB[1], 0.014) },
    bloodRange: [bloodStart, bloodEnd],
  };
}

const BONES = ['pelvis', 'spine', 'chest', 'head', 'uarmL', 'farmL', 'handL', 'uarmR', 'farmR', 'handR', 'thighL', 'shinL', 'footL', 'thighR', 'shinR', 'footR', 'fork'];

// ---------------------------------------------------------------------------------------------
// Animation. Everything is angles in radians; positive x rotation pitches the top forward (and a
// hanging limb backward). L is +x, R is -x, the figure faces +z.

const ARMS_IK = {
  R: { upper: 'uarmR', fore: 'farmR', hand: 'handR', ...ARM, pole: [-0.5, -0.8, -0.35] },
  L: { upper: 'uarmL', fore: 'farmL', hand: 'handL', ...ARM, pole: [0.5, -0.8, -0.35] },
};

// Hunched, heavy posture shared by everything. lean adds forward bend; headLevel keeps the sack
// looking where he is going rather than at his boots.
function torso(P, lean = 0, twist = 0, roll = 0, headLook = 0.12) {
  const sp = 0.26 + lean * 0.5, ch = 0.3 + lean * 0.5;
  P.rot('spine', sp, twist * 0.5, roll * 0.5);
  P.rot('chest', ch, twist * 0.5, roll * 0.5);
  return { sp, ch, headRx: -(sp + ch + 0.06) + headLook - 0.06 };
}

function freeArms(P, swing = 0, l = 1, r = 1) {
  P.rot('uarmL', -0.08 + swing * l, 0, 0.2);
  P.rot('farmL', -0.3 - Math.abs(swing) * 0.4, 0, 0);
  P.rot('handL', -0.1, 0, 0);
  P.rot('uarmR', -0.08 - swing * r, 0, -0.2);
  P.rot('farmR', -0.3, 0, 0);
  P.rot('handR', -0.1, 0, 0);
}

const _fe = new THREE.Euler(0, 0, 0, 'YXZ'), _fa = new THREE.Vector3();
// put the fork where the handle point u (m from the fork origin) sits at pelvis-relative (gx, gy, gz),
// pointing along the Euler (rx, ry, rz)
function holdFork(P, gx, gy, gz, rx, ry, rz, u) {
  _fe.set(rx, ry, rz, 'YXZ');
  _fa.set(0, 1, 0).applyEuler(_fe);
  P.fork(gx - _fa.x * u, gy - _fa.y * u, gz - _fa.z * u, rx, ry, rz);
  return P;
}
// the way he carries it: one hand low at his right side, the handle angled a little across his body,
// butt behind and up, tines forward and down a hand's breadth off the ground. A tool he has always carried.
// The angle stays small (0.08 rad, was 0.3) and swings outward as the right leg comes through: at 0.3
// the handle crossed in front of that leg and passed through his shin on every stride.
function hangFork(P, ph = 0, amp = 0, drop = 0, k = 0) {
  const sw = Math.cos(TAU * ph) * amp;
  holdFork(P, -0.44, -0.2 + drop, 0.1 + Math.sin(TAU * 2 * ph) * 0.012 * amp, 2.2 + 0.07 * sw + k, 0.08 + 0.05 * sw, 0, 0.98);
  P.grip(1, 0.98);
}
function plantFork(P, k = 0) {
  hangFork(P, 0, 0, 0, k);
}
function carryFork(P, ph = 0, amp = 1, lift = 0) {
  // the pelvis rides lower when he walks, so the hand comes up with it and the tines stay off the ground
  hangFork(P, ph, amp, lift, 0);
}

function stance(P, hip, t, wL = 0.06, wR = -0.06, spread = 0.03, pel = 0.05) {
  P.pel(0, hip - 1.0, 0);
  P.rot('pelvis', pel, 0, 0);
  legTo(P, 'L', D, spread, -(hip - D.ankle), wL, 0, [pel, 0, 0]);
  legTo(P, 'R', D, spread, -(hip - D.ankle), wR, 0, [pel, 0, 0]);
}

const G_WALK = { S: 1.0, duty: 0.62, lift: 0.1, hip: 0.86, foot: 0.2, toe: 0.22, roll: 0.3, sway: 0.045, yaw: 0.1, bob: 0.0, rollP: 0.035, pitch: 0.06, heel: 0.13 };
const G_STALK = { S: 0.85, duty: 0.68, lift: 0.07, hip: 0.8, foot: 0.2, toe: 0.2, roll: 0.3, sway: 0.05, yaw: 0.08, bob: 0.0, rollP: 0.04, pitch: 0.1, heel: 0.13 };
const G_CHASE = { S: 1.3, duty: 0.46, lift: 0.3, hip: 0.84, foot: 0.19, toe: 0.3, roll: 0.5, sway: 0.05, yaw: 0.2, bob: -0.045, rollP: 0.05, pitch: 0.2, heel: 0.13 };

function gait(P, st, G, lean, swingAmt, forkFn, headDrop = 0) {
  const ph = st.phase;
  const L = locomote(P, ph, G, D);
  // shoulders counter-twist against the hips; the head stays level and keeps looking ahead
  const t = torso(P, lean, -L.pyaw * 1.35, -L.proll * 1.1, 0.14 - headDrop);
  P.rot('head', t.headRx, L.pyaw * 0.35, L.proll * 0.9 + 0.1);
  freeArms(P, Math.cos(TAU * ph) * swingAmt, 1, 1);
  forkFn(P, ph);
  return L;
}

const killerAnims = {
  idle: {
    fade: 0.4,
    fn(P, st, ex) {
      const t = st.t, b = breath(t, 4.6);
      ex.breath = b;
      stance(P, 0.955 - b * 0.004, t, 0.07, -0.07, 0.035, 0.05);
      const tr = torso(P, 0.0 + b * 0.02, 0.03 * Math.sin(t * 0.37), 0.01 * Math.sin(t * 0.5), 0.14);
      P.addRot('chest', b * 0.025, 0, 0);
      P.rot('head', tr.headRx - b * 0.02, 0.06 * Math.sin(t * 0.23), 0.12 + 0.04 * Math.sin(t * 0.31));
      freeArms(P, 0, 1, 1);
      P.addRot('uarmL', 0, 0, b * 0.02);
      plantFork(P);
    },
  },
  standStill: {
    fade: 0.5,
    fn(P, st, ex) {
      ex.breath = 0;
      stance(P, 0.95, st.t, 0.05, -0.05, 0.03, 0.05);
      const tr = torso(P, 0.0, 0, 0, 0.06);
      P.rot('head', tr.headRx + 0.1, 0.05, 0.1); // the head hangs a little, like a stuffed one
      freeArms(P, 0, 1, 1);
      plantFork(P);
    },
  },
  scarecrow: {
    fade: 0.4,
    fn(P, st, ex) {
      // the fork across his shoulders, wrists hung over it: one more dummy on the range
      ex.breath = 0;
      stance(P, 0.96, st.t, 0.05, -0.05, 0.02, 0);
      P.rot('spine', 0.02, 0, 0);
      P.rot('chest', 0.0, 0, 0);
      P.rot('head', 0.5, 0.05, 0.22);
      P.fork(1.05, 0.54, -0.12, 0, 0, Math.PI / 2);
      P.grip(1, 1.85, 1, 0.25);
    },
  },
  listen: {
    fade: 0.5,
    fn(P, st, ex) {
      const t = st.t, b = breath(t, 6);
      ex.breath = b * 0.6;
      stance(P, 0.95, t, 0.07, -0.07, 0.035, 0.07);
      const k = sstep(0.5, 2.6, t); // the tilt takes its time, then stays too long
      const tr = torso(P, 0.04 * k, 0, 0.05 * k, 0.1);
      P.rot('head', tr.headRx + 0.06 * k, 0.12 * k, 0.55 * k + 0.012 * Math.sin(t * 1.3));
      freeArms(P, 0, 1, 1);
      plantFork(P);
    },
  },
  lookAround: {
    fade: 0.4,
    fn(P, st, ex) {
      const t = st.t, u = t % 8;
      const yaw = (x) => 1.05 * sstep(0.3, 1.4, x) - 1.05 * sstep(2.3, 3.2, x) - 1.15 * sstep(3.5, 4.8, x) + 1.15 * sstep(6, 7.3, x);
      const hy = yaw(u), cy = yaw((u + 8 - 0.55) % 8) * 0.55; // the head goes first, shoulders catch up
      ex.breath = breath(t, 4);
      stance(P, 0.955, t, 0.07, -0.07, 0.035, 0.05);
      const tr = torso(P, 0.0, cy, 0, 0.14);
      P.rot('head', tr.headRx, hy - cy * 0.55 * 0 - cy, 0);
      P.addRot('pelvis', 0, cy * 0.25, 0);
      freeArms(P, 0, 1, 1);
      plantFork(P);
    },
  },
  walk: {
    fade: 0.3,
    rate: (v) => (v * G_WALK.duty) / G_WALK.S,
    fn(P, st, ex) {
      ex.breath = 0.5;
      gait(P, st, G_WALK, 0.0, 0.2, (P2, ph) => carryFork(P2, ph, 1, 0.12));
    },
  },
  stalk: {
    fade: 0.35,
    rate: (v) => (v * G_STALK.duty) / G_STALK.S,
    fn(P, st, ex) {
      ex.breath = 0.5;
      // head set low and forward, watching
      gait(P, st, G_STALK, 0.15, 0.16, (P2, ph) => carryFork(P2, ph, 0.7, 0.2), -0.2);
    },
  },
  chase: {
    fade: 0.25,
    rate: (v) => (v * G_CHASE.duty) / G_CHASE.S,
    fn(P, st, ex) {
      ex.breath = 0.9;
      const ph = st.phase;
      const L = locomote(P, ph, G_CHASE, D);
      const t = torso(P, 0.2, -L.pyaw * 1.2, -L.proll, 0.28);
      P.rot('head', t.headRx + 0.05, L.pyaw * 0.3, L.proll * 0.8);
      freeArms(P, 0, 1, 1);
      // both hands on the fork, tines forward at chest height, driven by the stride
      holdFork(P, -0.1, 0.33, 0.32 + Math.cos(TAU * 2 * (ph - 0.1)) * 0.03, 1.42 + Math.cos(TAU * 2 * ph) * 0.04, 0.0, 0, 0.25);
      P.grip(1, 0.25, 1, 0.85);
    },
  },
  raise: {
    fade: 0.3,
    fn(P, st, ex) {
      // 0.35 s telegraph: fork hauled up and back, shoulders twisted, weight on the back foot
      const k = sstep(0, 0.35, st.t);
      ex.breath = 1;
      const pel = { x: 0, y: 0.8 + 0.01 * Math.sin(st.t * 20) * k, z: -0.05 * k };
      P.pel(pel.x, pel.y - 1.0, pel.z);
      P.rot('pelvis', 0.1, 0.0, 0);
      legWorld(P, 'L', D, pel, 0.1, 0.2, D.ankle, 0.34, 0);
      legWorld(P, 'R', D, pel, 0.1, -0.2, D.ankle, -0.32, 0);
      P.rot('spine', -0.04, -0.35, 0);
      P.rot('chest', 0.0, -0.2, 0);
      P.rot('head', -0.24, 0.5, 0.0);
      freeArms(P, 0, 1, 1);
      P.fork(-0.3, 0.56, -0.05, 0.85, -0.12, 0);
      P.grip(1, 0.2, 1, 0.88);
    },
  },
  strike: {
    fade: 0.04,
    fn(P, st, ex) {
      // The thrust starts two-handed; the left hand releases as the fork extends.
      const m = easeOut(st.t / 0.26);
      const settle = Math.sin(clamp((st.t - 0.26) / 0.35, 0, 1) * Math.PI) * 0.02;
      ex.breath = 1;
      const pel = { x: 0, y: lerp(0.8, 0.62, m), z: lerp(-0.05, 0.85, m) };
      P.pel(pel.x, pel.y - 1.0, pel.z);
      P.rot('pelvis', lerp(0.1, 0.26, m), lerp(0, 0.1, m), 0);
      const lf = easeOut(Math.min(1, m * 1.15));
      legWorld(P, 'L', D, pel, lerp(0.1, 0.26, m), 0.2, D.ankle + 0.14 * Math.sin(Math.PI * Math.min(1, m * 1.1)), lerp(0.34, 1.18, lf), -0.1 * m);
      legWorld(P, 'R', D, pel, lerp(0.1, 0.26, m), -0.2, D.ankle + 0.02, lerp(-0.32, 0.18, m), 0.3 * m);
      P.rot('spine', lerp(-0.04, 0.3, m), lerp(-0.35, 0.18, m), 0);
      P.rot('chest', lerp(0, 0.28, m), lerp(-0.2, 0.1, m), 0);
      P.rot('head', lerp(-0.24, -0.5, m), lerp(0.5, -0.25, m), 0);
      freeArms(P, 0, 1, 1);
      P.fork(lerp(-0.3, -0.16, m), lerp(0.56, 0.5, m), lerp(-0.05, 0.45, m) + settle, lerp(0.85, 1.2, m), lerp(-0.12, 0.0, m), 0);
      P.grip(1, 0.2, 1 - sstep(0.2, 1, m), 0.88);
    },
  },
  // short jab for the POV deaths: fork choked up and level, one step, tines about 1.2 m from the root
  jab: {
    fade: 0.04,
    fn(P, st, ex) {
      const m = easeOut(st.t / 0.22);
      ex.breath = 1;
      const pel = { x: 0, y: lerp(0.8, 0.72, m), z: lerp(-0.05, 0.4, m) };
      P.pel(pel.x, pel.y - 1.0, pel.z);
      P.rot('pelvis', lerp(0.1, 0.2, m), lerp(0, 0.1, m), 0);
      const lf = easeOut(Math.min(1, m * 1.15));
      legWorld(P, 'L', D, pel, lerp(0.1, 0.2, m), 0.2, D.ankle + 0.12 * Math.sin(Math.PI * Math.min(1, m * 1.1)), lerp(0.34, 0.9, lf), -0.1 * m);
      legWorld(P, 'R', D, pel, lerp(0.1, 0.2, m), -0.2, D.ankle + 0.02, lerp(-0.32, 0.0, m), 0.3 * m);
      P.rot('spine', lerp(-0.04, 0.28, m), lerp(-0.35, 0.1, m), 0);
      P.rot('chest', lerp(0, 0.26, m), lerp(-0.2, 0.05, m), 0);
      P.rot('head', lerp(-0.24, -0.5, m), lerp(0.5, -0.1, m), 0);
      freeArms(P, 0, 1, 1);
      P.fork(lerp(-0.3, -0.12, m), lerp(0.56, 0.53, m), lerp(-0.05, -0.5, m), lerp(0.85, 1.37, m), lerp(-0.12, 0.0, m), 0);
      P.grip(1, 1.3, 1, 0.85);
    },
  },
  // he lifts what is on the fork: from the thrust, up and back, and holds it
  lift: {
    fade: 0.05,
    fn(P, st, ex) {
      const m = sstep(0, 0.9, st.t);
      const strain = Math.sin(st.t * 3.1) * 0.01 * m;
      ex.breath = 0.8;
      const pel = { x: 0, y: lerp(0.62, 0.8, m), z: lerp(0.85, 0.62, m) };
      P.pel(pel.x, pel.y - 1.0, pel.z);
      P.rot('pelvis', lerp(0.26, 0.04, m), 0, 0);
      legWorld(P, 'L', D, pel, lerp(0.26, 0.04, m), 0.2, D.ankle, 1.18, -0.1 * (1 - m));
      legWorld(P, 'R', D, pel, lerp(0.26, 0.04, m), -0.2, D.ankle + 0.0, lerp(0.18, 0.2, m), 0.3 * (1 - m));
      P.rot('spine', lerp(0.3, -0.12, m), lerp(0.18, 0.05, m), 0);
      P.rot('chest', lerp(0.28, -0.05, m), lerp(0.1, 0.0, m), 0);
      const look = sstep(1.3, 2.8, st.t);
      P.rot('head', lerp(-0.5, -0.12, m) + 0.2 * look, lerp(-0.25, 0.0, m), 0.5 * look);
      freeArms(P, 0, 1, 1);
      P.fork(lerp(-0.16, -0.22, m), lerp(0.5, 0.55, m), lerp(0.45, 0.3, m) + strain, lerp(1.2, 1.0, m), lerp(0.0, -0.1, m), 0);
      P.grip(1, 0.2, 0, 0.88);
    },
  },
  // pull the fork out of a tree and stand back
  pullOut: {
    fade: 0.1,
    fn(P, st, ex) {
      const m = sstep(0.0, 0.6, st.t);
      ex.breath = 0.7;
      const pel = { x: 0, y: 0.76 + 0.02 * m, z: lerp(0.85, 0.5, m) };
      P.pel(pel.x, pel.y - 1.0, pel.z);
      P.rot('pelvis', 0.15, 0, 0);
      legWorld(P, 'L', D, pel, 0.15, 0.2, D.ankle, 1.18, 0);
      legWorld(P, 'R', D, pel, 0.15, -0.2, D.ankle, lerp(0.18, 0.1, m), 0);
      P.rot('spine', lerp(0.3, 0.1, m), 0.1, 0);
      P.rot('chest', 0.2, 0.05, 0);
      P.rot('head', -0.32 + 0.3 * sstep(0.7, 2.0, st.t), 0, 0.5 * sstep(0.7, 2.0, st.t));
      freeArms(P, 0, 1, 1);
      P.fork(lerp(-0.16, -0.2, m), lerp(0.5, 0.44, m), lerp(0.45, 0.3, m), lerp(1.2, 1.1, m), 0, 0);
      P.grip(1, 0.2, 1, 0.88);
    },
  },
  // he has let go of the fork (death sequences freeze the fork bone where it stands): arms hang, head tilts
  release: {
    fade: 0.5,
    fn(P, st, ex) {
      const t = st.t, b = breath(t, 4.2);
      ex.breath = b;
      stance(P, 0.95 - b * 0.004, t, 0.07, -0.07, 0.035, 0.07);
      const k = sstep(0.1, 1.6, t);
      const tr = torso(P, 0.03, 0, 0.03 * k, 0.1);
      P.rot('head', tr.headRx + 0.04 * k, 0.15 * k, 0.5 * k);
      P.rot('uarmL', 0.04, 0, 0.16);
      P.rot('farmL', -0.2, 0, 0);
      P.rot('handL', -0.1, 0, 0);
      P.rot('uarmR', 0.04, 0, -0.16);
      P.rot('farmR', -0.2, 0, 0);
      P.rot('handR', -0.1, 0, 0);
      P.fork(-0.43, -0.85, 0.16, 0.1, 0, 0.04);
      P.grip(0, 0, 0, 0);
    },
  },
  // walking with empty hands, arms swinging a little heavy
  walkFree: {
    fade: 0.4,
    rate: (v) => (v * G_WALK.duty) / G_WALK.S,
    fn(P, st, ex) {
      ex.breath = 0.5;
      gait(P, st, G_WALK, 0.02, 0.3, (P2) => {
        P2.fork(-0.43, -0.85, 0.16, 0.1, 0, 0.04);
        P2.grip(0, 0, 0, 0);
      });
    },
  },
  openDoor: {
    fade: 0.3,
    fn(P, st, ex) {
      const t = st.t, k = sstep(0, 0.6, t);
      ex.breath = 0.6;
      stance(P, 0.94, t, 0.12, -0.12, 0.03, 0.08);
      const tr = torso(P, 0.06 * k, -0.15 * k, 0, 0.1);
      P.rot('head', tr.headRx, 0.15 * k, 0.15 * k);
      freeArms(P, 0, 1, 1);
      // left arm out for the door, a slow push through
      const push = Math.sin(clamp((t - 0.4) / 1.2, 0, 1) * Math.PI) * 0.15;
      P.rot('uarmL', lerp(0.06, -1.25 - push, k), 0, lerp(0.13, 0.1, k));
      P.rot('farmL', lerp(-0.35, -0.25, k), 0, 0);
      plantFork(P);
    },
  },
  searchCloset: {
    fade: 0.4,
    fn(P, st, ex) {
      const t = st.t, k = sstep(0, 1.2, t);
      ex.breath = breath(t, 5);
      stance(P, 0.9, t, 0.1, -0.1, 0.03, 0.1);
      const tr = torso(P, 0.1 * k, 0.1 * k, 0, 0.05);
      P.rot('head', tr.headRx - 0.05 * k, 0.05, 0.5 * sstep(0.8, 3, t));
      freeArms(P, 0, 1, 1);
      carryFork(P, 0, 0.2, 0);
      holdFork(P, -0.38, -0.15, 0.38, 1.5, -0.2, 0, 0.8);
      P.grip(1, 0.8);
    },
  },
  carHit: {
    fade: 0.03,
    fn(P, st, ex) {
      // thrown backwards and left on the ground, face up
      const m = easeOut(st.t / 0.55);
      ex.breath = 0.3;
      const fall = lerp(-0.4, -1.52, easeOut(st.t / 0.7));
      const pel = { x: 0, y: lerp(1.0, 0.2, m) + Math.sin(Math.min(1, st.t / 0.55) * Math.PI) * 0.3, z: lerp(0, -1.4, m) };
      P.pel(pel.x, pel.y - 1.0, pel.z);
      P.rot('pelvis', fall, 0, 0);
      legTo(P, 'L', D, 0.1 + 0.2 * m, -0.86, 0.0, 0, [fall, 0, 0]);
      legTo(P, 'R', D, 0.1 + 0.15 * m, -0.84, 0.05, 0, [fall, 0, 0]);
      P.rot('spine', 0.1 * m, 0, 0);
      P.rot('chest', -0.1, 0, 0);
      P.rot('head', 0.3 * m, 0.2, 0.2);
      P.rot('uarmL', 0, 0, 0.9 * m);
      P.rot('uarmR', 0, 0, -1.1 * m);
      P.rot('farmL', -0.2, 0, 0);
      P.rot('farmR', -0.4, 0, 0);
      // the fork skids away beside him
      P.fork(-0.6 * m - 0.3 * (1 - m), 0.1, -0.12, 0, 0, 0);
      P.grip(1 - m, 0);
    },
  },
  rise: {
    fade: 0.1,
    fn(P, st, ex) {
      // lying, then up on an elbow, then upright. Not hurried.
      const t = st.t * 1.2;
      const a = sstep(0.8, 2.2, t), b = sstep(2.0, 3.6, t);
      ex.breath = breath(t, 3.2);
      const fall = lerp(lerp(-1.52, -0.5, a), 0.05, b);
      const pel = { x: 0, y: lerp(lerp(0.2, 0.4, a), D.hipY - 0.04, b), z: lerp(lerp(-0.2, 0, a), -0.06, b) };
      P.pel(pel.x, pel.y - D.hipY, pel.z);
      P.rot('pelvis', fall, 0, 0);
      const fy = D.ankle;
      legWorld(P, 'L', D, pel, fall, 0.14, fy, lerp(0.65, 0.2, b), 0);
      legWorld(P, 'R', D, pel, fall, -0.14, fy, lerp(0.65, -0.25, b), 0);
      P.rot('spine', lerp(0.0, 0.5, a) * (1 - b) + 0.16 * b, 0, 0);
      P.rot('chest', lerp(0.0, 0.45, a) * (1 - b) + 0.2 * b, 0, 0);
      P.rot('head', lerp(0.2, -0.5, a) * (1 - b) + (-0.3) * b, 0, 0.3 * (1 - b));
      P.rot('uarmL', lerp(0.0, 0.6, a) * (1 - b), 0, lerp(0.22, 0.2, a) * (1 - b) + 0.13 * b);
      P.rot('uarmR', lerp(0.0, 0.5, a) * (1 - b), 0, -lerp(0.3, 0.4, a) * (1 - b) - 0.13 * b);
      P.rot('farmL', -0.3, 0, 0);
      P.rot('farmR', -0.3, 0, 0);
      P.fork(-0.6 * (1 - b) - 0.43 * b, lerp(0.1, -0.16, b), lerp(-0.12, 0.16, b), lerp(0, 0.1, b), 0, 0.04 * b);
      P.grip(b, 0);
    },
  },
};

function selfLit(m) {
  m.onBeforeCompile = (sh) => {
    sh.fragmentShader = sh.fragmentShader.replace(
      '#include <emissivemap_fragment>',
      '#include <emissivemap_fragment>\n  totalEmissiveRadiance *= vColor.rgb;',
    );
  };
  return m;
}

export function createKiller() {
  const rig = new Rig({
    bones: BONES.map((n) => [n, PARENT[n], J[n]]),
    dims: D,
  });
  const geo = buildGeometry();
  // The old sack was nearly the width of the whole torso. Bring every head-bound part,
  // decal, rope, eye reflection and breath morph into the same adult human proportion.
  const headScale = [0.8, 0.82, 0.8];
  for (const g of [geo.burlap, geo.hard]) {
    const pos = g.attributes.position, skin = g.attributes.skinIndex;
    for (let i = 0; i < pos.count; i++) {
      if (skin.getX(i) !== rig.idx.head) continue;
      for (let axis = 0; axis < 3; axis++) pos.array[i * 3 + axis] = J.head[axis] + (pos.array[i * 3 + axis] - J.head[axis]) * headScale[axis];
    }
    for (const morph of g.morphAttributes.position || []) {
      for (let i = 0; i < morph.count; i++) for (let axis = 0; axis < 3; axis++) morph.array[i * 3 + axis] *= headScale[axis];
    }
    const normals = g.attributes.normal;
    for (let i=0;i<normals.count;i++) {
      if (skin.getX(i)!==rig.idx.head) continue;
      const n=[normals.getX(i)/headScale[0],normals.getY(i)/headScale[1],normals.getZ(i)/headScale[2]];
      const len=Math.hypot(...n)||1;
      normals.setXYZ(i,n[0]/len,n[1]/len,n[2]/len);
    }
    g.computeBoundingSphere();
  }
  for (const hole of Object.values(geo.holes)) hole.p = hole.p.map((v,i)=>v*headScale[i]);
  const matC = selfLit(lit({ map: clothTexture(), flatShading: false, vertexColors: true, emissive: 0x3b3934 }));
  const matH = selfLit(lit({ map: hardTexture(), flatShading: false, vertexColors: true, emissive: 0x3b3832 }));
  const matB = selfLit(lit({ map: burlapTexture(), vertexColors: true, emissive: 0x2c2b27 }));
  const cloth = rig.skinned(geo.cloth, matC);
  const hard = rig.skinned(geo.hard, matH);
  const burlap = rig.skinned(geo.burlap, matB);
  burlap.morphTargetInfluences = [0];
  cloth.name = 'killer-cloth'; hard.name = 'killer-hard'; burlap.name = 'killer-burlap';

  // two pinprick reflections in the eye holes
  const glintMat = new THREE.MeshBasicMaterial({ color: 0xfff1d0, fog: false, depthWrite: false, transparent: true, opacity: 1 });
  const glintGeo = new THREE.CircleGeometry(0.0034, 6);
  const glints = new THREE.Group();
  const head = rig.b('head');
  for (const h of [geo.holes.a, geo.holes.b]) {
    const m = new THREE.Mesh(glintGeo, glintMat);
    m.position.set(h.p[0], h.p[1], h.p[2]);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), new THREE.Vector3(...h.n));
    m.renderOrder = 5;
    glints.add(m);
  }
  glints.visible = false;
  head.add(glints);

  const forkBone = rig.b('fork');
  const forkTip = new THREE.Object3D();
  forkTip.position.set(0, 1.99, 0.05);
  forkBone.add(forkTip);
  const forkTines = new THREE.Object3D(); // the middle of the tines, where a body ends up
  forkTines.position.set(0, 1.76, 0.01);
  forkBone.add(forkTines);
  const headTop = new THREE.Object3D();
  headTop.position.set(0, 0.41, 0.064);
  head.add(headTop);

  const anim = new Animator(rig, killerAnims, { arms: ARMS_IK, lookWeight: 0.8, blendExtras: ['breath'] });
  const stance = createStanceStabilizer(rig, anim, { gaits: { walk: G_WALK, stalk: G_STALK, chase: G_CHASE }, release: { chase: [.4, .72] }, maxOffset: .16, maxWidth: .34, maxForward: .72 });
  const bloodAttr = geo.burlap.attributes.color;
  const bloodBase = [];
  for (let i = geo.bloodRange[0]; i < geo.bloodRange[1]; i++) bloodBase.push(bloodAttr.array[i * 3], bloodAttr.array[i * 3 + 1], bloodAttr.array[i * 3 + 2]);
  const wet = rgb(0x8a0808);

  const k = {
    root: rig.root,
    rig,
    anim: 'idle',
    height: 2.3,
    forkTip,
    forkTines,
    headTop,
    breathAmount: 1,
    update(dt, o = {}) {
      anim.extra.breath = 0.5;
      anim.update(dt, o);
      this.anim = anim.name;
      const t = rig.root.userData.t = (rig.root.userData.t || 0) + dt;
      // breathing made visible: the sack drawn in over the mouth, a faint rattle on top
      const b = anim.extra.breath ?? 0.5;
      burlap.morphTargetInfluences[0] = clamp(b * 0.95 + 0.05 * Math.sin(t * 17) * b, 0, 1) * this.breathAmount;
    },
    stabilizeStance: (dt, options) => stance.update(dt, options),
    resetStance: () => stance.reset(),
    setAnim(name, opts) {
      anim.setAnim(name, opts);
      this.anim = anim.name;
    },
    setEyeGlint(v) {
      glints.visible = v > 0.02;
      glintMat.opacity = clamp(v, 0, 1);
      for (const m of glints.children) m.scale.setScalar(0.6 + 0.8 * clamp(v, 0, 1));
    },
    // 0 clean .. 1 soaked: the stain on the sack
    setBloody(a) {
      a = clamp(a, 0, 1);
      for (let i = 0; i < bloodBase.length; i += 3) {
        bloodAttr.array[geo.bloodRange[0] * 3 + i] = lerp(bloodBase[i], wet[0], a);
        bloodAttr.array[geo.bloodRange[0] * 3 + i + 1] = lerp(bloodBase[i + 1], wet[1], a);
        bloodAttr.array[geo.bloodRange[0] * 3 + i + 2] = lerp(bloodBase[i + 2], wet[2], a);
      }
      bloodAttr.needsUpdate = true;
    },
    has: (n) => anim.has(n),
    animator: anim,
    meshes: [cloth, hard, burlap],
    triangles: () => (geo.cloth.attributes.position.count + geo.hard.attributes.position.count + geo.burlap.attributes.position.count) / 3,
    drawCalls: 5, // three skinned materials plus two eye reflections
    // pose-evaluate an anim at local time t and report forward reach of the fork tip: used to place him
    strikeReach() {
      const save = anim.cur;
      anim.setAnim('strike', { restart: true, fade: 0.001 });
      anim.update(0.6, { speed: 0 });
      anim.update(0.001, { speed: 0 });
      rig.root.updateMatrixWorld(true);
      const v = new THREE.Vector3();
      forkTip.getWorldPosition(v);
      rig.root.worldToLocal(v);
      return v;
    },
  };
  anim.setAnim('idle');
  anim.update(0.016, {});
  return k;
}

export { J as KILLER_JOINTS };
