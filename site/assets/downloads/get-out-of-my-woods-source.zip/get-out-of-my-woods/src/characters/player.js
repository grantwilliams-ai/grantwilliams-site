// The last counselor: 1.72 m, mustard windbreaker with STAFF across the back, jeans, sneakers, dark
// ponytail, a flashlight in the right hand. Smaller and lighter than the man in the sack, and
// animated to look afraid. Rigid segments on one skeleton, four draw calls.
import * as THREE from 'three';
import { lit } from '../render/materials.js';
import { Rig, Animator, legTo } from './rig.js';
import { MeshBuilder, toGeometry, surfaceAt, ringGrid, rgb } from './mesh.js';
import { clothTexture, hardTexture, staffTexture, skinTexture } from './tex.js';
import { locomote, legWorld, breath, sstep, easeOut, lerp, clamp, TAU } from './anim.js';
import { finishCounselorAppearance } from './player-appearance.js';
import { createStanceStabilizer } from './stance.js';

const J = {
  pelvis: [0, 0.92, 0], spine: [0, 1.0, 0], chest: [0, 1.17, 0], head: [0, 1.45, 0.0],
  uarmL: [0.2, 1.4, 0], farmL: [0.2, 1.11, 0], handL: [0.2, 0.84, 0],
  uarmR: [-0.2, 1.4, 0], farmR: [-0.2, 1.11, 0], handR: [-0.2, 0.84, 0],
  thighL: [0.095, 0.92, 0], shinL: [0.095, 0.5, 0], footL: [0.095, 0.08, 0],
  thighR: [-0.095, 0.92, 0], shinR: [-0.095, 0.5, 0], footR: [-0.095, 0.08, 0],
  tail: [0, 1.64, -0.1],
};
const PARENT = {
  pelvis: null, spine: 'pelvis', chest: 'spine', head: 'chest', tail: 'head',
  uarmL: 'chest', farmL: 'uarmL', handL: 'farmL', uarmR: 'chest', farmR: 'uarmR', handR: 'farmR',
  thighL: 'pelvis', shinL: 'thighL', footL: 'shinL', thighR: 'pelvis', shinR: 'thighR', footR: 'shinR',
};
const BONES = ['pelvis', 'spine', 'chest', 'head', 'tail', 'uarmL', 'farmL', 'handL', 'uarmR', 'farmR', 'handR', 'thighL', 'shinL', 'footL', 'thighR', 'shinR', 'footR'];
const D = { L1: 0.42, L2: 0.42, ankle: 0.08, hipX: 0.095, hipY: 0.92 };

const JACKET = 0xe1b249, JACKET_D = 0x98702f, JEANS = 0x4b6585, JEANS_D = 0x34475e, SKIN = 0xd6a686;
const JEANS_SEAM = 0x566a82, ZIPPER = 0x6d5b2c, SNEAKER = 0xd6cfbd, SOLE = 0xe9e4d6, LACE = 0xf2eee2, BLACK = 0x1a1a1a;

function slab(mb, cx, cy, cz, hw, hh, hd, color, bev = 0.01) {
  bev = Math.min(bev, hw * 0.8, hh * 0.8, hd * 0.8);
  const S = Math.SQRT2;
  mb.loft(
    [
      { y: cy - hh, rx: (hw - bev) * S, rz: (hd - bev) * S, ox: cx, oz: cz },
      { y: cy - hh + bev, rx: hw * S, rz: hd * S, ox: cx, oz: cz },
      { y: cy + hh - bev, rx: hw * S, rz: hd * S, ox: cx, oz: cz },
      { y: cy + hh, rx: (hw - bev) * S, rz: (hd - bev) * S, ox: cx, oz: cz },
    ],
    { sides: 4, phase: Math.PI / 4, sq: 1, color },
  );
}

function buildGeometry(look = {}) {
  const HAIR = look.hair ?? 0x1b1511;
  const cloth = new MeshBuilder(), hard = new MeshBuilder(), decal = new MeshBuilder();
  hard.uvScale = 4;
  const I = (n) => BONES.indexOf(n);
  const c = cloth;

  // jeans seat and the jacket
  c.part(I('pelvis'), J.pelvis);
  c.loft([
    { y: -0.17, rx: 0.14, rz: 0.1, c: JEANS_D },
    { y: -0.06, rx: 0.165, rz: 0.115, c: JEANS },
    { y: 0.06, rx: 0.17, rz: 0.12, c: JEANS },
  ], { sides: 10, sq: 0.85, capBot: false });
  c.part(I('spine'), J.spine);
  const gSpine = c.loft([
    { y: -0.07, rx: 0.185, rz: 0.135, c: JACKET_D }, // elastic hem
    { y: -0.04, rx: 0.19, rz: 0.14, c: JACKET },
    { y: 0.1, rx: 0.185, rz: 0.13, c: JACKET },
    { y: 0.17, rx: 0.19, rz: 0.13, c: JACKET },
  ], { sides: 10, sq: 0.85, capBot: false, capTop: false });
  c.fan([
    surfaceAt(gSpine, -0.035, -0.035, 0.006).p, surfaceAt(gSpine, 0.035, -0.035, 0.006).p,
    surfaceAt(gSpine, 0.035, 0.165, 0.006).p, surfaceAt(gSpine, -0.035, 0.165, 0.006).p,
  ], rgb(ZIPPER));
  for (const sx of [-1, 1]) {
    const a = sx * 0.65;
    c.fan([
      surfaceAt(gSpine, a - 0.2, 0.0, 0.007).p, surfaceAt(gSpine, a + 0.2, 0.028, 0.007).p,
      surfaceAt(gSpine, a + 0.2, 0.038, 0.007).p, surfaceAt(gSpine, a - 0.2, 0.01, 0.007).p,
    ], rgb(JACKET_D));
  }
  c.part(I('chest'), J.chest);
  const chestRings = [
    { y: 0, rx: 0.19, rz: 0.13, c: JACKET },
    { y: 0.1, rx: 0.205, rz: 0.135, oz: -0.005, c: JACKET },
    { y: 0.2, rx: 0.215, rz: 0.13, oz: -0.012, c: JACKET },
    { y: 0.26, rx: 0.17, rz: 0.115, oz: -0.012, c: JACKET },
    { y: 0.3, rx: 0.1, rz: 0.09, oz: -0.01, c: JACKET_D },
  ];
  const gChest = c.loft(chestRings, { sides: 12, sq: 0.85, capBot: false });
  c.fan([
    surfaceAt(gChest, -0.03, 0.005, 0.006).p, surfaceAt(gChest, 0.03, 0.005, 0.006).p,
    surfaceAt(gChest, 0.03, 0.265, 0.006).p, surfaceAt(gChest, -0.03, 0.265, 0.006).p,
  ], rgb(ZIPPER));
  // Tailored shoulder yoke and a muted cream seam frame the STAFF lettering from behind.
  for (const a of [0, Math.PI]) {
    c.fan([
      surfaceAt(gChest, a - 0.95, 0.22, 0.009).p, surfaceAt(gChest, a + 0.95, 0.22, 0.009).p,
      surfaceAt(gChest, a + 0.8, 0.255, 0.009).p, surfaceAt(gChest, a - 0.8, 0.255, 0.009).p,
    ], rgb(0xf0d18a));
  }
  // Small camp patch: cream border, pine-green centre, a simple two-triangle pine.
  c.fan([[-0.135,0.13,0.126],[-0.065,0.13,0.143],[-0.065,0.19,0.143],[-0.135,0.19,0.126]], rgb(0xe9d9a7));
  c.fan([[-0.126,0.137,0.129],[-0.073,0.137,0.145],[-0.073,0.183,0.145],[-0.126,0.183,0.129]], rgb(0x304f49));
  c.fan([[-0.118,0.149,0.14],[-0.081,0.149,0.148],[-0.099,0.178,0.145]], rgb(0xe9d9a7));
  c.part(I('head'), J.head); // collar
  c.loft([
    { y: -0.036, rx: 0.088, rz: 0.087, c: JACKET_D },
    { y: 0.004, rx: 0.092, rz: 0.089, c: JACKET },
    { y: 0.023, rx: 0.072, rz: 0.07, c: JACKET_D },
  ], { sides: 8, sq: 0.9, capTop: false, capBot: false });
  const sleeveSurfaces = {};
  for (const s of ['L', 'R']) {
    c.part(I('uarm' + s), J['uarm' + s]);
    sleeveSurfaces[s] = c.loft([
      // Tuck the top into the yoke; a broad level cap looked like shoulder armour.
      { y: 0.06, ox: s === 'L' ? -0.08 : 0.08, rx: 0.03, rz: 0.045, c: JACKET },
      { y: -0.04, rx: 0.075, rz: 0.075, c: JACKET },
      { y: -0.18, rx: 0.065, rz: 0.065, c: JACKET },
      { y: -0.29, rx: 0.058, rz: 0.058, c: JACKET },
    ], { sides: 8, sq: 0.9 });
    c.fan([[-0.045, -0.17, 0.067], [0.04, -0.19, 0.067], [0.04, -0.181, 0.069], [-0.045, -0.161, 0.069]], rgb(JACKET_D));
    c.part(I('farm' + s), J['farm' + s]);
    c.loft([
      { y: 0.03, rx: 0.058, rz: 0.058, c: JACKET },
      { y: -0.12, rx: 0.062, rz: 0.062, c: JACKET },
      { y: -0.24, rx: 0.052, rz: 0.052, c: JACKET },
      { y: -0.275, rx: 0.048, rz: 0.048, c: JACKET_D },
    ], { sides: 8, sq: 0.9 });
    c.part(I('thigh' + s), J['thigh' + s]);
    c.loft([
      { y: 0.05, rx: 0.1, rz: 0.1, c: JEANS },
      { y: -0.15, rx: 0.088, rz: 0.088, c: JEANS },
      { y: -0.42, rx: 0.066, rz: 0.068, c: JEANS_D },
    ], { sides: 8, sq: 0.9 });
    c.fan([[-0.003, 0.035, 0.102], [0.003, 0.035, 0.102], [0.003, -0.38, 0.071], [-0.003, -0.38, 0.071]], rgb(JEANS_SEAM));
    c.fan([[-0.055, -0.31, 0.079], [0.05, -0.33, 0.079], [0.05, -0.321, 0.081], [-0.055, -0.301, 0.081]], rgb(JEANS_D));
    c.part(I('shin' + s), J['shin' + s]);
    c.loft([
      { y: 0.03, rx: 0.066, rz: 0.068, c: JEANS_D },
      { y: -0.2, rx: 0.058, rz: 0.06, c: JEANS },
      { y: -0.4, rx: 0.056, rz: 0.058, c: JEANS_D },
    ], { sides: 8, sq: 0.9 });
    c.fan([[-0.045, -0.365, 0.06], [0.045, -0.365, 0.06], [0.045, -0.359, 0.061], [-0.045, -0.359, 0.061]], rgb(JEANS_SEAM));
  }

  // skin, hair, shoes, torch
  const h = hard;
  const FACE = look.face ?? SKIN;
  const NECK = look.neck ?? FACE;
  h.part(I('head'), J.head);
  h.loft([
    { y: -0.04, rx: 0.045, rz: 0.045, c: NECK },
    { y: 0.04, rx: 0.046, rz: 0.046, c: NECK },
  ], { sides: 8, sq: 0.95, capTop: false, capBot: false });
  // A continuous head surface: narrower chin and jaw, cheek volume, a quiet brow and
  // shallow sockets. Features sit on this surface instead of reading as pasted rectangles.
  const headRings = [
    { y: 0.035, rx: 0.034, rz: 0.043, oz: 0.012 },
    { y: 0.053, rx: 0.046, rz: 0.055, oz: 0.014 },
    { y: 0.078, rx: 0.067, rz: 0.072, oz: 0.006 },
    { y: 0.105, rx: 0.078, rz: 0.085, oz: -0.002 },
    { y: 0.137, rx: 0.088, rz: 0.096, oz: -0.007 },
    { y: 0.171, rx: 0.087, rz: 0.099, oz: -0.007 },
    { y: 0.195, rx: 0.087, rz: 0.101, oz: -0.006 },
    { y: 0.225, rx: 0.084, rz: 0.098, oz: -0.004 },
    { y: 0.255, rx: 0.072, rz: 0.087, oz: -0.006 },
    { y: 0.279, rx: 0.051, rz: 0.063, oz: -0.008 },
  ];
  const gHead = ringGrid(headRings, { sides: 32, sq: 0.96 });
  const gauss = (v,center,width) => Math.exp(-(((v-center)/width)**2));
  for (const row of gHead.p) for (const p of row) {
    if (p[2] <= 0) continue;
    const front = Math.max(0,p[2]/0.1);
    const socket = gauss(Math.abs(p[0]),0.034,0.019)*gauss(p[1],0.175,0.015);
    const cheek = gauss(Math.abs(p[0]),0.046,0.026)*gauss(p[1],0.138,0.022);
    const brow = gauss(Math.abs(p[0]),0.032,0.022)*gauss(p[1],0.196,0.01);
    p[2] += front * (-0.005*socket + 0.004*cheek + 0.0025*brow);
  }
  const skinColor = rgb(FACE);
  for (let j=0;j<gHead.p.length-1;j++) for(let i=0;i<gHead.n;i++) {
    const next=(i+1)%gHead.n;
    const point=(r,k)=>[...gHead.p[r][k],k/gHead.n,headRings[r].y*4];
    h.tri(point(j,i),point(j,next),point(j+1,next),skinColor);
    h.tri(point(j,i),point(j+1,next),point(j+1,i),skinColor);
  }
  // Invert the surface's front x coordinate, so eyelids/lips remain embedded on every angle.
  const facePoint = (x,y,off=0.002) => {
    let lo=-Math.PI/2,hi=Math.PI/2;
    for(let i=0;i<18;i++) {
      const mid=(lo+hi)/2;
      if(surfaceAt(gHead,mid,y,0).p[0]<x)lo=mid;else hi=mid;
    }
    return surfaceAt(gHead,(lo+hi)/2,y,off).p;
  };
  const faceShape = (points,color,off=0.002,edge) => h.fan(points.map(([x,y])=>facePoint(x,y,off)),rgb(color),edge===undefined?undefined:rgb(edge));
  // A tapered bridge flows into a small rounded tip; the nostril accents stay understated.
  h.loft([
    { y: 0.124, rx: 0.006, rz: 0.007, oz: 0.098, c: FACE },
    { y: 0.131, rx: 0.012, rz: 0.014, oz: 0.107, c: FACE },
    { y: 0.140, rx: 0.011, rz: 0.019, oz: 0.108, c: FACE },
    { y: 0.154, rx: 0.008, rz: 0.013, oz: 0.103, c: FACE },
    { y: 0.179, rx: 0.006, rz: 0.008, oz: 0.096, c: FACE },
    { y: 0.195, rx: 0.008, rz: 0.005, oz: 0.094, c: FACE },
  ].map(r=>({...r,oz:0.09+(r.oz-0.09)*0.75,rz:r.rz*0.75})), { sides: 10, sq: 1 });
  for(const sx of [-1,1]) {
    const eyeX=sx*0.034, eyeY=0.176;
    const almond=(w,up,down)=>[
      [eyeX-w,eyeY-0.0008],[eyeX-w*0.48,eyeY-down*0.8],[eyeX,eyeY-down],
      [eyeX+w*0.56,eyeY-down*0.7],[eyeX+w,eyeY+0.0007],
      [eyeX+w*0.5,eyeY+up*0.82],[eyeX,eyeY+up],[eyeX-w*0.55,eyeY+up*0.7],
    ];
    faceShape(almond(0.016,0.009,0.0055),0x95705c,0.001,FACE);
    faceShape(almond(0.0138,0.0057,0.0036),0xc8baa2,0.0024);
    // Iris is partly covered by the upper lid rather than a black rectangle.
    const iris=[];
    for(let i=0;i<10;i++) {const a=i/10*TAU;iris.push([eyeX+Math.cos(a)*0.0045,eyeY+0.0008+Math.sin(a)*0.0047]);}
    faceShape(iris,0x4b5044,0.0037);
    faceShape([[eyeX-0.0019,eyeY-0.0015],[eyeX+0.0019,eyeY-0.0015],[eyeX+0.0019,eyeY+0.0033],[eyeX-0.0019,eyeY+0.0033]],0x242823,0.0045);
    faceShape([[eyeX-0.0145,eyeY],[eyeX,eyeY+0.0049],[eyeX+0.014,eyeY+0.001],[eyeX+0.009,eyeY+0.0061],[eyeX,eyeY+0.0072],[eyeX-0.008,eyeY+0.006]],0x745440,0.0048);
    // Soft arched brows, raised a fraction at the inner end: alert, not scowling.
    const browY=0.197;
    faceShape([[eyeX-0.017,browY-0.001],[eyeX-0.005,browY+0.002],[eyeX+0.007,browY+0.0015],[eyeX+0.017,browY-0.002],
      [eyeX+0.011,browY+0.002],[eyeX-0.005,browY+0.005],[eyeX-0.015,browY+0.002]],0x4e3b2b,0.0025);
    h.part(I('head'),[J.head[0]+sx*0.087,J.head[1]+0.145,J.head[2]-0.01]);
    h.loft([{y:-0.021,rx:0.007,rz:0.013,c:FACE},{y:-0.004,rx:0.013,rz:0.018,c:FACE},{y:0.02,rx:0.01,rz:0.015,c:FACE}],{sides:8,sq:1});
    h.part(I('head'),J.head);
  }
  // Small cupid's bow, a quiet mouth crease and fuller lower lip; no painted-on smile.
  faceShape([[-0.02,0.105],[-0.008,0.104],[0,0.105],[0.008,0.104],[0.02,0.105],[0.008,0.109],[0.003,0.111],[0,0.1095],[-0.004,0.111],[-0.011,0.108]],0xa97763,0.0025,FACE);
  faceShape([[-0.019,0.1048],[-0.011,0.099],[0,0.0978],[0.012,0.0995],[0.019,0.105],[0,0.104]],0xbc8b74,0.003,FACE);
  faceShape([[-0.019,0.105],[-0.007,0.1033],[0,0.1038],[0.009,0.1035],[0.019,0.105],[0.006,0.1055],[-0.006,0.1055]],0x805747,0.0038);
  if (look.dead) {
    for (const sx of [-1, 1]) slab(h, sx * 0.036, 0.178, 0.094, 0.021, 0.015, 0.012, 0x120606, 0.004);
    slab(h, 0, 0.082, 0.083, 0.026, 0.021, 0.014, 0x160505, 0.004); // mouth, open
    // it ran toward the floor, which for him is up his face
    slab(h, -0.016, 0.135, 0.096, 0.011, 0.05, 0.008, 0x7a0f0c, 0.003);
    slab(h, 0.024, 0.215, 0.09, 0.015, 0.045, 0.012, 0x7a0f0c, 0.003);
  }
  // hair: a high, faceted hairline, a mass behind, and a band holding the tail
  const HAIR_HI = new THREE.Color(HAIR).lerp(new THREE.Color(0x6a5745), 0.14).getHex();
  h.loft([
    { y: 0.224, rx: 0.091, rz: 0.103, oz: -0.008, c: HAIR },
    { y: 0.25, rx: 0.094, rz: 0.104, oz: -0.009, c: HAIR },
    { y: 0.285, rx: 0.078, rz: 0.088, oz: -0.004, c: HAIR_HI },
    { y: 0.305, rx: 0.04, rz: 0.05, oz: -0.004, c: HAIR },
    { y: 0.312, rx: 0.015, rz: 0.022, oz: -0.004, c: HAIR },
  ], { sides: 10, sq: 0.9, capBot: false });
  // Swept front and short temple locks: no straight helmet edge over the eyebrows.
  faceShape([[-0.075,0.215],[-0.057,0.219],[-0.028,0.229],[0.004,0.24],[0.047,0.247],[0.072,0.241],[0.072,0.258],[-0.068,0.26]],HAIR,0.005);
  for (const sx of [-1,1]) {
    const lock = [[0.075,0.217],[0.083,0.194],[0.084,0.173],[0.089,0.19],[0.085,0.229]].map(([x,y])=>[sx*x,y]);
    faceShape(sx>0?lock:lock.reverse(),HAIR,0.004);
  }
  h.loft([
    { y: 0.06, rx: 0.07, rz: 0.04, oz: -0.07, c: HAIR },
    { y: 0.14, rx: 0.095, rz: 0.055, oz: -0.06, c: HAIR },
    { y: 0.225, rx: 0.096, rz: 0.06, oz: -0.05, c: HAIR },
    { y: 0.252, rx: 0.09, rz: 0.058, oz: -0.046, c: HAIR },
  ], { sides: 8, sq: 0.9, capBot: false, capTop: false });
  if (!look.noTail) {
    h.part(I('tail'), J.tail);
    h.loft([
      { y: 0.015, rx: 0.036, rz: 0.036, c: 0xaa2222 },
      { y: -0.015, rx: 0.04, rz: 0.04, c: HAIR },
      { y: -0.11, rx: 0.045, rz: 0.04, c: HAIR },
      { y: -0.24, rx: 0.03, rz: 0.028, c: HAIR },
      { y: -0.33, rx: 0.006, rz: 0.006, c: HAIR },
    ], { sides: 6, sq: 0.9, capBot: false });
  }
  h.part(I('chest'), J.chest);
  slab(h, 0, 0.21, 0.126, 0.005, 0.012, 0.003, 0x8b7a4c, 0.002); // zip pull
  for (const s of ['L', 'R']) {
    h.part(I('hand' + s), J['hand' + s]);
    h.loft([
      { y: 0.01, rx: 0.044, rz: 0.04, c: SKIN },
      { y: -0.05, rx: 0.05, rz: 0.045, c: SKIN },
      { y: -0.1, rx: 0.042, rz: 0.04, c: SKIN },
    ], { sides: 6, sq: 0.9 });
    h.part(I('foot' + s), J['foot' + s]);
    slab(h, 0, -0.01, 0.06, 0.047, 0.035, 0.1, SNEAKER, 0.015); // upper
    slab(h, 0, -0.065, 0.07, 0.05, 0.015, 0.125, SOLE, 0.008); // sole
    slab(h, 0, -0.008, 0.145, 0.046, 0.03, 0.035, 0xe1dacb, 0.01); // toe cap
    slab(h, 0, -0.051, 0.075, 0.051, 0.004, 0.12, 0x8e897e, 0.002); // foxing stripe
    slab(h, 0, 0.027, 0.065, 0.028, 0.004, 0.012, LACE, 0.002);
    slab(h, 0, 0.027, 0.103, 0.028, 0.004, 0.012, LACE, 0.002);
    h.part(I('shin' + s), J['shin' + s]);
    h.loft([
      { y: -0.38, rx: 0.058, rz: 0.06, c: 0xcfc8b6 },
      { y: -0.43, rx: 0.052, rz: 0.054, c: 0xcfc8b6 },
    ], { sides: 8, sq: 0.9, capTop: false });
  }
  // flashlight in the right hand: long black barrel, lens head
  h.part(I('handR'), J.handR);
  h.loft([
    { y: -0.02, rx: 0.03, rz: 0.03, c: BLACK },
    { y: -0.13, rx: 0.032, rz: 0.032, c: 0x303030 },
    { y: -0.2, rx: 0.034, rz: 0.034, c: BLACK },
    { y: -0.215, rx: 0.05, rz: 0.05, c: 0x555555 },
    { y: -0.26, rx: 0.052, rz: 0.052, c: 0x3a3a3a },
  ], { sides: 8, sq: 1 });

  // STAFF across the back: a curved strip laid on the jacket
  decal.part(I('chest'), J.chest);
  const cols = 8, y0 = 0.075, y1 = 0.21;
  const prow = (v) => Array.from({ length: cols + 1 }, (_, i) => surfaceAt(gChest, Math.PI - 0.55 + (1.1 * i) / cols, y0 + (y1 - y0) * v, 0.007).p);
  const rowA = prow(0), rowB = prow(1), white = [1, 1, 1];
  for (let i = 0; i < cols; i++) {
    const u0 = i / cols, u1 = (i + 1) / cols;
    decal.tri([...rowA[i], u0, 0], [...rowA[i + 1], u1, 0], [...rowB[i + 1], u1, 1], white);
    decal.tri([...rowA[i], u0, 0], [...rowB[i + 1], u1, 1], [...rowB[i], u0, 1], white);
  }

  // One cosmetic graze follows the left shoulder bone. It never changes movement or stamina.
  const wound = new MeshBuilder();
  wound.part(I('uarmL'),J.uarmL);
  const shoulder = sleeveSurfaces.L;
  for (const a of [0.55,2.45]) {
    const strip = (w,color,off) => wound.fan([
      surfaceAt(shoulder,a-0.42,-0.055-w,off).p,surfaceAt(shoulder,a+0.42,-0.025-w,off).p,
      surfaceAt(shoulder,a+0.42,-0.025+w,off).p,surfaceAt(shoulder,a-0.42,-0.055+w,off).p,
    ],rgb(color));
    strip(0.014,0x493323,0.007); strip(0.008,0x8e2e26,0.009);
  }
  return { cloth: toGeometry(cloth, null, true), hard: toGeometry(hard, null, true), decal: toGeometry(decal), wound: toGeometry(wound) };
}

// ---------------------------------------------------------------------------------------------
const G_WALK = { S: 1.1, duty: 0.5, lift: 0.09, hip: 0.77, foot: 0.105, toe: 0.2, roll: 0.3, sway: 0.02, yaw: 0.12, bob: 0.008, rollP: 0.02, pitch: 0.03, heel: 0.1 };
const G_SNEAK = { S: 0.82, duty: 0.62, lift: 0.05, hip: 0.78, foot: 0.11, toe: 0.15, roll: 0.25, sway: 0.025, yaw: 0.06, bob: 0.0, rollP: 0.02, pitch: 0.22, heel: 0.1 };
const G_RUN = { S: 1.28, duty: 0.355, lift: 0.24, hip: 0.75, foot: 0.1, toe: 0.2, roll: 0.5, sway: 0.03, yaw: 0.28, bob: -0.04, rollP: 0.04, pitch: 0.24, heel: 0.1 };

// right arm raised to aim the torch, blended by ex.light (0..1); aim pitch from the camera
function lightArm(P, ex, base) {
  const w = ex.light || 0;
  if (w < 0.001) return;
  const up = 1.22 + (ex.aim || 0) * 0.8;
  const a = P.a;
  const k = 17 + (BONES.indexOf('uarmR')) * 3;
  const kf = 17 + (BONES.indexOf('farmR')) * 3;
  const kh = 17 + (BONES.indexOf('handR')) * 3;
  const tx = -up + (base?.bounce || 0), tz = -0.1;
  a[k] = lerp(a[k], tx, w); a[k + 1] = lerp(a[k + 1], 0.05, w); a[k + 2] = lerp(a[k + 2], tz, w);
  a[kf] = lerp(a[kf], -0.28, w); a[kf + 1] = lerp(a[kf + 1], 0, w); a[kf + 2] = lerp(a[kf + 2], 0, w);
  a[kh] = lerp(a[kh], 0, w);
}

function relaxedArms(P, swing = 0, elbow = 0.3) {
  P.rot('uarmL', swing, 0, 0.1);
  P.rot('farmL', -elbow - Math.abs(swing) * 0.5, 0, 0);
  P.rot('uarmR', -swing, 0, -0.1);
  P.rot('farmR', -elbow - Math.abs(swing) * 0.5, 0, 0);
  P.rot('handL', -0.1, 0, 0);
  P.rot('handR', -0.1, 0, 0);
}

function stand(P, hip, wL = 0.04, wR = -0.04, spread = 0.015, pel = 0.0) {
  P.pel(0, hip - D.hipY, 0);
  P.rot('pelvis', pel, 0, 0);
  legTo(P, 'L', D, spread, -(hip - D.ankle), wL, 0, [pel, 0, 0]);
  legTo(P, 'R', D, spread, -(hip - D.ankle), wR, 0, [pel, 0, 0]);
}

function gaitPlayer(P, st, ex, G, o) {
  const ph = st.phase;
  const L = locomote(P, ph, G, D);
  const lean = o.lean || 0;
  P.rot('spine', lean * 0.5, -L.pyaw * 1.2, -L.proll);
  P.rot('chest', lean * 0.5, -L.pyaw * 1.0, -L.proll * 0.5);
  P.rot('head', -(lean + G.pitch) + (o.headUp || 0.0), L.pyaw * 0.2 + (o.look ? Math.sin(st.t * o.look) * 0.5 : 0), L.proll * 0.8);
  const sw = Math.cos(TAU * ph);
  P.rot('uarmL', sw * o.arm + (o.armF || 0), 0, 0.12 + (o.out || 0));
  P.rot('farmL', -(o.elbow || 0.4) - Math.abs(sw) * (o.elbow2 || 0.3), 0, 0);
  P.rot('uarmR', -sw * o.arm + (o.armF || 0), 0, -0.12 - (o.out || 0));
  P.rot('farmR', -(o.elbow || 0.4) - Math.abs(sw) * (o.elbow2 || 0.3), 0, 0);
  P.rot('handL', -0.15, 0, 0);
  P.rot('handR', -0.15, 0, 0);
  lightArm(P, ex, { bounce: Math.sin(TAU * 2 * ph) * (o.lightBounce || 0.0) });
  return L;
}

const playerAnims = {
  idle: {
    fade: 0.3,
    fn(P, st, ex) {
      const t = st.t, b = breath(t, 3.8), tremor = Math.sin(t * 19) * 0.006;
      stand(P, 0.915 - b * 0.003, 0.03 * Math.sin(t * 0.4), -0.03 * Math.sin(t * 0.4), 0.02, 0.01);
      P.rot('spine', 0.04 + b * 0.015, 0.03 * Math.sin(t * 0.3), 0);
      P.rot('chest', 0.05 + b * 0.025, 0, 0);
      P.rot('head', -0.09 + 0.02 * Math.sin(t * 0.5), 0.12 * Math.sin(t * 0.37), 0.025 * Math.sin(t * 0.21));
      relaxedArms(P, 0, 0.42);
      P.addRot('uarmL', -0.05, 0, 0.025);
      P.addRot('handL', tremor, 0, tremor);
      lightArm(P, ex);
    },
  },
  walk: {
    fade: 0.25,
    // Live play matches stance travel to actual post-collision speed. Films
    // keep their original authored cadence when the opt-in is absent.
    rate: (v, st) => st?.opts?.travelDriven ? (v * G_WALK.duty) / G_WALK.S : v / (2 * 1.35),
    fn(P, st, ex) {
      gaitPlayer(P, st, ex, G_WALK, { arm: 0.38, elbow: 0.35, elbow2: 0.25, lean: 0.03 });
    },
  },
  sneak: {
    fade: 0.3,
    rate: (v, st) => st?.opts?.travelDriven ? (v * G_SNEAK.duty) / G_SNEAK.S : v / (2 * 0.8),
    fn(P, st, ex) {
      // hunched, knees soft, elbows tucked in, chin down but eyes up
      gaitPlayer(P, st, ex, G_SNEAK, { arm: 0.14, elbow: 0.9, elbow2: 0.1, lean: 0.28, headUp: 0.32, out: -0.05, look: 0.9, armF: -0.25 });
    },
  },
  run: {
    fade: 0.2,
    rate: (v) => v / (2 * 1.8),
    fn(P, st, ex) {
      // panic: arms pumping wide, head thrown about, torso driven forward
      gaitPlayer(P, st, ex, G_RUN, { arm: 1.0, elbow: 1.1, elbow2: 0.35, lean: 0.2, headUp: 0.25, lightBounce: 0.075, out: 0.04, look: 1.2 });
      const k = Math.cos(TAU * 2 * st.phase);
      P.addRot('chest', 0.03 * k, 0, 0);
    },
  },
  winded: {
    fade: 0.35,
    fn(P, st, ex) {
      // bent double, hands on knees, hauling air
      const t = st.t, h = Math.sin(t * 8.5) * 0.5 + 0.5;
      const pel = { x: 0, y: 0.8, z: -0.12 };
      P.pel(pel.x, pel.y - D.hipY, pel.z);
      P.rot('pelvis', 0.5, 0, 0);
      legWorld(P, 'L', D, pel, 0.5, 0.14, D.ankle, 0.1, 0);
      legWorld(P, 'R', D, pel, 0.5, -0.14, D.ankle, -0.02, 0);
      P.rot('spine', 0.5 + h * 0.06, 0, 0);
      P.rot('chest', 0.35 + h * 0.05, 0, 0);
      P.rot('head', -0.6, 0.15 * Math.sin(t * 0.7), 0.05);
      P.rot('uarmL', -0.1 - 0.0, 0, 0.18);
      P.rot('uarmR', -0.1, 0, -0.18);
      P.rot('farmL', -0.2, 0, 0);
      P.rot('farmR', -0.2, 0, 0);
      P.rot('handL', 0.3, 0, 0);
      P.rot('handR', 0.3, 0, 0);
    },
  },
  search: {
    fade: 0.3,
    fn(P, st, ex) {
      // crouched, rummaging with both hands out in front
      const t = st.t;
      const pel = { x: 0, y: 0.66, z: -0.1 };
      P.pel(pel.x, pel.y - D.hipY, pel.z);
      P.rot('pelvis', 0.35, 0, 0);
      legWorld(P, 'L', D, pel, 0.35, 0.16, D.ankle, 0.12, 0);
      legWorld(P, 'R', D, pel, 0.35, -0.16, D.ankle, -0.08, 0);
      P.rot('spine', 0.4, 0, 0);
      P.rot('chest', 0.3, 0, 0);
      P.rot('head', -0.5, 0.2 * Math.sin(t * 0.8), 0);
      const s = Math.sin(t * 4.3) * 0.15;
      P.rot('uarmL', -1.0 + s, 0.1, 0.08);
      P.rot('uarmR', -1.0 - s, -0.1, -0.08);
      P.rot('farmL', -0.6, 0, 0);
      P.rot('farmR', -0.6, 0, 0);
      P.rot('handL', -0.3, 0, 0);
      P.rot('handR', -0.3, 0, 0);
    },
  },
  reach: {
    fade: 0.25,
    fn(P, st, ex) {
      const k = sstep(0, 0.35, st.t);
      stand(P, 0.9, 0.18, -0.12, 0.03, 0.06 * k);
      P.rot('spine', 0.12 * k, -0.2 * k, 0);
      P.rot('chest', 0.14 * k, -0.15 * k, 0);
      P.rot('head', -0.18, 0.1, 0);
      P.rot('uarmL', 0.2, 0, 0.14);
      P.rot('farmL', -0.5, 0, 0);
      P.rot('uarmR', lerp(0.05, -1.55, k), -0.0, -0.08);
      P.rot('farmR', lerp(-0.3, -0.12, k), 0, 0);
      P.rot('handR', -0.1, 0, 0);
      P.rot('handL', -0.1, 0, 0);
    },
  },
  vault: {
    fade: 0.2,
    fn(P, st, ex) {
      // over a window sill: weight on both hands, one knee driven up
      const k = sstep(0, 0.4, st.t);
      const pel = { x: 0, y: 0.95, z: 0.1 };
      P.pel(pel.x, pel.y - D.hipY, pel.z);
      P.rot('pelvis', 0.5 * k, 0, 0);
      legTo(P, 'L', D, 0.02, -0.55, 0.35, 0, [0.5 * k, 0, 0]);
      legWorld(P, 'R', D, pel, 0.5 * k, -0.1, D.ankle, -0.25, 0);
      P.rot('spine', 0.5 * k, 0, 0);
      P.rot('chest', 0.3 * k, 0, 0);
      P.rot('head', -0.5, 0, 0);
      P.rot('uarmL', -1.5 * k, 0, 0.2);
      P.rot('uarmR', -1.5 * k, 0, -0.2);
      P.rot('farmL', -0.1, 0, 0);
      P.rot('farmR', -0.1, 0, 0);
    },
  },
  hide: {
    fade: 0.3,
    fn(P, st, ex) {
      // folded small, arms over the head, breath held and shaking
      const t = st.t, tr = Math.sin(t * 23) * 0.006;
      const pel = { x: 0, y: 0.34 + tr, z: -0.12 };
      P.pel(pel.x, pel.y - D.hipY, pel.z);
      P.rot('pelvis', 0.35, 0, 0);
      legWorld(P, 'L', D, pel, 0.35, 0.12, D.ankle, 0.18, 0);
      legWorld(P, 'R', D, pel, 0.35, -0.12, D.ankle, 0.1, 0);
      P.rot('spine', 0.75, 0, 0);
      P.rot('chest', 0.5, 0, 0);
      P.rot('head', 0.35, 0.2, 0.15);
      P.rot('uarmL', -2.0, 0.2, 0.5);
      P.rot('farmL', -2.0, 0, 0);
      P.rot('uarmR', -2.0, -0.2, -0.5);
      P.rot('farmR', -2.0, 0, 0);
      P.rot('handL', 0, 0, 0);
      P.rot('handR', 0, 0, 0);
    },
  },
  driveSeat: {
    fade: 0.3,
    fn(P, st, ex) {
      // seated at the wheel, both hands up on it, eyes forward and wide
      const t = st.t;
      const pel = { x: 0, y: 0.5, z: -0.15 };
      P.pel(pel.x, pel.y - D.hipY, pel.z);
      P.rot('pelvis', -0.05, 0, 0);
      legWorld(P, 'L', D, pel, -0.05, 0.1, 0.12, 0.35, 0.3);
      legWorld(P, 'R', D, pel, -0.05, -0.1, 0.12, 0.38, 0.3);
      P.rot('spine', 0.04 + 0.01 * Math.sin(t * 9), 0, 0);
      P.rot('chest', 0.06, 0, 0);
      P.rot('head', -0.08, 0.08 * Math.sin(t * 1.6), 0);
      P.rot('uarmL', -0.95, 0, 0.15);
      P.rot('uarmR', -0.95, 0, -0.15);
      P.rot('farmL', -0.95, 0, 0);
      P.rot('farmR', -0.95, 0, 0);
      P.rot('handL', -0.1, 0, 0);
      P.rot('handR', -0.1, 0, 0);
    },
  },
  flinch: {
    fade: 0.04,
    fn(P, st, ex) {
      // the whole body shies away: arms up crossing the face, knees buckling, head turned
      const k = sstep(0, 0.1, st.t) * (1 - 0.35 * sstep(0.5, 1.4, st.t));
      stand(P, lerp(0.915, 0.76, k), 0.1 * k, -0.2 * k, 0.04, 0.15 * k);
      P.rot('spine', -0.15 * k + 0.2 * k, 0.3 * k, 0.1 * k);
      P.rot('chest', 0.1 * k, 0.2 * k, 0);
      P.rot('head', 0.2 * k, -0.6 * k, 0.15 * k);
      P.rot('uarmL', -1.3 * k, 0, 0.3 * k);
      P.rot('farmL', -2.0 * k, 0, 0);
      P.rot('uarmR', -1.1 * k, 0.1, -0.4 * k);
      P.rot('farmR', -2.1 * k, 0, 0);
      P.rot('handL', 0, 0, 0);
      P.rot('handR', 0, 0, 0);
      P.addRot('pelvis', 0, 0, 0.05 * k);
    },
  },
  dead: {
    fade: 0.1,
    fn(P, st, ex) {
      // flat on the back, limp
      const m = easeOut(st.t / 0.35);
      const fall = lerp(0, -Math.PI / 2, m);
      P.pel(0, lerp(0, 0.1 - D.hipY, m), lerp(0, 0, m));
      P.rot('pelvis', fall, 0.1, 0);
      legTo(P, 'L', D, 0.04, -0.82, 0.0, 0, [fall, 0.1, 0]);
      legTo(P, 'R', D, 0.08, -0.8, 0.0, 0, [fall, 0.1, 0]);
      P.rot('spine', 0, 0, 0);
      P.rot('chest', 0, 0.08, 0);
      P.rot('head', 0.25 * m, 0.3, 0.2);
      P.rot('uarmL', 0.0, 0, 0.5 * m);
      P.rot('farmL', -0.1, 0, 0);
      P.rot('uarmR', -0.0, 0, -0.9 * m);
      P.rot('farmR', -0.3, 0, 0);
    },
  },
  // ---- extras for the death sequences ----
  impaled: {
    fade: 0.08,
    fn(P, st, ex) {
      // hanging by the chest: head back, arms flung up and out, legs dangling and swinging
      const t = st.t, sw = Math.sin(t * 2.2) * 0.07 * Math.exp(-t * 0.25);
      const k = easeOut(st.t / 0.3);
      P.pel(0, 0, 0);
      P.rot('pelvis', -0.25 * k, 0, 0);
      legTo(P, 'L', D, 0.05, -0.8, 0.12 + sw, 0.0, [-0.25 * k, 0, 0]);
      legTo(P, 'R', D, 0.05, -0.78, -0.02 - sw, 0.0, [-0.25 * k, 0, 0]);
      P.rot('spine', -0.2 * k, 0, 0.1 * k);
      P.rot('chest', -0.25 * k, 0, 0);
      P.rot('head', -0.55 * k + sw, 0.2, 0.3 * k);
      P.rot('uarmL', -2.3 * k, 0, 0.7 * k);
      P.rot('farmL', -0.5 * k, 0, 0);
      P.rot('uarmR', -2.0 * k, 0, -0.6 * k);
      P.rot('farmR', -0.7 * k, 0, 0);
      P.rot('handL', 0.4, 0, 0);
      P.rot('handR', 0.4, 0, 0);
    },
  },
  pinned: {
    fade: 0.06,
    fn(P, st, ex) {
      // back against a trunk, held up by the chest, feet scrabbling then still
      const t = st.t, k = easeOut(t / 0.25);
      const scr = Math.sin(t * 17) * 0.25 * Math.exp(-t * 1.4);
      const pel = { x: 0, y: 0.92, z: 0 };
      P.pel(0, 0, 0);
      P.rot('pelvis', 0.0, 0, 0);
      legTo(P, 'L', D, 0.06, -0.8, 0.0 + scr * 0.5, 0.0, [0, 0, 0]);
      legTo(P, 'R', D, 0.06, -0.78, 0.05 - scr * 0.5, 0.0, [0, 0, 0]);
      P.rot('spine', -0.05 * k, 0, 0);
      P.rot('chest', -0.12 * k, 0, 0);
      P.rot('head', -0.4 * k, 0.1, 0.25 * k);
      P.rot('uarmL', -0.2 + scr * 0.4, 0, 1.1 * k);
      P.rot('farmL', -0.5, 0, 0);
      P.rot('uarmR', -0.2 - scr * 0.4, 0, -1.2 * k);
      P.rot('farmR', -0.6, 0, 0);
      P.rot('handL', 0.4, 0, 0);
      P.rot('handR', 0.4, 0, 0);
    },
  },
  hang: {
    fade: 0.05,
    fn(P, st, ex) {
      // strung up by one ankle: the free leg has folded, the arms fall past the head
      const sw = Math.sin(st.t * 1.7) * 0.07;
      P.rot('pelvis', 0, 0, 0.06);
      P.rot('thighL', 0, 0, 0);
      P.rot('thighR', -0.75, 0, -0.1);
      P.rot('shinR', 1.45, 0, 0);
      P.rot('spine', 0.05, 0, 0);
      P.rot('chest', 0.05, 0, 0);
      P.rot('head', -0.4, 0.2, 0);
      P.rot('uarmL', -2.95 + sw, 0, 0.1);
      P.rot('uarmR', -2.95 - sw, 0, -0.1);
      P.rot('farmL', -0.12, 0, 0);
      P.rot('farmR', -0.2, 0, 0);
    },
  },
  slump: {
    fade: 0.1,
    fn(P, st, ex) {
      // sliding down a trunk to sit, head dropped
      const m = easeOut(st.t / 0.9);
      const pel = { x: 0, y: lerp(0.92, 0.12, m), z: -0.1 * m };
      P.pel(pel.x, pel.y - D.hipY, pel.z);
      P.rot('pelvis', 0.0, 0, 0);
      legWorld(P, 'L', D, pel, 0, 0.13, lerp(D.ankle, 0.1, m), lerp(0, 0.5, m), 0);
      legWorld(P, 'R', D, pel, 0, -0.18, lerp(D.ankle, 0.08, m), lerp(0.05, 0.62, m), 0);
      P.rot('spine', 0.1 * m, 0, 0.1 * m);
      P.rot('chest', 0.2 * m, 0, 0.1 * m);
      P.rot('head', 0.8 * m, 0.2, 0.3 * m);
      P.rot('uarmL', 0.1, 0, 0.5);
      P.rot('uarmR', 0.1, 0, -0.5);
      P.rot('farmL', -0.3, 0, 0);
      P.rot('farmR', -0.3, 0, 0);
    },
  },
};

// a floor of visibility so the windbreaker still reads when the moon is behind him: the emissive is
// tinted by the vertex colours, so jeans stay blue and the jacket stays mustard
function selfLit(m) {
  m.onBeforeCompile = (sh) => {
    sh.fragmentShader = sh.fragmentShader.replace(
      '#include <emissivemap_fragment>',
      '#include <emissivemap_fragment>\n  totalEmissiveRadiance *= vColor.rgb;',
    );
  };
  return m;
}

// The same staff jacket, on someone who did not make the last bus.
export function createVictim() {
  const v = createPlayer({ hair: 0x4d3a26, noTail: true, dead: true, face: 0xb2a08f, neck: 0x6e0d0a });
  v.setFlashlight(false);
  v.hideLens = true;
  v.setAnim('hang');
  return v;
}

export function createPlayer(look) {
  const rig = new Rig({ bones: BONES.map((n) => [n, PARENT[n], J[n]]), dims: D });
  const geo = buildGeometry(look);
  finishCounselorAppearance(geo, rig);
  const cloth = rig.skinned(geo.cloth, selfLit(lit({ map: clothTexture(), flatShading: false, vertexColors: true, emissive: 0x5c5040 })));
  const hard = rig.skinned(geo.hard, selfLit(lit({ map: skinTexture(), flatShading: false, vertexColors: true, emissive: 0x4c4238 })));
  const staffMat = lit({ map: staffTexture(), vertexColors: true, transparent: true, alphaTest: 0.4 });
  const staff = rig.skinned(geo.decal, staffMat);
  staff.castShadow = false;
  const wound = rig.skinned(geo.wound, cloth.material);
  wound.visible = false;
  wound.castShadow = false;

  // torch lens: a warm disc that shows only when the light is on
  const lensMat = new THREE.MeshBasicMaterial({ color: 0xfff0c8, fog: false });
  const lens = new THREE.Mesh(new THREE.CircleGeometry(0.044, 8), lensMat);
  lens.rotation.x = Math.PI / 2;
  lens.position.set(0, -0.265, 0);
  lens.visible = false;
  rig.b('handR').add(lens);
  // where the light comes from: +z points out of the lens, along the forearm
  const anchor = new THREE.Object3D();
  anchor.position.set(0, -0.27, 0);
  anchor.rotation.x = Math.PI / 2;
  rig.b('handR').add(anchor);

  const tail = rig.b('tail');
  const spring = { a: 0.3, v: 0, z: 0, vz: 0 };
  const anim = new Animator(rig, playerAnims, {
    lookWeight: 0.7,
    post(rg, P, dt, an) {
      // the ponytail swings on a spring driven by the stride
      const sp = an.speed || 0;
      const tgt = 0.25 + Math.min(sp, 6) * 0.07;
      const bounce = Math.sin(an.cur ? an.cur.phase * TAU * 2 : 0) * Math.min(sp, 6) * 0.05;
      const sideT = Math.sin(an.cur ? an.cur.phase * TAU : 0) * Math.min(sp, 6) * 0.04;
      spring.v += ((tgt + bounce - spring.a) * 60 - spring.v * 7) * dt;
      spring.a += spring.v * dt;
      spring.vz += ((sideT - spring.z) * 50 - spring.vz * 6) * dt;
      spring.z += spring.vz * dt;
      tail.rotation.set(spring.a, 0, spring.z);
    },
  });
  anim.extra.light = 1;
  const stance = createStanceStabilizer(rig, anim, { gaits: { walk: G_WALK, sneak: G_SNEAK, run: G_RUN }, maxOffset: .12, maxWidth: .25, maxForward: .64 });

  const p = {
    root: rig.root,
    rig,
    anim: 'idle',
    height: 1.72,
    flashlightAnchor: anchor,
    update(dt, o = {}) {
      const target = this._light ? 1 : 0;
      anim.extra.light += (target - anim.extra.light) * (1 - Math.exp(-8 * dt));
      if (o.aim !== undefined) anim.extra.aim = o.aim;
      anim.update(dt, o);
      this.anim = anim.name;
      lens.visible = this._light && anim.extra.light > 0.5 && !this.hideLens;
    },
    stabilizeStance: (dt, options) => stance.update(dt, options),
    resetStance: () => stance.reset(),
    setAnim(name, opts) {
      anim.setAnim(name, opts);
      this.anim = anim.name;
    },
    setFlashlight(on) {
      this._light = !!on;
    },
    setWounded(on) {
      wound.visible = !!on;
      this.wounded = !!on;
    },
    setAim(pitch) {
      anim.extra.aim = pitch;
    },
    has: (n) => anim.has(n),
    animator: anim,
    meshes: [cloth, hard, staff, wound],
    triangles: () => (geo.cloth.attributes.position.count + geo.hard.attributes.position.count + geo.decal.attributes.position.count + geo.wound.attributes.position.count) / 3,
    drawCalls: 5, // worst case: lens and shoulder graze visible
    _light: true,
  };
  anim.setAnim('idle');
  anim.update(0.016, {});
  return p;
}
