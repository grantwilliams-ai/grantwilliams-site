// Shared cosmetic finish for the counselor and camp-staff variant. Geometry
// stays on the existing rig; hands, shoes, flashlight and animation are unchanged.
import * as THREE from 'three';

const finished = new WeakSet();
const clamp = n => Math.max(0, Math.min(1, n));
const smooth = n => { const t=clamp(n); return t*t*(3-2*t); };

function garmentWeights(geometry,rig) {
  const p=geometry.attributes.position,si=geometry.attributes.skinIndex,sw=geometry.attributes.skinWeight;
  for(let i=0;i<p.count;i++) {
    const source=si.getX(i),name=rig.names[source],y=p.getY(i);
    let upper,lower,blend;
    if(name==='spine'||name==='chest') {
      upper=rig.idx.spine;lower=rig.idx.chest;blend=smooth((y-1.09)/.18);
    } else if(name==='head') {
      // The short collar folds with the neck instead of standing like a rigid cuff.
      upper=rig.idx.chest;lower=rig.idx.head;blend=smooth((y-1.414)/.059);
    } else if(name.startsWith('uarm')&&y>1.31) {
      upper=rig.idx.chest;lower=source;blend=smooth((1.47-y)/.16);
    } else if(name.startsWith('uarm')||name.startsWith('farm')) {
      const side=name.slice(-1),center=rig.at[rig.idx['farm'+side]][1];
      if(Math.abs(y-center)>.085)continue;
      upper=rig.idx['uarm'+side];lower=rig.idx['farm'+side];blend=smooth((center+.07-y)/.14);
    } else if(name.startsWith('thigh')||name.startsWith('shin')) {
      const side=name.slice(-1),center=rig.at[rig.idx['shin'+side]][1];
      if(Math.abs(y-center)>.08)continue;
      upper=rig.idx['thigh'+side];lower=rig.idx['shin'+side];blend=smooth((center+.065-y)/.13);
    } else continue;
    si.setXYZW(i,upper,lower,0,0);sw.setXYZW(i,1-blend,blend,0,0);
  }
  si.needsUpdate=sw.needsUpdate=true;
}

function wornClothes(geometry,rig) {
  const p=geometry.attributes.position,c=geometry.attributes.color,si=geometry.attributes.skinIndex;
  for(let i=0;i<p.count;i++) {
    const x=p.getX(i),y=p.getY(i),z=p.getZ(i),r=c.getX(i),g=c.getY(i),b=c.getZ(i);
    const name=rig.names[si.getX(i)];
    if(r>.15&&g>.09&&b<g*.68&&r>g*1.15) {
      const arm=/^(uarm|farm)/.test(name);
      const hem=arm?0:Math.exp(-(((y-.958)/.041)**2))*.11;
      const cuff=arm?Math.exp(-(((y-.86)/.045)**2))*.09:0;
      const shoulder=Math.exp(-(((y-1.38)/.08)**2))*.045;
      const folds=.025*Math.sin(y*55+x*17)*Math.sin(z*38+y*13);
      const factor=1-hem-cuff+shoulder+folds;
      c.setXYZ(i,r*factor*.96,g*factor*.99,b*factor*1.035);
    } else if(b>r*1.15&&b>g) {
      const knee=Math.exp(-(((y-.51)/.095)**2))*Math.max(0,z)*.65;
      const cuff=Math.max(0,1-(y-.1)/.22)*.065;
      const factor=1+knee-cuff;
      c.setXYZ(i,r*factor,g*factor,b*factor);
    }
  }
  c.needsUpdate=true;
}

function softenFaceDetails(geometry,rig) {
  // Head shell follows the 8-sided neck (48 vertices), before the nose and
  // surface features. Match close facial decals to its normals so tiny eyelids
  // and lips do not catch the lamp as separate flat plates.
  const start=48,end=start+9*32*6,detailStart=end+5*10*6+2*10*3;
  const p=geometry.attributes.position,n=geometry.attributes.normal,si=geometry.attributes.skinIndex;
  const triangles=[];
  for(let i=start;i<end;i+=3)triangles.push({face:new THREE.Triangle(...[0,1,2].map(j=>new THREE.Vector3().fromBufferAttribute(p,i+j))),normals:[0,1,2].map(j=>new THREE.Vector3().fromBufferAttribute(n,i+j))});
  const point=new THREE.Vector3(),closest=new THREE.Vector3(),bary=new THREE.Vector3(),normal=new THREE.Vector3(),best=new THREE.Vector3();
  for(let i=detailStart;i<p.count;i++) {
    if(si.getX(i)!==rig.idx.head||p.getZ(i)<.025)continue;
    point.fromBufferAttribute(p,i);let distance=.008**2,found=false;
    for(const triangle of triangles) {
      triangle.face.closestPointToPoint(point,closest);const d=point.distanceToSquared(closest);
      if(d>=distance)continue;
      distance=d;triangle.face.getBarycoord(closest,bary);
      normal.copy(triangle.normals[0]).multiplyScalar(bary.x).addScaledVector(triangle.normals[1],bary.y).addScaledVector(triangle.normals[2],bary.z);
      best.copy(normal).normalize();found=true;
    }
    if(found)n.setXYZ(i,best.x,best.y,best.z);
  }
  n.needsUpdate=true;
}

export function finishCounselorAppearance(geometry,rig) {
  if(finished.has(geometry.cloth))return geometry;
  wornClothes(geometry.cloth,rig);
  garmentWeights(geometry.cloth,rig);
  // STAFF follows the same torso bend, and the graze follows its sleeve.
  garmentWeights(geometry.decal,rig);
  garmentWeights(geometry.wound,rig);
  softenFaceDetails(geometry.hard,rig);
  finished.add(geometry.cloth);
  return geometry;
}
