// Replaces three.js's fog chunks with the game's fog: distance fog plus a thick low ground layer,
// glowing toward the moon. Call installFog() once before any material compiles.
// Every lit material gets this automatically. Only ShaderMaterials with fog:true must add the chunks.
import * as THREE from 'three';
import { MOON_DIR } from './palette.js';

const vec3 = (v) => `vec3(${v.map((n) => n.toFixed(5)).join(',')})`;

export function installFog() {
  THREE.ShaderChunk.fog_pars_vertex = /* glsl */ `
#ifdef USE_FOG
  varying float vFogDepth;
  varying vec3 vFogWorld;
#endif`;

  THREE.ShaderChunk.fog_vertex = /* glsl */ `
#ifdef USE_FOG
  vFogDepth = - mvPosition.z;
  vFogWorld = (mvPosition.xyz * mat3(viewMatrix)) + cameraPosition;
#endif`;

  THREE.ShaderChunk.fog_pars_fragment = /* glsl */ `
#ifdef USE_FOG
  uniform vec3 fogColor;
  varying float vFogDepth;
  varying vec3 vFogWorld;
  uniform float fogDensity;
#endif`;

  THREE.ShaderChunk.fog_fragment = /* glsl */ `
#ifdef USE_FOG
  float gDepth = max(0.0, length(vFogWorld - cameraPosition) - 5.0);
  float gFogD = fogDensity * gDepth;
  float gFog = 1.0 - exp(-gFogD * gFogD);
  // Thick mist that hugs the ground: strongest below about 1 m, gone by about 7 m above the lake.
  float gLow = 1.0 - smoothstep(-1.0, 7.0, vFogWorld.y);
  gFog = 1.0 - (1.0 - gFog) * exp(-gDepth * 0.012 * gLow);
  vec3 gDir = normalize(vFogWorld - cameraPosition);
  float gMoon = pow(max(dot(gDir, ${vec3(MOON_DIR)}), 0.0), 5.0);
  gl_FragColor.rgb = mix(gl_FragColor.rgb, fogColor * (1.0 + gMoon * 0.7), clamp(gFog, 0.0, 1.0));
#endif`;
}
