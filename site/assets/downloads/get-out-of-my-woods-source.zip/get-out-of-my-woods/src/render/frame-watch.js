// Measures how fast frames really arrive, from real timestamps, never from the capped simulation
// step. A paused frame (dt 0), a hidden tab or a long gap restarts the sample instead of counting:
// those frames say nothing about whether the device keeps up.
export class FrameWatch {
  constructor({ window = 2, gap = 1.5 } = {}) {
    this.window = window; // seconds of real time per measurement
    this.gap = gap; // a frame later than this starts a fresh sample
    this.fps = 60;
    this.start = null;
    this.last = null;
    this.frames = 0;
  }

  reset() {
    this.start = this.last = null;
    this.frames = 0;
  }

  // now: milliseconds (performance.now()). Returns the new fps when a measurement completes.
  sample(now, { dt = 1, hidden = false } = {}) {
    if (!(dt > 0) || hidden || !Number.isFinite(now)) {
      this.reset();
      return null;
    }
    if (this.last !== null && (now - this.last) / 1000 > this.gap) this.reset();
    this.last = now;
    if (this.start === null) {
      this.start = now;
      this.frames = 0;
      return null;
    }
    this.frames++;
    const span = (now - this.start) / 1000;
    if (span < this.window) return null;
    this.fps = this.frames / span;
    this.start = now;
    this.frames = 0;
    return this.fps;
  }
}
