// Procedural texture helpers. Every texture in the game is drawn on a canvas at load time:
// there are no image files, so the game stays one self-contained HTML file.
import * as THREE from 'three';

// Draw into a size x size canvas and wrap it as a texture.
// opts: repeat [x,y], srgb (default true), nearest (default true: chunky PS1-era magnification)
export function canvasTexture(size, draw, opts = {}) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext('2d');
  draw(ctx, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  if (opts.repeat) tex.repeat.set(opts.repeat[0], opts.repeat[1]);
  tex.colorSpace = opts.srgb === false ? THREE.NoColorSpace : THREE.SRGBColorSpace;
  tex.magFilter = opts.nearest === false ? THREE.LinearFilter : THREE.NearestFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.generateMipmaps = true;
  return tex;
}

// Scatter speckles over the whole canvas: the base of bark, dirt, burlap, denim.
export function speckle(ctx, size, rng, colors, count, minR = 1, maxR = 2) {
  for (let i = 0; i < count; i++) {
    ctx.fillStyle = colors[Math.floor(rng() * colors.length)];
    const r = minR + rng() * (maxR - minR);
    ctx.fillRect(rng() * size, rng() * size, r, r);
  }
}
