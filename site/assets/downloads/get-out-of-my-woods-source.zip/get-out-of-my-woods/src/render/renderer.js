// Renders the scene into a small high-precision target, then runs the final picture pass at
// screen size. The low-res target is the art style and also what makes phones run this smoothly.
import * as THREE from 'three';
import { installFog } from './fog.js';
import { PostPass } from './post.js';
import { GLOBALS } from './materials.js';
import { detectQuality } from '../core/quality.js';
import { FrameWatch } from './frame-watch.js';

export class GameRenderer {
  constructor(canvas, quality = detectQuality()) {
    installFog();
    this.quality = quality;
    this.canvas = canvas;
    this.gl = new THREE.WebGLRenderer({
      canvas,
      antialias: false,
      alpha: false,
      depth: false, // the post pass needs none; the target below has its own
      stencil: false,
      powerPreference: 'high-performance',
    });
    this.gl.setPixelRatio(1);
    this.gl.toneMapping = THREE.NoToneMapping;
    this.gl.shadowMap.enabled = quality.shadowSize > 0;
    this.gl.shadowMap.type = THREE.PCFShadowMap;
    const hf = this.gl.extensions.has('EXT_color_buffer_half_float') || this.gl.extensions.has('EXT_color_buffer_float');
    this.target = new THREE.WebGLRenderTarget(640, 360, {
      type: hf ? THREE.HalfFloatType : THREE.UnsignedByteType,
      format: THREE.RGBAFormat,
      depthBuffer: true,
      stencilBuffer: false,
      minFilter: THREE.NearestFilter,
      magFilter: THREE.NearestFilter,
      generateMipmaps: false,
    });
    this.post = new PostPass();
    this.post.uniforms.tScene.value = this.target.texture;
    this.time = 0;
    this.resScale = 1; // dynamic resolution, lowered by the frame-time watcher
    this.sharp = false;
    this.viewport = null; // {x,y,w,h} in CSS px when the game does not fill the page (portrait phone)
    this.frameWatch = new FrameWatch();
    this.fps = 60;
    this.resize();
    this._onResize = () => this.resize();
    if (typeof window !== 'undefined') window.addEventListener('resize', this._onResize);
  }

  dispose() {
    if(this.disposed)return;this.disposed=true;
    window.removeEventListener('resize',this._onResize);
    this.target.dispose();this.post.mesh.geometry.dispose();this.post.material.dispose();
    this.gl.dispose();this.gl.forceContextLoss();
  }

  // Sharp = render at screen size without the chunky pixels. Retro is the default look.
  setSharp(on) {
    this.sharp = on;
    const f = on ? THREE.LinearFilter : THREE.NearestFilter;
    this.target.texture.minFilter = f;
    this.target.texture.magFilter = f;
    this.target.texture.needsUpdate = true;
    this.post.uniforms.uRetro.value = on ? 0 : 1;
    this.resize();
  }

  resize() {
    const rect = this.canvas.getBoundingClientRect();
    const cssW = Math.max(1, rect.width || window.innerWidth);
    const cssH = Math.max(1, rect.height || window.innerHeight);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const outH = Math.min(Math.round(cssH * dpr), this.quality.maxPixelHeight);
    const outW = Math.round((outH * cssW) / cssH);
    this.gl.setSize(outW, outH, false);
    const baseH = this.sharp ? outH : this.quality.internalHeight;
    const h = Math.max(160, Math.round(baseH * this.resScale));
    const w = Math.round((h * cssW) / cssH);
    this.target.setSize(w, h);
    this.aspect = cssW / cssH;
    this.post.uniforms.uInternal.value.set(w, h);
    this.post.uniforms.uOutput.value.set(outW, outH);
  }

  render(scene, camera, dt) {
    this.time += dt;
    GLOBALS.uTime.value = this.time;
    this.post.uniforms.uTime.value = this.time;
    if (camera.aspect !== this.aspect) {
      camera.aspect = this.aspect;
      camera.updateProjectionMatrix();
    }
    this.gl.setRenderTarget(this.target);
    this.gl.render(scene, camera);
    this.gl.setRenderTarget(null);
    this.gl.render(this.post.scene, this.post.camera);
    this._watchFrames(dt);
  }

  // If the device cannot keep up, drop the internal resolution a step at a time. Real frame
  // timestamps decide; the simulation's capped step and paused or hidden frames do not.
  _watchFrames(dt, now = typeof performance !== 'undefined' ? performance.now() : NaN) {
    const fps = this.frameWatch.sample(now, { dt, hidden: typeof document !== 'undefined' && document.hidden });
    if (fps === null) return;
    this.fps = fps;
    if (this.dynamicRes === false || (this.sharp && !this.adaptiveSharp) || this.fps >= 27) return;
    if (this.resScale > 0.6) {
      this.resScale = Math.max(0.6, this.resScale - 0.1);
      this.resize();
    } else if (this.fps < 24 && this.onStruggling) {
      // Already as small as the picture goes. One last thing to give up, once.
      this.onStruggling();
      this.onStruggling = null;
    }
  }
}
