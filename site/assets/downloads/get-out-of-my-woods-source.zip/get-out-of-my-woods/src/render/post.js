// Final picture: tone curve, night grade, vignette, ordered dither, VHS, danger pulse, fades.
// This is the single place the whole game's image passes through.
import * as THREE from 'three';

const VERT = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = position.xy * 0.5 + 0.5;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}`;

const FRAG = /* glsl */ `
precision highp float;
uniform sampler2D tScene;
uniform vec2 uInternal;
uniform vec2 uOutput;
uniform float uTime;
uniform float uBrightness; // user setting, 1 = default
uniform float uRetro;      // 1 = dither and quantise, 0 = clean
uniform float uVhs;        // 0..1 steady tape look
uniform float uTear;       // 0..1 momentary tracking tear for scares and cuts
uniform float uDanger;     // 0..1 red pressure at the screen edge
uniform float uFlash;      // 0..1 white flash
uniform float uFlashScale; // Settings: Flashes
uniform float uRed;        // 0..1 full-frame red wash
uniform float uFade;       // 0 = black, 1 = picture
uniform float uLetterbox;  // 0..1 cinema bars
uniform float uDesat;      // 0..1
varying vec2 vUv;

float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

float bayer4(vec2 p) {
  int x = int(mod(p.x, 4.0)), y = int(mod(p.y, 4.0));
  int i = x + y * 4;
  // 4x4 Bayer matrix, written out so it works everywhere.
  if (i == 0) return 0.0625;  if (i == 1) return 0.5625;  if (i == 2) return 0.1875;  if (i == 3) return 0.6875;
  if (i == 4) return 0.8125;  if (i == 5) return 0.3125;  if (i == 6) return 0.9375;  if (i == 7) return 0.4375;
  if (i == 8) return 0.25;    if (i == 9) return 0.75;    if (i == 10) return 0.125;  if (i == 11) return 0.625;
  if (i == 12) return 1.0;    if (i == 13) return 0.5;    if (i == 14) return 0.875;  return 0.375;
}

vec3 filmCurve(vec3 x) {
  const float a = 2.51, b = 0.03, c = 2.43, d = 0.59, e = 0.14;
  return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

void main() {
  vec2 uv = vUv;

  // Tape wobble and the tracking tear: a band of the picture slides sideways.
  float tear = uTear;
  float vhs = max(uVhs, tear);
  if (vhs > 0.001) {
    uv.x += (sin(uv.y * 90.0 + uTime * 9.0) * 0.0006 + sin(uv.y * 13.0 - uTime * 2.3) * 0.0009) * vhs;
    if (tear > 0.001) {
      float bandY = fract(uTime * 0.37 + 0.2);
      float band = smoothstep(0.07, 0.0, abs(uv.y - bandY));
      uv.x += band * 0.045 * tear * (0.5 + 0.5 * sin(uTime * 61.0));
      float band2 = smoothstep(0.02, 0.0, abs(uv.y - fract(uTime * 1.31)));
      uv.x += band2 * 0.09 * tear;
    }
  }

  float ca = 0.00015 + 0.0009 * vhs;
  vec3 col = vec3(
    texture2D(tScene, uv + vec2(ca, 0.0)).r,
    texture2D(tScene, uv).g,
    texture2D(tScene, uv - vec2(ca, 0.0)).b
  );

  col *= 1.25 * uBrightness;
  col = filmCurve(col);
  col = pow(col, vec3(1.0 / 2.2));

  // Brightness also lifts the blacks a touch, so a dim phone or tired eyes can still read shapes.
  col += (uBrightness - 1.0) * 0.035;

  float luma = dot(col, vec3(0.299, 0.587, 0.114));
  // Night grade: shadows slide to cold blue-green, highlights stay warm.
  vec3 shadowTint = vec3(0.86, 0.97, 1.12);
  vec3 highTint = vec3(1.05, 1.0, 0.94);
  col *= mix(shadowTint, highTint, smoothstep(0.1, 0.65, luma));
  col = mix(col, vec3(luma), uDesat);

  vec2 c = vUv - 0.5;
  float r2 = dot(c, c);
  col *= 1.0 - r2 * 0.75;

  // Danger: blood pressure at the edge of sight.
  float edge = smoothstep(0.14, 0.52, r2 + 0.02 * sin(uTime * 7.0) * uDanger);
  col = mix(col, col * vec3(0.55, 0.12, 0.1) + vec3(0.2, 0.0, 0.0) * edge, edge * uDanger);

  col = mix(col, vec3(dot(col, vec3(0.35, 0.5, 0.15))) * vec3(1.15, 0.12, 0.08), uRed);
  col = mix(col, vec3(0.92, 0.95, 1.0), uFlash * uFlashScale);

  // Grain at output resolution.
  float g = hash(vUv * uOutput + fract(uTime) * 311.0) - 0.5;
  col += g * (0.006 + 0.014 * vhs);

  if (uRetro > 0.5) {
    // Ordered dither on the low-res grid, quantised to a 15-bit style palette.
    vec2 px = floor(vUv * uInternal);
    float levels = 64.0;
    col += (bayer4(px) - 0.5) / levels;
    col = floor(col * levels + 0.5) / levels;
    // Faint scanlines, never enough to dim the picture.
    col *= 0.99 + 0.01 * sin(vUv.y * uInternal.y * 3.14159 * 2.0);
  }

  if (vhs > 0.001) {
    float noiseLine = step(0.994 - 0.03 * tear, hash(vec2(floor(vUv.y * 120.0), floor(uTime * 24.0))));
    col += noiseLine * hash(vec2(vUv.x * 200.0, uTime)) * 0.28 * vhs;
  }

  col *= uFade;
  if (abs(vUv.y - 0.5) > 0.5 - 0.11 * uLetterbox) col = vec3(0.0);
  gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}`;

export class PostPass {
  constructor() {
    this.uniforms = {
      tScene: { value: null },
      uInternal: { value: new THREE.Vector2(640, 360) },
      uOutput: { value: new THREE.Vector2(1280, 720) },
      uTime: { value: 0 },
      uBrightness: { value: 1 },
      uRetro: { value: 1 },
      uVhs: { value: 0.08 },
      uTear: { value: 0 },
      uDanger: { value: 0 },
      uFlash: { value: 0 },
      uFlashScale: { value: 1 },
      uRed: { value: 0 },
      uFade: { value: 1 },
      uLetterbox: { value: 0 },
      uDesat: { value: 0 },
    };
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array([-1, -1, 0, 3, -1, 0, -1, 3, 0]), 3));
    this.material = new THREE.ShaderMaterial({
      vertexShader: VERT,
      fragmentShader: FRAG,
      uniforms: this.uniforms,
      depthTest: false,
      depthWrite: false,
    });
    this.mesh = new THREE.Mesh(geo, this.material);
    this.mesh.frustumCulled = false;
    this.scene = new THREE.Scene();
    this.scene.add(this.mesh);
    this.camera = new THREE.Camera();
  }
}
