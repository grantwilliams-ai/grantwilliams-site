// Shared material helpers and the global uniforms every animated material reads.
import * as THREE from 'three';

// One object, shared by reference: updating .value here updates every patched material.
export const GLOBALS = {
  uTime: { value: 0 },
  uWind: { value: 1 }, // 1 = calm night, rises toward 3 as the storm builds
  // For a filmed moment: every tree and bush rooted within radius z of (x, y) is gone, so the camera
  // can stand anywhere. uKeep names one trunk that stays (the one she is pinned to).
  uClear: { value: new THREE.Vector3(0, 0, 0) },
  uKeep: { value: new THREE.Vector2(1e5, 1e5) },
  uSubject: { value: new THREE.Vector4(0, 0, 0, 0) },
};

// Lit, flat-shaded, fogged. The default material for everything solid.
// opts: any MeshLambertMaterial option, plus wind (metres of sway at 10 m above the base).
export function lit(opts = {}) {
  const { wind = 0, ...rest } = opts;
  const mat = new THREE.MeshLambertMaterial({ flatShading: true, ...rest });
  if (wind > 0) addWind(mat, wind);
  return mat;
}

// Sway vertices with height. Works on instanced and normal meshes. Height is measured from the
// object's own origin, so pivot trees and bushes at their base.
export function addWind(mat, amount) {
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = GLOBALS.uTime;
    shader.uniforms.uWind = GLOBALS.uWind;
    shader.uniforms.uClear = GLOBALS.uClear;
    shader.uniforms.uKeep = GLOBALS.uKeep;
    shader.uniforms.uSubject = GLOBALS.uSubject;
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\nuniform float uTime;\nuniform float uWind;\nuniform vec3 uClear;\nuniform vec2 uKeep;')
      .replace(
        '#include <begin_vertex>',
        /* glsl */ `#include <begin_vertex>
        {
          vec3 baseP = vec3(0.0);
          #ifdef USE_INSTANCING
            baseP = instanceMatrix[3].xyz;
          #endif
          float gust = 0.72 + 0.28 * sin(uTime * 0.19 + baseP.x * 0.035);
          float sway = sin(uTime * 0.65 + baseP.x * 0.21 + baseP.z * 0.17) * gust + 0.18 * sin(uTime * 1.7 + baseP.x * 0.6 + position.y * 0.5);
          float h = max(0.0, position.y);
          float k = h * h * 0.01 * ${amount.toFixed(4)} * uWind;
          transformed.x += sway * k;
          transformed.z += sway * k * 0.6;
          if (uClear.z > 0.0 && distance(baseP.xz, uClear.xy) < uClear.z && distance(baseP.xz, uKeep) > 0.05) transformed = vec3(0.0);
        }`,
      );
    // Only an obstructer in the camera-to-player corridor stipples away; peripheral geometry stays solid.
    shader.fragmentShader = shader.fragmentShader
      .replace('#include <common>', '#include <common>\nuniform vec4 uSubject;')
      .replace(
        '#include <clipping_planes_fragment>',
        /* glsl */ `#include <clipping_planes_fragment>
        {
          float depth = vViewPosition.z;
          vec3 subjectView = (viewMatrix * vec4(uSubject.xyz, 1.0)).xyz;
          vec3 fragmentView = -vViewPosition;
          float subjectT = dot(fragmentView, subjectView) / max(dot(subjectView, subjectView), 0.0001);
          float subjectPerp = length(fragmentView - subjectView * subjectT);
          if (uSubject.w > 0.5 && depth < 3.3 && subjectT > 0.0 && subjectT < 1.0 && subjectPerp <= 0.8) {
            float cell = mod(floor(gl_FragCoord.x) + floor(gl_FragCoord.y) * 2.0, 4.0) * 0.25;
            if ((depth - 1.6) / 1.7 < cell + 0.12) discard;
          }
        }`,
      );
  };
  mat.customProgramCacheKey = () => 'wind' + amount.toFixed(4);
  return mat;
}
