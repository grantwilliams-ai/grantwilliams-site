// The look of the night, in one place. Colours are sRGB hex; three.js converts them to linear.
// Rule of the picture: trees and the killer read as BLACK SHAPES against PALE BLUE FOG.
// Warm light is rare and precious: the fire, a lantern, a lit window, the flashlight, the car.
export const PALETTE = {
  fog: 0x293e54, // the pale blue wall everything dissolves into
  fogStorm: 0x262f3d, // darker once the storm breaks
  skyZenith: 0x060a14,
  skyHorizon: 0x304860,
  moon: 0xdfe8ff,
  moonLight: 0x9db8ea,
  ambient: 0x25344f,
  hemiSky: 0x33486b,
  hemiGround: 0x15202a,
  flashlight: 0xffe6b8,
  fire: 0xff7a2a,
  lantern: 0xffb45a,
  window: 0xffc477,
  blood: 0x6e0505,
  bloodBright: 0xa30d0d,
  bark: 0x1c1712,
  pine: 0x141f1a,
  grass: 0x1e2a1e,
  dirt: 0x3a2f24,
  wood: 0x4a3524,
  woodDark: 0x2b1e14,
  burlap: 0x8a7350,
  denim: 0x2e3a4a,
  rust: 0x5a2f18,
  jacket: 0xd9a21b, // the counselor's mustard windbreaker: the one warm thing that moves
};

// Direction TOWARD the moon (unit vector). Fixed for the whole game.
export const MOON_DIR = (() => {
  const v = [-0.45, 0.62, -0.64];
  const l = Math.hypot(...v);
  return v.map((c) => c / l);
})();
