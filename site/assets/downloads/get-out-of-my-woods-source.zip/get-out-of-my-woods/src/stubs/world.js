// Plain world with the real collision shapes, so the game runs before the World module lands.
import * as THREE from 'three';
import { PALETTE, MOON_DIR } from '../render/palette.js';
import { lit } from '../render/materials.js';
import { generateForest } from '../sim/forest.js';
import { GRID_HALF, GRID_N, heightGrid, surfaceY } from '../sim/terrain.js';
import { BUILDINGS, CAR, LAYOUT, PROPS, TEMPLATES } from '../sim/layout.js';
import { buildBuilding, buildCar, buildProp } from '../kit/index.js';

export function buildWorld(scene) {
  scene.add(new THREE.HemisphereLight(PALETTE.hemiSky, PALETTE.hemiGround, 1.2));
  const moon = new THREE.DirectionalLight(PALETTE.moonLight, 1.6);
  moon.position.set(...MOON_DIR.map((c) => c * 100));
  scene.add(moon);
  const geo = new THREE.PlaneGeometry(GRID_HALF * 2, GRID_HALF * 2, GRID_N - 1, GRID_N - 1);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) pos.setY(i, heightGrid[i]);
  geo.computeVertexNormals();
  scene.add(new THREE.Mesh(geo, lit({ color: PALETTE.grass })));
  const f = generateForest();
  const trunk = new THREE.CylinderGeometry(0.12, 0.3, 11, 5).translate(0, 5.5, 0);
  const crown = new THREE.ConeGeometry(2.1, 9, 6).translate(0, 8.5, 0);
  const tm = new THREE.InstancedMesh(trunk, lit({ color: PALETTE.bark }), f.trees.length);
  const cm = new THREE.InstancedMesh(crown, lit({ color: PALETTE.pine, wind: 0.25 }), f.trees.length);
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(), p = new THREE.Vector3();
  f.trees.forEach((t, i) => {
    p.set(t.x, t.y, t.z);
    s.setScalar(t.scale);
    m.compose(p, q, s);
    tm.setMatrixAt(i, m);
    cm.setMatrixAt(i, m);
  });
  scene.add(tm, cm);
  const doors = new Map();
  for (const b of BUILDINGS) {
    const g = buildBuilding(b, TEMPLATES[b.template]);
    g.position.set(b.x, surfaceY(b.x, b.z), b.z);
    g.rotation.y = b.rot;
    scene.add(g);
    (g.userData.doors || []).forEach((d, i) => doors.set(`${b.id}.d${i}`, d));
  }
  for (const pr of PROPS) {
    const g = buildProp(pr);
    g.position.set(pr.x, surfaceY(pr.x, pr.z), pr.z);
    g.rotation.y = pr.rot || 0;
    scene.add(g);
  }
  const car = buildCar();
  car.position.set(CAR.x, surfaceY(CAR.x, CAR.z), CAR.z);
  car.rotation.y = CAR.rot;
  scene.add(car);
  return {
    car, moon,
    update() {},
    setDoor(id, a) {
      const d = doors.get(id);
      if (d) d.pivot.rotation.y = (d.base ?? (d.base = d.pivot.rotation.y)) - a * 1.7;
    },
    setWindowLit() {}, lightning() {}, setIndoor() {}, scarecrows: [],
  };
}
