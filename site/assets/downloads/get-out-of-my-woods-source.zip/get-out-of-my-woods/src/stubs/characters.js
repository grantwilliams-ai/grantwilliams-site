// Capsule stand-ins with the real API. Replaced by src/characters/index.js.
import * as THREE from 'three';
import { lit } from '../render/materials.js';

function figure(color, h, r) {
  const root = new THREE.Group();
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(r, h - 2 * r, 3, 8), lit({ color }));
  body.position.y = h / 2;
  root.add(body);
  const head = new THREE.Mesh(new THREE.BoxGeometry(r * 1.1, r * 1.1, r * 1.1), lit({ color: 0xaa9060 }));
  head.position.set(0, h - r * 0.5, r * 0.4);
  root.add(head);
  return { root, anim: 'idle', update() {}, setAnim(n) { this.anim = n; } };
}

export function createKiller() {
  const k = figure(0x1a1a1a, 2.15, 0.42);
  k.setEyeGlint = () => {};
  return k;
}
export function createPlayer() {
  const p = figure(0xd9a21b, 1.72, 0.26);
  p.setFlashlight = () => {};
  p.flashlightAnchor = new THREE.Object3D();
  p.flashlightAnchor.position.set(0.25, 1.15, 0.3);
  p.root.add(p.flashlightAnchor);
  return p;
}
export function playDeath(kind, ctx) {
  ctx.post.uRed.value = 0.9;
  setTimeout(() => ctx.onDone?.(), 1500);
  return { update() {} };
}
export const createBlood = () => ({ burst() {}, decal() {}, update() {}, clear() {} });
