// Bare-bones stand-in so the game runs before the real interface lands. Keyboard only.
export function createUI(root, handlers) {
  const line = document.createElement('div');
  line.style.cssText = 'position:absolute;left:12px;top:12px;color:#fff;font:18px sans-serif;background:#0008;padding:6px 10px';
  root.appendChild(line);
  const cap = document.createElement('div');
  cap.style.cssText = 'position:absolute;left:12px;bottom:12px;color:#fff;font:18px sans-serif;background:#0008;padding:6px 10px';
  root.appendChild(cap);
  const input = { moveX: 0, moveY: 0, lookX: 0, lookY: 0, run: false, sneak: false, action: false, actionHeld: false, flashlightPressed: false, pausePressed: false, mapPressed: false };
  const keys = new Set();
  const sync = () => {
    input.moveX = (keys.has('KeyD') ? 1 : 0) - (keys.has('KeyA') ? 1 : 0);
    input.moveY = (keys.has('KeyW') ? 1 : 0) - (keys.has('KeyS') ? 1 : 0);
    input.run = keys.has('ShiftLeft');
    input.sneak = keys.has('KeyC');
    input.actionHeld = keys.has('KeyE');
  };
  addEventListener('keydown', (e) => {
    if (!keys.has(e.code)) {
      if (e.code === 'KeyE') input.action = true;
      if (e.code === 'KeyF') input.flashlightPressed = true;
      if (e.code === 'Escape') input.pausePressed = true;
    }
    keys.add(e.code);
    sync();
  });
  addEventListener('keyup', (e) => {
    keys.delete(e.code);
    sync();
  });
  return {
    input,
    showTitle() { line.textContent = 'TITLE (stub)'; },
    hideAll() {}, showPause() { line.textContent = 'PAUSED'; }, showGameOver(s) { line.textContent = 'GAME OVER ' + JSON.stringify(s); },
    showEnding(s) { line.textContent = 'ENDING ' + JSON.stringify(s); },
    showTitleCard(t) { cap.textContent = t; }, setObjective(t) { line.textContent = t; }, toast(t) { cap.textContent = t; }, caption(t) { cap.textContent = t; },
    setPrompt(p) { if (p) cap.textContent = '[' + p + ']'; }, showControlsHint() {}, setCarMode() {}, mapOpen: () => false, setStamina() {}, setInventory() {}, setHide() {}, setHold() {}, bloodSplat() {}, setTouchVisible() {}, showMap() {},
  };
}
