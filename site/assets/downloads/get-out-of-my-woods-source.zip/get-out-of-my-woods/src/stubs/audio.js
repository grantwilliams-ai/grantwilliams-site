// Silent stand-in. Replaced by src/audio/index.js.
const handle = { stop() {}, setVolume() {}, setPos() {} };
export const audio = {
  unlock() {}, setVolume() {}, setListener() {}, sfx() {}, loop: () => handle, ambience() {}, setRoom() {},
  music() {}, setIntensity() {}, setWeather() {}, setThreat() {}, pauseAll() {}, resumeAll() {},
};
