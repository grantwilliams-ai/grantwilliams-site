// Placeholder kit: plain boxes that match the template solids. Replaced by src/kit/index.js.
import * as THREE from 'three';
import { lit } from '../render/materials.js';
import { templateDoorPose, templateWallSegments, PROP_SHAPES } from '../sim/layout.js';

const wallMat = lit({ color: 0x4a3524 }), solidMat = lit({ color: 0x2b1e14 }), roofMat = lit({ color: 0x241a14 });

export function buildBuilding(b, t) {
  const g = new THREE.Group();
  for (const s of templateWallSegments(t)) {
    const len = Math.hypot(s.x2 - s.x1, s.z2 - s.z1);
    const m = new THREE.Mesh(new THREE.BoxGeometry(len, t.wallH, 0.18), wallMat);
    m.position.set((s.x1 + s.x2) / 2, t.wallH / 2, (s.z1 + s.z2) / 2);
    m.rotation.y = -Math.atan2(s.z2 - s.z1, s.x2 - s.x1);
    g.add(m);
  }
  const floor = new THREE.Mesh(new THREE.BoxGeometry(t.hx * 2, 0.1, t.hz * 2), solidMat);
  floor.position.y = -0.05;
  g.add(floor);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(t.hx * 2 + 0.6, 0.15, t.hz * 2 + 0.6), roofMat);
  roof.position.y = t.wallH + 0.1;
  g.add(roof);
  for (const s of t.solids || []) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(s.hx * 2, s.h, s.hz * 2), solidMat);
    m.position.set(s.x, s.h / 2, s.z);
    g.add(m);
  }
  g.userData.doors = (t.doors || []).map((d) => {
    const p = templateDoorPose(t, d);
    const pivot = new THREE.Object3D();
    pivot.position.set(p.x - p.ux * d.width / 2, 0, p.z - p.uz * d.width / 2);
    pivot.rotation.y = -Math.atan2(p.uz, p.ux);
    const leaf = new THREE.Mesh(new THREE.BoxGeometry(d.width, 2.05, 0.06), wallMat);
    leaf.position.set(d.width / 2, 1.02, 0);
    pivot.add(leaf);
    g.add(pivot);
    return { pivot, hingeOffset: 0 };
  });
  g.userData.windows = [];
  return g;
}

export function buildProp(p) {
  const g = new THREE.Group();
  const s = PROP_SHAPES[p.type] || {};
  if (s.box) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(s.box[0] * 2, 1, s.box[1] * 2), solidMat);
    m.position.y = 0.5;
    g.add(m);
  } else if (s.circle) {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(s.circle, s.circle, 1, 8), solidMat);
    m.position.y = 0.5;
    g.add(m);
  }
  return g;
}

export function buildCar() {
  const g = new THREE.Group();
  const body = new THREE.Mesh(new THREE.BoxGeometry(1.9, 1.3, 5.2), lit({ color: 0x6a4a2a }));
  body.position.y = 0.8;
  g.add(body);
  const noop = new THREE.Object3D();
  g.userData = { hoodPivot: noop, doorPivot: noop, headlights: [], taillights: [], wheels: [], windshield: body, windshieldPaint: new THREE.Object3D(), setHeadlights() {}, setBatteryVisible() {} };
  return g;
}
export const buildSign = () => new THREE.Group();
export const buildScarecrow = () => {
  const g = new THREE.Group();
  const m = new THREE.Mesh(new THREE.CapsuleGeometry(0.3, 1.2, 3, 6), lit({ color: 0x8a7350 }));
  m.position.y = 1;
  g.add(m);
  return g;
};
export const buildSearchMarker = () => {
  const m = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.2, 0.3), lit({ color: 0xaa8855 }));
  return m;
};
