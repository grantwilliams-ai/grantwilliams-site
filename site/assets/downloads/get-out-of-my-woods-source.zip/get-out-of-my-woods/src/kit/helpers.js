import * as THREE from 'three';
import { lit } from '../render/materials.js';
import { woodTexture, floorTexture, shingleTexture, rustTexture, tickingTexture, burlapTexture, signTexture } from './textures.js';

let shared;
export function materials() {
  if (shared) return shared;
  shared = {
    wood: lit({ map: woodTexture(), color: 0xb5a58e }),
    darkWood: lit({ map: woodTexture(), color: 0x625b52 }),
    floor: lit({ map: floorTexture(), color: 0xb6a792 }),
    shingles: lit({ map: shingleTexture(), color: 0xa9afb0 }),
    metal: lit({ map: rustTexture(), color: 0xa6aaa4 }),
    rust: lit({ map: rustTexture(), color: 0xb08768 }),
    iron: lit({ color: 0x343a3b }),
    chrome: lit({ color: 0x9da6a7 }),
    mattress: lit({ map: tickingTexture(), color: 0xbab6a6 }),
    blanket: lit({ color: 0x646b68 }),
    cloth: lit({ map: burlapTexture(), color: 0xb3a486, side: THREE.DoubleSide }),
    sack: lit({ map: burlapTexture(true), color: 0xb7a47e }),
    black: lit({ color: 0x171a19 }),
    red: lit({ color: 0x71352b }),
    green: lit({ color: 0x3f5145 }),
    cream: lit({ color: 0xb7ad8f }),
    blue: lit({ color: 0x425a61 }),
    orange: lit({ color: 0x9a5b2c }),
    glass: lit({ color: 0x81969d, transparent: true, opacity: .22, depthWrite: false, side: THREE.DoubleSide }),
  };
  return shared;
}

const unitBox = new THREE.BoxGeometry(1, 1, 1);
const dummy = new THREE.Object3D();

export class Batch {
  constructor() { this.parts = new Map(); }

  add(mat, geo, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1) {
    dummy.position.set(x, y, z); dummy.rotation.set(rx, ry, rz); dummy.scale.set(sx, sy, sz); dummy.updateMatrix();
    return this.addMatrix(mat, geo, dummy.matrix);
  }

  addMatrix(mat, geo, matrix) {
    let g = geo.index ? geo.toNonIndexed() : geo.clone();
    g.applyMatrix4(matrix);
    if (!this.parts.has(mat)) this.parts.set(mat, []);
    this.parts.get(mat).push(g);
    return this;
  }

  box(mat, w, h, d, x = 0, y = 0, z = 0, ry = 0, rz = 0) {
    return this.add(mat, unitBox, x, y, z, 0, ry, rz, w, h, d);
  }

  cylinder(mat, rt, rb, h, segments, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) {
    return this.add(mat, new THREE.CylinderGeometry(rt, rb, h, segments), x, y, z, rx, ry, rz);
  }

  sphere(mat, r, x, y, z, sx = 1, sy = 1, sz = 1, detail = 0) {
    return this.add(mat, new THREE.IcosahedronGeometry(r, detail), x, y, z, 0, 0, 0, sx, sy, sz);
  }

  beam(mat, a, b, width = .06, depth = width) {
    const va = new THREE.Vector3(...a), vb = new THREE.Vector3(...b);
    const delta = vb.clone().sub(va), mid = va.clone().add(vb).multiplyScalar(.5);
    const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), delta.clone().normalize());
    const m = new THREE.Matrix4().compose(mid, q, new THREE.Vector3(width, delta.length(), depth));
    return this.addMatrix(mat, unitBox, m);
  }

  finish(name = '') {
    const group = new THREE.Group(); group.name = name;
    for (const [mat, geos] of this.parts) {
      const mesh = new THREE.Mesh(merge(geos), mat);
      mesh.castShadow = true; mesh.receiveShadow = true;
      group.add(mesh);
      geos.forEach((g) => g.dispose());
    }
    this.parts.clear();
    return group;
  }
}

export function merge(geos) {
  let count = 0;
  for (const g of geos) count += g.attributes.position.count;
  const pos = new Float32Array(count * 3), norm = new Float32Array(count * 3), uv = new Float32Array(count * 2);
  let p = 0, u = 0;
  for (const g of geos) {
    pos.set(g.attributes.position.array, p); norm.set(g.attributes.normal.array, p);
    if (g.attributes.uv) uv.set(g.attributes.uv.array, u);
    p += g.attributes.position.count * 3; u += g.attributes.position.count * 2;
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(norm, 3));
  out.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  out.computeBoundingSphere();
  return out;
}

export function mesh(geo, mat, x = 0, y = 0, z = 0) {
  const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z);
  m.castShadow = true; m.receiveShadow = true;
  return m;
}

export function quad(points, uvs = [[0, 0], [1, 0], [1, 1], [0, 1]]) {
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute([
    ...points[0], ...points[1], ...points[2], ...points[0], ...points[2], ...points[3],
  ], 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute([
    ...uvs[0], ...uvs[1], ...uvs[2], ...uvs[0], ...uvs[2], ...uvs[3],
  ], 2));
  g.computeVertexNormals(); return g;
}

export function trianglePrism(width, height, depth) {
  const x = width / 2, z = depth / 2;
  const positions = [
    -x,0,z, x,0,z, 0,height,z,
    x,0,-z, -x,0,-z, 0,height,-z,
    -x,0,-z, -x,0,z, 0,height,z, -x,0,-z, 0,height,z, 0,height,-z,
    x,0,z, x,0,-z, 0,height,-z, x,0,z, 0,height,-z, 0,height,z,
    -x,0,-z, x,0,-z, x,0,z, -x,0,-z, x,0,z, -x,0,z,
  ];
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  const uv = []; for (let i = 0; i < positions.length / 3; i++) uv.push(positions[i * 3] / width + .5, positions[i * 3 + 1] / height);
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.computeVertexNormals(); return g;
}

export function textMaterial(map, options = {}) {
  return lit({ map, color: options.color || 0xffffff, side: THREE.DoubleSide, transparent: !!options.transparent });
}

export function addTextPlane(group, lines, w, h, x, y, z, options = {}) {
  const mat = textMaterial(options.map || signTexture(lines, options), options);
  const m = mesh(new THREE.PlaneGeometry(w, h), mat, x, y, z);
  if (options.ry) m.rotation.y = options.ry;
  if (options.rx) m.rotation.x = options.rx;
  group.add(m); return m;
}

export function countGroup(group) {
  let triangles = 0, calls = 0;
  group.traverse((o) => {
    if (!o.isMesh) return;
    calls++;
    triangles += (o.geometry.index ? o.geometry.index.count : o.geometry.attributes.position.count) / 3;
  });
  return { calls, triangles };
}
