import * as THREE from 'three';
import { lit } from '../render/materials.js';
import { Batch, materials, mesh, quad } from './helpers.js';
import { makePaintTexture } from './textures.js';

function bodyGeometry() {
  const p = [
    [-.91,.48,-2.5],[.91,.48,-2.5],[.91,1.0,-2.42],[-.91,1.0,-2.42],
    [-.91,.48,2.5],[.91,.48,2.5],[.82,.9,2.5],[-.82,.9,2.5],
    [-.91,1.04,-1.65],[.91,1.04,-1.65],[.91,1.04,1.15],[-.91,1.04,1.15],
  ];
  const faces = [
    [0,1,2],[0,2,3],[4,7,6],[4,6,5],[0,4,5],[0,5,1],
    [3,2,8],[2,9,8],[8,9,10],[8,10,11],[2,6,10],[2,10,9],[6,7,11],[6,11,10],
    [0,3,8],[0,8,11],[0,11,7],[0,7,4],[1,5,6],[1,6,9],[1,9,2],
    [0,1,5],[0,5,4],[3,2,1],[7,6,5],
  ];
  const pos = [], uv = [];
  for (const f of faces) for (const i of f) { pos.push(...p[i]); uv.push(p[i][0] + .5, p[i][2] / 5 + .5); }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos,3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv,2)); g.computeVertexNormals(); return g;
}

function addWheel(group, M, x, z, wheels) {
  const pivot = new THREE.Group(); pivot.position.set(x,.43,z);
  const b = new Batch();
  b.cylinder(M.black, .42, .42, .25, 14, 0, 0, 0, 0, 0, Math.PI / 2);
  b.cylinder(M.black, .24, .24, .265, 10, 0, 0, 0, 0, 0, Math.PI / 2);
  for (let i = 0; i < 10; i++) {
    const a = i / 10 * Math.PI * 2;
    b.box(M.black, .28, .055, .07, 0, Math.sin(a) * .405, Math.cos(a) * .405, 0, a);
  }
  pivot.add(b.finish('wheel')); group.add(pivot); wheels.push(pivot);
}

export function buildCar() {
  const M = materials(), car = new THREE.Group(); car.name = 'wood-panel station wagon';
  const paint = lit({ color: 0x58645c });
  const lightMat = lit({ color: 0xd8d0ad, emissive: 0xffdca0, emissiveIntensity: 0 });
  const tailMat = lit({ color: 0x7d1915, emissive: 0xff1d08, emissiveIntensity: .08 });
  const b = new Batch();
  b.add(paint, bodyGeometry());
  b.box(M.iron, 1.72, .16, 4.75, 0, .43, -.05);
  b.box(M.chrome, 1.94, .16, .18, 0, .57, 2.52);
  b.box(M.chrome, 1.94, .16, .18, 0, .57, -2.53);
  b.box(M.black, 1.1, .3, .035, 0, .76, 2.515);
  for (let x = -.45; x <= .45; x += .15) b.box(M.chrome, .025, .25, .045, x, .76, 2.54);
  for (const side of [-1,1]) {
    b.box(M.wood, .035, .39, 3.55, side * .923, .79, -.28);
    b.box(M.cream, .042, .025, 3.62, side * .945, .99, -.28);
    b.box(M.cream, .042, .025, 3.62, side * .945, .58, -.28);
    for (const z of [-1.65,-.45,1.02]) b.box(M.cream, .045, .4, .025, side * .945, .79, z);
    for (const z of [-1.62,1.62]) {
      b.add(M.chrome, new THREE.TorusGeometry(.46,.035,4,12,Math.PI), side * .94, .47, z, 0, Math.PI / 2, Math.PI / 2);
    }
    b.box(M.chrome, .045, .045, 3.6, side * .96, .51, -.2);
    b.box(M.chrome, .32, .045, .06, side * .98, 1.0, -.15);
  }
  b.box(paint, 1.48, .12, 2.45, 0, 1.76, -.55);
  b.box(M.chrome, 1.53, .055, 2.5, 0, 1.83, -.55);
  for (const x of [-.65,.65]) {
    b.box(M.iron, .045, .09, 2.4, x, 1.91, -.55);
    for (const z of [-1.55,.45]) b.box(M.iron, 1.35, .045, .045, 0, 1.94, z);
  }
  for (const side of [-1,1]) {
    b.beam(paint, [side * .84,1.0,1.26], [side * .68,1.72,.85], .1);
    b.beam(paint, [side * .88,1.0,-1.72], [side * .69,1.72,-1.72], .11);
    b.box(paint, .1, .76, .12, side * .86, 1.36, -.52);
    b.box(paint, .1, .76, .12, side * .8, 1.36, .73);
    b.box(M.glass, .025, .57, 1.05, side * .79, 1.39, -1.16);
    b.box(M.glass, .025, .57, .97, side * .8, 1.39, .1);
  }
  b.box(M.black, 1.55, .17, .48, 0, 1.02, .75);
  b.box(M.iron, 1.45, .16, .16, 0, 1.14, .7);
  for (const x of [-.43,.43]) {
    b.box(M.darkWood, .65, .22, .75, x, .76, -.05);
    b.box(M.darkWood, .65, .7, .18, x, 1.12, -.4, 0, -.12);
    b.box(M.darkWood, .65, .22, .7, x, .76, -1.15);
    b.box(M.darkWood, .65, .62, .18, x, 1.08, -1.45);
  }
  b.beam(M.iron, [-.48,1.03,.55], [-.48,1.25,.34], .045);
  b.add(M.black, new THREE.TorusGeometry(.19,.025,5,14), -.48, 1.25, .32, Math.PI / 2.7);
  b.box(M.black, 1.3, .06, 1.25, 0, .91, 1.68);
  car.add(b.finish('wagon body'));

  const windshieldGeo = quad([[-.82,1.04,1.29],[.82,1.04,1.29],[.68,1.7,.88],[-.68,1.7,.88]]);
  const windshield = mesh(windshieldGeo, M.glass); windshield.name = 'windshield'; car.add(windshield);
  const rear = mesh(quad([[.75,1.05,-1.78],[-.75,1.05,-1.78],[-.67,1.68,-1.76],[.67,1.68,-1.76]]), M.glass); car.add(rear);
  const paintGeo = quad([[-.79,1.075,1.303],[.79,1.075,1.303],[.65,1.665,.902],[-.65,1.665,.902]]);
  const paintMat = new THREE.MeshBasicMaterial({ map: makePaintTexture(), transparent: true, depthWrite: false, side: THREE.DoubleSide, fog: true });
  const windshieldPaint = mesh(paintGeo, paintMat); windshieldPaint.name = 'GET OUT OF MY WOODS'; car.add(windshieldPaint);

  const hoodPivot = new THREE.Group(); hoodPivot.position.set(0,1.03,1.08);
  const hb = new Batch();
  hb.box(paint, 1.72, .12, 1.46, 0, 0, .73);
  hb.box(M.wood, 1.2, .025, 1.12, 0, -.075, .74);
  hb.box(M.chrome, .045, .04, 1.25, 0, .075, .74);
  hoodPivot.add(hb.finish('opening hood')); car.add(hoodPivot);

  const doorPivot = new THREE.Group(); doorPivot.position.set(-.94,.53,.8);
  const db = new Batch();
  db.box(paint, .07, .5, 1.1, 0, .25, -.55);
  db.box(M.wood, .078, .34, 1.0, -.01, .26, -.55);
  db.box(M.cream, .085, .025, 1.04, -.015, .45, -.55);
  db.box(M.chrome, .09, .04, .23, -.02, .5, -.85);
  doorPivot.add(db.finish('driver door')); car.add(doorPivot);

  const wheels = [];
  for (const x of [-.94,.94]) for (const z of [-1.62,1.62]) addWheel(car, M, x, z, wheels);

  const frontLights = new Batch();
  for (const x of [-.64,.64]) frontLights.box(lightMat, .38, .25, .055, x, .8, 2.52);
  const headlights = [frontLights.finish('headlights')]; car.add(headlights[0]);
  const rearLights = new Batch();
  for (const x of [-.7,.7]) {
    rearLights.box(M.chrome, .3, .4, .04, x, .82, -2.51);
    for (const y of [.71,.82,.93]) rearLights.box(tailMat, .25, .088, .05, x, y, -2.525);
  }
  const taillights = [rearLights.finish('taillights')]; car.add(taillights[0]);
  const glowTex = new THREE.CanvasTexture((() => {
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const g = c.getContext('2d'), r = g.createRadialGradient(32, 32, 2, 32, 32, 32);
    r.addColorStop(0, 'rgba(255,255,255,1)');
    r.addColorStop(.3, 'rgba(255,255,255,.3)');
    r.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = r;
    g.fillRect(0, 0, 64, 64);
    return c;
  })());
  const glowMat = new THREE.MeshBasicMaterial({ map: glowTex, color: 0xff2410, transparent: true, opacity: .32, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
  const tailGlow = new THREE.Group();
  for (const x of [-.7,.7]) {
    const q = new THREE.Mesh(new THREE.PlaneGeometry(.95, .95), glowMat);
    q.position.set(x, .82, -2.58);
    q.rotation.y = Math.PI;
    tailGlow.add(q);
  }
  tailGlow.visible = false;
  car.add(tailGlow);

  const coneMat = new THREE.MeshBasicMaterial({ color: 0xffe2ac, transparent: true, opacity: .006, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: true });
  const coneBatch = new Batch();
  for (const x of [-.64,.64]) coneBatch.add(coneMat, new THREE.ConeGeometry(1.3,6,12,1,true), x, .72, 5.48, Math.PI / 2);
  const cones = coneBatch.finish('headlight beams'); cones.visible = false; car.add(cones); headlights.push(cones);

  const battery = new THREE.Group();
  const bb = new Batch();
  bb.box(M.black, .42, .32, .3, .38, 1.0, 1.72);
  bb.box(M.red, .44, .06, .32, .38, 1.19, 1.72);
  bb.cylinder(M.chrome, .035, .035, .06, 7, .25, 1.25, 1.72);
  bb.cylinder(M.chrome, .035, .035, .06, 7, .5, 1.25, 1.72);
  battery.add(bb.finish('battery')); battery.visible = false; car.add(battery);

  car.userData = {
    hoodPivot, doorPivot, headlights, taillights, wheels, windshield, windshieldPaint,
    setHeadlights(on) {
      lightMat.emissiveIntensity = on ? 2.2 : 0;
      tailMat.emissiveIntensity = on ? 1.1 : .08;
      tailGlow.visible = on;
      cones.visible = on;
    },
    setBatteryVisible(on) { battery.visible = on; },
  };
  return car;
}
