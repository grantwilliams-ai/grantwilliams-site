import * as THREE from 'three';
import { Batch, materials, mesh, textMaterial, quad } from './helpers.js';
import { mapTexture, signTexture } from './textures.js';

function firepit(b, M) {
  for (let i = 0; i < 14; i++) {
    const a = i / 14 * Math.PI * 2;
    b.sphere(M.metal, .25, Math.sin(a) * 1.05, .15, Math.cos(a) * 1.05, 1.2, .7, .9);
  }
  b.cylinder(M.black, .9, .95, .05, 16, 0, .025, 0);
  for (let i = 0; i < 5; i++) {
    const a = i / 5 * Math.PI;
    b.cylinder(M.black, .1, .13, 1.35, 7, 0, .18 + i * .025, 0, Math.PI / 2, a, 0);
  }
}

function logbench(b, M) {
  b.cylinder(M.wood, .29, .32, 2.6, 9, 0, .42, 0, 0, 0, Math.PI / 2);
  for (const x of [-.85,.85]) b.box(M.darkWood, .22, .35, .55, x, .18, 0);
}

function picnictable(b, M) {
  for (let i = -2; i <= 2; i++) b.box(M.wood, .38, .09, 1.6, i * .39, .76, 0);
  for (const x of [-.82,.82]) b.box(M.darkWood, .34, .1, 1.65, x, .43, 0);
  for (const z of [-.55,.55]) {
    b.beam(M.darkWood, [-.85,.04,z], [-.36,.72,z], .12);
    b.beam(M.darkWood, [.85,.04,z], [.36,.72,z], .12);
    b.box(M.darkWood, 2.0, .12, .12, 0, .34, z);
  }
}

function barrel(b, M) {
  b.cylinder(M.rust, .4, .4, .9, 12, 0, .45, 0);
  for (const y of [.08,.25,.7,.87]) b.cylinder(M.iron, .415, .415, .035, 12, 0, y, 0);
  b.cylinder(M.iron, .37, .37, .025, 12, 0, .91, 0);
  b.cylinder(M.black, .035, .035, .02, 7, .17, .93, .1);
}

function dumpster(b, M) {
  b.box(M.green, 2.35, 1.15, 1.55, 0, .72, 0);
  b.box(M.iron, 2.42, .12, 1.62, 0, 1.34, 0, 0, -.04);
  for (const x of [-.9,.9]) for (const z of [-.58,.58]) b.cylinder(M.black, .1, .1, .12, 8, x, .1, z, Math.PI / 2);
  for (const x of [-1.21,1.21]) b.box(M.iron, .08, .32, .5, x, .9, 0);
  b.box(M.rust, .7, .25, .02, -.45, .8, .786, 0, -.1);
}

function canoe(b, M) {
  b.add(M.red, new THREE.SphereGeometry(1, 12, 6), 0, .26, 0, 0, 0, 0, .5, .25, 2.3);
  b.add(M.black, new THREE.SphereGeometry(1, 12, 5), 0, .39, 0, 0, 0, 0, .4, .12, 1.85);
  for (const z of [-1.1,0,1.1]) b.box(M.wood, .78, .055, .09, 0, .48, z);
}

function fence(b, M, length) {
  const n = Math.ceil(length / 2.2);
  for (let i = 0; i <= n; i++) b.box(M.darkWood, .14, 1.35, .14, -length / 2 + i * length / n, .675, 0);
  for (const y of [.47,1.02]) b.box(M.wood, length, .13, .09, 0, y, 0);
}

function fueltank(b, M) {
  b.cylinder(M.rust, .68, .68, 2.5, 12, 0, 1.25, 0, 0, 0, Math.PI / 2);
  b.sphere(M.rust, .68, -1.25, 1.25, 0, .25, 1, 1);
  b.sphere(M.rust, .68, 1.25, 1.25, 0, .25, 1, 1);
  for (const x of [-.75,.75]) {
    b.box(M.iron, .13, .65, 1.25, x, .35, 0);
    b.box(M.iron, .5, .12, 1.4, x, .06, 0);
  }
  b.cylinder(M.iron, .08, .08, .2, 8, .65, 1.98, 0);
}

function tractor(b, M) {
  b.box(M.rust, 1.05, .55, 1.65, 0, .83, .35);
  b.box(M.iron, .85, .12, .7, 0, 1.15, .42);
  b.box(M.rust, .82, .75, .18, 0, .85, -.72, 0, -.18);
  b.box(M.black, .7, .13, .65, 0, .78, -.55);
  for (const x of [-.91,.91]) {
    b.cylinder(M.black, .68, .68, .32, 12, x, .67, -.75, 0, 0, Math.PI / 2);
    b.cylinder(M.rust, .3, .3, .34, 10, x, .67, -.75, 0, 0, Math.PI / 2);
    b.cylinder(M.black, .38, .38, .24, 12, x * .8, .38, 1.02, 0, 0, Math.PI / 2);
    b.cylinder(M.rust, .16, .16, .26, 8, x * .8, .38, 1.02, 0, 0, Math.PI / 2);
  }
  b.cylinder(M.iron, .055, .07, 1.15, 7, .28, 1.65, .65);
  b.beam(M.iron, [0,1.0,-.45], [0,1.5,-.15], .055);
  b.add(M.iron, new THREE.TorusGeometry(.24,.025,4,12), 0, 1.5, -.15, Math.PI / 2);
  for (let x = -.35; x <= .35; x += .14) b.box(M.black, .055, .36, .025, x, .85, 1.185);
}

function phonebooth(group, b, M) {
  b.box(M.iron, 1.0, .12, 1.0, 0, .06, 0);
  b.box(M.iron, 1.04, .16, 1.04, 0, 2.35, 0);
  for (const x of [-.46,.46]) for (const z of [-.46,.46]) b.box(M.iron, .07, 2.25, .07, x, 1.18, z);
  for (const x of [-.47,.47]) b.box(M.glass, .025, 1.65, .82, x, 1.35, 0);
  b.box(M.glass, .82, 1.65, .025, 0, 1.35, -.47);
  b.box(M.iron, .46, .75, .18, 0, 1.35, -.35);
  b.box(M.black, .16, .34, .09, -.17, 1.45, -.22);
  b.beam(M.black, [-.2,1.25,-.22], [-.32,.95,-.22], .025);
  b.box(M.iron, .2, .25, .03, .12, 1.28, -.24);
  const sign = mesh(new THREE.PlaneGeometry(.82,.25), textMaterial(signTexture(['PHONE'], { fontSize: 42 })), 0, 2.2, .51);
  group.add(sign);
}

function busstop(b, M) {
  for (const x of [-1.5,1.5]) for (const z of [-.62,.62]) b.box(M.darkWood, .12, 2.25, .12, x, 1.125, z);
  b.box(M.wood, 3.1, 1.25, .09, 0, 1.25, -.63);
  b.box(M.shingles, 3.5, .13, 1.7, 0, 2.32, 0, 0, -.06);
  b.box(M.wood, 2.65, .12, .48, 0, .52, -.22);
  for (const x of [-1.05,1.05]) b.box(M.darkWood, .13, .5, .4, x, .25, -.22);
}

function gate(group, M) {
  const fixed = new Batch();
  for (const x of [-6,6]) {
    fixed.cylinder(M.iron, .09, .11, 1.65, 8, x, .825, 0);
    fixed.sphere(M.iron, .13, x, 1.68, 0);
  }
  group.add(fixed.finish('gate posts'));
  const leaves = [];
  for (const side of [-1,1]) {
    const pivot = new THREE.Group(); pivot.position.x = side * 5.85;
    const b = new Batch(), dir = -side, length = 5.8;
    for (const y of [.45,1.25]) b.cylinder(M.iron, .045, .045, length, 7, dir * length / 2, y, 0, 0, 0, Math.PI / 2);
    for (let i = 0; i <= 7; i++) b.cylinder(M.iron, .035, .035, .85, 6, dir * (i * length / 7), .85, 0);
    b.beam(M.iron, [0,.45,0], [dir * length,1.25,0], .055);
    if (side === 1) {
      for (let i = 0; i < 7; i++) b.add(M.rust, new THREE.TorusGeometry(.055,.012,4,7), dir * (length - .12 - i * .07), .83 - i * .025, .04, 0, i % 2 ? Math.PI / 2 : 0);
      b.box(M.rust, .12, .16, .06, dir * (length - .55), .64, .04);
    }
    pivot.add(b.finish(side < 0 ? 'left gate leaf' : 'right gate leaf'));
    group.add(pivot); leaves.push(pivot);
  }
  group.userData.leaves = leaves;
}

export function buildProp(p) {
  const M = materials(), group = new THREE.Group(); group.name = p.type;
  const b = new Batch();
  if (p.type === 'firepit') firepit(b, M);
  else if (p.type === 'logbench') logbench(b, M);
  else if (p.type === 'picnictable') picnictable(b, M);
  else if (p.type === 'barrel') barrel(b, M);
  else if (p.type === 'dumpster') dumpster(b, M);
  else if (p.type === 'canoe') canoe(b, M);
  else if (p.type === 'fence') fence(b, M, p.length || 4);
  else if (p.type === 'fueltank') fueltank(b, M);
  else if (p.type === 'tractor') tractor(b, M);
  else if (p.type === 'phonebooth') phonebooth(group, b, M);
  else if (p.type === 'busstop') busstop(b, M);
  else if (p.type === 'gate') gate(group, M);
  else if (p.type === 'flagpole') {
    b.cylinder(M.iron, .045, .075, 6.5, 8, 0, 3.25, 0);
    b.cylinder(M.concrete || M.metal, .28, .36, .35, 8, 0, .175, 0);
    b.box(M.cloth, 1.35, .75, .025, .7, 5.85, 0, 0, -.06);
    b.box(M.blue, .52, .36, .028, .25, 6.02, .015);
  } else if (p.type === 'noticeboard') {
    for (const x of [-.82,.82]) b.box(M.darkWood, .13, 2.15, .13, x, 1.075, 0);
    b.box(M.wood, 2.0, 1.25, .14, 0, 1.5, 0);
    b.box(M.shingles, 2.25, .12, .55, 0, 2.18, 0, 0, -.08);
    const map = mesh(new THREE.PlaneGeometry(1.35,1.0), textMaterial(mapTexture()), 0, 1.5, .081);
    group.add(map);
  } else if (p.type === 'campsign') {
    for (const x of [-1.6,1.6]) b.box(M.darkWood, .18, 2.8, .18, x, 1.4, 0);
    b.box(M.wood, 4.0, 1.7, .16, 0, 2.15, 0);
    const sign = mesh(new THREE.PlaneGeometry(3.75,1.45), textMaterial(signTexture(['CAMP STILLWATER','CLOSED FOR THE SEASON'], { fontSize: 22 })), 0, 2.15, .09);
    group.add(sign);
  }
  if (b.parts.size) group.add(b.finish(`${p.type} geometry`));
  return group;
}

function arrowGeometry(width, height) {
  const s = new THREE.Shape();
  s.moveTo(-width / 2, -height / 2); s.lineTo(width / 2 - .2, -height / 2);
  s.lineTo(width / 2, 0); s.lineTo(width / 2 - .2, height / 2);
  s.lineTo(-width / 2, height / 2); s.closePath();
  const geo = new THREE.ShapeGeometry(s);
  // A shape's uvs are its own coordinates. The sign's text needs them 0 to 1 across the board.
  const pos = geo.attributes.position, uv = geo.attributes.uv;
  for (let i = 0; i < pos.count; i++) uv.setXY(i, pos.getX(i) / width + 0.5, pos.getY(i) / height + 0.5);
  return geo;
}

export function buildSign(s) {
  const M = materials(), group = new THREE.Group(), b = new Batch();
  b.box(M.darkWood, .14, 2.25, .14, 0, 1.125, 0);
  b.box(M.darkWood, .24, .1, .24, 0, .05, 0);
  const lines = s.text.split('.').map((q) => q.trim()).filter(Boolean).slice(0,3);
  lines.forEach((line, i) => {
    const y = 1.95 - i * .43, ry = i % 2 ? Math.PI : 0;
    const board = mesh(arrowGeometry(1.75,.32), textMaterial(signTexture([line], { fontSize: 14 })), 0, y, .075);
    board.rotation.y = ry; group.add(board);
    b.add(M.darkWood, arrowGeometry(1.75,.32), 0, y, .055, 0, ry);
  });
  group.add(b.finish('sign post'));
  return group;
}

export function buildScarecrow() {
  const M = materials(), b = new Batch();
  b.box(M.darkWood, .13, 2.35, .13, 0, 1.175, 0);
  b.box(M.darkWood, 1.65, .11, .11, 0, 1.55, 0);
  b.box(M.blue, .67, .78, .3, 0, 1.35, 0);
  b.box(M.blue, .52, .25, .26, -.5, 1.53, 0, 0, -.09);
  b.box(M.blue, .52, .25, .26, .5, 1.53, 0, 0, .09);
  b.box(M.cloth, .2, .25, .2, -.82, 1.5, 0);
  b.box(M.cloth, .2, .25, .2, .82, 1.5, 0);
  for (const x of [-.2,.2]) b.box(M.darkWood, .25, .72, .25, x, .67, 0, 0, x * .12);
  b.cylinder(M.cloth, .09, .12, .18, 7, 0, 1.84, 0);
  b.sphere(M.cloth, .3, 0, 2.08, .015, .82, 1.12, .8, 1);
  b.cylinder(M.cloth, .11, .17, .12, 7, 0, 2.37, 0);
  for (const [x,y,a] of [[-.2,1.5,-.3],[.22,1.22,.25],[.06,1.62,.12]]) {
    b.beam(M.darkWood, [x,y,.05], [x + a,y + .12,.85], .018);
    b.box(M.cloth, .1, .025, .18, x + a, y + .12, .76, 0, a);
    b.add(M.iron, new THREE.ConeGeometry(.035,.12,5), x, y, -.02, Math.PI / 2);
  }
  const group = b.finish('archery scarecrow');
  group.name = 'sack-headed archery dummy';
  return group;
}
