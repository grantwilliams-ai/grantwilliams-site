import * as THREE from 'three';
import { lit } from '../render/materials.js';
import { templateDoorPose } from '../sim/layout.js';
import { makeRng } from '../core/rng.js';
import { Batch, materials, mesh, trianglePrism, textMaterial } from './helpers.js';
import { signTexture, posterTexture } from './textures.js';

const WALLS = {
  front: (t) => ({ axis: 'x', fixed: t.hz, lo: -t.hx, hi: t.hx, ry: 0, out: 1 }),
  back: (t) => ({ axis: 'x', fixed: -t.hz, lo: -t.hx, hi: t.hx, ry: Math.PI, out: -1 }),
  left: (t) => ({ axis: 'z', fixed: -t.hx, lo: -t.hz, hi: t.hz, ry: -Math.PI / 2, out: -1 }),
  right: (t) => ({ axis: 'z', fixed: t.hx, lo: -t.hz, hi: t.hz, ry: Math.PI / 2, out: 1 }),
};

function wallBox(batch, mat, w, u, y, width, height, depth = .16, offset = 0) {
  if (w.axis === 'x') batch.box(mat, width, height, depth, u, y, w.fixed + offset * w.out, w.ry);
  else batch.box(mat, width, height, depth, w.fixed + offset * w.out, y, u, w.ry);
}

function wallPoint(w, u, y, offset = 0) {
  return w.axis === 'x' ? [u, y, w.fixed + offset * w.out] : [w.fixed + offset * w.out, y, u];
}

function buildShell(batch, glassBatch, t, kind) {
  const M = materials();
  const wallMat = kind === 'messhall' ? M.darkWood : M.wood;
  for (const name of ['front', 'back', 'left', 'right']) {
    if (t.openWalls?.includes(name)) continue;
    const w = WALLS[name](t);
    const openings = [];
    for (const d of t.doors || []) if (d.wall === name) openings.push({ at: d.at, width: d.width, bottom: 0, top: 2.14, door: true });
    for (const d of t.windows || []) if (d.wall === name) openings.push({ at: d.at, width: d.width, bottom: .95, top: Math.min(2.05, t.wallH - .3), window: true });
    for (const d of t.vault || []) if (d.wall === name) openings.push({ at: d.at, width: d.width, bottom: .7, top: 2.05, vault: true });
    const cuts = [...new Set([w.lo, w.hi, ...openings.flatMap((o) => [o.at - o.width / 2, o.at + o.width / 2])])].sort((a, b) => a - b);
    for (let i = 0; i < cuts.length - 1; i++) {
      const a = cuts[i], b = cuts[i + 1], mid = (a + b) / 2, width = b - a;
      if (width < .005) continue;
      const o = openings.find((q) => mid > q.at - q.width / 2 && mid < q.at + q.width / 2);
      const ranges = o ? [[0, o.bottom], [o.top, t.wallH]] : [[0, t.wallH]];
      for (const [lo, hi] of ranges) {
        if (hi - lo < .01) continue;
        wallBox(batch, wallMat, w, mid, (lo + hi) / 2, width, hi - lo);
        if (kind === 'cabin') {
          for (let u = a + .08; u < b; u += .36) {
            const p = wallPoint(w, u, (lo + hi) / 2, .095);
            batch.add(M.darkWood, new THREE.PlaneGeometry(.035, hi - lo), ...p, 0, w.ry);
          }
        } else if (kind === 'messhall') {
          for (let y = lo + .13; y < hi; y += .27) wallBox(batch, M.wood, w, mid, y, width + .025, .21, .22, .015);
        }
      }
    }
    for (const o of openings) {
      if (o.door) {
        for (const side of [-1, 1]) wallBox(batch, M.darkWood, w, o.at + side * (o.width / 2 + .045), 1.09, .09, 2.18, .23, .015);
        wallBox(batch, M.darkWood, w, o.at, 2.17, o.width + .18, .1, .23, .015);
        continue;
      }
      const cy = (o.bottom + o.top) / 2, wh = o.top - o.bottom;
      for (const side of [-1, 1]) wallBox(batch, M.darkWood, w, o.at + side * (o.width / 2 + .035), cy, .07, wh + .14, .22, .025);
      for (const y of [o.bottom - .035, o.top + .035]) wallBox(batch, M.darkWood, w, o.at, y, o.width + .14, .07, .24, .025);
      wallBox(batch, M.darkWood, w, o.at, o.bottom - .075, o.width + .25, .07, .34, .04);
      if (o.vault) continue;
      wallBox(batch, M.darkWood, w, o.at, cy, .035, wh, .08, .055);
      wallBox(batch, M.darkWood, w, o.at, cy, o.width, .035, .08, .055);
      const p = wallPoint(w, o.at, cy, .01);
      glassBatch.add(M.glass, new THREE.PlaneGeometry(o.width, wh), ...p, 0, w.ry, 0);
    }
  }
  for (const iw of t.innerWalls || []) {
    const len = Math.hypot(iw.x2 - iw.x1, iw.z2 - iw.z1);
    batch.box(M.darkWood, len, t.wallH, .16, (iw.x1 + iw.x2) / 2, t.wallH / 2, (iw.z1 + iw.z2) / 2, -Math.atan2(iw.z2 - iw.z1, iw.x2 - iw.x1));
    batch.box(M.wood, len, .12, .24, (iw.x1 + iw.x2) / 2, 2.15, (iw.z1 + iw.z2) / 2, -Math.atan2(iw.z2 - iw.z1, iw.x2 - iw.x1));
  }
}

function buildFloor(batch, t, boathouse = false) {
  const M = materials();
  batch.box(M.floor, t.hx * 2, .12, t.hz * 2, 0, -.06, 0);
  if (!boathouse) batch.box(M.darkWood, t.hx * 2 - .12, 1, t.hz * 2 - .12, 0, -.56, 0);
  else {
    for (const x of [-t.hx + .22, t.hx - .22]) for (const z of [-t.hz + .3, 0, t.hz - .3]) {
      batch.box(M.darkWood, .24, 4.15, .24, x, -2.02, z);
    }
    for (const x of [-t.hx + .22, t.hx - .22]) batch.beam(M.darkWood, [x, -2.8, -t.hz + .3], [x, -.2, t.hz - .3], .13);
  }
}

function buildRoof(batch, t, kind) {
  const M = materials();
  const over = kind === 'messhall' ? .55 : .38;
  const half = t.hx + over, rise = t.ridgeH - t.wallH;
  // The gable and walls meet at x=±hx; continue that slope outward to the eaves.
  // Using the overhang in the pitch left a sky slit above both side walls.
  const slope = Math.atan2(rise, t.hx), eaveY = t.wallH - over * rise / t.hx;
  const len = Math.hypot(half, t.ridgeH - eaveY);
  const roofY = (t.ridgeH + eaveY) / 2 + .06;
  const porch = t.porch || 0, depth = t.hz * 2 + over * 2 + porch;
  const z = porch / 2;
  const roofMat = kind === 'shed' ? M.metal : M.shingles;
  batch.add(roofMat, new THREE.BoxGeometry(len, .12, depth), -half / 2, roofY, z, 0, 0, slope);
  batch.add(roofMat, new THREE.BoxGeometry(len, .12, depth), half / 2, roofY, z, 0, 0, -slope);
  batch.box(M.darkWood, .13, .16, depth + .08, 0, t.ridgeH + .08, z);
  for (const side of [-1, 1]) {
    const gable = trianglePrism(t.hx * 2, rise, .12);
    batch.add(M.wood, gable, 0, t.wallH, side * t.hz);
    batch.box(M.darkWood, .13, .17, depth, side * half, eaveY + .01, z);
  }
  for (const side of [-1, 1]) {
    batch.box(M.darkWood, .13, .16, t.hx * 2, 0, t.wallH - .02, z + side * depth / 2, Math.PI / 2);
  }
}

function buildPorch(batch, t) {
  if (!t.porch) return;
  const M = materials(), z = t.hz + t.porch / 2;
  batch.box(M.floor, t.hx * 2 + .15, .12, t.porch, 0, -.07, z);
  batch.box(M.darkWood, t.hx * 2 - .1, .75, t.porch - .1, 0, -.5, z);
  const front = t.hz + t.porch - .12;
  for (const x of [-t.hx + .15, t.hx - .15]) {
    batch.box(M.darkWood, .15, t.wallH + .12, .15, x, (t.wallH + .12) / 2, front);
    batch.box(M.darkWood, .12, .12, t.porch, x, .78, z);
    batch.box(M.darkWood, .12, .12, t.porch, x, .32, z);
  }
  const door = t.doors?.find((d) => d.wall === 'front');
  const gap = door ? door.width / 2 + .35 : .8;
  for (const side of [-1, 1]) {
    const a = door ? door.at + side * gap : -gap;
    const b = side * (t.hx - .12);
    const lo = Math.min(a, b), hi = Math.max(a, b);
    if (hi - lo < .1) continue;
    for (const y of [.32, .78]) batch.box(M.darkWood, hi - lo, .1, .1, (lo + hi) / 2, y, front);
    for (let x = lo + .15; x < hi; x += .42) batch.box(M.wood, .055, .5, .055, x, .53, front);
  }
  batch.box(M.floor, 1.65, .16, .45, door?.at || 0, -.16, t.hz + t.porch + .18);
  batch.box(M.floor, 1.85, .16, .45, door?.at || 0, -.32, t.hz + t.porch + .55);
}

function buildDoor(t, d, kind) {
  const M = materials(), p = templateDoorPose(t, d);
  const pivot = new THREE.Group();
  pivot.position.set(p.x - p.ux * d.width / 2, 0, p.z - p.uz * d.width / 2);
  pivot.rotation.y = -Math.atan2(p.uz, p.ux);
  const b = new Batch();
  if (kind === 'cabin') {
    for (const x of [.055, d.width - .055]) b.box(M.darkWood, .11, 2.04, .07, x, 1.02, 0);
    for (const y of [.08, .72, 1.98]) b.box(M.darkWood, d.width, .12, .07, d.width / 2, y, 0);
    b.box(M.darkWood, d.width - .18, .58, .055, d.width / 2, .37, 0);
    b.box(M.iron, d.width - .18, 1.13, .018, d.width / 2, 1.34, 0);
    for (let x = .15; x < d.width - .1; x += .12) b.box(M.darkWood, .012, 1.1, .025, x, 1.34, .015);
    for (let y = .83; y < 1.9; y += .12) b.box(M.darkWood, d.width - .18, .012, .025, d.width / 2, y, .015);
  } else {
    b.box(M.wood, d.width, 2.04, .075, d.width / 2, 1.02, 0);
    for (const y of [.32, 1.58]) b.box(M.darkWood, d.width - .12, .12, .095, d.width / 2, y, 0);
    b.beam(M.darkWood, [.1, .4, .055], [d.width - .1, 1.5, .055], .09);
  }
  b.sphere(M.darkWood, .045, d.width - .14, 1.0, .075, 1, 1, 1);
  pivot.add(b.finish('door leaf'));
  return { pivot, hingeOffset: 0 };
}

function bunk(batch, s) {
  const M = materials();
  for (const x of [s.x - s.hx + .045, s.x + s.hx - .045]) for (const z of [s.z - s.hz + .045, s.z + s.hz - .045]) {
    batch.box(M.darkWood, .09, s.h, .09, x, s.h / 2, z);
  }
  for (const y of [.42, 1.28]) {
    batch.box(M.darkWood, s.hx * 2, .12, s.hz * 2, s.x, y, s.z);
    batch.box(M.mattress, s.hx * 2 - .12, .13, s.hz * 2 - .1, s.x, y + .12, s.z);
    batch.box(M.blanket, s.hx * 2 - .1, .035, s.hz * 1.12, s.x, y + .2, s.z + .28);
    batch.box(M.mattress, s.hx * 1.3, .09, .36, s.x, y + .22, s.z - s.hz + .25);
  }
  const aisle = s.x < 0 ? s.x + s.hx : s.x - s.hx;
  for (const y of [.75, 1.05, 1.62]) batch.box(M.darkWood, .055, .055, .48, aisle, y, s.z + s.hz - .25);
  for (const z of [s.z + s.hz - .45, s.z + s.hz - .08]) batch.box(M.darkWood, .055, 1.05, .055, aisle, 1.02, z);
}

function closet(batch, s, facing = 'z', steel = false) {
  const M = materials(), g = new Batch();
  if (facing === 'x' || facing === '-x') s = { ...s, hx: s.hz, hz: s.hx };
  const mat = steel ? M.metal : M.darkWood;
  g.box(mat, s.hx * 2, s.h, .1, 0, s.h / 2, -s.hz + .05);
  for (const x of [-s.hx + .05, s.hx - .05]) g.box(mat, .1, s.h, s.hz * 2, x, s.h / 2, 0);
  for (const y of [.05, s.h - .05]) g.box(mat, s.hx * 2, .1, s.hz * 2, 0, y, 0);
  g.box(M.darkWood, s.hx * 1.6, s.h * .77, .025, 0, s.h * .54, -s.hz + .11);
  for (const x of [-s.hx + .055, s.hx - .055]) g.box(mat, .1, s.h, .09, x, s.h / 2, s.hz + .04);
  for (const y of [.07, s.h - .07]) g.box(mat, s.hx * 2, .14, .09, 0, y, s.hz + .04);
  for (let y = .32; y < s.h - .18; y += .13) g.add(mat, new THREE.BoxGeometry(s.hx * 1.65, .085, .045), 0, y, s.hz + .055, -.28, 0, 0);
  g.sphere(M.iron, .035, s.hx * .57, s.h * .47, s.hz + .105);
  const group = g.finish('louvred closet'); group.position.set(s.x, 0, s.z);
  if (facing === 'x') group.rotation.y = Math.PI / 2;
  if (facing === '-z') group.rotation.y = Math.PI;
  if (facing === '-x') group.rotation.y = -Math.PI / 2;
  return group;
}

function absorb(batch, group) {
  group.updateMatrixWorld(true);
  group.traverse((o) => {
    if (!o.isMesh) return;
    batch.addMatrix(o.material, o.geometry, o.matrixWorld);
    o.geometry.dispose();
  });
}

function desk(batch, s) {
  const M = materials();
  batch.box(M.wood, s.hx * 2, .1, s.hz * 2, s.x, s.h - .05, s.z);
  batch.box(M.darkWood, s.hx * 2 - .08, .42, s.hz * 2 - .1, s.x, s.h - .3, s.z);
  for (const x of [s.x - s.hx + .07, s.x + s.hx - .07]) for (const z of [s.z - s.hz + .07, s.z + s.hz - .07]) batch.box(M.darkWood, .09, s.h - .1, .09, x, (s.h - .1) / 2, z);
  for (const y of [.5, .67]) {
    batch.box(M.wood, s.hx * 1.7, .13, .035, s.x, y, s.z + s.hz + .02);
    batch.box(M.iron, .18, .025, .035, s.x, y, s.z + s.hz + .05);
  }
}

function footlocker(batch, s) {
  const M = materials();
  batch.box(M.iron, s.hx * 2, s.h - .06, s.hz * 2, s.x, (s.h - .06) / 2, s.z);
  batch.box(M.iron, s.hx * 2 + .015, .07, s.hz * 2 + .015, s.x, s.h - .035, s.z);
  for (const x of [s.x - s.hx + .04, s.x + s.hx - .04]) batch.box(M.iron, .04, s.h, s.hz * 2 + .025, x, s.h / 2, s.z);
  batch.box(M.iron, .12, .09, .025, s.x, s.h - .1, s.z + s.hz + .025);
}

function table(batch, s) {
  const M = materials();
  batch.box(M.wood, 1.0, .11, s.hz * 2, s.x, s.h - .055, s.z);
  for (const side of [-1, 1]) {
    batch.box(M.darkWood, .38, .1, s.hz * 2, s.x + side * .64, .43, s.z);
    for (const z of [s.z - s.hz + .3, s.z + s.hz - .3]) {
      batch.beam(M.darkWood, [s.x + side * .65, .05, z], [s.x + side * .37, s.h - .1, z], .1);
      batch.box(M.darkWood, .1, .42, .1, s.x + side * .65, .22, z);
    }
  }
  for (const z of [s.z - s.hz + .3, s.z + s.hz - .3]) batch.box(M.darkWood, .11, s.h - .1, .11, s.x, (s.h - .1) / 2, z);
}

function bench(batch, s) {
  const M = materials();
  batch.box(M.wood, s.hx * 2, .12, s.hz * 2, s.x, s.h - .06, s.z);
  batch.box(M.darkWood, s.hx * 2 - .1, .32, s.hz * 1.6, s.x, s.h - .28, s.z);
  for (const x of [s.x - s.hx + .12, s.x + s.hx - .12]) for (const z of [s.z - s.hz + .1, s.z + s.hz - .1]) batch.box(M.darkWood, .12, s.h - .12, .12, x, (s.h - .12) / 2, z);
}

function stove(batch, s) {
  const M = materials();
  batch.box(M.iron, s.hx * 2, s.h, s.hz * 2, s.x, s.h / 2, s.z);
  batch.box(M.iron, s.hx * 1.35, .46, .025, s.x, .43, s.z + s.hz + .015);
  batch.box(M.metal, s.hx * 2 + .12, .07, s.hz * 2 + .1, s.x, s.h + .02, s.z);
  for (const x of [s.x - .36, s.x + .36]) for (const z of [s.z - .5, s.z + .5]) batch.cylinder(M.iron, .19, .19, .025, 10, x, s.h + .07, z);
  batch.cylinder(M.iron, .1, .1, 2.6, 8, s.x + .45, s.h + 1.3, s.z - .55);
}

function cabin(batch, group, t, b) {
  const M = materials();
  for (const s of t.solids) {
    if (s.kind === 'bunk') bunk(batch, s);
    else if (s.kind === 'closet') absorb(batch, closet(batch, s, 'x'));
    else if (s.kind === 'desk') desk(batch, s);
    else if (s.kind === 'footlocker') footlocker(batch, s);
  }
  batch.cylinder(M.iron, .012, .012, .52, 5, 0, t.wallH - .28, 0);
  batch.sphere(M.mattress, .085, 0, t.wallH - .58, 0, .8, 1.2, .8, 1);
  batch.cylinder(M.iron, .12, .07, .09, 8, 0, t.wallH - .5, 0);
  const posterMat = textMaterial(posterTexture(Number(b.name?.match(/\d+/)?.[0] || 1) % 2));
  const poster = mesh(new THREE.PlaneGeometry(.65, .88), posterMat, -3.095, 1.55, .75);
  poster.rotation.y = Math.PI / 2; poster.rotation.z = -.045; group.add(poster);
  const number = b.name?.match(/\d+/)?.[0] || '1';
  const sign = mesh(new THREE.PlaneGeometry(.32, .32), textMaterial(signTexture([number], { paper: true, fontSize: 70 })), .83, 1.67, t.hz + .095);
  group.add(sign);
}

function messhall(batch, group, t) {
  const M = materials();
  for (const s of t.solids) {
    if (s.kind === 'table') table(batch, s);
    else if (s.kind === 'counter') {
      batch.box(M.darkWood, s.hx * 2, s.h, s.hz * 2, s.x, s.h / 2, s.z);
      batch.box(M.metal, s.hx * 2 + .08, .08, s.hz * 2 + .06, s.x, s.h, s.z);
      for (let z = -3.8; z < 4; z += .8) batch.box(M.iron, .025, .13, .35, s.x - s.hx - .025, .68, z);
    } else if (s.kind === 'stove') stove(batch, s);
    else if (s.kind === 'closet') absorb(batch, closet(batch, s, '-z'));
    else if (s.kind === 'crate') {
      batch.box(M.wood, s.hx * 2, s.h, s.hz * 2, s.x, s.h / 2, s.z);
      for (const y of [.15, .72]) batch.box(M.darkWood, s.hx * 2 + .03, .09, s.hz * 2 + .03, s.x, y, s.z);
    }
  }
  batch.beam(M.iron, [4.1, 2.45, .4], [7.8, 2.45, .4], .045);
  for (let i = 0; i < 6; i++) {
    const x = 4.3 + i * .6;
    batch.cylinder(M.iron, .18, .13, .19, 8, x, 2.12, .4);
    batch.cylinder(M.iron, .012, .012, .25, 5, x, 2.32, .4);
  }
  const signMap = signTexture(['MESS HALL'], { fontSize: 39 });
  const signMat = textMaterial(signMap);
  signMat.emissive.set(0xffc890);
  signMat.emissiveMap = signMap;
  signMat.emissiveIntensity = 0.16;
  const sign = mesh(new THREE.PlaneGeometry(3.6, .68), signMat, -2.7, 2.72, t.hz + .18);
  group.add(sign);
  batch.cylinder(M.iron, .13, .13, 2.1, 8, 6.0, 4.7, 1.7);
  batch.cylinder(M.iron, .22, .16, .16, 8, 6.0, 5.78, 1.7);
}

function canoe(batch, M, s, upturned = true, y = .38) {
  const geo = new THREE.SphereGeometry(1, 12, 6);
  batch.add(upturned ? M.green : M.red, geo, s.x, upturned ? .22 : y, s.z, 0, 0, 0, s.hx, upturned ? .28 : .22, s.hz);
  batch.box(M.darkWood, .055, .08, s.hz * 1.55, s.x - s.hx * .65, upturned ? .35 : y + .12, s.z);
  batch.box(M.darkWood, .055, .08, s.hz * 1.55, s.x + s.hx * .65, upturned ? .35 : y + .12, s.z);
}

function boathouse(batch, group, t) {
  const M = materials();
  for (const s of t.solids) {
    if (s.kind === 'canoeRack') {
      for (const z of [s.z - s.hz + .15, s.z + s.hz - .15]) batch.box(M.darkWood, .15, s.h, .15, s.x, s.h / 2, z);
      for (const y of [.48, 1.13, 1.78]) {
        batch.box(M.darkWood, s.hx * 2, .09, s.hz * 2, s.x, y - .18, s.z);
        canoe(batch, M, { ...s, hx: .42, hz: s.hz * .88 }, false, y);
      }
    } else if (s.kind === 'canoe') canoe(batch, M, s);
    else if (s.kind === 'bench') bench(batch, s);
    else if (s.kind === 'motorStand') {
      batch.box(M.darkWood, .13, 1, .13, s.x, .5, s.z);
      batch.box(M.darkWood, s.hx * 2, .12, s.hz * 2, s.x, .88, s.z);
      batch.box(M.iron, .52, .48, .42, s.x, 1.12, s.z);
      batch.cylinder(M.iron, .055, .055, .75, 7, s.x, .62, s.z - .25, .18);
      batch.box(M.black, .36, .08, .12, s.x, .26, s.z - .36);
    }
  }
  for (let i = 0; i < 4; i++) {
    const z = -3.8 + i * .48;
    batch.box(M.orange, .16, .55, .38, 3.48, 1.55, z);
    batch.box(M.black, .17, .16, .16, 3.38, 1.63, z);
  }
  for (const z of [3.8, 4.25]) {
    batch.beam(M.wood, [2.8, .1, z], [3.15, 1.8, z + .2], .045);
    batch.box(M.wood, .18, .55, .045, 2.77, .22, z, 0, -.2);
  }
}

function shed(batch, group, t) {
  const M = materials();
  for (const s of t.solids) {
    if (s.kind === 'bench') bench(batch, s);
    else if (s.kind === 'locker') absorb(batch, closet(batch, s, 'x', true));
    else if (s.kind === 'generator') {
      batch.box(M.green, s.hx * 2, .7, s.hz * 2, s.x, .55, s.z);
      batch.box(M.iron, s.hx * 2 + .1, .12, s.hz * 2 + .1, s.x, .12, s.z);
      batch.cylinder(M.iron, .23, .23, .65, 10, s.x, .73, s.z, 0, 0, Math.PI / 2);
      for (let x = s.x - .4; x < s.x + .4; x += .12) batch.box(M.black, .055, .32, .025, x, .55, s.z + s.hz + .015);
      batch.cylinder(M.iron, .055, .055, .65, 7, s.x + .35, 1.22, s.z - .3);
    }
  }
  for (let i = 0; i < 7; i++) {
    const x = -1.8 + i * .55;
    batch.beam(M.iron, [x, 1.25, -2.48], [x + .08, 1.85 + (i % 2) * .15, -2.48], .045);
    if (i % 2) batch.box(M.iron, .28, .07, .045, x + .08, 1.88, -2.48, 0, .2);
    else batch.cylinder(M.iron, .13, .13, .04, 8, x, 1.85, -2.48, Math.PI / 2);
  }
  for (const [x,z,sx,sz] of [[1.6,.5,.8,.45],[-.5,-1.4,1.2,.25],[2.3,1.8,.5,.5]]) {
    batch.add(M.black, new THREE.CircleGeometry(.5, 12), x, .009, z, -Math.PI / 2, 0, 0, sx, sz, 1);
  }
}

function shack(batch, group, t) {
  const M = materials();
  for (const name of ['front','back','left','right']) {
    const w = WALLS[name](t);
    for (let u = w.lo + .12; u < w.hi; u += .23) {
      if (name === 'front' && Math.abs(u) < .57) continue;
      const h = 2.08 + Math.sin(u * 17) * .09;
      wallBox(batch, M.darkWood, w, u, h / 2, .18, h, .12, Math.sin(u * 9) * .025);
    }
    wallBox(batch, M.wood, w, 0, .23, w.hi - w.lo, .1, .15, .03);
    wallBox(batch, M.wood, w, 0, 1.92, w.hi - w.lo, .1, .15, .03);
  }
  for (const s of t.solids) if (s.kind === 'bench') bench(batch, s);
  const rng = makeRng(31);
  for (let i = 0; i < 12; i++) {
    const x = -2.1 + (i % 4) * 1.35 + (rng() - .5) * .25;
    const z = -1.25 + Math.floor(i / 4) * 1.25 + (rng() - .5) * .3;
    const y = 1.25 + rng() * .45;
    batch.cylinder(M.darkWood, .012, .012, t.wallH - y + .35, 4, x, (t.wallH + y) / 2, z);
    const ry = (rng() - .5) * 1.4, rz = (rng() - .5) * .16;
    batch.add(M.cloth, new THREE.SphereGeometry(.27, 8, 6), x, y, z, 0, ry, rz, .85, 1.35, .62);
    batch.add(M.sack, new THREE.CircleGeometry(.27, 8), x + Math.sin(ry) * .17, y, z + Math.cos(ry) * .17, 0, ry, rz, .85, 1.35, 1);
    batch.add(M.sack, new THREE.CircleGeometry(.27, 8), x - Math.sin(ry) * .17, y, z - Math.cos(ry) * .17, 0, ry + Math.PI, -rz, .85, 1.35, 1);
    batch.cylinder(M.cloth, .07, .12, .16, 6, x, y + .38, z);
  }
  for (const x of [-2.3, 0, 2.3]) batch.beam(M.darkWood, [x, 2.12, -2.6], [x, 2.12, 2.6], .12);
}

function outhouse(batch, group, t) {
  const M = materials();
  const shape = new THREE.Shape();
  shape.moveTo(-.58, .03); shape.lineTo(.58, .03); shape.lineTo(.58, 2.02); shape.lineTo(-.58, 2.02); shape.closePath();
  const moon = new THREE.Path();
  moon.absarc(0, 1.57, .15, -Math.PI / 2, Math.PI / 2, false);
  moon.absarc(.075, 1.57, .135, Math.PI / 2, -Math.PI / 2, true);
  moon.closePath(); shape.holes.push(moon);
  const door = new THREE.ExtrudeGeometry(shape, { depth: .065, bevelEnabled: false, curveSegments: 8 });
  batch.add(M.darkWood, door, 0, 0, t.hz + .045);
  for (const y of [.42, 1.82]) batch.box(M.iron, .28, .055, .025, -.4, y, t.hz + .12);
  batch.sphere(M.iron, .035, .42, 1.0, t.hz + .13);
  batch.box(M.darkWood, .7, .12, .65, 0, .48, -.12);
  batch.cylinder(M.black, .18, .18, .02, 12, 0, .55, -.12);
}

export function buildBuilding(b, t) {
  const M = materials(), group = new THREE.Group(); group.name = b.name || b.template;
  const batch = new Batch(), glassBatch = new Batch();
  buildFloor(batch, t, b.template === 'boathouse');
  if (b.template !== 'shack') buildShell(batch, glassBatch, t, b.template);
  buildRoof(batch, t, b.template);
  buildPorch(batch, t);
  if (b.template === 'cabin') cabin(batch, group, t, b);
  else if (b.template === 'messhall') messhall(batch, group, t);
  else if (b.template === 'boathouse') boathouse(batch, group, t);
  else if (b.template === 'shed') shed(batch, group, t);
  else if (b.template === 'shack') shack(batch, group, t);
  else if (b.template === 'outhouse') outhouse(batch, group, t);
  group.add(batch.finish('merged structure'));
  const glassMat = lit({ color: 0x6e858a, emissive: 0x000000, transparent: true, opacity: .3, depthWrite: false, side: THREE.DoubleSide, forceSinglePass: true });
  const windows = glassBatch.finish('windows');
  // Thin transparent panes should not cast the opaque shadows used for wood and furniture.
  windows.traverse((o) => { if (o.isMesh) { o.material = glassMat; o.castShadow = false; } });
  group.add(windows);
  group.userData.windows = windows.children.filter((o) => o.isMesh);
  group.userData.doors = (t.doors || []).map((d) => {
    const door = buildDoor(t, d, b.template); group.add(door.pivot); return door;
  });
  return group;
}
