import * as THREE from 'three';
import { Batch, materials } from './helpers.js';

export function buildSearchMarker(spot) {
  const M = materials(), b = new Batch();
  const id = spot.id || '';
  if (id.includes('locker')) {
    b.box(M.green, .52, .36, .84, 0, .18, 0);
    b.box(M.iron, .54, .07, .86, 0, .385, 0);
    for (const x of [-.22,.22]) b.box(M.iron, .035, .39, .86, x, .2, 0);
    b.box(M.iron, .11, .08, .025, 0, .3, .435);
  } else if (id.includes('duffel')) {
    b.sphere(M.green, .35, 0, .24, 0, .75, .65, 1.25, 1);
    b.beam(M.darkWood, [-.18,.43,-.18], [-.18,.56,.15], .035);
    b.beam(M.darkWood, [.18,.43,-.18], [.18,.56,.15], .035);
    b.beam(M.darkWood, [-.18,.56,.15], [.18,.56,.15], .035);
    b.box(M.iron, .04, .04, .65, 0, .43, 0);
  } else if (id.includes('desk') || id.includes('kitchen')) {
    const w = id.includes('kitchen') ? .72 : .78;
    b.box(M.wood, w, .32, .48, 0, .64, 0);
    for (const y of [.56,.74]) {
      b.box(M.darkWood, w - .06, .14, .035, 0, y, .255);
      b.box(M.iron, .18, .025, .035, 0, y, .285);
    }
  } else if (id.includes('lost')) {
    b.box(M.wood, .85, .12, .62, 0, .84, 0);
    for (const x of [-.39,.39]) b.box(M.darkWood, .07, .35, .62, x, 1.0, 0);
    for (const z of [-.28,.28]) b.box(M.darkWood, .75, .35, .06, 0, 1.0, z);
    b.box(M.blue, .35, .13, .38, -.15, .96, 0, .15);
    b.box(M.red, .27, .18, .32, .18, .98, -.06, -.2);
  } else if (id.includes('tackle') || id.includes('toolbox')) {
    const mat = id.includes('tackle') ? M.green : M.red;
    b.box(mat, .58, .25, .34, 0, .93, 0);
    b.box(M.iron, .6, .045, .36, 0, 1.07, 0);
    b.beam(M.iron, [-.15,1.1,0], [-.15,1.22,0], .025);
    b.beam(M.iron, [.15,1.1,0], [.15,1.22,0], .025);
    b.beam(M.iron, [-.15,1.22,0], [.15,1.22,0], .025);
    b.box(M.iron, .07, .07, .025, 0, .98, .185);
  } else if (id.includes('motor')) {
    b.box(M.iron, .52, .44, .4, 0, 1.18, 0);
    b.box(M.black, .42, .06, .32, 0, 1.43, 0);
    b.cylinder(M.iron, .05, .05, .72, 7, 0, .67, -.12, .16);
    b.box(M.black, .34, .07, .1, 0, .29, -.22);
    b.beam(M.iron, [.15,1.25,.1], [.45,1.22,.38], .04);
  } else if (id.includes('bench')) {
    b.box(M.red, .42, .2, .3, -.3, .99, 0);
    b.box(M.iron, .44, .035, .32, -.3, 1.1, 0);
    b.cylinder(M.metal, .09, .09, .28, 8, .22, 1.04, .04);
    b.beam(M.iron, [.05,.92,-.15], [.45,1.0,.12], .035);
    b.box(M.wood, .32, .035, .22, .4, .92, -.12, .25);
  } else if (id.includes('range')) {
    b.box(M.green, .8, .5, .55, 0, .25, 0);
    b.box(M.iron, .82, .055, .57, 0, .52, 0);
    for (const x of [-.32,.32]) b.box(M.iron, .04, .52, .58, x, .27, 0);
    b.box(M.iron, .13, .09, .025, 0, .39, .29);
  } else if (id.includes('cooler')) {
    b.box(M.blue, .72, .38, .45, 0, .19, 0);
    b.box(M.cream, .75, .09, .48, 0, .425, 0);
    for (const x of [-.37,.37]) b.box(M.iron, .025, .18, .2, x, .28, 0);
    b.box(M.cream, .18, .055, .025, 0, .29, .238);
  } else {
    b.box(M.wood, .45, .25, .35, 0, .125, 0);
    b.box(M.iron, .12, .04, .025, 0, .18, .19);
  }
  const group = b.finish(spot.label || 'search marker');
  group.userData.searchId = spot.id;
  return group;
}
