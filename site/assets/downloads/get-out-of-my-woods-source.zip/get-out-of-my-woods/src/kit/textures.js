import * as THREE from 'three';
import { canvasTexture, speckle } from '../render/textures.js';
import { makeRng } from '../core/rng.js';

const cache = new Map();

function texture(key, draw, size = 128, opts = {}) {
  if (!cache.has(key)) cache.set(key, canvasTexture(size, draw, opts));
  return cache.get(key);
}

// Weathered boards use broad sun/rain wear and finer grain. The texture stays
// procedural and cached; geometry, search surfaces and collision are unchanged.
function weatheredBoards(ctx, n, floor) {
  const rng = makeRng(floor ? 193 : 841), board = n / 8;
  ctx.fillStyle = floor ? '#554735' : '#70614a'; ctx.fillRect(0, 0, n, n);
  ctx.save();
  if (floor) { ctx.translate(n, 0); ctx.rotate(Math.PI / 2); }
  for (let x = 0; x < n; x += board) {
    const shade = 86 + Math.floor(rng() * 27);
    const wash = ctx.createLinearGradient(x, 0, x + board, 0);
    wash.addColorStop(0, `rgb(${shade - 17},${shade - 24},${shade - 35})`);
    wash.addColorStop(.16, `rgb(${shade + 17},${shade + 5},${shade - 13})`);
    wash.addColorStop(.75, `rgb(${shade + 8},${shade},${shade - 17})`);
    wash.addColorStop(1, `rgb(${shade - 7},${shade - 14},${shade - 25})`);
    ctx.fillStyle = wash; ctx.fillRect(x + 1, 0, board - 2, n);
    ctx.fillStyle = '#302d25'; ctx.fillRect(x, 0, 1.2, n);
    ctx.fillStyle = 'rgba(207,196,161,.14)'; ctx.fillRect(x + 1.4, 0, .7, n);
    for (let i = 0; i < 85; i++) {
      const u = x + 2 + rng() * (board - 4), y = rng() * n;
      ctx.strokeStyle = i % 3 ? 'rgba(29,26,19,.17)' : 'rgba(201,191,154,.2)';
      ctx.lineWidth = .35 + rng() * .75;
      ctx.beginPath(); ctx.moveTo(u, y); ctx.bezierCurveTo(u - 1.4, y + 7, u + 1.7, y + 13, u + rng() - .5, y + 8 + rng() * 38); ctx.stroke();
    }
    const knotX = x + board * (.35 + rng() * .3), knotY = 25 + rng() * (n - 50);
    for (let k = 3; k > 0; k--) {
      ctx.strokeStyle = `rgba(39,32,23,${.14 + (3-k)*.05})`; ctx.lineWidth = .8;
      ctx.beginPath(); ctx.ellipse(knotX, knotY, k * 1.1, k * 4.2, -.1, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.fillStyle = 'rgba(34,31,25,.6)';
    for (const y of [10, n - 11]) { ctx.beginPath(); ctx.arc(x + board*.23, y, .85, 0, Math.PI*2); ctx.fill(); }
    if (floor) {
      const joint = (x * 5 + 49) % n;
      ctx.fillStyle = '#312e25'; ctx.fillRect(x, joint, board, 1);
      ctx.fillStyle = 'rgba(193,181,143,.1)'; ctx.fillRect(x + 3, 30, board - 6, n - 60);
    } else {
      const damp = ctx.createLinearGradient(0, n * .63, 0, n);
      damp.addColorStop(0, 'rgba(31,43,31,0)'); damp.addColorStop(1, 'rgba(31,43,31,.34)');
      ctx.fillStyle = damp; ctx.fillRect(x + 1, n*.63, board - 2, n*.37);
    }
  }
  ctx.restore();
  speckle(ctx, n, rng, ['rgba(37,35,28,.12)', 'rgba(200,190,162,.1)'], 1800, .4, 1.2);
}

export function woodTexture() {
  return texture('wood', (ctx, n) => weatheredBoards(ctx, n, false), 256, { nearest: false });
}

export function floorTexture() {
  return texture('floor', (ctx, n) => weatheredBoards(ctx, n, true), 256, { nearest: false });
}

export function shingleTexture() {
  return texture('shingle', (ctx, n) => {
    const rng = makeRng(772);
    ctx.fillStyle = '#282a29'; ctx.fillRect(0, 0, n, n);
    for (let y = 0; y < n; y += 16) {
      const off = (y / 16) % 2 ? 8 : 0;
      for (let x = -off; x < n; x += 16) {
        const v = 38 + Math.floor(rng() * 18);
        ctx.fillStyle = `rgb(${v},${v + 2},${v + 1})`;
        ctx.fillRect(x + 1, y + 1, 14, 14);
        ctx.fillStyle = '#171b1b'; ctx.fillRect(x, y + 14, 16, 2);
        if (rng() > 0.65) { ctx.fillStyle = '#51534b'; ctx.fillRect(x + 3, y + 4, 4, 2); }
      }
    }
  });
}

export function rustTexture() {
  return texture('rust', (ctx, n) => {
    const rng = makeRng(518);
    ctx.fillStyle = '#4d5150'; ctx.fillRect(0, 0, n, n);
    speckle(ctx, n, rng, ['#643b26', '#7b4628', '#342f2a', '#8a5937', '#383d3c'], 850, 1, 5);
    for (let i = 0; i < 20; i++) {
      ctx.fillStyle = '#3b2b23'; ctx.fillRect(rng() * n, rng() * n, 1, 8 + rng() * 30);
    }
  });
}

export function tickingTexture() {
  return texture('ticking', (ctx, n) => {
    const rng = makeRng(87);
    ctx.fillStyle = '#aaa28b'; ctx.fillRect(0, 0, n, n);
    for (let x = 0; x < n; x += 12) {
      ctx.fillStyle = '#696e68'; ctx.fillRect(x, 0, 2, n);
      ctx.fillStyle = '#85867a'; ctx.fillRect(x + 4, 0, 1, n);
    }
    speckle(ctx, n, rng, ['#756c58', '#8c8067', '#b5ac92'], 260, 1, 3);
    ctx.fillStyle = 'rgba(73,56,39,.35)';
    ctx.beginPath(); ctx.ellipse(87, 61, 22, 15, .4, 0, Math.PI * 2); ctx.fill();
  });
}

export function burlapTexture(eyes = false) {
  return texture(eyes ? 'sack-eyes' : 'burlap', (ctx, n) => {
    const rng = makeRng(eyes ? 666 : 665);
    ctx.fillStyle = '#897453'; ctx.fillRect(0, 0, n, n);
    for (let i = 0; i < n; i += 3) {
      ctx.fillStyle = i % 6 ? '#796648' : '#9b825d';
      ctx.fillRect(i, 0, 1, n); ctx.fillRect(0, i, n, 1);
    }
    speckle(ctx, n, rng, ['#564a37', '#ac9268'], 300, 1, 2);
    if (eyes) {
      ctx.fillStyle = '#100f0d';
      for (const x of [39, 87]) {
        ctx.beginPath();
        ctx.moveTo(x - 10, 46); ctx.lineTo(x - 5, 39); ctx.lineTo(x + 7, 41);
        ctx.lineTo(x + 11, 49); ctx.lineTo(x + 3, 55); ctx.lineTo(x - 8, 53); ctx.closePath(); ctx.fill();
      }
    }
  });
}

export function signTexture(lines, options = {}) {
  const key = `sign:${lines.join('|')}:${options.paper ? 'paper' : 'wood'}:${options.fontSize || 0}`;
  return texture(key, (ctx, n) => {
    ctx.fillStyle = options.paper ? '#c4b894' : '#385047'; ctx.fillRect(0, 0, n, n);
    ctx.strokeStyle = options.paper ? '#665d49' : '#d7cfaa'; ctx.lineWidth = 3; ctx.strokeRect(4, 4, n - 8, n - 8);
    ctx.fillStyle = options.paper ? '#38372e' : '#ded6b4';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    // Boards are wide and shallow in the world: use the canvas height instead of tiny glyphs.
    const size = lines.length > 2 ? 54 : lines.length > 1 ? 68 : 128;
    ctx.font = `700 ${size}px 'Oswald', sans-serif`;
    lines.forEach((line, i) => ctx.fillText(line, n / 2, n / 2 + (i - (lines.length - 1) / 2) * (size + 5), n - 14));
    const rng = makeRng(lines.join('').length * 19);
    speckle(ctx, n, rng, options.paper ? ['#8d8063'] : ['#243b34', '#7e8067'], 80, 1, 2);
  }, 256);
}

export function mapTexture() {
  return texture('camp-map', (ctx, n) => {
    ctx.fillStyle = '#c8bd98'; ctx.fillRect(0, 0, n, n);
    ctx.strokeStyle = '#6d775c'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.ellipse(48, 179, 35, 49, -.4, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = '#75634b'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(245, 145); ctx.lineTo(173, 143); ctx.lineTo(115, 128); ctx.lineTo(71, 115); ctx.stroke();
    ctx.lineWidth = 2;
    for (const pts of [[[115,128],[92,80],[105,42]], [[115,128],[153,91],[182,52]], [[115,128],[67,156],[50,182]], [[173,143],[190,196]]]) {
      ctx.beginPath(); ctx.moveTo(...pts[0]); pts.slice(1).forEach((p) => ctx.lineTo(...p)); ctx.stroke();
    }
    ctx.fillStyle = '#475747';
    for (const [x,z] of [[91,74],[101,91],[117,78],[104,37],[178,47],[187,193],[49,181]]) ctx.fillRect(x - 4, z - 4, 8, 8);
    ctx.fillStyle = '#3c3a30'; ctx.textAlign = 'center'; ctx.font = 'bold 17px serif';
    ctx.fillText('CAMP STILLWATER', 128, 22);
    ctx.font = '11px serif'; ctx.fillText('COUNSELOR TRAIL MAP', 128, 39);
    ctx.font = 'bold 12px serif'; ctx.fillText('YOU ARE HERE', 123, 151);
    ctx.strokeStyle = '#4b4537'; ctx.strokeRect(5, 5, 246, 246);
    const rng = makeRng(12); speckle(ctx, n, rng, ['#958766', '#ded2aa'], 200, 1, 3);
  }, 256);
}

export function posterTexture(kind = 0) {
  return texture(`poster${kind}`, (ctx, n) => {
    ctx.fillStyle = kind ? '#a89b76' : '#854d3d'; ctx.fillRect(0, 0, n, n);
    ctx.fillStyle = kind ? '#43594f' : '#d0bd8d';
    ctx.beginPath(); ctx.arc(64, 48, 28, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#242d2c';
    ctx.beginPath(); ctx.moveTo(12, 110); ctx.lineTo(50, 53); ctx.lineTo(78, 110); ctx.lineTo(98, 70); ctx.lineTo(122, 110); ctx.fill();
    ctx.fillStyle = '#d5c9a2'; ctx.textAlign = 'center'; ctx.font = 'bold 13px sans-serif';
    ctx.fillText(kind ? 'STILLWATER' : 'SUMMER', 64, 16); ctx.fillText(kind ? 'ARCHERY CLUB' : 'OF 1984', 64, 124);
  });
}

export function makePaintTexture() {
  const canvas = document.createElement('canvas'); canvas.width = 1024; canvas.height = 256;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, 1024, 256);
  ctx.fillStyle = '#a31112'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.font = "74px 'Rock Salt', cursive";
  ctx.save(); ctx.translate(512, 80); ctx.rotate(-.035); ctx.fillText('GET OUT OF', 0, 0, 960); ctx.restore();
  ctx.save(); ctx.translate(512, 174); ctx.rotate(.025); ctx.fillText('MY WOODS', 0, 0, 930); ctx.restore();
  const rng = makeRng(1313);
  for (let i = 0; i < 42; i++) {
    const x = 50 + rng() * 924, y = 85 + rng() * 120;
    ctx.fillRect(x, y, 2 + rng() * 4, 8 + rng() * 48);
    ctx.beginPath(); ctx.arc(x + 2, y + 30, 2 + rng() * 3, 0, Math.PI * 2); ctx.fill();
  }
  const tex = new THREE.CanvasTexture(canvas); tex.colorSpace = THREE.SRGBColorSpace;
  tex.magFilter = THREE.NearestFilter; tex.minFilter = THREE.LinearMipmapLinearFilter;
  return tex;
}

export async function prepareKit() {
  if (typeof document !== 'undefined' && document.fonts) {
    await document.fonts.load("40px 'Rock Salt'");
  }
}
