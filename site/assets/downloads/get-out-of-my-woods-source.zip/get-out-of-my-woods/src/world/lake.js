// The lake: a near-black mirror with a moon glitter path, slow ripples, fresnel toward the fog,
// a dark reflected tree line found by marching the reflection ray over a baked canopy map,
// and a lapping edge at the shore. Plus the plank dock.
import * as THREE from 'three';
import { makeRng } from '../core/rng.js';
import { lit } from '../render/materials.js';
import { DECKS, WATER_LEVEL } from '../sim/layout.js';
import { GRID_HALF, heightAt } from '../sim/terrain.js';
import { GLOBALS } from '../render/materials.js';
import { GeoBuilder, hexLin, mulc } from './common.js';
import { SKY_GLSL } from './sky.js';
import { treeShape } from './ground.js';

const MAP_N = 512;
const MAP_LO = -6, MAP_RANGE = 46; // occluder height encoding: y = g * 46 - 6

// RGBA: r = water depth over the ground here (-0.6..3.4 m), g = top of the highest thing (tree or hill).
function buildMap(forest) {
  const data = new Uint8Array(MAP_N * MAP_N * 4);
  const cell = (GRID_HALF * 2) / MAP_N;
  const enc = (y) => Math.max(0, Math.min(255, Math.round(((y - MAP_LO) / MAP_RANGE) * 255)));
  for (let j = 0; j < MAP_N; j++) {
    for (let i = 0; i < MAP_N; i++) {
      const x = -GRID_HALF + (i + 0.5) * cell, z = -GRID_HALF + (j + 0.5) * cell;
      const h = heightAt(x, z);
      const k = (j * MAP_N + i) * 4;
      data[k] = Math.max(0, Math.min(255, Math.round(((WATER_LEVEL - h + 0.6) / 4) * 255)));
      data[k + 1] = enc(h);
      data[k + 3] = 255;
    }
  }
  // Trees as cones: the reflection of a pine is a pine.
  for (const t of forest.trees) {
    const sh = treeShape[t.kind];
    const H = sh.H * t.scale, R = Math.max(sh.R * t.scale, cell * 0.8), h0 = sh.h0 * t.scale;
    const ci = (t.x + GRID_HALF) / cell, cj = (t.z + GRID_HALF) / cell;
    const rr = Math.ceil(R / cell);
    for (let dj = -rr; dj <= rr; dj++) {
      for (let di = -rr; di <= rr; di++) {
        const i = Math.floor(ci) + di, j = Math.floor(cj) + dj;
        if (i < 0 || j < 0 || i >= MAP_N || j >= MAP_N) continue;
        const d = Math.hypot(i + 0.5 - ci, j + 0.5 - cj) * cell;
        if (d > R) continue;
        const top = t.y + h0 + (H - h0) * (1 - d / R) * (t.kind === 'birch' ? 0.5 : 1) + (t.kind === 'birch' ? 0 : 0);
        const k = (j * MAP_N + i) * 4 + 1;
        const v = enc(top);
        if (v > data[k]) data[k] = v;
      }
    }
  }
  const tex = new THREE.DataTexture(data, MAP_N, MAP_N, THREE.RGBAFormat, THREE.UnsignedByteType);
  tex.minFilter = THREE.LinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.generateMipmaps = false;
  tex.needsUpdate = true;
  return tex;
}

const VERT = /* glsl */ `
varying vec3 vW;
void main() {
  vec4 w = modelMatrix * vec4(position, 1.0);
  vW = w.xyz;
  gl_Position = projectionMatrix * viewMatrix * w;
}`;

const FRAG = /* glsl */ `
${SKY_GLSL}
uniform sampler2D uMap;
uniform float uFogDensity;
uniform float uWL;
varying vec3 vW;

float occluderAt(vec2 p) {
  vec2 uv = (p + ${GRID_HALF.toFixed(1)}) / ${(GRID_HALF * 2).toFixed(1)};
  if (uv.x < 0.0 || uv.y < 0.0 || uv.x > 1.0 || uv.y > 1.0) return -6.0;
  return texture2D(uMap, uv).g * ${MAP_RANGE.toFixed(1)} + (${MAP_LO.toFixed(1)});
}

float fogAmount(float d) {
  d = max(0.0, d - 5.0);
  float f = 1.0 - exp(-d * d * uFogDensity * uFogDensity);
  return 1.0 - (1.0 - f) * exp(-d * 0.012);
}

void main() {
  vec3 toP = vW - cameraPosition;
  float dist = length(toP);
  vec3 V = toP / dist;
  vec2 p = vW.xz;
  float t = uTime;

  // Ripples: slow big swell, small cat's-paws. Flatter with distance so far water stays calm.
  vec2 a = vec2(sNoise(p * 0.55 + vec2(t * 0.10, t * 0.06)), sNoise(p * 0.55 + vec2(-t * 0.07, t * 0.09) + 17.0)) - 0.5;
  vec2 b = vec2(sNoise(p * 1.7 + vec2(t * 0.22, -t * 0.12)), sNoise(p * 1.7 + vec2(-t * 0.18, -t * 0.2) + 9.0)) - 0.5;
  vec2 c = vec2(sNoise(p * 5.3 + vec2(t * 0.55, t * 0.3)), sNoise(p * 5.3 + vec2(-t * 0.4, t * 0.5) + 4.0)) - 0.5;
  float calm = 1.0 / (1.0 + dist * 0.028);
  float chop = 1.0 + uStorm * 1.8;
  vec2 slope = (a * 0.16 + b * 0.12 + c * 0.1 * calm) * calm * chop;
  vec3 N = normalize(vec3(slope.x, 1.0, slope.y));

  float cosT = max(dot(-V, N), 0.0);
  float F = 0.035 + 0.965 * pow(1.0 - cosT, 5.0);
  vec3 R = reflect(V, N);
  R.y = abs(R.y) + 0.002;
  R = normalize(R);

  // Reflected tree line: march the reflection ray over the canopy height map.
  vec2 hd = normalize(R.xz + 1e-5);
  float tanE = R.y / max(length(R.xz), 1e-4);
  float jit = sHash(floor(p * 2.0));
  float occ = 0.0;
  float occT = 100.0;
  for (int i = 0; i < 15; i++) {
    float s = 1.4 * pow(1.38, float(i) + jit * 0.8);
    float ry = uWL + tanE * s;
    float o = occluderAt(p + hd * s) - ry;
    float hit = smoothstep(-0.15, 0.9, o);
    if (hit > occ) { occ = hit; occT = s; }
  }

  vec3 sky = skyColor(R, true);
  float fogR = fogAmount(dist + occT);
  vec3 treeCol = vec3(0.006, 0.011, 0.013);
  vec3 refl = mix(sky, mix(treeCol, horizonColor(R), fogR), occ);

  // Moon glitter: a lowered stand-in moon so the path reaches the near water, broken by ripples.
  vec3 M = normalize(vec3(MOON_DIR.x, 0.2, MOON_DIR.z));
  float sp = max(dot(R, M), 0.0);
  float glit = pow(sp, 260.0) * 5.0 + pow(sp, 36.0) * 0.28 + pow(sp, 9.0) * 0.05;
  float spark = 0.45 + 0.8 * step(0.5, sNoise(p * 9.0 + t * vec2(0.9, 0.5)));
  glit *= spark * (1.0 - occ) * (1.0 - uStorm * 0.92);
  vec3 moonCol = vec3(0.78, 0.88, 1.0);

  vec3 body = vec3(0.004, 0.009, 0.013);
  vec3 col = mix(body, refl, F) + moonCol * glit * (0.35 + 0.65 * F);
  col += vec3(0.5, 0.58, 0.7) * uFlash * (0.25 + F);

  // Shore: shallow water goes see-through, with a lapping line of foam.
  float depth = texture2D(uMap, (p + ${GRID_HALF.toFixed(1)}) / ${(GRID_HALF * 2).toFixed(1)}).r * 4.0 - 0.6;
  float lap = 0.10 + 0.09 * sin(t * 0.8 + sNoise(p * 0.8) * 6.0);
  float foam = (1.0 - smoothstep(lap, lap + 0.1, depth)) * smoothstep(-0.12, 0.03, depth);
  foam *= 0.45 + 0.55 * sNoise(p * 3.5 + vec2(t * 0.25, -t * 0.2));
  vec3 foamCol = uFogCol * 1.35 + vec3(0.03, 0.04, 0.05);
  col = mix(col, foamCol, foam * 0.75);
  float alpha = clamp(smoothstep(0.0, 0.55, depth) * 0.97 + foam * 0.85, 0.0, 1.0);

  // Same fog as everything else.
  float fg = fogAmount(dist);
  col = mix(col, horizonColor(V), fg);
  gl_FragColor = vec4(col, alpha);
}`;

export function buildLake(forest, fogColor, fogDensity) {
  const map = buildMap(forest);
  const uniforms = {
    uTime: GLOBALS.uTime,
    uStorm: { value: 0 },
    uFlash: { value: 0 },
    uFogCol: { value: fogColor },
    uZenith: { value: new THREE.Color(0x0d1424) },
    uMap: { value: map },
    uFogDensity: { value: fogDensity },
    uWL: { value: WATER_LEVEL },
  };
  const mat = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: VERT,
    fragmentShader: FRAG,
    transparent: true,
    depthWrite: false,
    fog: false,
  });
  const geo = new THREE.PlaneGeometry(210, 146, 1, 1);
  geo.rotateX(-Math.PI / 2);
  geo.translate(-57, WATER_LEVEL, 100);
  const mesh = new THREE.Mesh(geo, mat);
  mesh.renderOrder = 4;
  mesh.frustumCulled = false;
  mesh.name = 'lake';
  return { mesh, uniforms, map };
}

// Plank dock matching DECKS[0]: boards across, stringers, pilings down into the lake bed.
export function buildDock() {
  const d = DECKS[0];
  const rng = makeRng(2024);
  const gb = new GeoBuilder();
  const wood = hexLin(0x5a4430);
  const dark = hexLin(0x2a1e14);
  const w = d.maxX - d.minX, len = d.maxZ - d.minZ;
  const cx = (d.minX + d.maxX) / 2;
  const top = d.y;
  const n = Math.floor(len / 0.2);
  const pw = len / n;
  for (let i = 0; i < n; i++) {
    const z = d.minZ + (i + 0.5) * pw;
    const k = 0.62 + rng() * 0.55;
    const c = mulc(wood, k);
    const cut = rng() < 0.18 ? 0.35 + rng() * 0.3 : 0; // some boards are split in two
    const jy = (rng() - 0.5) * 0.014;
    if (cut) {
      gb.box(d.minX + (w * cut) / 2, top - 0.04 + jy, z, (w * cut) / 2 - 0.01, 0.04, pw / 2 - 0.012, c, [0, 1, 0, 1]);
      gb.box(d.minX + w * cut + (w * (1 - cut)) / 2, top - 0.04 - jy, z, (w * (1 - cut)) / 2 - 0.01, 0.04, pw / 2 - 0.012, mulc(c, 0.9), [0, 1, 0, 1]);
    } else {
      gb.box(cx, top - 0.04 + jy, z, w / 2, 0.04, pw / 2 - 0.012, c, [0, 1, 0, 1]);
    }
  }
  for (const x of [d.minX + 0.35, cx, d.maxX - 0.35]) gb.box(x, top - 0.18, (d.minZ + d.maxZ) / 2, 0.07, 0.1, len / 2, dark);
  for (let z = d.minZ + 0.2; z <= d.maxZ; z += 2.9) gb.box(cx, top - 0.3, z, w / 2 + 0.05, 0.06, 0.07, dark);
  // pilings
  const piles = [];
  for (let z = d.minZ + 0.4; z <= d.maxZ - 0.2; z += 2.9) piles.push(z);
  piles.push(d.maxZ - 0.15);
  piles.forEach((z, i) => {
    for (const x of [d.minX + 0.12, d.maxX - 0.12]) {
      const tall = i % 2 === 0 || i === piles.length - 1;
      gb.prism(0.14, 0.12, -5.2, top + (tall ? 0.62 : 0.0), 6, dark, mulc(dark, 1.3), [0, 1, 0, 1], [0, 0], [x, z]);
      if (tall) gb.prism(0.13, 0.13, top + 0.62, top + 0.67, 6, mulc(wood, 0.5), mulc(wood, 0.5), [0, 1, 0, 1], [0, 0], [x, z]);
    }
  });
  const geo = gb.build();
  const mesh = new THREE.Mesh(geo, lit({ vertexColors: true }));
  mesh.name = 'dock';
  return mesh;
}
