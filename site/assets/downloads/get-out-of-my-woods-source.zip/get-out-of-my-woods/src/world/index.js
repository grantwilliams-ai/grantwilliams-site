// The World: everything outdoors, placed and lit. See docs/DESIGN.md for the contract.
import * as THREE from 'three';
import { PALETTE, MOON_DIR } from '../render/palette.js';
import { GLOBALS } from '../render/materials.js';
import { generateForest } from '../sim/forest.js';
import { BUILDINGS, CAR, LAYOUT, PROPS, SCARECROWS, SIGNS, TEMPLATES } from '../sim/layout.js';
import { heightAt, surfaceY } from '../sim/terrain.js';
import { buildBuilding, buildCar, buildProp, buildScarecrow, buildSearchMarker, buildSign } from '../kit/index.js';
import { buildTerrain, buildMask } from './ground.js';
import { buildTrees } from './trees.js';
import { buildSky } from './sky.js';
import { buildLake, buildDock } from './lake.js';
import { buildCover } from './cover.js';
import { buildLights } from './lights.js';
import { buildAir } from './air.js';

// Inward normal of each wall in building-local x,z.
const INWARD = { front: [0, -1], back: [0, 1], left: [1, 0], right: [-1, 0] };
const FOG_DENSITY = 0.022;
const HEMI_BASE = 1.2, MOON_BASE = 1.6;

const BUILT_IN_SEARCHES = new Set(['c1-locker', 'c3-desk', 'mess-kitchen', 'boat-motor']);

export class World {
  constructor(scene, quality) {
    this.scene = scene;
    this.quality = quality;
    this.root = new THREE.Group();
    this.root.name = 'world';
    scene.add(this.root);
    this.forest = generateForest();
    this.timings = {};
    const t0 = performance.now();
    let t1 = t0;
    const lap = (name) => {
      const t = performance.now();
      this.timings[name] = Math.round(t - t1);
      t1 = t;
    };

    if (!scene.fog) scene.fog = new THREE.FogExp2(PALETTE.fog, FOG_DENSITY);
    this.fog = scene.fog;
    this.fogCalm = new THREE.Color(PALETTE.fog);
    this.fogStorm = new THREE.Color(PALETTE.fogStorm);
    this.fogFlash = new THREE.Color(0xa9bfff);

    this.hemi = new THREE.HemisphereLight(PALETTE.hemiSky, PALETTE.hemiGround, HEMI_BASE);
    this.moon = new THREE.DirectionalLight(PALETTE.moonLight, MOON_BASE);
    this.moon.position.set(...MOON_DIR.map((c) => c * 100));
    this.root.add(this.hemi, this.moon);

    this.mask = buildMask();
    this.terrain = buildTerrain(quality, this.forest);
    this.root.add(this.terrain.mesh);
    lap('ground');

    this.trees = buildTrees(quality, this.forest);
    this.root.add(this.trees.group);
    lap('trees');

    this.cover = buildCover(quality, this.forest, this.mask);
    this.root.add(this.cover.group);
    lap('cover');

    this.sky = buildSky(this.fog.color);
    this.root.add(this.sky.mesh);
    lap('sky');

    this.lake = buildLake(this.forest, this.fog.color, FOG_DENSITY);
    this.root.add(this.lake.mesh);
    this.root.add(buildDock());
    lap('lake');

    this.lights = buildLights(quality);
    this.root.add(this.lights.group);
    lap('lights');

    this.air = buildAir(quality, this.lights.sources);
    this.root.add(this.air.group);
    lap('air');

    this.placeThings();
    lap('placement');
    this.timings.total = Math.round(performance.now() - t0);

    this.flicker = { fire: 1 };
    this.indoorId = null;
    this.indoorAmt = 0;
    this.indoorTarget = 0;
    this.flashlightOn = false;
  }

  // Buildings, props, the car, signs, scarecrows and search markers, all placed from the layout.
  placeThings() {
    this.buildings = new Map();
    this.doors = new Map();
    this.windows = new Map();
    this.markers = new Map();
    for (const b of BUILDINGS) {
      const t = TEMPLATES[b.template];
      const g = buildBuilding(b, t);
      g.position.set(b.x, surfaceY(b.x, b.z), b.z);
      g.rotation.y = b.rot;
      g.name = b.id;
      this.root.add(g);
      this.buildings.set(b.id, g);
      (g.userData.doors || []).forEach((d, i) => {
        const door = t.doors[i];
        const base = d.pivot.rotation.y;
        // Swing the free end toward the room.
        const n = INWARD[door.wall];
        const dir = -Math.sin(base) * n[0] - Math.cos(base) * n[1] >= 0 ? 1 : -1;
        this.doors.set(`${b.id}.d${i}`, { pivot: d.pivot, base, dir });
      });
      this.windows.set(b.id, { meshes: g.userData.windows || [], cloned: false });
    }
    for (const p of PROPS) {
      const g = buildProp(p);
      g.position.set(p.x, surfaceY(p.x, p.z), p.z);
      g.rotation.y = p.rot || 0;
      this.root.add(g);
      if (g.userData.leaves) this.gate = { leaves: g.userData.leaves, rest: g.userData.leaves.map((l) => l.rotation.y), swing: 0, target: 0, v: 0 };
    }
    this.car = buildCar();
    this.car.position.set(CAR.x, surfaceY(CAR.x, CAR.z), CAR.z);
    this.car.rotation.y = CAR.rot;
    this.root.add(this.car);
    for (const s of SIGNS) {
      const g = buildSign(s);
      g.position.set(s.x, surfaceY(s.x, s.z), s.z);
      g.rotation.y = s.rot || 0;
      this.root.add(g);
    }
    this.scarecrows = SCARECROWS.map((s) => {
      const g = buildScarecrow();
      g.position.set(s.x, heightAt(s.x, s.z), s.z);
      g.rotation.y = s.rot || 0;
      this.root.add(g);
      return g;
    });
    for (const spot of LAYOUT.searches) {
      // These four are already furniture in their rooms.
      if (BUILT_IN_SEARCHES.has(spot.id)) continue;
      const m = buildSearchMarker(spot);
      if (!m) continue;
      if (spot.building) {
        // inside its building, in the building's own frame, on the floor
        this.buildings.get(spot.building).add(m);
        m.position.set(spot.x, 0, spot.z);
      } else {
        m.position.set(spot.wx, surfaceY(spot.wx, spot.wz), spot.wz);
        this.root.add(m);
      }
      this.markers.set(spot.id, m);
    }
  }

  // door id from LAYOUT.doors, amount 0 closed .. 1 open
  setDoor(id, amount) {
    const d = this.doors.get(id);
    if (!d) return;
    d.pivot.rotation.y = d.base + d.dir * Math.min(1, Math.max(0, amount)) * 1.75;
  }

  setWindowLit(buildingId, on) {
    const w = this.windows.get(buildingId);
    if (!w) return;
    if (!w.cloned) {
      // do not light the neighbours: give this building its own window materials
      for (const m of w.meshes) if (m.material) m.material = m.material.clone();
      w.cloned = true;
    }
    for (const m of w.meshes) {
      const mat = m.material;
      if (!mat) continue;
      if (mat.emissive) {
        if (mat.emissive.getHex() === 0) mat.emissive.set(PALETTE.window);
        mat.emissiveIntensity = on ? 1.4 : 0;
      } else if (mat.color) {
        mat.color.set(on ? PALETTE.window : 0x0a0d12);
      }
    }
  }

  // The camera has moved inside a building (or out, with null).
  setIndoor(buildingId, zoneId = buildingId) {
    this.indoorId = buildingId || null;
    this.indoorTarget = buildingId ? 1 : 0;
    if (buildingId) {
      const b = BUILDINGS.find((q) => q.id === buildingId);
      if (b) {
        const t = TEMPLATES[b.template];
        const fill = this.lights.fill;
        const base = surfaceY(b.x, b.z);
        if (b.template === 'cabin' && zoneId === `${b.id}.rear`) {
          fill.pos.set(b.x - 2.2 * Math.sin(b.rot), base + 2.0, b.z - 2.2 * Math.cos(b.rot));
        } else {
          fill.pos.set(b.x, base + Math.min(t.wallH - 0.5, 2.5), b.z);
        }
        fill.radius = Math.max(t.hx, t.hz) * 1.3;
      }
    }
  }

  setFlashlight(on) {
    this.flashlightOn = !!on;
  }

  lightning(strength = 1, hold = null) {
    this.air.setCam(this._cam || new THREE.Vector3());
    this.air.lightning(strength, hold);
  }

  // Film the next moment here: trees and bushes rooted near this point are gone. No arguments puts them back.
  clearStage(x = 0, z = 0, r = 0, keep = null) {
    GLOBALS.uClear.value.set(x, z, r);
    GLOBALS.uKeep.value.set(keep ? keep.x : 1e5, keep ? keep.z : 1e5);
  }

  // The wagon goes through the gate. The leaves fly open, hit their stops and rock back.
  burstGate() {
    if (!this.gate) return;
    this.gate.v = 9;
    this.gate.target = 1.8;
  }

  resetGate() {
    const g = this.gate;
    if (!g) return;
    g.swing = g.v = g.target = 0;
    g.leaves.forEach((l, i) => { l.rotation.y = g.rest[i]; });
  }

  updateGate(dt) {
    const g = this.gate;
    if (!g || !g.target) return;
    g.v += (g.target - g.swing) * 10 * dt;
    g.v *= Math.exp(-2.4 * dt);
    g.swing += g.v * dt;
    if (g.swing > 2.15) {
      g.swing = 2.15;
      g.v *= -0.4;
    }
    g.leaves.forEach((l, i) => {
      l.rotation.y = g.rest[i] + (i ? 1 : -0.88) * g.swing;
    });
  }

  update(dt, ctx) {
    const storm = Math.min(1, Math.max(0, ctx.storm || 0));
    const cam = ctx.camera;
    this.updateGate(dt);
    this._cam = cam.position;
    // indoor fade, about 0.15 s
    const step = dt / 0.15;
    this.indoorAmt += Math.max(-step, Math.min(step, this.indoorTarget - this.indoorAmt));
    const ind = this.indoorAmt;
    this.lights.fill.active = ind > 0.001;
    this.lights.fill.amount = ind;

    GLOBALS.uWind.value = 1 + storm * 2;
    const flash = this.air.state.flash;

    // fog colour: calm -> storm, and a white-blue wash while lightning strikes
    this.fog.color.copy(this.fogCalm).lerp(this.fogStorm, storm).lerp(this.fogFlash, Math.min(1, flash * 0.32));

    // moon and sky light, dimmed by cloud and cut indoors
    const outdoor = 1 - ind;
    this.moon.intensity = (MOON_BASE * (1 - 0.72 * storm) + flash * 2.2) * (1 - 0.97 * ind);
    this.hemi.intensity = (HEMI_BASE * (1 - 0.25 * storm) + flash * 2.4) * (1 - 0.82 * ind);

    const su = this.sky.uniforms;
    su.uStorm.value = storm;
    su.uFlash.value = flash * 0.6;
    this.sky.mesh.position.copy(cam.position);
    this.lake.uniforms.uStorm.value = storm;
    this.lake.uniforms.uFlash.value = flash;

    this.terrain.update(cam);
    this.trees.update(cam);
    this.cover.update(cam);
    this.lights.update(dt, ctx.time ?? 0, cam.position, 1, storm);
    this.flicker.fire = this.lights.fire ? this.lights.fire.flick : 1;
    this.air.setCam(cam.position);
    this.air.update(dt, ctx.time ?? 0, cam, storm, ind, this.flashlightOn);
  }
}

export function buildWorld(scene, quality) {
  return new World(scene, quality);
}
