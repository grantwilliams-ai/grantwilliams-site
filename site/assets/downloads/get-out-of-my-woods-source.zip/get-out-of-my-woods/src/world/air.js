// The air: ground mist drifting around the camera, moths at the lights, fireflies by the lake,
// specks in the flashlight beam, rain once the storm passes 0.35, and the far-off lightning bolt.
// Particles are animated in the vertex shader, so there is almost no CPU cost.
import * as THREE from 'three';
import { makeRng } from '../core/rng.js';
import { noiseTile } from './common.js';
import { GLOBALS } from '../render/materials.js';
import { WATER_LEVEL } from '../sim/layout.js';
import { heightAt } from '../sim/terrain.js';

function mistTexture() {
  const n = 128;
  const c = document.createElement('canvas');
  c.width = c.height = n;
  const g = c.getContext('2d');
  // lumpy cloud from two noise octaves inside a circular falloff, written straight to pixels
  const a = noiseTile(n, 5, 31), b = noiseTile(n, 11, 32);
  const id = g.createImageData(n, n);
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const d = Math.hypot(i - n / 2, j - n / 2) / (n / 2);
      const k = Math.max(0, 1 - d);
      const edge = k * k * (3 - 2 * k);
      const v = Math.max(0, a[j * n + i] * 0.7 + b[j * n + i] * 0.45 - 0.35);
      const o = (j * n + i) * 4;
      id.data[o] = id.data[o + 1] = id.data[o + 2] = 255;
      id.data[o + 3] = Math.min(255, v * 520 * edge);
    }
  }
  g.putImageData(id, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

const POINT_FRAG = /* glsl */ `
varying vec4 vCol;
void main() {
  vec2 d = gl_PointCoord - 0.5;
  float a = smoothstep(0.5, 0.15, length(d));
  gl_FragColor = vec4(vCol.rgb, vCol.a * a);
}`;

function pointsMat(vertex, extra = {}) {
  return new THREE.ShaderMaterial({
    uniforms: { uTime: GLOBALS.uTime, ...extra },
    vertexShader: vertex,
    fragmentShader: POINT_FRAG,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    fog: false,
  });
}

function rand4(n, rng) {
  const a = new Float32Array(n * 4);
  for (let i = 0; i < a.length; i++) a[i] = rng();
  return a;
}

export function buildAir(quality, lightSources) {
  const group = new THREE.Group();
  group.name = 'air';
  const rng = makeRng(555);
  const P = quality.particles;

  // ---- Mist -----------------------------------------------------------------------------------
  const nMist = quality.mist;
  const mistMat = new THREE.MeshBasicMaterial({ map: mistTexture(), transparent: true, depthWrite: false, color: 0x93b0cc, opacity: 0.5, side: THREE.DoubleSide });
  // Low, feathered wisps face the view. Horizontal sheets sliced through legs
  // and porch walls as sharp blue bands; these keep their soft cloud outline.
  mistMat.onBeforeCompile = (s) => {
    s.vertexShader = s.vertexShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vMistDir;')
      .replace('#include <begin_vertex>', `#include <begin_vertex>
        vMistDir = (modelMatrix * instanceMatrix * vec4(transformed, 1.0)).xyz - cameraPosition;`);
    s.fragmentShader = s.fragmentShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vMistDir;')
      // Instance red stores coverage, not tint: fading a patch must reveal the scene, not turn black.
      .replace('#include <color_fragment>', `
        #ifdef USE_INSTANCING_COLOR
          diffuseColor.a *= vColor.r;
        #endif`)
      .replace('#include <dithering_fragment>', `#include <dithering_fragment>
        gl_FragColor.a *= smoothstep(3.0, 11.0, length(vMistDir));`);
  };
  mistMat.customProgramCacheKey = () => 'mist-v4-soft-wisps';
  const mistGeo = new THREE.PlaneGeometry(1, 1);
  const mist = new THREE.InstancedMesh(mistGeo, mistMat, nMist);
  mist.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(nMist * 3).fill(1), 3);
  mist.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  mist.instanceColor.setUsage(THREE.DynamicDrawUsage);
  mist.frustumCulled = false;
  mist.renderOrder = 8;
  group.add(mist);
  const patches = [];
  for (let i = 0; i < nMist; i++) {
    const a = rng() * 6.28, d = 4 + Math.sqrt(rng()) * 40;
    patches.push({ ox: Math.cos(a) * d, oz: Math.sin(a) * d, x: 0, z: 0, vx: (0.25 + rng() * 0.4) * (rng() < 0.2 ? -0.5 : 1), vz: 0.08 + rng() * 0.2, size: 13 + rng() * 14, h: 0.25 + rng() * 1.1, rot: rng() * 6.28, spin: (rng() - 0.5) * 0.02, init: false, phase: rng() * 9 });
  }

  // ---- Moths ----------------------------------------------------------------------------------
  const lamps = lightSources.filter((s) => s.kind !== 'fire');
  const mothN = Math.round(P / 12) + 4;
  const mothCount = lamps.length * mothN;
  if (mothCount) {
    const g = new THREE.BufferGeometry();
    const center = new Float32Array(mothCount * 3);
    lamps.forEach((l, li) => {
      for (let i = 0; i < mothN; i++) center.set([l.pos.x, l.pos.y, l.pos.z], (li * mothN + i) * 3);
    });
    g.setAttribute('position', new THREE.BufferAttribute(center, 3));
    g.setAttribute('seed', new THREE.BufferAttribute(rand4(mothCount, rng), 4));
    const moths = new THREE.Points(g, pointsMat(/* glsl */ `
      attribute vec4 seed; uniform float uTime; varying vec4 vCol;
      void main() {
        float t = uTime * (0.8 + seed.x * 1.4) + seed.y * 60.0;
        float r = 0.2 + seed.z * 0.55;
        vec3 p = position + vec3(cos(t) * r + sin(t * 3.7) * 0.1, sin(t * 1.3) * r * 0.7 + sin(t * 5.1) * 0.12, sin(t) * r + cos(t * 2.9) * 0.1);
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_Position = projectionMatrix * mv;
        gl_PointSize = 1.6 + seed.w * 1.2;
        float flutter = 0.55 + 0.45 * sin(uTime * 38.0 + seed.x * 99.0);
        vCol = vec4(0.95, 0.92, 0.8, 0.9 * flutter * exp(-pow(length(mv.xyz) / 60.0, 2.0)));
      }`));
    moths.frustumCulled = false;
    moths.renderOrder = 7;
    group.add(moths);
  }

  // ---- Fireflies by the lake ------------------------------------------------------------------
  const ffN = Math.round(P / 8);
  {
    const base = [];
    let guard = 0;
    while (base.length < ffN && guard++ < 20000) {
      const x = -105 + rng() * 140, z = 28 + rng() * 80;
      const h = heightAt(x, z);
      if (h > WATER_LEVEL + 0.2 && h < WATER_LEVEL + 1.8) base.push(x, h + 0.6, z);
    }
    const n = base.length / 3;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(base), 3));
    g.setAttribute('seed', new THREE.BufferAttribute(rand4(n, rng), 4));
    const ff = new THREE.Points(g, pointsMat(/* glsl */ `
      attribute vec4 seed; uniform float uTime; varying vec4 vCol;
      void main() {
        float t = uTime * (0.15 + seed.x * 0.2) + seed.y * 100.0;
        vec3 p = position + vec3(sin(t * 1.7) * 2.5 + sin(t * 4.3) * 0.4, 0.5 + sin(t * 1.1) * 0.5 + seed.z * 1.2, cos(t * 1.3) * 2.5);
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_Position = projectionMatrix * mv;
        float blink = smoothstep(0.55, 0.95, sin(uTime * (0.6 + seed.w * 0.5) + seed.y * 40.0));
        gl_PointSize = 2.0 + blink * 2.0;
        vCol = vec4(0.65, 1.0, 0.3, (0.1 + blink * 0.9) * exp(-pow(length(mv.xyz) / 50.0, 2.0)));
      }`));
    ff.frustumCulled = false;
    ff.renderOrder = 7;
    group.add(ff);
  }

  // ---- Dust specks around the camera ----------------------------------------------------------
  const dustN = Math.round(P * 0.8);
  const dustU = { uCam: { value: new THREE.Vector3() }, uFwd: { value: new THREE.Vector3(0, 0, -1) }, uBeam: { value: 0 }, uAir: { value: 1 } };
  {
    const g = new THREE.BufferGeometry();
    const pos = new Float32Array(dustN * 3);
    for (let i = 0; i < pos.length; i++) pos[i] = rng() * 10;
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('seed', new THREE.BufferAttribute(rand4(dustN, rng), 4));
    const dust = new THREE.Points(g, pointsMat(/* glsl */ `
      attribute vec4 seed; uniform float uTime; uniform vec3 uCam; uniform vec3 uFwd; uniform float uBeam; uniform float uAir;
      varying vec4 vCol;
      void main() {
        vec3 q = position + vec3(sin(uTime * 0.2 + seed.x * 30.0) * 0.6 + uTime * 0.08, -uTime * 0.03 + sin(uTime * 0.3 + seed.y * 20.0) * 0.3, uTime * 0.05);
        vec3 rel = mod(q - uCam + 5.0, 10.0) - 5.0;
        vec3 p = uCam + rel;
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_Position = projectionMatrix * mv;
        float dist = length(rel);
        float cone = smoothstep(0.86, 0.97, dot(rel / max(dist, 0.01), uFwd));
        float a = (0.05 + uBeam * cone * 0.7) * smoothstep(0.4, 1.2, dist) * smoothstep(5.0, 3.0, dist) * uAir;
        gl_PointSize = 1.4 + seed.w * 1.2;
        vCol = vec4(mix(vec3(0.5, 0.62, 0.8), vec3(1.0, 0.88, 0.62), uBeam * cone), a);
      }`, dustU));
    dust.frustumCulled = false;
    dust.renderOrder = 9;
    group.add(dust);
  }

  // ---- Rain -----------------------------------------------------------------------------------
  const rainN = Math.round(P * 6);
  const rainU = { uCam: { value: new THREE.Vector3() }, uRain: { value: 0 }, uWind: GLOBALS.uWind };
  const rainMat = new THREE.ShaderMaterial({
    uniforms: { uTime: GLOBALS.uTime, ...rainU },
    vertexShader: /* glsl */ `
      attribute vec4 seed; attribute float tip;
      uniform float uTime; uniform vec3 uCam; uniform float uRain; uniform float uWind;
      varying float vA;
      void main() {
        float W = 26.0, H = 16.0;
        float speed = 11.0 + seed.w * 4.0;
        vec2 xz = mod(seed.xz * W - uCam.xz + W * 0.5, W) - W * 0.5;
        float y = mod(seed.y * H - uTime * speed, H) - 5.0;
        vec3 p = vec3(uCam.x + xz.x, uCam.y + y, uCam.z + xz.y);
        vec3 fall = normalize(vec3(0.16 * uWind * 0.5, -1.0, 0.05));
        p -= fall * tip * (0.55 + seed.w * 0.5);
        p.x += y * 0.0;
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_Position = projectionMatrix * mv;
        float d = length(mv.xyz);
        vA = uRain * (0.12 + 0.2 * seed.z) * smoothstep(0.8, 3.0, d) * smoothstep(20.0, 8.0, d) * (1.0 - tip * 0.6);
      }`,
    fragmentShader: /* glsl */ `
      varying float vA;
      void main() { gl_FragColor = vec4(0.72, 0.82, 1.0, vA); }`,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    fog: false,
  });
  const rain = (() => {
    const g = new THREE.BufferGeometry();
    const seed = new Float32Array(rainN * 2 * 4), tip = new Float32Array(rainN * 2), pos = new Float32Array(rainN * 2 * 3);
    for (let i = 0; i < rainN; i++) {
      const s = [rng(), rng(), rng(), rng()];
      for (let k = 0; k < 2; k++) {
        seed.set(s, (i * 2 + k) * 4);
        tip[i * 2 + k] = k;
      }
    }
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('seed', new THREE.BufferAttribute(seed, 4));
    g.setAttribute('tip', new THREE.BufferAttribute(tip, 1));
    const l = new THREE.LineSegments(g, rainMat);
    l.frustumCulled = false;
    l.renderOrder = 9;
    l.visible = false;
    return l;
  })();
  group.add(rain);

  // ---- Lightning bolt -------------------------------------------------------------------------
  const boltMat = new THREE.LineBasicMaterial({ color: 0xcfe0ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
  const boltGeo = new THREE.BufferGeometry();
  boltGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(120 * 2 * 3), 3));
  const bolt = new THREE.LineSegments(boltGeo, boltMat);
  bolt.frustumCulled = false;
  bolt.visible = false;
  bolt.renderOrder = 2;
  group.add(bolt);

  function makeBolt(camPos) {
    const a = Math.random() * Math.PI * 2, dist = 120 + Math.random() * 80;
    const ox = camPos.x + Math.cos(a) * dist, oz = camPos.z + Math.sin(a) * dist;
    const arr = boltGeo.attributes.position.array;
    let n = 0;
    const seg = (x0, y0, z0, x1, y1, z1) => {
      if (n >= 120) return;
      arr.set([x0, y0, z0, x1, y1, z1], n * 6);
      n++;
    };
    const fork = (x, y, z, len, depth) => {
      let cx = x, cy = y, cz = z;
      const dx = (Math.random() - 0.5) * 24, dz = (Math.random() - 0.5) * 24;
      for (let i = 0; i < len; i++) {
        const nx = cx + dx * 0.5 + (Math.random() - 0.5) * 14, ny = cy - 6 - Math.random() * 6, nz = cz + dz * 0.5 + (Math.random() - 0.5) * 14;
        seg(cx, cy, cz, nx, ny, nz);
        cx = nx; cy = ny; cz = nz;
        if (depth > 0 && Math.random() < 0.18) fork(cx, cy, cz, 3 + Math.floor(Math.random() * 4), depth - 1);
      }
    };
    fork(ox, 130, oz, 18, 2);
    boltGeo.setDrawRange(0, n * 2);
    boltGeo.attributes.position.needsUpdate = true;
  }

  // ---- Lightning envelope: a double strobe over 150 ms, then decay -----------------------------
  const L = { t: 99, strength: 0 };
  const envelope = (t) => {
    if (t < 0.0) return 0;
    if (t < 0.035) return t / 0.035;
    if (t < 0.07) return 1 - ((t - 0.035) / 0.035) * 0.65;
    if (t < 0.1) return 0.35 + ((t - 0.07) / 0.03) * 0.65;
    if (t < 0.15) return 1;
    return Math.exp(-(t - 0.15) * 6.0);
  };

  const state = { flash: 0 };
  const camFwd = new THREE.Vector3();
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), roll = new THREE.Quaternion(), sv = new THREE.Vector3(), pv = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0), rollAxis = new THREE.Vector3(0, 0, 1);
  const col = new THREE.Color();

  function update(dt, time, camera, storm, indoor, flashlight) {
    const cp = camera.position;
    // lightning
    if (L.hold == null) L.t += dt;
    state.flash = L.strength * envelope(L.t);
    bolt.visible = L.t < 0.5 && L.strength > 0;
    boltMat.opacity = Math.min(1, state.flash * 1.4) * (1 - indoor * 0.8);

    // mist
    mist.visible = indoor < 0.99;
    const wind = GLOBALS.uWind.value;
    for (let i = 0; i < patches.length; i++) {
      const p = patches[i];
      if (!p.init) {
        p.x = cp.x + p.ox;
        p.z = cp.z + p.oz;
        p.init = true;
      }
      p.x += p.vx * dt * wind;
      p.z += p.vz * dt * wind;
      p.rot += p.spin * dt;
      let dx = p.x - cp.x, dz = p.z - cp.z;
      const d = Math.hypot(dx, dz);
      if (d > 48) {
        // re-enter on the far side so a patch never pops in view
        const a = Math.random() * 6.28;
        p.x = cp.x + Math.cos(a) * 44;
        p.z = cp.z + Math.sin(a) * 44;
        dx = p.x - cp.x;
        dz = p.z - cp.z;
      }
      const dd = Math.hypot(dx, dz);
      // thin out right around the camera so it never becomes a wall, and thicker with the storm
      const near = Math.min(1, Math.max(0, (dd - 2.5) / 7));
      const gy = heightAt(p.x, p.z);
      q.setFromAxisAngle(up, Math.atan2(cp.x - p.x, cp.z - p.z));
      q.multiply(roll.setFromAxisAngle(rollAxis, Math.sin(p.rot) * 0.24));
      const breathe = 1 + 0.08 * Math.sin(time * 0.3 + p.phase);
      sv.set(p.size * breathe, 1.45 + p.h * .8, 1);
      pv.set(p.x, Math.max(gy, WATER_LEVEL) + p.h, p.z);
      m4.compose(pv, q, sv);
      mist.setMatrixAt(i, m4);
      const far = Math.min(1, Math.max(0, (46 - dd) / 9));
      const k = near * far * (1 + storm * 0.3);
      col.setRGB(k, k, k);
      mist.setColorAt(i, col);
    }
    mist.instanceMatrix.needsUpdate = true;
    mist.instanceColor.needsUpdate = true;
    mistMat.opacity = 0.16 - storm * 0.025;

    // specks
    camera.getWorldDirection(camFwd);
    dustU.uCam.value.copy(cp);
    dustU.uFwd.value.copy(camFwd);
    dustU.uBeam.value += ((flashlight ? 1 : 0) - dustU.uBeam.value) * Math.min(1, dt * 8);
    dustU.uAir.value = 1 - indoor * 0.4;

    // rain
    const r = Math.min(1, Math.max(0, (storm - 0.35) / 0.25));
    rain.visible = r > 0.001 && indoor < 0.99;
    rainU.uCam.value.copy(cp);
    rainU.uRain.value = r * (1 - indoor);
  }

  return {
    group,
    update,
    state,
    // hold: debug only, freezes the envelope at that many seconds (null to let it run)
    lightning(strength, hold = null) {
      L.hold = hold;
      L.t = hold ?? 0;
      L.strength = Math.max(0, Math.min(1, strength));
      makeBolt(new THREE.Vector3().copy(L.cam || new THREE.Vector3()));
    },
    setCam(c) { L.cam = c; },
  };
}
