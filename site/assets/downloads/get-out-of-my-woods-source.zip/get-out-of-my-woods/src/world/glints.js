// A faint glint where the flashlight catches something worth searching. The dark hides you, and it
// hides these too.
import * as THREE from 'three';
import { LAYOUT } from '../sim/layout.js';
import { surfaceY } from '../sim/terrain.js';

const RANGE = 15;
const CONE = 0.9; // how nearly the beam must point at it
const SIZE = 0.22; // metres, near enough, whatever the screen

function starTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 32;
  const g = c.getContext('2d');
  const r = g.createRadialGradient(16, 16, 0, 16, 16, 16);
  r.addColorStop(0, 'rgba(255,255,255,1)');
  r.addColorStop(0.25, 'rgba(255,255,255,0.35)');
  r.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = r;
  g.fillRect(0, 0, 32, 32);
  g.fillStyle = 'rgba(255,255,255,0.8)';
  g.fillRect(15, 2, 2, 28);
  g.fillRect(2, 15, 28, 2);
  return new THREE.CanvasTexture(c);
}

export class Glints {
  constructor(scene) {
    this.spots = LAYOUT.searches.map((s) => ({ id: s.id, x: s.wx, y: surfaceY(s.wx, s.wz) + s.y + 0.12, z: s.wz, phase: s.wx * 3.1 }));
    const pos = new Float32Array(this.spots.length * 3);
    this.spots.forEach((s, i) => pos.set([s.x, s.y, s.z], i * 3));
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    this.color = new THREE.BufferAttribute(new Float32Array(this.spots.length * 3), 3);
    geo.setAttribute('color', this.color);
    this.mat = new THREE.PointsMaterial({
      size: SIZE,
      map: starTexture(),
      vertexColors: true,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      fog: false,
    });
    this.points = new THREE.Points(geo, this.mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 4;
    scene.add(this.points);
  }

  // scale: render target height over canvas height. three sizes points by the canvas.
  update(time, from, aim, lightOn, searched, scale) {
    this.mat.size = SIZE * scale * 3;
    const col = this.color.array;
    this.spots.forEach((s, i) => {
      let v = 0;
      if (lightOn && !searched.has(s.id)) {
        const dx = s.x - from.x, dy = s.y - from.y, dz = s.z - from.z;
        const d = Math.hypot(dx, dy, dz) || 1;
        const along = (dx * aim.x + dy * aim.y + dz * aim.z) / d;
        if (d < RANGE && along > CONE) {
          const twinkle = 0.55 + 0.45 * Math.sin(time * 5.3 + s.phase) * Math.sin(time * 3.1 + s.phase * 2);
          v = twinkle * Math.min(1, (along - CONE) * 14) * Math.min(1, (RANGE - d) / 4);
        }
      }
      col[i * 3] = v;
      col[i * 3 + 1] = v * 0.92;
      col[i * 3 + 2] = v * 0.72;
    });
    this.color.needsUpdate = true;
  }

  hide() {
    this.color.array.fill(0);
    this.color.needsUpdate = true;
  }
}
