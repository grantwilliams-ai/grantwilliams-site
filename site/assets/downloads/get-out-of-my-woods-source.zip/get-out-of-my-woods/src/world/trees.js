// The woods. Real pine silhouettes (ragged drooping skirts on bare trunks, nothing below 2.6 m),
// dead snags, pale birches. InstancedMesh per kind and LOD; instances are rebuilt from the sectors
// the camera can see, so only what is in view and inside the fog is drawn.
import * as THREE from 'three';
import { makeRng } from '../core/rng.js';
import { lit } from '../render/materials.js';
import { canvasTexture } from '../render/textures.js';
import { GeoBuilder, cameraFrustum, hexLin, lerp, mulc, sphereVisible } from './common.js';
import { treeShape } from './ground.js';

const FOLIAGE = hexLin(0x1b2d25);
const BARK = hexLin(0x41352a);
const BARK_TOP = hexLin(0x261e17);
const DEAD = hexLin(0x4b453b);
const BIRCH = hexLin(0xc4c2b0);
const BIRCH_LEAF = hexLin(0x34452b);

const UV_BARK = [0.02, 0.48, 0.02, 0.48];
const UV_BIRCH = [0.52, 0.98, 0.02, 0.48];

// Foliage uv: a corner of the speckle region.
const fuv = (i, n, top) => [0.05 + 0.9 * ((i % n) / n), top ? 0.92 : 0.55];

function tube(gb, a, b, r0, r1, sides, c0, c1, uvr) {
  const d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
  const len = Math.hypot(...d) || 1;
  const n = d.map((x) => x / len);
  const up = Math.abs(n[1]) > 0.9 ? [1, 0, 0] : [0, 1, 0];
  let u = [n[1] * up[2] - n[2] * up[1], n[2] * up[0] - n[0] * up[2], n[0] * up[1] - n[1] * up[0]];
  const ul = Math.hypot(...u);
  u = u.map((x) => x / ul);
  const v = [n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0]];
  const ring = (c, r, i) => {
    const an = (i / sides) * Math.PI * 2;
    const cs = Math.cos(an) * r, sn = Math.sin(an) * r;
    return [c[0] + u[0] * cs + v[0] * sn, c[1] + u[1] * cs + v[1] * sn, c[2] + u[2] * cs + v[2] * sn];
  };
  const [u0, u1, v0, v1] = uvr;
  for (let i = 0; i < sides; i++) {
    const ua = lerp(u0, u1, i / sides), ub = lerp(u0, u1, (i + 1) / sides);
    gb.quad(ring(a, r0, i), ring(a, r0, i + 1), ring(b, r1, i + 1), ring(b, r1, i), c0, c0, c1, c1, [[ua, v0], [ub, v0], [ub, v1], [ua, v1]]);
  }
}

// opts: H total height, h0 first branch height, R skirt radius, tiers, sides, mid (arched skirts), trunk radius
function pineGeo(o, seed) {
  const gb = new GeoBuilder();
  if (o.trunkSides) gb.prism(o.trunk, 0.035, -0.22, o.H, o.trunkSides, BARK, BARK_TOP, UV_BARK);
  // Each bough has its own drooping tip. Gaps between branches break the old solid-cone outline.
  // Tier-local seeds keep the same crown when detail changes; only the folded surface simplifies.
  for (let k = 0; k < o.tiers; k++) {
    const rng = makeRng(seed * 97 + k * 173);
    const t = k / Math.max(1, o.tiers - 1);
    const y = lerp(o.h0, o.H - 0.7, t);
    const radius = o.R * Math.pow(1 - t, 0.75) + 0.24;
    const turn = k * 2.399 + seed * 0.17;
    for (let i = 0; i < o.sides; i++) {
      const a = turn + i / o.sides * Math.PI * 2;
      const r = radius * (0.66 + rng() * 0.46);
      const dx = Math.cos(a), dz = Math.sin(a), sx = -dz, sz = dx;
      const w = r * (0.24 + rng() * 0.1);
      const root = [dx * 0.08, Math.min(o.H, y + 0.95), dz * 0.08];
      const left = [dx * r * 0.55 + sx * w, y + 0.12, dz * r * 0.55 + sz * w];
      const right = [dx * r * 0.55 - sx * w, y + 0.12, dz * r * 0.55 - sz * w];
      const tip = [dx * r, y - 0.18 - rng() * 0.24, dz * r];
      const crest = [dx * r * 0.48, y + 0.35, dz * r * 0.48];
      const hi = mulc(FOLIAGE, 0.95 + t * 0.28 + rng() * 0.3);
      const lo = mulc(hi, 0.55);
      if (o.mid) {
        gb.tri(root, left, crest, hi, lo, hi, [0.5,0.96], [0.06,0.58], [0.5,0.8]);
        gb.tri(crest, left, tip, hi, lo, lo, [0.5,0.8], [0.06,0.58], [0.5,0.52]);
        gb.tri(crest, tip, right, hi, lo, lo, [0.5,0.8], [0.5,0.52], [0.94,0.58]);
        gb.tri(crest, right, root, hi, lo, hi, [0.5,0.8], [0.94,0.58], [0.5,0.96]);
      } else {
        gb.tri(root, left, tip, hi, lo, lo, [0.5,0.96], [0.06,0.58], [0.5,0.52]);
        gb.tri(root, tip, right, hi, lo, lo, [0.5,0.96], [0.5,0.52], [0.94,0.58]);
      }
      if (o.mid && k < 3 && i % 3 === 0) {
        tube(gb, [0, y + 0.22, 0], [dx * r * 0.82, y - 0.1, dz * r * 0.82], 0.045, 0.012, 3, BARK, BARK_TOP, UV_BARK);
      }
    }
  }
  return gb.build();
}

function deadGeo(seed, branches) {
  const rng = makeRng(seed);
  const gb = new GeoBuilder();
  const H = 8;
  let p = [0, -0.2, 0];
  const segs = [[3, 0.26, 0.19], [6, 0.19, 0.11], [H, 0.11, 0.03]];
  const pts = [p];
  let r = 0.28;
  for (const [y, r0, r1] of segs) {
    const q = [p[0] + (rng() - 0.5) * 0.7, y, p[2] + (rng() - 0.5) * 0.7];
    tube(gb, p, q, r || r0, r1, 5, BARK, mulc(DEAD, 0.7), UV_BARK);
    r = 0;
    p = q;
    pts.push(q);
  }
  if (branches) {
    const n = 7;
    for (let i = 0; i < n; i++) {
      const y = 3.6 + rng() * 3.8;
      const base = [pts[1][0] * (y / 3) * 0.0 + (y < 6 ? lerp(pts[1][0], pts[2][0], (y - 3) / 3) : lerp(pts[2][0], pts[3][0], (y - 6) / 2)), y, y < 6 ? lerp(pts[1][2], pts[2][2], (y - 3) / 3) : lerp(pts[2][2], pts[3][2], (y - 6) / 2)];
      const a = rng() * 6.28, len = 0.9 + rng() * 1.9;
      const tip = [base[0] + Math.cos(a) * len, y + 0.4 + rng() * 0.9, base[2] + Math.sin(a) * len];
      tube(gb, base, tip, 0.07, 0.015, 3, DEAD, mulc(DEAD, 0.8), UV_BARK);
      const mid = [lerp(base[0], tip[0], 0.55), lerp(base[1], tip[1], 0.55), lerp(base[2], tip[2], 0.55)];
      const a2 = a + (rng() - 0.5) * 1.6;
      tube(gb, mid, [mid[0] + Math.cos(a2) * 0.7, mid[1] + 0.5, mid[2] + Math.sin(a2) * 0.7], 0.035, 0.01, 3, DEAD, DEAD, UV_BARK);
    }
  }
  return gb.build();
}

function puff(gb, c, rx, ry, rng, col) {
  const j = () => 0.8 + rng() * 0.4;
  const top = [c[0], c[1] + ry, c[2]], bot = [c[0], c[1] - ry * 0.9, c[2]];
  const ring = [];
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2 + rng() * 0.3;
    ring.push([c[0] + Math.cos(a) * rx * j(), c[1] + (rng() - 0.5) * ry * 0.3, c[2] + Math.sin(a) * rx * j()]);
  }
  for (let i = 0; i < 6; i++) {
    const k = (i + 1) % 6;
    gb.tri(top, ring[i], ring[k], mulc(col, 1.25), col, col, [0.5, 0.9], fuv(i, 6), fuv(i + 1, 6));
    gb.tri(bot, ring[k], ring[i], mulc(col, 0.5), col, col, [0.5, 0.6], fuv(i + 1, 6), fuv(i, 6));
  }
}

function birchGeo(seed, puffs, branches) {
  const rng = makeRng(seed);
  const gb = new GeoBuilder();
  const H = 9;
  const lean = [(rng() - 0.5) * 0.9, (rng() - 0.5) * 0.9];
  const top = [lean[0], H, lean[1]];
  tube(gb, [0, -0.2, 0], top, 0.17, 0.04, 6, BIRCH, mulc(BIRCH, 0.85), UV_BIRCH);
  const at = (y) => [lean[0] * (y / H), y, lean[1] * (y / H)];
  for (let i = 0; i < branches; i++) {
    const y = 3.2 + rng() * 4.5;
    const a = rng() * 6.28, len = 1.0 + rng() * 1.4;
    const b = at(y);
    tube(gb, b, [b[0] + Math.cos(a) * len, y + 0.9 + rng() * 0.6, b[2] + Math.sin(a) * len], 0.05, 0.015, 3, BIRCH, mulc(BIRCH, 0.8), UV_BIRCH);
  }
  for (let i = 0; i < puffs; i++) {
    const y = 3.8 + (i / puffs) * 5.2 + rng() * 0.6;
    const a = rng() * 6.28, d = i === puffs - 1 ? 0 : 0.7 + rng() * 0.9;
    const b = at(y);
    puff(gb, [b[0] + Math.cos(a) * d, y + 0.3, b[2] + Math.sin(a) * d], 1.0 + rng() * 0.5, 0.65 + rng() * 0.3, rng, BIRCH_LEAF);
  }
  return gb.build();
}

function texture() {
  return canvasTexture(128, (g, s) => {
    const rng = makeRng(404);
    // top half: needle speckle (uv v 0.5..1 is the canvas top)
    g.fillStyle = '#9a9a9a';
    g.fillRect(0, 0, s, s / 2);
    for (let i = 0; i < 700; i++) {
      const v = 110 + Math.floor(rng() * 110);
      g.fillStyle = `rgb(${v},${v},${v})`;
      g.fillRect(rng() * s, rng() * s * 0.5, 1 + rng() * 2, 1 + rng() * 2);
    }
    // bottom left: furrowed bark, long vertical streaks
    g.fillStyle = '#a8a8a8';
    g.fillRect(0, s / 2, s / 2, s / 2);
    for (let i = 0; i < 90; i++) {
      const v = 70 + Math.floor(rng() * 150);
      g.fillStyle = `rgb(${v},${v},${v})`;
      g.fillRect(rng() * s * 0.5, s / 2 + rng() * s * 0.5, 1 + rng() * 2, 10 + rng() * 40);
    }
    // bottom right: birch, pale with black scars
    g.fillStyle = '#e8e8e8';
    g.fillRect(s / 2, s / 2, s / 2, s / 2);
    for (let i = 0; i < 46; i++) {
      g.fillStyle = `rgba(20,20,20,${0.5 + rng() * 0.5})`;
      g.fillRect(s / 2 + rng() * s * 0.5, s / 2 + rng() * s * 0.5, 4 + rng() * 14, 1 + rng() * 2.5);
    }
  });
}

// Keep the existing bough geometry and rooted forest. An alpha-cut needle atlas
// breaks the paper-straight edges without adding trees, collision or draw calls.
function pineTexture(base) {
  const c = document.createElement('canvas'); c.width = c.height = 512;
  const g = c.getContext('2d'), rng = makeRng(481);
  g.drawImage(base.image, 0, 0, 512, 512);
  g.clearRect(0, 0, 512, 256);
  g.lineCap = 'round';
  const line = (x, y, xx, yy, width, shade) => {
    g.strokeStyle = `rgb(${shade},${shade},${shade})`; g.lineWidth = width;
    g.beginPath(); g.moveTo(x, y); g.lineTo(xx, yy); g.stroke();
  };
  // The mesh UVs run from the root at (.5,.96) to the tip at (.5,.52).
  line(256, 20, 256, 247, 9, 115);
  for (let row = 0; row < 22; row++) {
    const y = 30 + row * 9.5;
    // Stay inside the folded mesh's diamond UV outline, including the needle
    // tips. Otherwise the polygon clips off the texture's irregular edge.
    const edge = y < 202 ? (y - 20) / 195 * 225 : (246 - y) / 44 * 210;
    const spread = Math.max(7, edge - 26) * (.88 + rng() * .1);
    for (const side of [-1, 1]) {
      const ex = 256 + side * spread, ey = y + 19;
      line(256, y, ex, ey, 3, 131);
      for (let n = 0; n < 20; n++) {
        const t = (n + .4) / 20, x = 256 + side * spread * t, yy = y + 19 * t;
        const len = 7 + rng()*10;
        line(x, yy, x + side * (7 + rng()*8), Math.min(248, yy + len), 1.5 + rng(), 125 + Math.floor(rng()*80));
        line(x, yy, x + side * (8 + rng()*7), Math.max(20, yy - len*.65), 1.3 + rng(), 105 + Math.floor(rng()*65));
      }
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 2;
  return tex;
}

export function buildTrees(quality, forest) {
  const tex = texture();
  const matPine = lit({ map: pineTexture(tex), alphaTest: .32, vertexColors: true, side: THREE.DoubleSide, wind: 0.12 });
  const matDead = lit({ map: tex, vertexColors: true, side: THREE.DoubleSide, wind: 0.018 });
  const matBirch = lit({ map: tex, vertexColors: true, side: THREE.DoubleSide, wind: 0.16 });

  const P = (o, seed) => pineGeo(o, seed);
  const pineBase = { H: 10.5, h0: 2.9, R: 2.3, trunk: 0.3 };
  const tallBase = { H: 15.5, h0: 4.4, R: 2.5, trunk: 0.32 };
  // kind -> list of mesh definitions by lod. Variants are picked by tree index.
  const pine = (base, tiers, sides, seed, detail) => P({ ...base, tiers, sides, mid: detail, trunkSides: detail ? 6 : 4 }, seed);
  const deadDetailed = [deadGeo(31, true), deadGeo(32, true)];
  const birchDetailed = [birchGeo(41, 6, 5), birchGeo(42, 5, 4)];
  const defs = {
    pine: [
      [pine(pineBase, 6, 7, 11, true), pine(pineBase, 6, 7, 12, true)],
      [pine(pineBase, 6, 7, 11, false), pine(pineBase, 6, 7, 12, false)],
      [pine(pineBase, 4, 5, 11, false), pine(pineBase, 4, 5, 12, false)],
    ],
    tallpine: [
      [pine(tallBase, 8, 7, 21, true)],
      [pine(tallBase, 8, 7, 21, false)],
      [pine(tallBase, 5, 5, 21, false)],
    ],
    dead: [deadDetailed, deadDetailed, [deadGeo(31, false), deadGeo(32, false)]],
    birch: [birchDetailed, birchDetailed, [birchGeo(41, 3, 0), birchGeo(42, 3, 0)]],
  };
  const mats = { pine: matPine, tallpine: matPine, dead: matDead, birch: matBirch };
  const KINDS = ['pine', 'tallpine', 'dead', 'birch'];

  // Instance-matrix store for every tree.
  const trees = forest.trees;
  const n = trees.length;
  const mtx = new Float32Array(n * 16);
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(), p = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0);
  const rng = makeRng(77);
  trees.forEach((t, i) => {
    const sxz = t.scale * (0.86 + rng() * 0.3);
    q.setFromAxisAngle(up, t.rot);
    s.set(sxz, t.scale * (0.92 + rng() * 0.16), sxz);
    p.set(t.x, t.y, t.z);
    m.compose(p, q, s);
    m.toArray(mtx, i * 16);
    t._kind = KINDS.indexOf(t.kind);
    t._var = i;
  });

  const group = new THREE.Group();
  group.name = 'trees';
  // Capacity per instanced mesh: generous, clamped.
  const cap = [Math.min(n, 700), Math.min(n, 1200), Math.min(n, 2200)];
  const meshes = {}; // meshes[kind][lod] = [InstancedMesh per variant]
  const uniqueMeshes = [];
  for (const kind of KINDS) {
    const shared = new Map();
    meshes[kind] = defs[kind].map((geos, lod) => {
      // Identical near/middle silhouettes share one draw without changing their geometry.
      return geos.map((g) => {
        if (shared.has(g)) return shared.get(g);
        const capacity = Math.min(n, defs[kind].reduce((sum, row, i) => sum + (row.includes(g) ? cap[i] : 0), 0));
        const im = new THREE.InstancedMesh(g, mats[kind], capacity);
        im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
        im.frustumCulled = false;
        im.count = 0;
        im.name = `${kind}-lod${lod}`;
        group.add(im);
        uniqueMeshes.push(im);
        shared.set(g, im);
        return im;
      });
    });
  }

  // Sectors of 30 m.
  const SEC = 30, SH = 180, NS = Math.ceil((SH * 2) / SEC);
  const sectors = Array.from({ length: NS * NS }, () => []);
  trees.forEach((t, i) => {
    const sx = Math.min(NS - 1, Math.max(0, Math.floor((t.x + SH) / SEC)));
    const sz = Math.min(NS - 1, Math.max(0, Math.floor((t.z + SH) / SEC)));
    sectors[sz * NS + sx].push(i);
  });

  const dsc = 0.6 + 0.4 * (quality.trees ?? 1);
  const previousLod = new Int8Array(n).fill(-1);
  const D0 = 26 * dsc, D1 = 58 * dsc, D2 = 98 * dsc;
  const visSig = new Uint8Array(NS * NS);
  const curSig = new Uint8Array(NS * NS);
  const lastCam = new THREE.Vector3(1e9, 0, 0);
  const counts = {};
  let overflow = 0;

  function update(camera) {
    const fr = cameraFrustum(camera);
    const cp = camera.position;
    let changed = cp.distanceToSquared(lastCam) > 1.4;
    for (let k = 0; k < sectors.length; k++) {
      const sx = k % NS, sz = Math.floor(k / NS);
      const cx = -SH + (sx + 0.5) * SEC, cz = -SH + (sz + 0.5) * SEC;
      const d = Math.hypot(cx - cp.x, cz - cp.z);
      const v = sectors[k].length && d < D2 + 22 && (d < 34 || sphereVisible(fr, cx, 7, cz, 24)) ? 1 : 0;
      curSig[k] = v;
      if (v !== visSig[k]) changed = true;
    }
    if (!changed) return;
    visSig.set(curSig);
    lastCam.copy(cp);
    for (const im of uniqueMeshes) counts[im.name + im.id] = 0;
    for (let k = 0; k < sectors.length; k++) {
      if (!curSig[k]) continue;
      for (const i of sectors[k]) {
        const t = trees[i];
        const d = Math.hypot(t.x - cp.x, t.z - cp.z);
        if (d > D2) continue;
        let lod = d < D0 ? 0 : d < D1 ? 1 : 2;
        const prior = previousLod[i];
        // Hysteresis prevents a tree flickering between two forms during small camera movements.
        if (prior >= 0 && prior !== lod) {
          const boundary = Math.min(prior, lod) === 0 ? D0 : D1;
          if (Math.abs(d - boundary) < 3) lod = prior;
        }
        previousLod[i] = lod;
        const list = meshes[KINDS[t._kind]][lod];
        const im = list[t._var % list.length];
        const key = im.name + im.id;
        const c = counts[key];
        if (c >= im.instanceMatrix.count) {
          overflow++;
          continue;
        }
        im.instanceMatrix.array.set(mtx.subarray(i * 16, i * 16 + 16), c * 16);
        counts[key] = c + 1;
      }
    }
    for (const im of uniqueMeshes) {
      im.count = counts[im.name + im.id];
      im.instanceMatrix.needsUpdate = true;
    }
  }

  function stats() {
    let inst = 0, tris = 0;
    for (const im of uniqueMeshes) {
      inst += im.count;
      tris += (im.geometry.attributes.position.count / 3) * im.count;
    }
    return { instances: inst, triangles: Math.round(tris), overflow };
  }

  return { group, update, stats };
}
