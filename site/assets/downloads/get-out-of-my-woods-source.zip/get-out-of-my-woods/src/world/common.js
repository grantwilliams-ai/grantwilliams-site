// Small shared helpers for the world module: geometry builder, moon-shadow vector, frustum test.
import * as THREE from 'three';
import { MOON_DIR } from '../render/palette.js';

// Horizontal displacement of a shadow per metre of caster height (moon is MOON_DIR above the horizon).
const hLen = Math.hypot(MOON_DIR[0], MOON_DIR[2]);
export const SHADOW_DIR = [-MOON_DIR[0] / hLen, -MOON_DIR[2] / hLen]; // unit, on the ground
export const SHADOW_PER_M = hLen / MOON_DIR[1];

export const smooth = (a, b, x) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};
export const lerp = (a, b, t) => a + (b - a) * t;
export const clamp = (x, a, b) => Math.min(b, Math.max(a, x));

// Non-indexed triangle soup with vertex colours and uvs.
export class GeoBuilder {
  constructor() {
    this.pos = [];
    this.col = [];
    this.uv = [];
  }

  vert(p, c, uv) {
    this.pos.push(p[0], p[1], p[2]);
    this.col.push(c[0], c[1], c[2]);
    this.uv.push(uv[0], uv[1]);
  }

  tri(a, b, c, ca, cb = ca, cc = ca, ua = [0, 0], ub = [1, 0], uc = [0.5, 1]) {
    this.vert(a, ca, ua);
    this.vert(b, cb, ub);
    this.vert(c, cc, uc);
  }

  quad(a, b, c, d, ca, cb = ca, cc = ca, cd = ca, uvs = [[0, 0], [1, 0], [1, 1], [0, 1]]) {
    this.tri(a, b, c, ca, cb, cc, uvs[0], uvs[1], uvs[2]);
    this.tri(a, c, d, ca, cc, cd, uvs[0], uvs[2], uvs[3]);
  }

  // Tapered prism along +y from y0 to y1. off shifts the top ring, base shifts the whole thing.
  prism(r0, r1, y0, y1, sides, c0, c1, uvRegion, off = [0, 0], base = [0, 0]) {
    const [u0, u1, v0, v1] = uvRegion;
    const p = (a, r, y, o) => [base[0] + o[0] + Math.cos(a) * r, y, base[1] + o[1] + Math.sin(a) * r];
    for (let i = 0; i < sides; i++) {
      const a0 = (i / sides) * Math.PI * 2, a1 = ((i + 1) / sides) * Math.PI * 2;
      const A = p(a0, r0, y0, [0, 0]), B = p(a1, r0, y0, [0, 0]);
      const C = p(a1, r1, y1, off), D = p(a0, r1, y1, off);
      const ua = u0 + (u1 - u0) * (i / sides), ub = u0 + (u1 - u0) * ((i + 1) / sides);
      this.quad(A, B, C, D, c0, c0, c1, c1, [[ua, v0], [ub, v0], [ub, v1], [ua, v1]]);
    }
  }

  // Axis-aligned box, all six faces.
  box(cx, cy, cz, hx, hy, hz, c, uv = [0, 1, 0, 1]) {
    const [u0, u1, v0, v1] = uv;
    const f = (a, b, cc, d) => this.quad(a, b, cc, d, c, c, c, c, [[u0, v0], [u1, v0], [u1, v1], [u0, v1]]);
    const x0 = cx - hx, x1 = cx + hx, y0 = cy - hy, y1 = cy + hy, z0 = cz - hz, z1 = cz + hz;
    f([x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0]); // top
    f([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]); // bottom
    f([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]); // +z
    f([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0]); // -z
    f([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1]); // +x
    f([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]); // -x
  }

  build() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.col, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2));
    g.computeVertexNormals();
    g.computeBoundingSphere();
    g.computeBoundingBox();
    return g;
  }
}

// Linear colour from sRGB hex, as an array.
export const hexLin = (hex) => {
  const c = new THREE.Color(hex);
  return [c.r, c.g, c.b];
};
export const mulc = (c, k) => [c[0] * k, c[1] * k, c[2] * k];
export const mixc = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

const _frustum = new THREE.Frustum();
const _pv = new THREE.Matrix4();
const _sph = new THREE.Sphere();
export function cameraFrustum(camera) {
  camera.updateMatrixWorld();
  _pv.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse);
  return _frustum.setFromProjectionMatrix(_pv);
}
export function sphereVisible(frustum, x, y, z, r) {
  _sph.center.set(x, y, z);
  _sph.radius = r;
  return frustum.intersectsSphere(_sph);
}

// Periodic value-noise tile as Float32 0..1, so patterns tile without seams.
export function noiseTile(n, cells, seed) {
  let s = seed >>> 0;
  const rnd = () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
  const lat = new Float32Array(cells * cells);
  for (let i = 0; i < lat.length; i++) lat[i] = rnd();
  const out = new Float32Array(n * n);
  const g = (a, b) => lat[(b % cells) * cells + (a % cells)];
  for (let y = 0; y < n; y++) {
    for (let x = 0; x < n; x++) {
      const fx = (x / n) * cells, fy = (y / n) * cells;
      const ix = Math.floor(fx), iy = Math.floor(fy);
      const tx = fx - ix, ty = fy - iy;
      const u = tx * tx * (3 - 2 * tx), v = ty * ty * (3 - 2 * ty);
      const a = g(ix, iy), b = g(ix + 1, iy), c = g(ix, iy + 1), d = g(ix + 1, iy + 1);
      out[y * n + x] = a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
    }
  }
  return out;
}

export const groundSize = (q) => (q.tier === 'high' ? 2048 : q.tier === 'med' ? 1536 : 1024);
