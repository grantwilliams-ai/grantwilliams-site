// Warm light, which is rare and precious: the fire, lanterns, yard lights.
// Three real point lights, always present (so shaders never recompile), reassigned each frame to the
// most relevant sources. Everything else is painted: glow billboards, light pools on the ground,
// a faint cone under each yard light, embers off the fire.
import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { PALETTE } from '../render/palette.js';
import { GLOBALS } from '../render/materials.js';
import { LIGHTS, BUILDINGS } from '../sim/layout.js';
import { heightAt, surfaceY } from '../sim/terrain.js';
import { GeoBuilder, hexLin, mulc } from './common.js';
import { lit } from '../render/materials.js';

function radialTexture(size, stops) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d');
  const gr = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  for (const [t, a] of stops) gr.addColorStop(t, `rgba(255,255,255,${a})`);
  g.fillStyle = gr;
  g.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function flameTexture() {
  const s = 64;
  const c = document.createElement('canvas');
  c.width = s; c.height = s * 2;
  const g = c.getContext('2d');
  // A tongue of flame built from stacked soft blobs: bright yellow-white at the base, orange, then red wisps.
  g.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 9; i++) {
    const t = i / 8;
    const cy = s * 2 * (0.82 - t * 0.7);
    const rx = s * (0.36 - t * 0.27), ry = s * (0.5 - t * 0.28);
    const sway = Math.sin(t * 3.0) * s * 0.07;
    g.save();
    g.translate(s / 2 + sway, cy);
    g.scale(rx / ry, 1);
    const gr = g.createRadialGradient(0, 0, 0, 0, 0, ry);
    const col = t < 0.3 ? '255,226,150' : t < 0.65 ? '255,140,36' : '200,50,10';
    gr.addColorStop(0, `rgba(${col},${0.7 - t * 0.35})`);
    gr.addColorStop(1, `rgba(${col},0)`);
    g.fillStyle = gr;
    g.fillRect(-ry, -ry, ry * 2, ry * 2);
    g.restore();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

const BILL_VERT = /* glsl */ `
varying vec2 vUv;
varying vec3 vCol;
void main() {
  vec3 c = vec3(instanceMatrix[3]);
  vec2 sz = vec2(length(instanceMatrix[0].xyz), length(instanceMatrix[1].xyz));
  vec4 mv = viewMatrix * vec4(c, 1.0);
  mv.xy += position.xy * sz;
  gl_Position = projectionMatrix * mv;
  vUv = uv;
  vCol = instanceColor;
}`;
const BILL_FRAG = /* glsl */ `
uniform sampler2D uMap;
varying vec2 vUv;
varying vec3 vCol;
void main() {
  vec4 t = texture2D(uMap, vUv);
  gl_FragColor = vec4(t.rgb * vCol, t.a);
}`;

function billboards(map, cap) {
  const mat = new THREE.ShaderMaterial({
    uniforms: { uMap: { value: map } },
    vertexShader: BILL_VERT,
    fragmentShader: BILL_FRAG,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    fog: false,
  });
  const im = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1), mat, cap);
  im.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(cap * 3), 3);
  im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  im.instanceColor.setUsage(THREE.DynamicDrawUsage);
  im.frustumCulled = false;
  im.renderOrder = 6;
  return im;
}

// A terrain-following disc of light on the ground, merged into one geometry.
function poolGeo(list) {
  const pos = [], uv = [], col = [], idx = [];
  const n = 10;
  for (const p of list) {
    const base = pos.length / 3;
    for (let j = 0; j <= n; j++) {
      for (let i = 0; i <= n; i++) {
        const x = p.x + (i / n - 0.5) * 2 * p.r, z = p.z + (j / n - 0.5) * 2 * p.r;
        pos.push(x, heightAt(x, z) + 0.07, z);
        uv.push(i / n, j / n);
        col.push(...p.col);
      }
    }
    for (let j = 0; j < n; j++) {
      for (let i = 0; i < n; i++) {
        const a = base + j * (n + 1) + i;
        idx.push(a, a + n + 1, a + 1, a + 1, a + n + 1, a + n + 2);
      }
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.setIndex(idx);
  return g;
}

export function buildLights(quality) {
  const group = new THREE.Group();
  group.name = 'lights';
  const glowTex = radialTexture(64, [[0, 1], [0.2, 0.55], [0.5, 0.16], [1, 0]]);
  const poolTex = radialTexture(64, [[0, 0.9], [0.4, 0.5], [0.75, 0.14], [1, 0]]);

  const fireC = hexLin(PALETTE.fire), lanC = hexLin(PALETTE.lantern);
  const sources = [];
  const housing = new GeoBuilder(), bulbs = new GeoBuilder();
  const metal = hexLin(0x15171a), woodC = hexLin(0x2f2318);
  const pools = [], poolsFire = [];
  const coneAt = []; // the faint light under each yard lamp
  let fire = null;

  for (const L of LIGHTS) {
    if (L.kind === 'window') continue;
    const pos = new THREE.Vector3(L.x, L.y, L.z);
    const ground = Math.max(surfaceY(L.x, L.z), heightAt(L.x, L.z));
    const src = { kind: L.kind, pos, ground, phase: Math.random() * 100 };
    if (L.kind === 'fire') {
      Object.assign(src, { color: new THREE.Color(PALETTE.fire), intensity: 17, distance: 24, glow: 3.4 });
      poolsFire.push({ x: L.x, z: L.z, r: 9, col: mulc(fireC, 0.17) });
      fire = src;
    } else if (L.kind === 'lantern') {
      Object.assign(src, { color: new THREE.Color(PALETTE.lantern), intensity: 16, distance: 16, glow: 1.5 });
      pools.push({ x: L.x, z: L.z, r: 4.6, col: mulc(lanC, 0.55) });
      // a small cage lantern on a chain
      const y = L.y;
      housing.prism(0.015, 0.015, y + 0.17, y + 0.5, 4, metal, metal, [0, 1, 0, 1], [0, 0], [L.x, L.z]);
      housing.prism(0.13, 0.1, y - 0.16, y - 0.12, 6, metal, metal, [0, 1, 0, 1], [0, 0], [L.x, L.z]);
      housing.prism(0.04, 0.12, y + 0.12, y + 0.17, 6, metal, metal, [0, 1, 0, 1], [0, 0], [L.x, L.z]);
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI * 2 + 0.78;
        housing.prism(0.01, 0.01, y - 0.14, y + 0.13, 3, metal, metal, [0, 1, 0, 1], [0, 0], [L.x + Math.cos(a) * 0.1, L.z + Math.sin(a) * 0.1]);
      }
      bulbs.prism(0.07, 0.05, y - 0.1, y + 0.08, 6, hexLin(0xffe0a0), hexLin(0xffd080), [0, 1, 0, 1], [0, 0], [L.x, L.z]);
    } else if (L.kind === 'yardlight') {
      Object.assign(src, { color: new THREE.Color(0xffd9a0), intensity: 14, distance: 24, glow: 1.9, buzz: true });
      pools.push({ x: L.x, z: L.z, r: 7.5, col: mulc(hexLin(0xffd9a0), 0.2) });
      // wooden pole with an arm, lamp hanging at the arm's end
      const px = L.x + 1.0, pz = L.z;
      housing.prism(0.12, 0.09, ground - 0.3, L.y + 0.6, 6, woodC, mulc(woodC, 0.8), [0, 1, 0, 1], [0, 0], [px, pz]);
      housing.box(L.x + 0.5, L.y + 0.55, L.z, 0.55, 0.045, 0.045, woodC);
      housing.prism(0.34, 0.03, L.y + 0.06, L.y + 0.3, 8, metal, metal, [0, 1, 0, 1], [0, 0], [L.x, L.z]);
      bulbs.prism(0.09, 0.06, L.y - 0.08, L.y + 0.06, 6, hexLin(0xfff0c8), hexLin(0xffe0a0), [0, 1, 0, 1], [0, 0], [L.x, L.z]);
      coneAt.push({ x: L.x, top: L.y - 0.05, ground, z: L.z });
    }
    sources.push(src);
  }

  const mk = (gb, mat, name) => {
    if (!gb.pos.length) return null;
    const m = new THREE.Mesh(gb.build(), mat);
    m.name = name;
    m.frustumCulled = false;
    group.add(m);
    return m;
  };
  mk(housing, lit({ vertexColors: true }), 'light-fixtures');
  mk(bulbs, new THREE.MeshBasicMaterial({ vertexColors: true, fog: false }), 'light-bulbs');
  if (coneAt.length) {
    // Soft at the edges and gone when you stand under it: a shape in the mist, never a solid tent.
    const geos = coneAt.map((c) => {
      const h = c.top - c.ground, g = new THREE.ConeGeometry(4.2, h, 18, 1, true);
      g.translate(c.x, c.ground + h / 2, c.z);
      return g;
    });
    const mat = new THREE.ShaderMaterial({
      vertexShader: /* glsl */ `
        varying float vAlong; varying vec3 vN; varying vec3 vV;
        void main() {
          vAlong = uv.y;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          vN = normalize(normalMatrix * normal);
          vV = -mv.xyz;
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: /* glsl */ `
        varying float vAlong; varying vec3 vN; varying vec3 vV;
        void main() {
          float d = length(vV);
          float rim = pow(abs(dot(normalize(vN), vV / d)), 2.6);
          float near = smoothstep(3.0, 11.0, d);
          gl_FragColor = vec4(vec3(1.0, 0.8, 0.52) * rim * vAlong * vAlong * near * 0.1, 1.0);
        }`,
      blending: THREE.AdditiveBlending,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const coneMesh = new THREE.Mesh(mergeGeometries(geos), mat);
    coneMesh.name = 'light-cones';
    coneMesh.renderOrder = 5;
    group.add(coneMesh);
    geos.forEach((g) => g.dispose());
  }

  const poolMat = (o) => new THREE.MeshBasicMaterial({ map: poolTex, vertexColors: true, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, fog: false, opacity: o, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
  const poolMesh = new THREE.Mesh(poolGeo(pools), poolMat(1));
  poolMesh.renderOrder = 3;
  poolMesh.frustumCulled = false;
  group.add(poolMesh);
  const firePool = new THREE.Mesh(poolGeo(poolsFire), poolMat(1));
  firePool.renderOrder = 3;
  firePool.frustumCulled = false;
  group.add(firePool);

  // Glow billboards: one per source, plus a wide halo for the fire.
  const glows = billboards(glowTex, 16);
  group.add(glows);
  const flames = billboards(flameTexture(), 8);
  group.add(flames);
  const flameN = 6;

  // Embers: GPU-animated points.
  const EM = quality.tier === 'low' ? 24 : 48;
  let embers = null;
  if (fire) {
    const g = new THREE.BufferGeometry();
    const seeds = new Float32Array(EM * 4);
    for (let i = 0; i < seeds.length; i++) seeds[i] = Math.random();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(EM * 3), 3));
    g.setAttribute('seed', new THREE.BufferAttribute(seeds, 4));
    embers = new THREE.Points(g, new THREE.ShaderMaterial({
      uniforms: { uTime: GLOBALS.uTime, uWind: GLOBALS.uWind, uBase: { value: new THREE.Vector3(fire.pos.x, fire.ground + 0.5, fire.pos.z) } },
      vertexShader: /* glsl */ `
        attribute vec4 seed;
        uniform float uTime; uniform float uWind; uniform vec3 uBase;
        varying float vA;
        void main() {
          float life = fract(uTime * (0.12 + seed.y * 0.16) + seed.x);
          float a = seed.z * 6.283 + uTime * 0.3;
          vec3 p = uBase + vec3(cos(a) * seed.w * 0.5 * (0.3 + life), life * (2.0 + seed.y * 3.5), sin(a) * seed.w * 0.5 * (0.3 + life));
          p.x += life * life * 1.8 * uWind + sin(uTime * 2.0 + seed.x * 30.0) * 0.15 * life;
          p.z += life * life * 0.6 + cos(uTime * 1.7 + seed.z * 30.0) * 0.15 * life;
          vA = (1.0 - life) * smoothstep(0.0, 0.05, life);
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = (2.0 + seed.y * 2.5) * (0.5 + vA * 0.5);
        }`,
      fragmentShader: /* glsl */ `
        varying float vA;
        void main() {
          gl_FragColor = vec4(mix(vec3(1.0, 0.25, 0.04), vec3(1.0, 0.75, 0.3), vA) * 2.0, vA);
        }`,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      fog: false,
    }));
    embers.frustumCulled = false;
    embers.renderOrder = 7;
    group.add(embers);
  }

  // Three point lights, always present.
  const points = [0, 1, 2].map(() => {
    const l = new THREE.PointLight(0xffffff, 0, 20, 2);
    l.castShadow = false;
    group.add(l);
    return l;
  });

  const m4 = new THREE.Matrix4(), qI = new THREE.Quaternion(), sv = new THREE.Vector3(), pv = new THREE.Vector3();
  const tmpC = new THREE.Color();
  const order = sources.map((s, i) => i);
  const fill = { active: false, pos: new THREE.Vector3(), radius: 6, amount: 0 };

  // Smooth flicker in 0..~1.3
  const fireFlicker = (t, ph) => 1 + 0.16 * Math.sin(t * 17.3 + ph) + 0.11 * Math.sin(t * 29.1 + ph * 2) + 0.08 * Math.sin(t * 7.1 + ph * 3) + (Math.random() - 0.5) * 0.12;
  const buzz = (t, ph) => {
    const k = (Math.sin(t * 0.7 + ph) + Math.sin(t * 1.93 + ph * 1.7)) * 0.5;
    const dip = k > 0.93 ? 0.35 + 0.65 * Math.abs(Math.sin(t * 43)) : 1; // an old lamp, now and then failing
    return dip * (0.97 + 0.03 * Math.sin(t * 120));
  };

  function update(dt, time, cam, lightMul, storm) {
    // Flicker values per source.
    for (const s of sources) {
      s.flick = s.kind === 'fire' ? fireFlicker(time, s.phase) : s.buzz ? buzz(time, s.phase) : 1 + 0.035 * Math.sin(time * 5.1 + s.phase) + 0.02 * Math.sin(time * 13 + s.phase);
      s.flick *= 1 + storm * 0.1 * Math.sin(time * 3.1 + s.phase * 2);
      s.score = (s.intensity * s.flick) / (cam.distanceToSquared(s.pos) + 9);
    }
    order.sort((a, b) => sources[b].score - sources[a].score);
    // Assign the best three sources. Indoors, slot 0 is the room's fill light instead.
    let slot = 0;
    if (fill.amount > 0.001) {
      const p = points[0];
      p.position.copy(fill.pos);
      p.color.set(0xffc890);
      p.intensity = 5.5 * fill.amount;
      p.distance = fill.radius * 2.6;
      slot = 1;
    } else {
      points[0].intensity = 0;
    }
    for (let k = 0; slot < 3; slot++, k++) {
      const s = sources[order[k]];
      const p = points[slot];
      if (!s) {
        p.intensity = 0;
        continue;
      }
      p.position.copy(s.pos);
      p.color.copy(s.color);
      p.intensity = s.intensity * s.flick * lightMul;
      p.distance = s.distance;
    }

    // Glow billboards and the fire.
    let gi = 0;
    const camP = cam;
    for (const s of sources) {
      const d = camP.distanceTo(s.pos);
      const far = Math.exp(-Math.pow(d / 120, 2));
      const k = s.flick * far * lightMul;
      tmpC.copy(s.color).multiplyScalar(0.8 * k);
      sv.set(s.glow, s.glow, 1);
      pv.copy(s.pos);
      m4.compose(pv, qI, sv);
      glows.setMatrixAt(gi, m4);
      glows.setColorAt(gi, tmpC);
      gi++;
      if (s.kind === 'fire') {
        sv.set(s.glow * 3.2, s.glow * 3.2, 1);
        pv.set(s.pos.x, s.pos.y + 0.8, s.pos.z);
        m4.compose(pv, qI, sv);
        glows.setMatrixAt(gi, m4);
        tmpC.copy(s.color).multiplyScalar(0.16 * k);
        glows.setColorAt(gi, tmpC);
        gi++;
      }
    }
    glows.count = gi;
    glows.instanceMatrix.needsUpdate = true;
    glows.instanceColor.needsUpdate = true;
    if (fire) {
      const far = Math.exp(-Math.pow(camP.distanceTo(fire.pos) / 120, 2));
      for (let i = 0; i < flameN; i++) {
        const ph = i * 1.7;
        const h = 1.2 + 0.6 * Math.abs(Math.sin(time * (5 + i) + ph)) + 0.3 * Math.sin(time * 11 + ph * 3) + (i < 2 ? 0.6 : 0);
        const w = (i < 2 ? 0.95 : 0.65) * (0.9 + 0.2 * Math.sin(time * 8 + ph));
        const a = (i / flameN) * Math.PI * 2 + time * 0.2;
        const rad = i < 2 ? 0.0 : 0.38;
        pv.set(fire.pos.x + Math.cos(a) * rad + Math.sin(time * 3 + ph) * 0.05, fire.ground + 0.28 + h * 0.5, fire.pos.z + Math.sin(a) * rad);
        sv.set(w, h, 1);
        m4.compose(pv, qI, sv);
        flames.setMatrixAt(i, m4);
        tmpC.setRGB(1.5, 1.3, 1.1).multiplyScalar((0.85 + 0.15 * Math.sin(time * 13 + ph)) * far * lightMul);
        flames.setColorAt(i, tmpC);
      }
      flames.count = flameN;
      flames.instanceMatrix.needsUpdate = true;
      flames.instanceColor.needsUpdate = true;
      firePool.material.opacity = (0.55 + 0.35 * fire.flick) * lightMul;
    }
    poolMesh.material.opacity = lightMul;
    for (const s of sources) if (s.buzz) poolMesh.material.opacity = lightMul * (0.75 + 0.25 * s.flick);
  }

  return { group, update, points, sources, fire, fill };
}
