// Ground cover: ferns, grass tufts, bushes and rocks around the camera, and the tall brush at every
// hide spot. All alpha-tested crossed cards in a few InstancedMeshes, rebuilt as the camera moves.
import * as THREE from 'three';
import { fbm, makeRng } from '../core/rng.js';
import { lit } from '../render/materials.js';
import { canvasTexture } from '../render/textures.js';
import { BUSH_HIDES, WATER_LEVEL } from '../sim/layout.js';
import { GRID_HALF, GRID_N, GRID_STEP, heightAt } from '../sim/terrain.js';
import { GeoBuilder, hexLin, mulc } from './common.js';
import { MASK } from './ground.js';

const W = [1, 1, 1];

function fernTexture() {
  return canvasTexture(256, (g, s) => {
    // Draw in a small logical space but retain fine curved pinnae near the
    // camera. Positions, footprint and the five-card mesh stay unchanged.
    g.scale(s / 64, s / 64);
    const rng = makeRng(5);
    g.lineCap = 'round';
    g.strokeStyle = '#c7cfbd'; g.lineWidth = .75;
    g.beginPath(); g.moveTo(32, 63); g.quadraticCurveTo(30, 34, 36, 4); g.stroke();
    for (let i = 0; i < 19; i++) {
      const t = i / 18, y = 60 - t * 54;
      const sx = 32 + Math.sin(t * 2.4) * 3 - t * 2;
      const length = (1 - t * .85) * 24 + 2;
      for (const side of [-1, 1]) {
        const l = length * (.87 + rng() * .13), ey = y - 5 + t * 2;
        const v = 150 + Math.floor(rng() * 78);
        g.fillStyle = `rgb(${v},${v + 7},${v - 8})`;
        g.beginPath(); g.moveTo(sx, y + 1);
        g.quadraticCurveTo(sx + side * l * .35, y - 4, sx + side * l, ey);
        g.quadraticCurveTo(sx + side * l * .62, y + 1.8, sx, y + 1); g.fill();
        g.strokeStyle = 'rgba(232,238,217,.45)'; g.lineWidth = .23;
        g.beginPath(); g.moveTo(sx, y); g.lineTo(sx + side * l * .9, ey + .15); g.stroke();
      }
    }
  }, { nearest: false });
}

function grassTexture() {
  return canvasTexture(64, (g, s) => {
    const rng = makeRng(8);
    g.lineCap = 'round';
    for (let i = 0; i < 18; i++) {
      const x = 8 + rng() * 48, lean = (rng() - 0.5) * 22, h = 28 + rng() * 34;
      const v = 140 + Math.floor(rng() * 110);
      g.strokeStyle = `rgb(${v},${v},${v})`;
      g.lineWidth = 2.4;
      g.beginPath();
      g.moveTo(x, 63);
      g.quadraticCurveTo(x + lean * 0.3, 63 - h * 0.6, x + lean, 63 - h);
      g.stroke();
    }
  });
}

function leafTexture() {
  return canvasTexture(128, (g, s) => {
    const rng = makeRng(9);
    for (let i = 0; i < 260; i++) {
      const x = rng() * s, y = rng() * s;
      // fuller toward the middle so the card reads as a clump, ragged at the rim
      const dx = (x - s / 2) / (s / 2), dy = (y - s * 0.55) / (s * 0.5);
      if (dx * dx + dy * dy > 0.95 + rng() * 0.2) continue;
      const v = 90 + Math.floor(rng() * 165);
      g.fillStyle = `rgb(${v},${v},${v})`;
      g.save();
      g.translate(x, y);
      g.rotate(rng() * 6.28);
      g.beginPath();
      g.ellipse(0, 0, 3 + rng() * 5, 1.6 + rng() * 2.6, 0, 0, 6.28);
      g.fill();
      g.restore();
    }
  });
}

// A card: quad from base centre, width w, height h, yaw, lean (radians from vertical, outward).
function card(gb, cx, cy, cz, w, h, yaw, lean, c0, c1) {
  const ux = Math.cos(yaw), uz = Math.sin(yaw);       // along the card
  const fx = -Math.sin(yaw), fz = Math.cos(yaw);      // card normal (lean direction)
  const lx = fx * Math.sin(lean) * h, lz = fz * Math.sin(lean) * h, ly = Math.cos(lean) * h;
  const a = [cx - ux * w / 2, cy, cz - uz * w / 2], b = [cx + ux * w / 2, cy, cz + uz * w / 2];
  const c = [b[0] + lx, cy + ly, b[2] + lz], d = [a[0] + lx, cy + ly, a[2] + lz];
  gb.quad(a, b, c, d, c0, c0, c1, c1);
}

function fernGeo() {
  const gb = new GeoBuilder();
  const lo = mulc(W, 0.45), hi = mulc(W, 1);
  for (let i = 0; i < 5; i++) card(gb, 0, 0, 0, 1.0, 0.8, (i / 5) * Math.PI * 2, 0.6, lo, hi);
  return gb.build();
}
function grassGeo() {
  const gb = new GeoBuilder();
  const rng = makeRng(808);
  // Short tapered blades, not tall crossed silhouette cards. Only ten triangles per tuft.
  for (let i = 0; i < 10; i++) {
    const a = rng() * Math.PI * 2, r = Math.sqrt(rng()) * 0.22;
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    const h = 0.18 + rng() * 0.22, w = 0.012 + rng() * 0.018;
    const lean = 0.06 + rng() * 0.1;
    gb.tri([x - Math.cos(a) * w, 0, z - Math.sin(a) * w],
      [x + Math.cos(a) * w, 0, z + Math.sin(a) * w],
      [x - Math.sin(a) * lean, h, z + Math.cos(a) * lean],
      mulc(W, 0.64), mulc(W, 0.64), mulc(W, 0.92 + rng() * 0.18));
  }
  return gb.build();
}
function bushGeo() {
  const gb = new GeoBuilder();
  const lo = mulc(W, 0.35), hi = mulc(W, 1);
  for (let i = 0; i < 6; i++) card(gb, 0, 0, 0, 1.7, 1.2, (i / 6) * Math.PI * 2 + 0.3, 0.25 + (i % 2) * 0.25, lo, hi);
  for (let i = 0; i < 2; i++) card(gb, 0, 0.75, 0, 1.4, 1.2, i * 1.5, 1.35, hi, hi);
  return gb.build();
}
// The hide: a hollow ring of tall leaf walls, closed overhead, with the middle empty for a person.
function hideGeo() {
  const gb = new GeoBuilder();
  const lo = mulc(W, 0.35), hi = mulc(W, 1);
  const n1 = 9, n2 = 11;
  for (let i = 0; i < n1; i++) {
    const a = (i / n1) * Math.PI * 2;
    card(gb, Math.cos(a) * 0.95, 0, Math.sin(a) * 0.95, 1.45, 2.2, a + Math.PI / 2, 0.2, lo, hi);
  }
  for (let i = 0; i < n2; i++) {
    const a = ((i + 0.5) / n2) * Math.PI * 2;
    card(gb, Math.cos(a) * 1.45, 0, Math.sin(a) * 1.45, 1.6, 2.0, a + Math.PI / 2, 0.12, lo, hi);
  }
  for (let i = 0; i < 6; i++) {
    const a = ((i + 0.3) / 6) * Math.PI * 2;
    card(gb, Math.cos(a) * 1.05, 1.55, Math.sin(a) * 1.05, 1.4, 1.1, a + Math.PI / 2, 0.95, hi, hi);
  }
  return gb.build();
}

function rockGeo() {
  const rng = makeRng(13);
  const g = new THREE.IcosahedronGeometry(1, 0);
  const pos = g.attributes.position;
  const seen = new Map();
  for (let i = 0; i < pos.count; i++) {
    const key = `${pos.getX(i).toFixed(3)},${pos.getY(i).toFixed(3)},${pos.getZ(i).toFixed(3)}`;
    if (!seen.has(key)) seen.set(key, 0.75 + rng() * 0.5);
    const k = seen.get(key);
    pos.setXYZ(i, pos.getX(i) * k, pos.getY(i) * k * 0.8, pos.getZ(i) * k);
  }
  g.computeVertexNormals();
  return g;
}

const hash = (a, b, c) => {
  let h = Math.imul(a, 374761393) + Math.imul(b, 668265263) + Math.imul(c, 2147483647);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};

export function buildCover(quality, forest, mask) {
  const group = new THREE.Group();
  group.name = 'cover';
  const tier = quality.tier;
  const fernR = tier === 'high' ? 26 : tier === 'med' ? 20 : 15;
  const grassR = tier === 'high' ? 15 : tier === 'med' ? 12 : 9;
  const bushR = tier === 'high' ? 62 : 50;
  const rockR = 70;

  const mk = (geo, tex, tint, wind, cap) => {
    const mat = lit({ map: tex, vertexColors: true, color: tint, side: THREE.DoubleSide, alphaTest: 0.5, wind });
    const im = new THREE.InstancedMesh(geo, mat, cap);
    im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    im.frustumCulled = false;
    im.count = 0;
    group.add(im);
    return im;
  };
  const ferns = mk(fernGeo(), fernTexture(), 0x3a5a45, 7, 1400);
  const grass = mk(grassGeo(), null, 0x56654a, 5, 1400);
  grass.material.emissive.set(0x152019);
  grass.material.emissiveIntensity = 0.3;
  const bushes = mk(bushGeo(), leafTexture(), 0x233829, 3, 700);
  const hides = mk(hideGeo(), leafTexture(), 0x28402b, 2, BUSH_HIDES.length);
  const rocks = new THREE.InstancedMesh(rockGeo(), lit({ color: 0x4a4e52 }), Math.max(1, forest.rocks.length));
  rocks.frustumCulled = false;
  rocks.count = 0;
  group.add(rocks);

  // Hide brush is static.
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(), p = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0);
  BUSH_HIDES.forEach((h, i) => {
    q.setFromAxisAngle(up, hash(i, 3, 3) * 6.28);
    s.set(1, 1, 1);
    p.set(h.x, heightAt(h.x, h.z) - 0.05, h.z);
    hides.setMatrixAt(i, m.compose(p, q, s));
  });
  hides.count = BUSH_HIDES.length;
  hides.instanceMatrix.needsUpdate = true;

  const maskAt = (x, z) => {
    const i = Math.round((x + GRID_HALF) / GRID_STEP), j = Math.round((z + GRID_HALF) / GRID_STEP);
    if (i < 0 || j < 0 || i >= GRID_N || j >= GRID_N) return 255;
    return mask[j * GRID_N + i];
  };

  const last = new THREE.Vector3(1e9, 0, 1e9);
  const CELL = 2.4;

  function scatter(im, radius, perCell, minScale, maxScale, salt, blocked, patchFreq) {
    const cp = last;
    const c0 = Math.floor((cp.x - radius) / CELL), c1 = Math.floor((cp.x + radius) / CELL);
    const r0 = Math.floor((cp.z - radius) / CELL), r1 = Math.floor((cp.z + radius) / CELL);
    let n = 0;
    const cap = im.instanceMatrix.count;
    for (let cj = r0; cj <= r1; cj++) {
      for (let ci = c0; ci <= c1; ci++) {
        const cx = (ci + 0.5) * CELL, cz = (cj + 0.5) * CELL;
        if (Math.hypot(cx - cp.x, cz - cp.z) > radius) continue;
        const patch = fbm(cx * patchFreq, cz * patchFreq, salt, 2);
        const count = Math.round(perCell * (0.15 + patch * 1.5));
        for (let k = 0; k < count; k++) {
          const x = (ci + hash(ci, cj, salt + k * 7)) * CELL, z = (cj + hash(ci, cj, salt + k * 7 + 3)) * CELL;
          if (Math.hypot(x - cp.x, z - cp.z) > radius) continue;
          if (maskAt(x, z) & blocked) continue;
          const y = heightAt(x, z);
          if (y < WATER_LEVEL + 0.25) continue;
          // fade out by shrinking toward the radius so there is no visible pop
          const edge = 1 - Math.max(0, (Math.hypot(x - cp.x, z - cp.z) - radius * 0.7) / (radius * 0.3));
          const sc = (minScale + hash(ci, cj, salt + k * 7 + 5) * (maxScale - minScale)) * (0.3 + 0.7 * edge);
          q.setFromAxisAngle(up, hash(ci, cj, salt + k * 7 + 9) * 6.28);
          s.set(sc, sc * (0.8 + hash(ci, cj, k) * 0.5), sc);
          p.set(x, y - 0.03, z);
          m.compose(p, q, s);
          m.toArray(im.instanceMatrix.array, n * 16);
          if (++n >= cap) {
            im.count = n;
            im.instanceMatrix.needsUpdate = true;
            return;
          }
        }
      }
    }
    im.count = n;
    im.instanceMatrix.needsUpdate = true;
  }

  function update(camera) {
    const cp = camera.position;
    if (Math.hypot(cp.x - last.x, cp.z - last.z) < 2.2) return;
    last.set(cp.x, 0, cp.z);
    scatter(ferns, fernR, 2.3, 0.7, 1.35, 101, MASK.TRAIL | MASK.BARE | MASK.BUILD | MASK.WET | MASK.CLEAR, 0.05);
    scatter(grass, grassR, 3.2, 0.8, 1.2, 202, MASK.TRAIL | MASK.BARE | MASK.BUILD | MASK.WET, 0.07);
    // bushes: the forest's own list
    let n = 0;
    for (const b of forest.bushes) {
      const d = Math.hypot(b.x - cp.x, b.z - cp.z);
      if (d > bushR || n >= bushes.instanceMatrix.count) continue;
      q.setFromAxisAngle(up, b.rot);
      s.setScalar(b.scale * (d > bushR * 0.8 ? 1 - (d - bushR * 0.8) / (bushR * 0.2) : 1));
      p.set(b.x, b.y - 0.05, b.z);
      m.compose(p, q, s);
      m.toArray(bushes.instanceMatrix.array, n * 16);
      n++;
    }
    bushes.count = n;
    bushes.instanceMatrix.needsUpdate = true;
    n = 0;
    for (const r of forest.rocks) {
      const d = Math.hypot(r.x - cp.x, r.z - cp.z);
      if (d > rockR) continue;
      q.setFromAxisAngle(up, r.rot);
      s.set(r.r * 1.15, r.r * 0.75, r.r);
      p.set(r.x, r.y + r.r * 0.12, r.z);
      m.compose(p, q, s);
      m.toArray(rocks.instanceMatrix.array, n * 16);
      n++;
    }
    rocks.count = n;
    rocks.instanceMatrix.needsUpdate = true;
  }

  return { group, update };
}
