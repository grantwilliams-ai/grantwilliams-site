// Sky dome: horizon that equals the fog (same formula as src/render/fog.js, so far trees dissolve
// into it), stars, a big pale moon with halo, thin slow cloud that closes over as the storm rises.
import * as THREE from 'three';
import { PALETTE, MOON_DIR } from '../render/palette.js';
import { GLOBALS } from '../render/materials.js';

const v3 = (v) => `vec3(${v.map((n) => n.toFixed(5)).join(',')})`;

// Shared by the sky and the lake reflection. Needs uniforms: uTime, uStorm, uFlash, uFogCol, uZenith.
export const SKY_GLSL = /* glsl */ `
uniform float uTime;
uniform float uStorm;
uniform float uFlash;
uniform vec3 uFogCol;
uniform vec3 uZenith;
const vec3 MOON_DIR = ${v3(MOON_DIR)};

float sHash(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float sHash3(vec3 p) { p = fract(p * vec3(0.1031, 0.1030, 0.0973)); p += dot(p, p.yxz + 33.33); return fract((p.x + p.y) * p.z); }
float sNoise(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(sHash(i), sHash(i + vec2(1, 0)), f.x), mix(sHash(i + vec2(0, 1)), sHash(i + vec2(1, 1)), f.x), f.y);
}
float sFbm(vec2 p) {
  float s = 0.0, a = 0.5;
  for (int i = 0; i < 4; i++) { s += a * sNoise(p); p = p * 2.03 + 7.1; a *= 0.5; }
  return s;
}

// Same moon glow lobe the fog uses, so the horizon and the fog agree.
vec3 horizonColor(vec3 d) {
  float gMoon = pow(max(dot(d, MOON_DIR), 0.0), 5.0);
  return uFogCol * (1.0 + gMoon * 1.4);
}

// d is a unit direction. stars: draw stars and the moon disk.
vec3 skyColor(vec3 d, bool detail) {
  float e = max(d.y, 0.0);
  vec3 hz = horizonColor(d);
  vec3 col = mix(hz, uZenith, 1.0 - exp(-e * 2.4));
  // Clouds on a plane high above: thin wisps when calm, a lid when stormy.
  vec2 cuv = d.xz / (d.y + 0.22) * 0.9 + vec2(uTime * 0.006, uTime * 0.0035);
  float cn = sFbm(cuv * 1.3) * 0.7 + sFbm(cuv * 3.1 + 3.0) * 0.3;
  float cover = mix(0.6, 0.22, uStorm);
  float dens = smoothstep(cover, cover + 0.3, cn) * mix(0.42, 1.0, uStorm);
  dens *= smoothstep(0.0, 0.16, d.y);
  float m = dot(d, MOON_DIR);
  float moonVis = (1.0 - uStorm * 0.94);
  if (detail) {
    vec3 sp = d * 150.0;
    vec3 cell = floor(sp);
    float h = sHash3(cell);
    if (h > 0.984) {
      vec3 f = fract(sp) - 0.5;
      vec3 c = (vec3(sHash3(cell + 1.7), sHash3(cell + 3.1), sHash3(cell + 5.3)) - 0.5) * 0.5;
      float s = smoothstep(0.17, 0.0, length(f - c)) * (0.55 + 0.45 * sin(uTime * (1.5 + h * 5.0) + h * 99.0));
      col += vec3(0.75, 0.85, 1.0) * s * smoothstep(0.04, 0.3, d.y) * (1.0 - dens) * (1.0 - uStorm);
    }
  }
  // Moon: halo first, then the disk with faint maria.
  float halo = exp(-(1.0 - m) * 55.0) * 0.55 + exp(-(1.0 - m) * 7.0) * 0.16;
  col += vec3(0.42, 0.55, 0.85) * halo * moonVis * (1.0 - dens * 0.65);
  if (detail && m > 0.9975) {
    float disk = smoothstep(0.99835, 0.99865, m);
    vec3 a = normalize(cross(MOON_DIR, vec3(0.0, 1.0, 0.0)));
    vec3 b = cross(a, MOON_DIR);
    vec2 lp = vec2(dot(d, a), dot(d, b)) * 18.0;
    float mar = sFbm(lp * 2.2 + 4.0);
    vec3 mc = vec3(0.86, 0.92, 1.0) * (0.72 + 0.4 * smoothstep(0.35, 0.7, mar)) * 2.6;
    col = mix(col, mc, disk * moonVis * (1.0 - dens * 0.8));
  }
  // Cloud body: lit pale by the moon behind it, dark otherwise.
  vec3 cc = mix(uFogCol * 0.55, uFogCol * (1.0 + 0.9 * pow(max(m, 0.0), 4.0)) + vec3(0.04, 0.06, 0.1) * pow(max(m, 0.0), 12.0) * 6.0 * moonVis, 0.65);
  cc = mix(cc, hz * 0.7, uStorm * 0.5);
  col = mix(col, cc, dens * 0.8);
  col += vec3(0.75, 0.82, 1.0) * uFlash * (0.25 + dens * 0.8 + 0.2 * (1.0 - d.y));
  return col;
}
`;

export function buildSky(fogColor) {
  const uniforms = {
    uTime: GLOBALS.uTime,
    uStorm: { value: 0 },
    uFlash: { value: 0 },
    uFogCol: { value: fogColor },
    uZenith: { value: new THREE.Color(PALETTE.skyZenith).multiplyScalar(2.2) },
  };
  const mat = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: /* glsl */ `
      varying vec3 vDir;
      void main() {
        vDir = position;
        vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        gl_Position = p;
      }`,
    fragmentShader: /* glsl */ `
      ${SKY_GLSL}
      varying vec3 vDir;
      void main() {
        vec3 d = normalize(vDir);
        gl_FragColor = vec4(skyColor(d, true), 1.0);
      }`,
    side: THREE.BackSide,
    depthTest: false,
    depthWrite: false,
    fog: false,
  });
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(100, 28, 16), mat);
  mesh.renderOrder = -1000;
  mesh.frustumCulled = false;
  mesh.name = 'sky';
  return { mesh, uniforms };
}
