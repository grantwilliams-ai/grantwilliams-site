// The ground: one mesh from heightGrid (one draw call, indices rebuilt as the camera moves),
// one big painted canvas (paths, clearings, gravel, mud, baked moon shadows) and a tiling detail texture.
import * as THREE from 'three';
import { makeRng, WORLD_SEED } from '../core/rng.js';
import { lit } from '../render/materials.js';
import { BUILDINGS, CLEARINGS, TEMPLATES, TRAILS, WATER_LEVEL, localToWorld, CAR } from '../sim/layout.js';
import { GRID_HALF, GRID_N, GRID_STEP, heightGrid, nearestTrail } from '../sim/terrain.js';
import { SHADOW_DIR, SHADOW_PER_M, cameraFrustum, groundSize, noiseTile, sphereVisible } from './common.js';

export const PAINT_HALF = 150; // the painted canvas covers +-150 m; the mesh runs to +-180 and clamps

// Mask flags for 2 m cells, used by ground cover so nothing grows on paths or in the lake.
export const MASK = { TRAIL: 1, CLEAR: 2, BARE: 4, WET: 8, BUILD: 16 };

export function buildMask() {
  const m = new Uint8Array(GRID_N * GRID_N);
  for (let j = 0; j < GRID_N; j++) {
    for (let i = 0; i < GRID_N; i++) {
      const x = -GRID_HALF + i * GRID_STEP, z = -GRID_HALF + j * GRID_STEP;
      let f = 0;
      const h = heightGrid[j * GRID_N + i];
      if (h < WATER_LEVEL + 0.5) f |= MASK.WET;
      const nt = nearestTrail(x, z);
      if (nt.trail && nt.dist < nt.trail.width * 0.5 + 0.7) f |= nt.trail.kind === 'overgrown' ? 0 : MASK.TRAIL;
      for (const c of CLEARINGS) {
        const d = Math.hypot(x - c.x, z - c.z);
        if (d < c.r) f |= MASK.CLEAR;
        if ((c.id === 'lot' || c.id === 'gate') && d < c.r * 0.9) f |= MASK.BARE;
      }
      for (const b of BUILDINGS) {
        const t = TEMPLATES[b.template];
        if (Math.hypot(x - b.x, z - b.z) < Math.max(t.hx, t.hz) + 2.2) f |= MASK.BUILD;
      }
      m[j * GRID_N + i] = f;
    }
  }
  return m;
}

// Soft round brush with an optional grainy alpha, cached per colour.
function makeDab(rgb, grainy, rng) {
  const n = 64;
  const c = document.createElement('canvas');
  c.width = c.height = n;
  const g = c.getContext('2d', { willReadFrequently: true });
  const gr = g.createRadialGradient(n / 2, n / 2, 0, n / 2, n / 2, n / 2);
  const [r, gg, b] = rgb;
  gr.addColorStop(0, `rgba(${r},${gg},${b},1)`);
  gr.addColorStop(0.45, `rgba(${r},${gg},${b},0.8)`);
  gr.addColorStop(0.8, `rgba(${r},${gg},${b},0.25)`);
  gr.addColorStop(1, `rgba(${r},${gg},${b},0)`);
  g.fillStyle = gr;
  g.fillRect(0, 0, n, n);
  if (grainy) {
    const id = g.getImageData(0, 0, n, n);
    for (let i = 3; i < id.data.length; i += 4) id.data[i] *= 0.25 + rng() * 0.95;
    g.putImageData(id, 0, 0);
  }
  return c;
}

// Greyscale-alpha noise tile turned into a canvas of one colour, for pattern fills.
function noisePattern(n, cells, seed, rgb, lo, hi, gain) {
  const v = noiseTile(n, cells, seed);
  const c = document.createElement('canvas');
  c.width = c.height = n;
  const g = c.getContext('2d');
  const id = g.createImageData(n, n);
  for (let i = 0; i < n * n; i++) {
    id.data[i * 4] = rgb[0];
    id.data[i * 4 + 1] = rgb[1];
    id.data[i * 4 + 2] = rgb[2];
    id.data[i * 4 + 3] = Math.max(0, Math.min(1, (v[i] - lo) / (hi - lo))) * 255 * gain;
  }
  g.putImageData(id, 0, 0);
  return c;
}

// Densify a polyline to roughly `step` metre spacing, returning points with normals.
function densify(pts, step) {
  const out = [];
  for (let i = 0; i + 1 < pts.length; i++) {
    const [ax, az] = pts[i], [bx, bz] = pts[i + 1];
    const len = Math.hypot(bx - ax, bz - az);
    const n = Math.max(1, Math.ceil(len / step));
    const nx = -(bz - az) / len, nz = (bx - ax) / len;
    for (let k = 0; k < n; k++) out.push({ x: ax + ((bx - ax) * k) / n, z: az + ((bz - az) * k) / n, nx, nz });
  }
  const [lx, lz] = pts[pts.length - 1];
  const last = out[out.length - 1];
  out.push({ x: lx, z: lz, nx: last.nx, nz: last.nz });
  return out;
}

// A path wanders a little: smooth lateral offset along its length.
const wander = (i, seed) => Math.sin(i * 0.11 + seed) * 0.35 + Math.sin(i * 0.037 + seed * 2.3) * 0.5;

const TREE_SHAPE = {
  pine: { H: 10.5, h0: 3.0, R: 2.3 },
  tallpine: { H: 15.5, h0: 4.4, R: 2.5 },
  dead: { H: 8, h0: 4.5, R: 0.8 },
  birch: { H: 9, h0: 3.8, R: 1.7 },
};
export const treeShape = TREE_SHAPE;

export function paintGround(quality, forest) {
  const S = groundSize(quality);
  const K = S / (PAINT_HALF * 2);
  const rng = makeRng(WORLD_SEED + 77);
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = S;
  const ctx = canvas.getContext('2d');
  const X = (x) => (x + PAINT_HALF) * K, Y = (z) => (z + PAINT_HALF) * K;
  const dab = (sprite, x, z, rm, alpha) => {
    const r = rm * K;
    ctx.globalAlpha = alpha;
    ctx.drawImage(sprite, X(x) - r, Y(z) - r, r * 2, r * 2);
  };

  // Base: dark needle-litter and moss.
  ctx.fillStyle = '#26332c';
  ctx.fillRect(0, 0, S, S);
  const mossTile = noisePattern(256, 8, 11, [52, 70, 44], 0.42, 0.8, 0.55);
  const rustTile = noisePattern(256, 12, 29, [66, 46, 30], 0.5, 0.85, 0.4);
  const darkTile = noisePattern(256, 6, 47, [3, 6, 8], 0.35, 0.75, 0.75);
  const darkTile2 = noisePattern(256, 16, 53, [3, 6, 8], 0.4, 0.8, 0.5);
  const tiled = (tile, scale, alpha) => {
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.scale(scale, scale);
    ctx.fillStyle = ctx.createPattern(tile, 'repeat');
    ctx.fillRect(0, 0, S / scale, S / scale);
    ctx.restore();
  };
  tiled(mossTile, S / 256 * 1.2, 0.8);
  tiled(rustTile, S / 256 * 0.7, 0.7);
  tiled(darkTile, S / 256 * 0.9, 0.9);
  tiled(darkTile2, S / 256 * 0.35, 0.8);

  // Needle litter flecks.
  ctx.lineWidth = Math.max(1, K * 0.1);
  const flecks = Math.round((S * S) / 170);
  const fc = ['rgba(70,50,30,0.35)', 'rgba(40,58,38,0.4)', 'rgba(8,10,10,0.5)', 'rgba(90,76,50,0.22)'];
  for (let i = 0; i < flecks; i++) {
    ctx.strokeStyle = fc[i & 3];
    const x = rng() * S, y = rng() * S, a = rng() * 6.28, l = 2 + rng() * 4;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l);
    ctx.stroke();
  }

  const dabs = {
    lawn: makeDab([48, 62, 44], true, rng),
    lawnSoft: makeDab([40, 54, 40], false, rng),
    drySoft: makeDab([66, 62, 44], true, rng),
    dirt: makeDab([150, 132, 104], true, rng),
    dirtSoft: makeDab([176, 158, 128], false, rng),
    road: makeDab([138, 128, 112], true, rng),
    roadSoft: makeDab([160, 150, 134], false, rng),
    mud: makeDab([30, 26, 20], true, rng),
    silt: makeDab([11, 15, 17], false, rng),
    pebble: makeDab([88, 88, 80], true, rng),
    ash: makeDab([14, 12, 10], false, rng),
    ashPale: makeDab([84, 80, 74], true, rng),
    dark: makeDab([4, 7, 8], true, rng),
    grass: makeDab([30, 46, 30], true, rng),
  };

  // Clearings: worn lawn with dry patches.
  for (const c of CLEARINGS) {
    const n = Math.round(c.r * c.r * 0.6);
    for (let i = 0; i < n; i++) {
      const a = rng() * 6.28, d = Math.sqrt(rng()) * c.r * 0.95;
      dab(rng() < 0.7 ? dabs.lawn : dabs.drySoft, c.x + Math.cos(a) * d, c.z + Math.sin(a) * d, 1.4 + rng() * 2.6, 0.18 + rng() * 0.25);
    }
    for (let i = 0; i < c.r * 3; i++) {
      const a = rng() * 6.28, d = Math.sqrt(rng()) * c.r * 0.6;
      dab(dabs.dirt, c.x + Math.cos(a) * d, c.z + Math.sin(a) * d, 0.8 + rng() * 1.8, 0.12 + rng() * 0.15);
    }
  }

  // Dirt in front of every door and under the buildings.
  for (const b of BUILDINGS) {
    const t = TEMPLATES[b.template];
    for (let i = 0; i < 14; i++) {
      const [wx, wz] = localToWorld(b, (rng() - 0.5) * 3.2, t.hz + (t.porch || 0.5) + 0.6 + rng() * 2.4);
      dab(dabs.dirt, wx, wz, 0.9 + rng() * 1.3, 0.3 + rng() * 0.25);
    }
    for (let i = 0; i < 24; i++) {
      const [wx, wz] = localToWorld(b, (rng() * 2 - 1) * (t.hx + 1), (rng() * 2 - 1) * (t.hz + 1));
      dab(dabs.dark, wx, wz, 1.0 + rng() * 1.2, 0.35);
    }
  }

  // Fire pit: charcoal heart, ash, trodden earth.
  for (let i = 0; i < 90; i++) {
    const a = rng() * 6.28, d = Math.sqrt(rng()) * 5.2;
    dab(dabs.dirt, Math.cos(a) * d, 8 + Math.sin(a) * d, 0.7 + rng() * 1.1, 0.2 + rng() * 0.2);
  }
  for (let i = 0; i < 30; i++) {
    const a = rng() * 6.28, d = Math.sqrt(rng()) * 2.1;
    dab(rng() < 0.2 ? dabs.ashPale : dabs.ash, Math.cos(a) * d, 8 + Math.sin(a) * d, 0.4 + rng() * 0.6, 0.5);
  }

  // Trails. Paths must be clearly lighter than the ground: that is how the player finds the way.
  for (const t of TRAILS) {
    const pts = densify(t.pts, 0.28);
    const seed = t.pts[0][0] * 0.13;
    const ov = t.kind === 'overgrown', road = t.kind === 'road';
    const w = t.width;
    const edge = road ? dabs.road : dabs.dirt, core = road ? dabs.roadSoft : dabs.dirtSoft;
    pts.forEach((p, i) => {
      const o = wander(i, seed) * (road ? 0.25 : 0.55);
      const px = p.x + p.nx * o, pz = p.z + p.nz * o;
      const ragged = (rng() - 0.5) * w * 0.4;
      dab(edge, px + p.nx * ragged, pz + p.nz * ragged, w * (0.52 + rng() * 0.3), ov ? 0.1 : 0.7);
      if (i % 2 === 0) dab(core, px, pz, w * 0.36 * (0.8 + rng() * 0.4), ov ? 0.1 : 0.55);
      if (!ov && rng() < 0.2) dab(dabs.dark, px + p.nx * w * (rng() - 0.5), pz + p.nz * w * (rng() - 0.5), 0.25 + rng() * 0.3, 0.45);
    });
    if (road) {
      // Tyre ruts and a tufted crown down the middle.
      ctx.globalAlpha = 1;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      for (const side of [-0.95, 0.95]) {
        ctx.strokeStyle = 'rgba(34,28,22,0.6)';
        ctx.lineWidth = 0.55 * K;
        ctx.beginPath();
        pts.forEach((p, i) => {
          const o = wander(i, seed) * 0.25 + side + Math.sin(i * 0.3 + side) * 0.06;
          const x = X(p.x + p.nx * o), y = Y(p.z + p.nz * o);
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        });
        ctx.stroke();
        ctx.strokeStyle = 'rgba(20,16,12,0.45)';
        ctx.lineWidth = 0.22 * K;
        ctx.stroke();
      }
      pts.forEach((p, i) => {
        if (rng() < 0.5) dab(dabs.grass, p.x + p.nx * wander(i, seed) * 0.25 + (rng() - 0.5) * 0.4, p.z + p.nz * wander(i, seed) * 0.25 + (rng() - 0.5) * 0.4, 0.3 + rng() * 0.4, 0.5);
      });
    }
  }

  // Parking lot gravel and the gate yard.
  const gravel = document.createElement('canvas');
  gravel.width = gravel.height = 128;
  {
    const g = gravel.getContext('2d');
    g.fillStyle = '#6a6c6c';
    g.fillRect(0, 0, 128, 128);
    for (let i = 0; i < 1600; i++) {
      const v = 70 + Math.floor(rng() * 70);
      g.fillStyle = `rgb(${v},${v + 2},${v + 2})`;
      const s = 1 + rng() * 2.4;
      g.fillRect(rng() * 128, rng() * 128, s, s);
    }
    for (let i = 0; i < 500; i++) {
      g.fillStyle = 'rgba(20,20,20,0.5)';
      g.fillRect(rng() * 128, rng() * 128, 1.5, 1.5);
    }
  }
  for (const id of ['lot', 'gate']) {
    const c = CLEARINGS.find((q) => q.id === id);
    const rr = c.r * 0.88;
    ctx.save();
    ctx.globalAlpha = 0.92;
    ctx.beginPath();
    const N = 64;
    const jit = [];
    for (let i = 0; i < N; i++) jit.push(0.9 + ((Math.sin(i * 0.7) + Math.sin(i * 1.9 + 1)) * 0.06) + rng() * 0.06);
    for (let i = 0; i <= N; i++) {
      const a = (i / N) * 6.2832, r = rr * jit[i % N];
      const x = X(c.x + Math.cos(a) * r), y = Y(c.z + Math.sin(a) * r);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.clip();
    ctx.scale(K * 0.2, K * 0.2);
    ctx.fillStyle = ctx.createPattern(gravel, 'repeat');
    ctx.fillRect(0, 0, S / (K * 0.2), S / (K * 0.2));
    ctx.restore();
    for (let i = 0; i < c.r * 14; i++) {
      const a = rng() * 6.28, r = rr * (0.9 + rng() * 0.2);
      dab(dabs.pebble, c.x + Math.cos(a) * r, c.z + Math.sin(a) * r, 0.5 + rng() * 1.0, 0.45);
    }
    // parking-bay oil stains
    for (let i = 0; i < c.r * 1.2; i++) {
      const a = rng() * 6.28, r = Math.sqrt(rng()) * rr * 0.75;
      dab(dabs.dark, c.x + Math.cos(a) * r, c.z + Math.sin(a) * r, 0.5 + rng() * 0.7, 0.3);
    }
  }
  // road across the lot reads over the gravel
  {
    const t = TRAILS[0];
    const pts = densify(t.pts, 0.4);
    pts.forEach((p) => dab(dabs.roadSoft, p.x, p.z, 2.4, 0.18));
  }

  // The lake bed, the wet mud and the pebbles at the waterline, straight from the height grid.
  for (let j = 0; j < GRID_N; j++) {
    for (let i = 0; i < GRID_N; i++) {
      const h = heightGrid[j * GRID_N + i];
      if (h > WATER_LEVEL + 1.6) continue;
      const x = -GRID_HALF + i * GRID_STEP, z = -GRID_HALF + j * GRID_STEP;
      if (Math.abs(x) > PAINT_HALF + 4 || Math.abs(z) > PAINT_HALF + 4) continue;
      if (h < WATER_LEVEL - 0.1) dab(dabs.silt, x, z, 2.6, 0.9);
      else if (h < WATER_LEVEL + 0.55) dab(dabs.mud, x, z, 2.4, 0.75);
      else dab(dabs.pebble, x + (rng() - 0.5), z + (rng() - 0.5), 1.5, 0.28);
    }
  }

  // Darker soil under every trunk.
  for (const t of forest.trees) {
    if (Math.abs(t.x) > PAINT_HALF || Math.abs(t.z) > PAINT_HALF) continue;
    dab(dabs.dark, t.x, t.z, 1.2 * t.scale, 0.35);
  }

  // ---- Baked moon shadows -------------------------------------------------------------------
  // Drawn opaque into a small mask (so overlaps do not stack), then multiplied in, soft by upscaling.
  const MS = Math.max(256, S / 4);
  const mk = MS / (PAINT_HALF * 2);
  const mask = document.createElement('canvas');
  mask.width = mask.height = MS;
  const mg = mask.getContext('2d');
  mg.fillStyle = '#fff';
  mg.fillRect(0, 0, MS, MS);
  mg.fillStyle = '#8c95a8';
  const MX = (x) => (x + PAINT_HALF) * mk, MY = (z) => (z + PAINT_HALF) * mk;
  const sx = SHADOW_DIR[0] * SHADOW_PER_M, sz = SHADOW_DIR[1] * SHADOW_PER_M;
  const poly = (pts) => {
    mg.beginPath();
    pts.forEach((p, i) => (i ? mg.lineTo(MX(p[0]), MY(p[1])) : mg.moveTo(MX(p[0]), MY(p[1]))));
    mg.closePath();
    mg.fill();
  };
  for (const t of forest.trees) {
    if (t.x < -PAINT_HALF - 22 || t.x > PAINT_HALF || t.z < -PAINT_HALF - 22 || t.z > PAINT_HALF) continue;
    const sh = TREE_SHAPE[t.kind];
    const s = t.scale;
    const H = sh.H * s, h0 = sh.h0 * s, R = sh.R * s;
    const px = -SHADOW_DIR[1], pz = SHADOW_DIR[0]; // perpendicular on the ground
    const tw = 0.3 * s;
    poly([[t.x - px * tw, t.z - pz * tw], [t.x + px * tw, t.z + pz * tw], [t.x + px * tw * 0.5 + sx * h0, t.z + pz * tw * 0.5 + sz * h0], [t.x - px * tw * 0.5 + sx * h0, t.z - pz * tw * 0.5 + sz * h0]]);
    const cx = t.x + sx * h0, cz = t.z + sz * h0;
    if (t.kind === 'dead') {
      poly([[cx - px * R, cz - pz * R], [cx + px * R, cz + pz * R], [t.x + sx * H, t.z + sz * H]]);
      continue;
    }
    poly([[cx - px * R, cz - pz * R], [cx + px * R, cz + pz * R], [t.x + sx * H, t.z + sz * H]]);
    mg.beginPath();
    mg.arc(MX(cx), MY(cz), R * mk, 0, 6.2832);
    mg.fill();
  }
  for (const b of BUILDINGS) {
    const t = TEMPLATES[b.template];
    const hx = t.hx + 0.35, hz = t.hz + 0.35;
    const corners = [[-hx, -hz], [hx, -hz], [hx, hz], [-hx, hz]].map(([x, z]) => localToWorld(b, x, z));
    const hgt = (t.wallH + t.ridgeH) * 0.5 + 0.2;
    const d = [sx * hgt, sz * hgt];
    poly(corners);
    poly(corners.map((c) => [c[0] + d[0], c[1] + d[1]]));
    for (let i = 0; i < 4; i++) {
      const a = corners[i], c = corners[(i + 1) % 4];
      poly([a, c, [c[0] + d[0], c[1] + d[1]], [a[0] + d[0], a[1] + d[1]]]);
    }
  }
  // the car and the flagpole cast small shadows too
  {
    const a = CAR.rot, ux = Math.sin(a), uz = Math.cos(a);
    const pts = [[-1, -2.6], [1, -2.6], [1, 2.6], [-1, 2.6]].map(([x, z]) => [CAR.x + x * Math.cos(a) + z * ux, CAR.z - x * Math.sin(a) + z * uz]);
    const d = [sx * 1.6, sz * 1.6];
    poly(pts);
    poly(pts.map((c) => [c[0] + d[0], c[1] + d[1]]));
    for (let i = 0; i < 4; i++) {
      const p0 = pts[i], p1 = pts[(i + 1) % 4];
      poly([p0, p1, [p1[0] + d[0], p1[1] + d[1]], [p0[0] + d[0], p0[1] + d[1]]]);
    }
  }
  ctx.imageSmoothingEnabled = true;
  ctx.globalCompositeOperation = 'multiply';
  ctx.globalAlpha = 1;
  ctx.drawImage(mask, 0, 0, S, S);
  // a second, blurrier pass for the soft penumbra
  const blur = document.createElement('canvas');
  blur.width = blur.height = Math.max(64, MS / 6);
  const bg = blur.getContext('2d');
  bg.imageSmoothingEnabled = true;
  bg.drawImage(mask, 0, 0, blur.width, blur.height);
  ctx.globalAlpha = 0.55;
  ctx.drawImage(blur, 0, 0, S, S);
  ctx.globalCompositeOperation = 'source-over';
  ctx.globalAlpha = 1;

  return canvas;
}

// Small tiling texture multiplied over the ground near the camera, so the earth is not blurry underfoot.
function makeDetailTexture() {
  const n = 256;
  const c = document.createElement('canvas');
  c.width = c.height = n;
  const g = c.getContext('2d');
  const rng = makeRng(WORLD_SEED + 5);
  const a = noiseTile(n, 8, 3), b = noiseTile(n, 32, 9), d = noiseTile(n, 64, 21);
  const id = g.createImageData(n, n);
  for (let i = 0; i < n * n; i++) {
    const v = 0.5 + (a[i] - 0.5) * 0.28 + (b[i] - 0.5) * 0.3 + (d[i] - 0.5) * 0.22;
    const k = Math.max(0, Math.min(1, v)) * 255;
    id.data[i * 4] = k;
    id.data[i * 4 + 1] = k;
    id.data[i * 4 + 2] = k;
    id.data[i * 4 + 3] = 255;
  }
  g.putImageData(id, 0, 0);
  const stroke = (x, y, col, l, ang) => {
    g.strokeStyle = col;
    g.beginPath();
    g.moveTo(x, y);
    g.lineTo(x + Math.cos(ang) * l, y + Math.sin(ang) * l);
    g.stroke();
  };
  g.lineWidth = 1;
  for (let i = 0; i < 1800; i++) {
    const x = rng() * n, y = rng() * n, l = 3 + rng() * 6, ang = rng() * 6.28;
    const col = rng() < 0.5 ? 'rgba(30,30,30,0.55)' : 'rgba(190,190,190,0.4)';
    for (const ox of [-n, 0, n]) for (const oy of [-n, 0, n]) if (Math.abs(x + ox - n / 2) < n * 0.6 && Math.abs(y + oy - n / 2) < n * 0.6) stroke(x + ox, y + oy, col, l, ang);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.NoColorSpace;
  tex.anisotropy = 4;
  return tex;
}

const CHUNK = 12; // cells per chunk side (24 m)

export function buildTerrain(quality, forest) {
  const canvas = paintGround(quality, forest);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.anisotropy = 8;
  tex.generateMipmaps = true;
  const detail = makeDetailTexture();

  // Shared vertex buffers for the whole grid.
  const N = GRID_N;
  const pos = new Float32Array(N * N * 3), nrm = new Float32Array(N * N * 3), uv = new Float32Array(N * N * 2);
  const hAt = (i, j) => heightGrid[Math.min(N - 1, Math.max(0, j)) * N + Math.min(N - 1, Math.max(0, i))];
  for (let j = 0; j < N; j++) {
    for (let i = 0; i < N; i++) {
      const k = j * N + i;
      const x = -GRID_HALF + i * GRID_STEP, z = -GRID_HALF + j * GRID_STEP;
      pos[k * 3] = x;
      pos[k * 3 + 1] = heightGrid[k];
      pos[k * 3 + 2] = z;
      const dx = (hAt(i + 1, j) - hAt(i - 1, j)) / (2 * GRID_STEP), dz = (hAt(i, j + 1) - hAt(i, j - 1)) / (2 * GRID_STEP);
      const l = Math.hypot(dx, 1, dz);
      nrm[k * 3] = -dx / l;
      nrm[k * 3 + 1] = 1 / l;
      nrm[k * 3 + 2] = -dz / l;
      uv[k * 2] = (x + PAINT_HALF) / (PAINT_HALF * 2);
      uv[k * 2 + 1] = 1 - (z + PAINT_HALF) / (PAINT_HALF * 2);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setAttribute('normal', new THREE.BufferAttribute(nrm, 3));
  geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 0, 0), GRID_HALF * 1.5);

  // Per-chunk index lists.
  const nc = Math.floor((N - 1) / CHUNK);
  const chunks = [];
  for (let cj = 0; cj < nc; cj++) {
    for (let ci = 0; ci < nc; ci++) {
      const idx = new Uint16Array(CHUNK * CHUNK * 6);
      let o = 0, hs = 0;
      for (let j = cj * CHUNK; j < (cj + 1) * CHUNK; j++) {
        for (let i = ci * CHUNK; i < (ci + 1) * CHUNK; i++) {
          const a = j * N + i, b = a + 1, c = a + N, d = c + 1;
          idx[o++] = a; idx[o++] = c; idx[o++] = b;
          idx[o++] = b; idx[o++] = c; idx[o++] = d;
          hs += heightGrid[a];
        }
      }
      chunks.push({ idx, x: -GRID_HALF + (ci + 0.5) * CHUNK * GRID_STEP, z: -GRID_HALF + (cj + 0.5) * CHUNK * GRID_STEP, y: hs / (CHUNK * CHUNK) });
    }
  }
  const indexAttr = new THREE.BufferAttribute(new Uint16Array(chunks.length * CHUNK * CHUNK * 6), 1);
  indexAttr.setUsage(THREE.DynamicDrawUsage);
  geo.setIndex(indexAttr);
  geo.setDrawRange(0, 0);

  const mat = lit({ map: tex, flatShading: false, color: 0xffffff, emissive: 0x263942, emissiveIntensity: 0.09 });
  mat.onBeforeCompile = (s) => {
    s.uniforms.uDetail = { value: detail };
    s.vertexShader = s.vertexShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vWPos;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;');
    s.fragmentShader = s.fragmentShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vWPos;\nuniform sampler2D uDetail;')
      .replace('#include <map_fragment>', `#include <map_fragment>
        {
          float gd = length(vWPos - cameraPosition);
          float gf = 1.0 - smoothstep(8.0, 38.0, gd);
          vec3 d1 = texture2D(uDetail, vWPos.xz * 0.42).rgb;
          vec3 d2 = texture2D(uDetail, vWPos.xz * 0.093 + 0.37).rgb;
          vec3 dd = d1 * d2 * 4.0;
          diffuseColor.rgb *= mix(vec3(1.0), dd, gf * 0.9 + 0.1);
        }`);
  };
  mat.customProgramCacheKey = () => 'ground1';

  const mesh = new THREE.Mesh(geo, mat);
  mesh.frustumCulled = false;
  mesh.name = 'ground';

  const prev = new Uint8Array(chunks.length);
  const cur = new Uint8Array(chunks.length);
  let first = true;
  function update(camera, maxDist = 118) {
    const fr = cameraFrustum(camera);
    const cp = camera.position;
    let changed = first;
    first = false;
    for (let i = 0; i < chunks.length; i++) {
      const c = chunks[i];
      const near = Math.abs(cp.x - c.x) < 20 && Math.abs(cp.z - c.z) < 20;
      const v = near || (Math.hypot(cp.x - c.x, cp.z - c.z) < maxDist + 17 && sphereVisible(fr, c.x, c.y, c.z, 19)) ? 1 : 0;
      cur[i] = v;
      if (v !== prev[i]) changed = true;
    }
    if (!changed) return;
    prev.set(cur);
    const arr = indexAttr.array;
    let o = 0;
    for (let i = 0; i < chunks.length; i++) {
      if (!cur[i]) continue;
      arr.set(chunks[i].idx, o);
      o += chunks[i].idx.length;
    }
    indexAttr.needsUpdate = true;
    geo.setDrawRange(0, o);
  }

  return { mesh, update, texture: tex, canvas };
}
