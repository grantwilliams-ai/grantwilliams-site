// Picks the rendering tier for this device. Everything visual that costs frames reads these numbers.
// Set window.__quality = 'low'|'med'|'high' or add ?quality=low to force a tier.
export const TIERS = {
  low: { tier: 'low', internalHeight: 270, shadowSize: 0, trees: 0.7, mist: 6, particles: 60, maxPixelHeight: 720 },
  med: { tier: 'med', internalHeight: 330, shadowSize: 512, trees: 0.85, mist: 12, particles: 120, maxPixelHeight: 900 },
  high: { tier: 'high', internalHeight: 400, shadowSize: 1024, trees: 1, mist: 20, particles: 240, maxPixelHeight: 1080 },
};

export function isTouchDevice() {
  if (typeof window === 'undefined') return false;
  // What matters is the main way of pointing: a laptop with a touch screen still has its mouse.
  if (window.matchMedia) return window.matchMedia('(pointer: coarse)').matches;
  return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
}

export function detectQuality() {
  const forced = typeof location !== 'undefined' ? new URLSearchParams(location.search).get('quality') : null;
  const name = forced || (typeof window !== 'undefined' && window.__quality) || (isTouchDevice() ? 'med' : 'high');
  return { ...(TIERS[name] || TIERS.med), isTouch: isTouchDevice() };
}
