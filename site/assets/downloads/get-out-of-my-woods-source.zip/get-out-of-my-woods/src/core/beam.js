// Which way the flashlight points. Standing still it follows the view, so looking around lights
// what you look at. On the move it is in her hand: it goes where her body faces, turns toward the
// view only as far as an arm can (about 55 degrees), and not at all once she is coming back toward
// the camera. Before this the beam followed the camera alone, and lit the ground behind her
// whenever she ran toward the view or across it.
const wrap = (a) => Math.atan2(Math.sin(a), Math.cos(a));
export const BEAM_REACH = 0.95;

export function beamYaw(bodyYaw, viewYaw) {
  const diff = wrap(viewYaw - bodyYaw), away = Math.abs(diff);
  const follow = away < 1.2 ? 1 : away > 2.4 ? 0 : 1 - (away - 1.2) / 1.2;
  return bodyYaw + Math.max(-BEAM_REACH, Math.min(BEAM_REACH, diff)) * follow;
}

// The beam's yaw this frame, eased so a start, a stop or a turn swings the light instead of snapping it.
export function aimBeam(current, bodyYaw, viewYaw, moving, dt, rate = 9) {
  const want = moving ? beamYaw(bodyYaw, viewYaw) : viewYaw;
  if (!Number.isFinite(current)) return want;
  return current + wrap(want - current) * (1 - Math.exp(-Math.max(0, dt) * rate));
}
