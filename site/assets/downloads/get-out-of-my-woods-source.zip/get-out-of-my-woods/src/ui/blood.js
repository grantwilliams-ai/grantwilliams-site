// Blood on the lens. Drops land, run, and fade.

export function createBlood(parent) {
  const canvas = document.createElement('canvas');
  canvas.className = 'blood-canvas';
  canvas.setAttribute('aria-hidden', 'true');
  parent.appendChild(canvas);
  const drops = [];
  let last = performance.now();

  function size() {
    const w = parent.clientWidth || 1;
    const h = parent.clientHeight || 1;
    const dpr = Math.min(2, typeof devicePixelRatio === 'number' ? devicePixelRatio : 1);
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
    }
    return { w, h, dpr };
  }

  // An irregular edge, so a drop never reads as a sticker.
  function edge(r) {
    const e = [];
    for (let i = 0; i < 10; i++) e.push(r * (0.68 + Math.random() * 0.55));
    return e;
  }

  // Spatter throws out from where it hit: a few heavy drops that run, and a fine spray that stays.
  function splat(amount) {
    const a = Math.max(0.15, Math.min(1, amount || 0.6));
    const { w, h } = size();
    for (let c = 0; c < 1 + Math.round(a * 1.6); c++) {
      const cx = w * (0.15 + Math.random() * 0.7), cy = h * (0.1 + Math.random() * 0.5);
      const reach = Math.min(w, h) * (0.16 + a * 0.3);
      const n = 12 + Math.floor(a * 26);
      for (let i = 0; i < n; i++) {
        const heavy = i < 2 + a * 3;
        const an = Math.random() * 6.28, far = reach * (heavy ? 0.3 : 0.15 + 0.85 * Math.random()) * Math.random();
        const r = heavy ? 5 + Math.random() * 9 * a : 0.9 + Math.random() * Math.random() * 3.6;
        drops.push({
          x: cx + Math.cos(an) * far,
          y: cy + Math.sin(an) * far * 0.8,
          r,
          e: edge(r),
          stretch: 1 + Math.random() * (heavy ? 0.4 : 1.2),
          rot: an,
          vy: heavy ? 5 + Math.random() * 26 * a : 0,
          life: 1,
          fade: 0.1 + Math.random() * 0.12,
          trail: [],
        });
      }
    }
  }

  function update(now) {
    if (!drops.length) return;
    const { w, h, dpr } = size();
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    const g = canvas.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, h);
    for (let i = drops.length - 1; i >= 0; i--) {
      const d = drops[i];
      if (d.vy) {
        d.y += d.vy * dt;
        d.vy += 14 * dt;
        d.x += Math.sin(d.y * 0.04) * 0.08;
        d.trail.push([d.x, d.y]);
        if (d.trail.length > 90) d.trail.shift();
      }
      d.life -= d.fade * dt;
      if (d.life <= 0 || d.y - d.r > h + 40) {
        drops.splice(i, 1);
        continue;
      }
      const a = Math.max(0, Math.min(1, d.life * 1.6));
      if (d.trail.length > 1) {
        g.strokeStyle = `rgba(74, 3, 3, ${0.7 * a})`;
        g.lineWidth = Math.max(1, d.r * 0.2);
        g.lineCap = 'round';
        g.beginPath();
        d.trail.forEach(([tx, ty], k) => (k ? g.lineTo(tx, ty) : g.moveTo(tx, ty)));
        g.stroke();
      }
      g.save();
      g.translate(d.x, d.y);
      g.rotate(d.rot);
      g.scale(d.stretch, 1);
      g.fillStyle = `rgba(92, 5, 5, ${0.88 * a})`;
      g.beginPath();
      d.e.forEach((rr, k) => {
        const an = (k / d.e.length) * 6.283;
        g[k ? 'lineTo' : 'moveTo'](Math.cos(an) * rr, Math.sin(an) * rr);
      });
      g.closePath();
      g.fill();
      if (d.r > 4) {
        g.fillStyle = `rgba(52, 2, 2, ${0.8 * a})`;
        g.beginPath();
        g.arc(d.r * 0.1, d.r * 0.06, d.r * 0.42, 0, 7);
        g.fill();
      }
      g.restore();
    }
    if (!drops.length) g.clearRect(0, 0, w, h);
  }

  function clear() {
    drops.length = 0;
    const { w, h, dpr } = size();
    const g = canvas.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, h);
  }

  return { splat, update, clear, canvas };
}
