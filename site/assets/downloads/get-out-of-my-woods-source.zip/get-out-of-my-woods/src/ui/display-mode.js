// How this browser can show the game without its bars, and what to tell the player about it.
// standalone: already launched from a Home Screen icon or in full screen display mode.
// native: the page can ask for full screen itself. ios: iPhone, where only a Home Screen icon can.
// window: neither; the browser's own menu is the only way.
export function displayMode(doc = globalThis.document, nav = globalThis.navigator, win = globalThis.window) {
  if (nav?.standalone || win?.matchMedia?.('(display-mode: standalone)').matches || win?.matchMedia?.('(display-mode: fullscreen)').matches) return 'standalone';
  if (typeof doc?.documentElement?.requestFullscreen === 'function' && doc.fullscreenEnabled !== false) return 'native';
  if (/iPhone|iPad|iPod/.test(nav?.userAgent || '') || (nav?.platform === 'MacIntel' && nav.maxTouchPoints > 1)) return 'ios';
  return 'window';
}

// Which set of steps to put first. Everyone still gets all of them: the page is shared publicly
// and a player may be setting the game up for another device.
export function deviceKind(nav = globalThis.navigator) {
  const ua = nav?.userAgent || '';
  if (/iPhone|iPad|iPod/.test(ua) || (nav?.platform === 'MacIntel' && nav.maxTouchPoints > 1)) return 'apple';
  if (/Android/.test(ua)) return 'android';
  return 'computer';
}

export function displayHelp(mode = displayMode(), kind = deviceKind()) {
  if (mode === 'standalone') return '<p>You are already playing without the browser address bar. Turn your phone sideways for a wider view.</p>';
  const button = mode === 'native' ? 'Use the fullscreen button below.' : 'Use your browser’s own full screen option.';
  const steps = {
    apple: '<h3>iPhone and iPad</h3><ol><li>Open this game in <strong>Safari</strong>.</li><li>Tap <strong>Share</strong>, then <strong>Add to Home Screen</strong>.</li><li>Turn on <strong>Open as Web App</strong> if shown, then tap <strong>Add</strong>.</li><li>Open the game from its new icon.</li></ol>',
    android: `<h3>Android</h3><p>${button} For an icon of its own, open the browser menu (⋮) and tap <strong>Add to Home screen</strong> or <strong>Install app</strong>.</p>`,
    computer: `<h3>Computer</h3><p>${button} Or press <strong>F11</strong> (Mac: <strong>Control + Command + F</strong>). Esc leaves full screen.</p>`,
  };
  const order = [kind, ...Object.keys(steps).filter((name) => name !== kind)];
  return order.map((name) => steps[name]).join('') +
    '<p>Opened from Facebook or another app? Use its menu (⋯) to open the page in your browser first.</p>' +
    '<p>Turn a phone sideways for the widest picture. A Home Screen icon keeps its own saved progress.</p>';
}

export async function enterFullscreen(doc = globalThis.document) {
  try {
    if (typeof doc?.documentElement?.requestFullscreen !== 'function' || doc.fullscreenEnabled === false) return false;
    await doc.documentElement.requestFullscreen();
    return !!doc.fullscreenElement;
  } catch { return false; }
}

export async function exitFullscreen(doc = globalThis.document) {
  try {
    if (!doc?.fullscreenElement || typeof doc.exitFullscreen !== 'function') return false;
    await doc.exitFullscreen();
    return !doc.fullscreenElement;
  } catch { return false; }
}

export const FULLSCREEN_FAILURE = 'Fullscreen could not open here. Keep playing, or follow the steps for your device.';
