// A small heading tape for the top of the HUD: N, E, S, W sliding past a fixed needle, and one
// quiet marker for the place the current objective names. Both chapters use it.
//
// The map's frame: +x is east, +z is south, so north is -z. A view yaw of 0 faces +z (south) and
// PI/2 faces +x (east); see sim/layout.js. Bearings here are degrees clockwise from north.

const wrap360 = (d) => ((d % 360) + 360) % 360;
const wrap180 = (d) => wrap360(d + 180) - 180;

// Which way the view faces, as a compass bearing.
export function headingDegrees(yaw) {
  return wrap360(Math.atan2(Math.sin(yaw), -Math.cos(yaw)) * 180 / Math.PI);
}

// The bearing from one point on the map to another.
export function bearingDegrees(fromX, fromZ, toX, toZ) {
  return wrap360(Math.atan2(toX - fromX, -(toZ - fromZ)) * 180 / Math.PI);
}

// Where the marker sits on the tape, in degrees right (+) or left (-) of the needle, held at the
// edge when the place is off to the side or behind. off: -1 left edge, 1 right edge, 0 on the tape.
export function markerOffset(heading, bearing, limit) {
  const delta = wrap180(bearing - heading);
  if (delta > limit) return { degrees: limit, off: 1 };
  if (delta < -limit) return { degrees: -limit, off: -1 };
  return { degrees: delta, off: 0 };
}

export const COMPASS_POINTS = Object.freeze([
  [0, 'N'], [45, 'NE'], [90, 'E'], [135, 'SE'], [180, 'S'], [225, 'SW'], [270, 'W'], [315, 'NW'],
]);

const PX_PER_DEGREE = 1.55;
const WIDTH = 216; // the visible window; about 70 degrees either side of the needle
const LEAD = 180; // degrees of tape drawn before 0 and after 360, so the window never runs out

const CSS = `
.goomw-compass{position:absolute;width:${WIDTH}px;height:36px;pointer-events:none;user-select:none;-webkit-user-select:none;opacity:.92}
.goomw-compass[hidden]{display:none!important}
.goomw-compass .gc-window{position:absolute;inset:0 0 9px 0;overflow:hidden;border-bottom:1px solid rgba(239,230,214,.5);background:linear-gradient(rgba(4,6,9,0),rgba(4,6,9,.62));-webkit-mask-image:linear-gradient(90deg,transparent,#000 20%,#000 80%,transparent);mask-image:linear-gradient(90deg,transparent,#000 20%,#000 80%,transparent)}
.goomw-compass .gc-tape{position:absolute;left:0;top:0;height:100%;will-change:transform}
.goomw-compass .gc-tape b,.goomw-compass .gc-tape i{position:absolute;bottom:0;transform:translateX(-50%)}
.goomw-compass .gc-tape b{bottom:7px;font:600 16px/1 Oswald,Arial,sans-serif;letter-spacing:.04em;color:#f4ecdd;text-shadow:0 1px 2px #000,0 0 5px #000,0 0 9px #000}
.goomw-compass .gc-tape b.is-minor{font-size:12px;font-weight:500;color:#d6cdbc;bottom:8px}
.goomw-compass .gc-tape b.is-north{color:#ff6a55}
.goomw-compass .gc-tape i{width:1px;height:4px;background:rgba(239,230,214,.55)}
.goomw-compass .gc-needle{position:absolute;left:50%;bottom:1px;width:0;height:0;margin-left:-5px;border-left:5px solid transparent;border-right:5px solid transparent;border-bottom:7px solid #f4ecdd;filter:drop-shadow(0 1px 1px #000)}
.goomw-compass .gc-mark{position:absolute;left:50%;bottom:5px;width:8px;height:8px;margin-left:-4px;background:#ffcf7a;transform:rotate(45deg);box-shadow:0 0 0 1px rgba(0,0,0,.75),0 0 9px rgba(255,207,122,.6);will-change:left}
.goomw-compass .gc-mark[hidden]{display:none}
.goomw-compass .gc-mark.is-off{width:6px;height:6px;margin-left:-3px;bottom:6px;opacity:.75}
`;

function ensureCss(doc) {
  if (doc.getElementById('goomw-compass-css')) return;
  const style = doc.createElement('style');
  style.id = 'goomw-compass-css';
  style.textContent = CSS;
  doc.head.append(style);
}

// parent: the HUD element the compass lives in. Position it with the host's own CSS (.goomw-compass).
export function createCompass(parent, doc = globalThis.document) {
  ensureCss(doc);
  const el = doc.createElement('div');
  el.className = 'goomw-compass';
  el.setAttribute('aria-hidden', 'true');
  el.hidden = true;
  const windowEl = doc.createElement('div');
  windowEl.className = 'gc-window';
  const tape = doc.createElement('div');
  tape.className = 'gc-tape';
  const at = (degrees) => (degrees + LEAD) * PX_PER_DEGREE;
  tape.style.width = at(360 + LEAD) + 'px';
  for (let d = -LEAD; d <= 360 + LEAD; d += 15) {
    const point = COMPASS_POINTS.find(([deg]) => deg === wrap360(d));
    const node = doc.createElement(point ? 'b' : 'i');
    node.style.left = at(d) + 'px';
    if (point) {
      node.textContent = point[1];
      if (point[1].length > 1) node.className = 'is-minor';
      else if (point[1] === 'N') node.className = 'is-north';
    }
    tape.append(node);
  }
  const needle = doc.createElement('i');
  needle.className = 'gc-needle';
  const mark = doc.createElement('i');
  mark.className = 'gc-mark';
  mark.hidden = true;
  windowEl.append(tape);
  el.append(windowEl, needle, mark);
  parent.append(el);

  let lastTape = NaN, lastMark = NaN, lastOff = 0, shown = false;
  const limit = (WIDTH / 2 - 10) / PX_PER_DEGREE;
  return {
    el,
    // view: {yaw, x, z, target?: {x, z}} while the compass should show, or null to put it away.
    set(view) {
      const on = !!view && Number.isFinite(view.yaw);
      if (on !== shown) { shown = on; el.hidden = !on; }
      if (!on) return;
      const heading = headingDegrees(view.yaw);
      const shift = Math.round((WIDTH / 2 - at(heading)) * 4) / 4;
      if (shift !== lastTape) { lastTape = shift; tape.style.transform = `translateX(${shift}px)`; }
      const target = view.target;
      if (!target || !Number.isFinite(target.x) || !Number.isFinite(target.z) || Math.hypot(target.x - view.x, target.z - view.z) < 4) {
        if (!mark.hidden) { mark.hidden = true; lastMark = NaN; }
        return;
      }
      const where = markerOffset(heading, bearingDegrees(view.x, view.z, target.x, target.z), limit);
      const left = Math.round((WIDTH / 2 + where.degrees * PX_PER_DEGREE) * 4) / 4;
      if (mark.hidden) mark.hidden = false;
      if (left !== lastMark) { lastMark = left; mark.style.left = left + 'px'; }
      if (where.off !== lastOff) { lastOff = where.off; mark.classList.toggle('is-off', !!where.off); }
    },
    dispose() { el.remove(); },
  };
}
