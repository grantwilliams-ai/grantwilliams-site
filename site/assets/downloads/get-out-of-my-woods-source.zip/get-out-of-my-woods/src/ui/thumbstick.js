// A stationary base and a bounded knob share one screen-space neutral point.
// The two chapters retain their original input travel and movement thresholds.
export const THUMB_KNOB_TRAVEL = 36;

export function stickCenter(element) {
  const r = element.getBoundingClientRect();
  return {x:r.left+r.width/2,y:r.top+r.height/2};
}

export function stickVector(x, y, center, radius) {
  let dx=x-center.x, dy=y-center.y;
  const length=Math.hypot(dx,dy);
  if(length>radius){dx*=radius/length;dy*=radius/length;}
  return {x:dx/radius,y:-dy/radius,knobX:dx/radius*THUMB_KNOB_TRAVEL,knobY:dy/radius*THUMB_KNOB_TRAVEL};
}

export function inStickPad(element, x, y) {
  const r=element.getBoundingClientRect();
  return x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom;
}

export function stickLayout(element, win=globalThis.window) {
  const r=element?.getBoundingClientRect?.();
  return [win?.innerWidth,win?.innerHeight,r?.left,r?.top,r?.width,r?.height].join(':');
}
