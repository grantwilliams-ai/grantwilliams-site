// Hand-drawn paper camp map. Drawn from layout.js — one source of truth.
import {
  BUILDINGS, TEMPLATES, TRAILS, LAKE, MAP_LABELS, SEARCH_SPOTS, DECKS, LAYOUT, localToWorld,
} from '../sim/layout.js';
import { makeRng } from '../core/rng.js';

const PAD = 36;
const BOUNDS = { minX: -130, maxX: 150, minZ: -122, maxZ: 132 };

function tx(x, w) {
  return PAD + ((x - BOUNDS.minX) / (BOUNDS.maxX - BOUNDS.minX)) * (w - PAD * 2);
}
function tz(z, h) {
  return PAD + ((z - BOUNDS.minZ) / (BOUNDS.maxZ - BOUNDS.minZ)) * (h - PAD * 2);
}

function paperFill(g, w, h) {
  g.fillStyle = '#d4c19a';
  g.fillRect(0, 0, w, h);
  const rng = makeRng(1984);
  const img = g.getImageData(0, 0, w, h);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (rng() - 0.5) * 18;
    d[i] = Math.max(0, d[i] + n - 4);
    d[i + 1] = Math.max(0, d[i + 1] + n - 2);
    d[i + 2] = Math.max(0, d[i + 2] + n);
  }
  g.putImageData(img, 0, 0);

  // coffee / damp stains
  const stains = [
    [w * 0.18, h * 0.22, 70, 'rgba(120,70,30,0.10)'],
    [w * 0.78, h * 0.7, 90, 'rgba(90,50,20,0.12)'],
    [w * 0.5, h * 0.08, 50, 'rgba(80,40,20,0.08)'],
    [w * 0.12, h * 0.82, 60, 'rgba(70,55,30,0.10)'],
  ];
  for (const [x, y, r, c] of stains) {
    const grd = g.createRadialGradient(x, y, 4, x, y, r);
    grd.addColorStop(0, c);
    grd.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = grd;
    g.beginPath();
    g.arc(x, y, r, 0, 7);
    g.fill();
  }

  // edge burn
  const edge = g.createLinearGradient(0, 0, 0, h);
  edge.addColorStop(0, 'rgba(70,40,18,0.22)');
  edge.addColorStop(0.08, 'rgba(0,0,0,0)');
  edge.addColorStop(0.92, 'rgba(0,0,0,0)');
  edge.addColorStop(1, 'rgba(50,30,12,0.28)');
  g.fillStyle = edge;
  g.fillRect(0, 0, w, h);
  const side = g.createLinearGradient(0, 0, w, 0);
  side.addColorStop(0, 'rgba(50,30,12,0.22)');
  side.addColorStop(0.06, 'rgba(0,0,0,0)');
  side.addColorStop(0.94, 'rgba(0,0,0,0)');
  side.addColorStop(1, 'rgba(50,30,12,0.22)');
  g.fillStyle = side;
  g.fillRect(0, 0, w, h);
}

const ROSE_INSET = 44; // the rose's centre, in from the right edge
const ROSE_DROP = 14; // and down from where the old north arrow sat

// A filled arrowhead at (x, y) pointing along yaw (0 = south/down the page, as in the world: +z is south).
function drawArrow(g, x, y, yaw, scale = 1) {
  const fx = Math.sin(yaw), fy = Math.cos(yaw), rx = fy, ry = -fx;
  const tip = 12 * scale, back = 8 * scale, half = 8 * scale, notch = 3 * scale;
  g.beginPath();
  g.moveTo(x + fx * tip, y + fy * tip);
  g.lineTo(x - fx * back + rx * half, y - fy * back + ry * half);
  g.lineTo(x - fx * notch, y - fy * notch);
  g.lineTo(x - fx * back - rx * half, y - fy * back - ry * half);
  g.closePath();
  g.lineJoin = 'round';
  g.strokeStyle = '#efe6d6';
  g.lineWidth = 3 * scale;
  g.stroke();
  g.fillStyle = '#c41212';
  g.fill();
}

// Where she is: a soft red wash, a ring, and the arrowhead (a dot when her facing is not known).
// Returns the marker's radius so nothing else is drawn on top of it.
function drawYou(g, x, y, yaw) {
  const R = 17;
  const wash = g.createRadialGradient(x, y, 4, x, y, R + 12);
  wash.addColorStop(0, 'rgba(196, 18, 18, 0.30)');
  wash.addColorStop(1, 'rgba(196, 18, 18, 0)');
  g.fillStyle = wash;
  g.beginPath();
  g.arc(x, y, R + 12, 0, 7);
  g.fill();
  g.beginPath();
  g.arc(x, y, R, 0, 7);
  g.strokeStyle = 'rgba(239, 230, 214, 0.95)';
  g.lineWidth = 4.5;
  g.stroke();
  g.strokeStyle = '#c41212';
  g.lineWidth = 2.2;
  g.stroke();
  if (yaw === null) {
    g.beginPath();
    g.arc(x, y, 6, 0, 7);
    g.strokeStyle = '#efe6d6';
    g.lineWidth = 2;
    g.stroke();
    g.fillStyle = '#c41212';
    g.fill();
  } else drawArrow(g, x, y, yaw, 0.82);
  return R;
}

// Four points and four letters.
function drawRose(g, x, y) {
  const long = 17, waist = 4.5;
  g.lineJoin = 'miter';
  for (let k = 0; k < 4; k++) {
    const a = k * Math.PI / 2, c = Math.cos(a), sn = Math.sin(a);
    // k = 0 points up the page (north); each point is a slim kite, one half inked
    const tipX = x + sn * long, tipY = y - c * long;
    const lx = x - c * waist, lyy = y - sn * waist, rx2 = x + c * waist, ry2 = y + sn * waist;
    g.beginPath();
    g.moveTo(tipX, tipY); g.lineTo(lx, lyy); g.lineTo(x, y); g.closePath();
    g.fillStyle = k === 0 ? '#a01010' : '#2a1810';
    g.fill();
    g.beginPath();
    g.moveTo(tipX, tipY); g.lineTo(rx2, ry2); g.lineTo(x, y); g.closePath();
    g.fillStyle = 'rgba(212, 193, 154, 0.9)';
    g.fill();
    g.beginPath();
    g.moveTo(tipX, tipY); g.lineTo(lx, lyy); g.lineTo(x, y); g.lineTo(rx2, ry2); g.closePath();
    g.strokeStyle = k === 0 ? '#a01010' : '#2a1810';
    g.lineWidth = 1.2;
    g.stroke();
  }
  g.font = '700 15px "Oswald", sans-serif';
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  for (const [letter, dx, dy] of [['N', 0, -long - 10], ['E', long + 9, 1], ['S', 0, long + 11], ['W', -long - 10, 1]]) {
    g.fillStyle = letter === 'N' ? '#a01010' : '#2a1810';
    g.fillText(letter, x + dx, y + dy);
  }
}

function jitterLine(g, pts, w, h, amp, rng) {
  g.beginPath();
  pts.forEach(([x, z], i) => {
    const px = tx(x, w) + (rng() - 0.5) * amp;
    const py = tz(z, h) + (rng() - 0.5) * amp;
    if (i === 0) g.moveTo(px, py);
    else g.lineTo(px, py);
  });
  g.stroke();
}

function worldOfSearch(s) {
  if (typeof s === 'string') {
    const spot = LAYOUT.searches.find((p) => p.id === s) || SEARCH_SPOTS.find((p) => p.id === s);
    if (spot) {
      if (spot.wx != null) return { x: spot.wx, z: spot.wz };
      if (spot.building) {
        const b = BUILDINGS.find((q) => q.id === spot.building);
        const [x, z] = localToWorld(b, spot.x, spot.z);
        return { x, z };
      }
      return { x: spot.x, z: spot.z };
    }
    const b = BUILDINGS.find((q) => q.id === s);
    if (b) return { x: b.x, z: b.z };
    return null;
  }
  if (s && typeof s === 'object') return { x: s.x, z: s.z ?? s.y };
  return null;
}

export function drawCampMap(canvas, state = {}) {
  const cssW = Math.max(160, canvas.clientWidth || 640);
  const cssH = Math.max(120, canvas.clientHeight || 480);
  const dpr = Math.min(2, (typeof devicePixelRatio === 'number' ? devicePixelRatio : 1));
  canvas.width = Math.round(cssW * dpr);
  canvas.height = Math.round(cssH * dpr);
  const g = canvas.getContext('2d');
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  const w = cssW, h = cssH;
  const rng = makeRng(77);

  paperFill(g, w, h);

  // lake — hand-drawn shore, +z is south so the water sits at the bottom
  const sx = (w - PAD * 2) / (BOUNDS.maxX - BOUNDS.minX);
  const sz = (h - PAD * 2) / (BOUNDS.maxZ - BOUNDS.minZ);
  g.fillStyle = 'rgba(62, 102, 122, 0.62)';
  g.strokeStyle = 'rgba(36, 64, 82, 0.9)';
  g.lineWidth = 1.6;
  for (const lake of LAKE) {
    g.beginPath();
    for (let a = 0; a <= Math.PI * 2 + 0.01; a += 0.18) {
      const j = 1 + (rng() - 0.5) * 0.05;
      const px = tx(lake.x, w) + Math.cos(a) * lake.rx * sx * j;
      const py = tz(lake.z, h) + Math.sin(a) * lake.rz * sz * j;
      if (a === 0) g.moveTo(px, py);
      else g.lineTo(px, py);
    }
    g.closePath();
    g.fill();
    g.stroke();
  }
  g.font = '18px "Special Elite", cursive';
  g.fillStyle = '#1e3344';
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  const lakeName = { x: tx(-78, w), y: tz(96, h) }; // out in the open water, clear of the dock
  g.fillText('LAKE', lakeName.x, lakeName.y);

  // trails
  g.lineCap = 'round';
  g.lineJoin = 'round';
  for (const t of TRAILS) {
    g.strokeStyle = t.kind === 'road' ? '#6a4a28' : t.kind === 'path' ? '#5a4030' : '#7a6048';
    g.lineWidth = t.kind === 'road' ? 5.5 : t.kind === 'path' ? 2.6 : 1.6;
    if (t.kind === 'overgrown') g.setLineDash([5, 6]);
    else g.setLineDash([]);
    jitterLine(g, t.pts, w, h, t.kind === 'road' ? 0.8 : 1.4, rng);
  }
  g.setLineDash([]);

  // buildings
  for (const b of BUILDINGS) {
    const t = TEMPLATES[b.template];
    const hx = t.hx, hz = t.hz;
    const corners = [
      localToWorld(b, -hx, -hz),
      localToWorld(b, hx, -hz),
      localToWorld(b, hx, hz),
      localToWorld(b, -hx, hz),
    ].map(([x, z]) => [tx(x, w), tz(z, h)]);
    g.beginPath();
    corners.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y)));
    g.closePath();
    g.fillStyle = b.template === 'outhouse' ? '#8a7050' : '#5c4030';
    g.strokeStyle = '#2a1810';
    g.lineWidth = 1.4;
    g.fill();
    g.stroke();
  }

  // the dock: planks running out over the water, drawn wide enough to see on a small map
  const dockRects = [];
  for (const deck of DECKS) {
    const cx = tx((deck.minX + deck.maxX) / 2, w), top = tz(deck.minZ, h), bottom = tz(deck.maxZ, h);
    const dw = Math.max(7, tx(deck.maxX, w) - tx(deck.minX, w));
    g.fillStyle = '#8a6a48';
    g.strokeStyle = '#2a1810';
    g.lineWidth = 1.4;
    g.fillRect(cx - dw / 2, top, dw, bottom - top);
    g.strokeRect(cx - dw / 2, top, dw, bottom - top);
    g.lineWidth = 1;
    g.strokeStyle = 'rgba(42, 24, 16, 0.55)';
    g.beginPath();
    for (let y = top + 5; y < bottom - 2; y += 5) { g.moveTo(cx - dw / 2, y); g.lineTo(cx + dw / 2, y); }
    g.stroke();
    dockRects.push({ x: cx, top, bottom, w: dw });
  }

  // search spots that stand out in the open (the archery range's equipment box, the cooler at the
  // end of the dock): a small box each, so the map shows there is something there to look in.
  const openSpots = [];
  for (const spot of SEARCH_SPOTS) {
    if (spot.building) continue;
    const x = tx(spot.x, w), y = tz(spot.z, h), r = 4;
    g.fillStyle = '#5c4030';
    g.strokeStyle = '#2a1810';
    g.lineWidth = 1.4;
    g.fillRect(x - r, y - r, r * 2, r * 2);
    g.strokeRect(x - r, y - r, r * 2, r * 2);
    openSpots.push({ x, y });
  }

  // labels — each stays beside its place. When a small map forces one away from its building it is
  // pushed to the nearest free spot and joined back with a short leader tick, so none drifts loose.
  g.font = '18px "Oswald", sans-serif';
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  const pl0 = state.player || { x: 3.4, z: 11.4 };
  const ppx = tx(pl0.x, w), ppy = tz(pl0.z, h);
  // The header and the compass are paper furniture too: labels keep clear of them.
  g.font = '22px "Special Elite", cursive';
  const headerTight0 = g.measureText('CAMP STILLWATER  ·  STAFF MAP  ·  1984').width > w - PAD - 52;
  const topEdge = (headerTight0 ? 56 : 34) + 14;
  g.font = '18px "Oswald", sans-serif';
  const roseY = (headerTight0 ? 62 : 36) + ROSE_DROP;
  const placed = [-1, 0, 1].map((k) => ({ x: w - ROSE_INSET, y: roseY + k * 24, w: 62 }));
  const LAB_H = 24;
  // Labels keep off the dock and the open-air boxes, or the things they name would be hidden.
  // (soft: worth a 40 px detour and no more; on a map too small for both, a name over a box beats a name far from its place.)
  for (const dk of dockRects) for (let y = dk.top + 6; y < dk.bottom + 12; y += 20) placed.push({ x: dk.x, y: Math.min(y, dk.bottom), w: dk.w - 8, soft: true });
  for (const sp of openSpots) placed.push({ x: sp.x, y: sp.y, w: 0, soft: true });
  placed.push({ x: lakeName.x, y: lakeName.y, w: 46, soft: true });
  const rectOverlap = (ax, ay, aw, bx, by, bw) => Math.abs(ax - bx) < (aw + bw) / 2 + 12 && Math.abs(ay - by) < LAB_H + 2;
  const onMarker = (x, y, tw) => {
    const cx = Math.max(x - tw / 2 - 4, Math.min(ppx, x + tw / 2 + 4));
    const cy = Math.max(y - LAB_H / 2, Math.min(ppy, y + LAB_H / 2));
    return Math.hypot(cx - ppx, cy - ppy) < 24;
  };
  const drawn = [];
  for (const lab of MAP_LABELS) {
    const ax = tx(lab.x, w), ay = tz(lab.z, h);
    const tw = g.measureText(lab.text).width;
    const half = tw / 2 + 4;
    // Nearest free spot first: a ring search around the place, so a crowded corner pushes the label
    // outward (and joins it with a leader) instead of ever drawing it over another word.
    const cands = [[0, 0]];
    for (let r = 8; r <= 220; r += 8) {
      for (let k = 0; k < 24; k++) {
        const a2 = (k / 24) * Math.PI * 2;
        cands.push([Math.round(Math.cos(a2) * r * 1.6), Math.round(Math.sin(a2) * r)]);
      }
    }
    let best = null, bestScore = Infinity;
    for (const [dx, dy] of cands) {
      const x = ax + dx, y = ay + dy;
      if (x < half + 4 || x > w - half - 4 || y < topEdge || y > h - 18) continue;
      if (onMarker(x, y, tw)) continue;
      const hits = placed.reduce((n, p) => n + (rectOverlap(p.x, p.y, p.w, x, y, tw) ? (p.soft ? 0.00004 : 1) : 0), 0);
      const score = hits * 1e6 + Math.hypot(dx, dy);
      if (score < bestScore) { bestScore = score; best = { x, y }; }
      if (!hits) break;
    }
    if (!best) best = { x: Math.max(half + 4, Math.min(w - half - 4, ax)), y: Math.max(topEdge, Math.min(h - 18, ay)) };
    placed.push({ x: best.x, y: best.y, w: tw });
    drawn.push({ lab, ax, ay, tw, x: best.x, y: best.y });
  }
  // leader ticks first, so each label's paper patch sits over its end
  g.strokeStyle = '#2a1810';
  g.fillStyle = '#2a1810';
  g.lineWidth = 1.4;
  g.lineCap = 'round';
  for (const d of drawn) {
    const left = d.x - d.tw / 2 - 4, right = d.x + d.tw / 2 + 4, top = d.y - LAB_H / 2, bottom = d.y + LAB_H / 2;
    const nx = Math.max(left, Math.min(d.ax, right)), ny = Math.max(top, Math.min(d.ay, bottom));
    if (Math.hypot(nx - d.ax, ny - d.ay) < 8) continue; // still on its place
    g.beginPath();
    g.moveTo(d.ax, d.ay);
    g.lineTo(nx, ny);
    g.stroke();
    g.beginPath();
    g.arc(d.ax, d.ay, 2.6, 0, 7);
    g.fill();
  }
  for (const d of drawn) {
    g.fillStyle = 'rgba(212, 193, 154, 0.88)';
    g.fillRect(d.x - d.tw / 2 - 4, d.y - LAB_H / 2, d.tw + 8, LAB_H);
    g.fillStyle = d.lab.text === '???' ? '#6e0505' : '#1a120c';
    g.fillText(d.lab.text, d.x, d.y);
  }

  // searched crosses
  const searched = state.searched || [];
  g.strokeStyle = '#6e0505';
  g.lineWidth = 2.4;
  g.lineCap = 'square';
  for (const s of searched) {
    const p = worldOfSearch(s);
    if (!p) continue;
    const x = tx(p.x, w), y = tz(p.z, h);
    const r = 9;
    g.beginPath();
    g.moveTo(x - r, y - r);
    g.lineTo(x + r, y + r);
    g.moveTo(x + r, y - r);
    g.lineTo(x - r, y + r);
    g.stroke();
  }

  // killer hint: a smudge, not a radar ping
  const hint = state.killerHint;
  if (hint && hint.x != null) {
    const x = tx(hint.x, w), y = tz(hint.z, h);
    const r = (hint.r || 18) * (w - PAD * 2) / (BOUNDS.maxX - BOUNDS.minX);
    const grd = g.createRadialGradient(x, y, 2, x, y, r);
    grd.addColorStop(0, 'rgba(110, 5, 5, 0.28)');
    grd.addColorStop(1, 'rgba(110, 5, 5, 0)');
    g.fillStyle = grd;
    g.beginPath();
    g.arc(x, y, r, 0, 7);
    g.fill();
  }

  // YOU: an arrowhead pointing the way she faces, inside a ring, with nothing laid over the map.
  const pl = state.player || { x: 3.4, z: 11.4 };
  const px = tx(pl.x, w), py = tz(pl.z, h);
  const marker = drawYou(g, px, py, Number.isFinite(pl.yaw) ? pl.yaw : null);
  // The legend along the bottom names it; where there is no room for the legend, a small tag does.
  const legendFits = w >= 480 && h >= 300 && py < h - 72;
  let ly = py;
  if (!legendFits) {
    g.font = '700 16px "Oswald", sans-serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    const tagW = g.measureText('YOU').width + 10;
    const spots = [[px, py - marker - 14], [px, py + marker + 14], [px + marker + tagW / 2 + 4, py], [px - marker - tagW / 2 - 4, py]];
    const crowdedBy = (x, y) => {
      if (x - tagW / 2 < 6 || y < 34 || x + tagW / 2 > w - 6 || y > h - 14) return Infinity;
      return placed.filter((q) => Math.abs(q.x - x) < (q.w + tagW) / 2 + 6 && Math.abs(q.y - y) < 22).length;
    };
    let best = spots[0], least = Infinity;
    for (const spot of spots) { const n = crowdedBy(spot[0], spot[1]); if (n < least) { least = n; best = spot; } }
    g.fillStyle = '#c41212';
    g.fillRect(best[0] - tagW / 2, best[1] - 10, tagW, 20);
    g.fillStyle = '#efe6d6';
    g.fillText('YOU', best[0], best[1] + 1);
    ly = best[1];
  }

  // header / compass — two lines when the paper is narrow, so nothing clips
  g.textAlign = 'left';
  g.textBaseline = 'top';
  g.fillStyle = '#2a1810';
  g.font = '22px "Special Elite", cursive';
  const header = 'CAMP STILLWATER  ·  STAFF MAP  ·  1984';
  const headerTight = g.measureText(header).width > w - PAD - 52;
  if (headerTight) {
    g.fillText('CAMP STILLWATER', PAD, 6);
    g.fillText('STAFF MAP  ·  1984', PAD, 30);
  } else {
    g.fillText(header, PAD, 8);
  }

  // compass rose: all four points, north in red, matching the heading strip in play
  drawRose(g, w - ROSE_INSET, (headerTight ? 62 : 36) + ROSE_DROP);

  if (legendFits && ly < h - 52) {
    g.font = '700 18px "Oswald", sans-serif';
    g.textAlign = 'left';
    g.textBaseline = 'middle';
    const hereW = g.measureText('YOU ARE HERE').width;
    const searchedW = g.measureText('X = SEARCHED').width;
    const legendW = 16 + hereW + 24 + searchedW;
    if (legendW <= w - PAD * 2) {
      const x = PAD, y = h - 18;
      g.fillStyle = 'rgba(212, 193, 154, 0.94)';
      g.fillRect(x - 8, y - 14, legendW + 16, 28);
      drawArrow(g, x + 5, y + 1, Math.PI, 0.62);
      g.fillStyle = '#2a1810';
      g.font = '700 18px "Oswald", sans-serif';
      g.textAlign = 'left';
      g.textBaseline = 'middle';
      g.fillText('YOU ARE HERE', x + 16, y);
      g.fillText('X = SEARCHED', x + 16 + hereW + 24, y);
    }
  }
}
