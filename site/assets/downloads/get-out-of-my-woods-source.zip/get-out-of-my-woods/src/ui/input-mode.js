// One rule, for both chapters, for which controls the player is shown: on-screen touch controls or
// the keyboard strip, and which instructions come first. It decides controls and words only; the
// render quality tier stays a hardware decision (core/quality.js).
//
// The primary pointer decides. A touch-screen laptop driven by a trackpad or mouse is a keyboard
// player; a phone or tablet is a touch player. The player can override it in Settings, and the
// other set of instructions is never hidden, only placed second.
export const INPUT_MODES = Object.freeze(['auto', 'keyboard', 'touch']);

export function detectInputMode(win = globalThis.window) {
  try {
    if (win?.matchMedia?.('(pointer: coarse)')?.matches) return 'touch';
  } catch { /* no media queries: treat as keyboard */ }
  return 'keyboard';
}

export function resolveInputMode(preference = 'auto', win = globalThis.window) {
  return preference === 'keyboard' || preference === 'touch' ? preference : detectInputMode(win);
}
