import { stickCenter, stickVector, inStickPad, stickLayout } from './thumbstick.js';

// Keyboard, mouse drag/pointer lock, and multi-touch. All feed the same ui.input.

const STICK_R = 56;
const LOOK_SENS = 1;

export function createInputState() {
  return {
    moveX: 0,
    moveY: 0,
    lookX: 0,
    lookY: 0,
    run: false,
    sneak: false,
    action: false,       // one-shot; the game clears it
    actionHeld: false,   // level, true while E/Space/ACTION is down
    flashlightPressed: false,
    quickTurnPressed: false,
    pausePressed: false,
    lockLost: false,
    mapPressed: false,
  };
}

export function peekInput(input) {
  return { ...input };
}

function isPortraitPanel() {
  return window.matchMedia('(orientation: portrait) and (max-width: 820px)').matches;
}

export function bindInput(input, ctx) {
  const keys = { up: 0, down: 0, left: 0, right: 0, run: 0, sneak: 0, action: 0 };
  const pressedKeys = new Set();
  const keyGroups = {
    up: ['KeyW', 'ArrowUp'], down: ['KeyS', 'ArrowDown'],
    left: ['KeyA', 'ArrowLeft'], right: ['KeyD', 'ArrowRight'],
    run: ['ShiftLeft', 'ShiftRight'],
    sneak: ['KeyC'], // never Ctrl: Ctrl+W closes the tab and a page cannot stop it
    action: ['KeyE', 'Space'],
  };
  const groupedCodes = new Set(Object.values(keyGroups).flat());
  function syncKeys() {
    for (const [name, codes] of Object.entries(keyGroups)) keys[name] = codes.some(code => pressedKeys.has(code)) ? 1 : 0;
  }
  const pointers = new Map();
  const actionHolds = new Set();
  const removeListeners = [];
  let disposed = false;
  function listen(target, type, fn, options) {
    target.addEventListener(type, fn, options);
    removeListeners.push(() => target.removeEventListener(type, fn, options));
  }
  let stick = null; // {id, ox, oy}
  let lightOn = true; // every night starts with the flashlight on

  function blocked() {
    return typeof ctx.blocked === 'function' ? ctx.blocked() : !!ctx.blocked;
  }
  function playing() {
    return typeof ctx.playing === 'function' ? ctx.playing() : !!ctx.playing;
  }
  function touchOn() {
    return typeof ctx.touchOn === 'function' ? ctx.touchOn() : !!ctx.touchOn;
  }

  function pulse(name) {
    input[name] = true;
  }

  function syncMove() {
    if (stick) {
      const p = pointers.get(stick.id);
      if (p) {
        const v = stickVector(p.x,p.y,{x:stick.ox,y:stick.oy},STICK_R);
        const mag = Math.hypot(v.x,v.y);
        input.moveX = v.x;
        input.moveY = v.y;
        input.sneak = mag > 0.02 && mag < 0.5 && !input.run && !keys.run;
        if (ctx.stickEl) {
          if (!ctx.stickZone) {
            const layer = ctx.touchEl ? ctx.touchEl.getBoundingClientRect() : { left: 0, top: 0 };
            ctx.stickEl.style.left = (stick.ox - layer.left) + 'px';
            ctx.stickEl.style.top = (stick.oy - layer.top) + 'px';
          }
          ctx.stickEl.classList.add('is-active');
          ctx.stickEl.hidden = false;
          ctx.stickEl.removeAttribute('hidden');
          const knob = ctx.stickEl.querySelector('.stick-knob');
          if (knob) {
            knob.style.transform = `translate(${v.knobX}px, ${v.knobY}px)`;
          }
        }
      }
    } else {
      let mx = (keys.right ? 1 : 0) - (keys.left ? 1 : 0);
      let my = (keys.up ? 1 : 0) - (keys.down ? 1 : 0);
      const mag = Math.hypot(mx, my);
      if (mag > 1) { mx /= mag; my /= mag; }
      input.moveX = mx;
      input.moveY = my;
      input.sneak = !!keys.sneak && !keys.run && !input.run;
      if (ctx.stickEl) {
        ctx.stickEl.hidden = !ctx.stickZone;
        ctx.stickEl.classList.remove('is-active');
        const knob=ctx.stickEl.querySelector('.stick-knob');
        if(knob)knob.style.transform='';
      }
    }
    if (ctx.touchEl) {
      const hint = ctx.touchEl.querySelector('.stick-hint');
      if (hint) hint.hidden = !!stick;
    }
    input.run = !!(keys.run || runHeld);
    if (input.run) input.sneak = false;
    input.actionHeld = !!(keys.action || actionHolds.size);
  }

  let runHeld = false;

  function setRunLatch(on) {
    runHeld = on;
    const button = ctx.touchEl?.querySelector('.tbtn-run');
    button?.classList.toggle('is-on', on);
    button?.setAttribute('aria-pressed', String(on));
  }

  function handleBtn(name, down, source) {
    if (name === 'run') {
      // A tap, not a hold: nobody should need three fingers to run away.
      if (down) setRunLatch(!runHeld);
    } else if (name === 'action') {
      if (down) actionHolds.add(source);else actionHolds.delete(source);
      if (down) {
        input.action = true;
        input.actionHeld = true;
      }
    } else if (name === 'light' && down) {
      lightOn = !lightOn;
      pulse('flashlightPressed');
      if (ctx.onLight) ctx.onLight(lightOn);
    } else if (name === 'map' && down) {
      pulse('mapPressed');
    } else if (name === 'pause' && down) {
      pulse('pausePressed');
    }
    syncMove();
  }

  function hitRole(x, y, target) {
    if (target && target.closest && target.closest('[data-touch]')) return 'btn';
    if (!touchOn()) return null;
    if (ctx.stickZone) return inStickPad(ctx.stickZone,x,y) ? 'stick' : 'look';
    const layer = ctx.touchEl;
    if (isPortraitPanel() && layer) {
      const r = layer.getBoundingClientRect();
      if (y < r.top - 2) return 'look'; // drag on the picture to look
      const mid = r.left + r.width * 0.42;
      return x < mid ? 'stick' : 'look';
    }
    const mid = window.innerWidth * 0.5;
    return x < mid ? 'stick' : 'look';
  }

  function onPointerDown(e) {
    if (e.button != null && e.button !== 0) return;
    if (blocked()) return;
    if (pointers.has(e.pointerId)) return; // a surface may also bubble through the UI root
    const t = e.target;
    const btn = t?.closest?.('[data-touch]');
    if (btn) {
      pointers.set(e.pointerId, { role: 'btn', name: btn.dataset.touch, btn, x: e.clientX, y: e.clientY });
      btn.classList.add('is-down');
      capturePointer(e, btn);
      handleBtn(btn.dataset.touch, true, e.pointerId);
      e.preventDefault();
      return;
    }
    // Native menu/help controls never become a movement or look gesture.
    if (t?.closest?.('button,input,select,textarea,a,[contenteditable]')) return;
    if (!playing()) return;
    if (!touchOn()) {
      if (!ctx.dragLook || document.pointerLockElement || t.closest?.('button')) return;
      pointers.set(e.pointerId, {role:'look', x:e.clientX, y:e.clientY});
      capturePointer(e, ctx.gameEl || t);
      e.preventDefault();
      return;
    }
    const role = hitRole(e.clientX, e.clientY, t);
    if (role === 'stick' && !stick) {
      const center=ctx.stickZone&&ctx.stickEl ? stickCenter(ctx.stickEl) : {x:e.clientX,y:e.clientY};
      stick = { id: e.pointerId, ox: center.x, oy: center.y };
      lastLayout=stickLayout(ctx.stickEl);
      pointers.set(e.pointerId, { role: 'stick', x: e.clientX, y: e.clientY });
      syncMove();
    } else if (role === 'look' && ![...pointers.values()].some(p=>p.role==='look')) {
      pointers.set(e.pointerId, { role: 'look', x: e.clientX, y: e.clientY });
    } else {
      // An extra thumb on the movement pad cannot steal it or turn the camera.
      return;
    }
    capturePointer(e, ctx.touchEl || t);
    e.preventDefault();
  }

  function capturePointer(e, target) {
    if (e.legacyTouch) return;
    const p = pointers.get(e.pointerId);
    if (p) p.capture = target;
    try { target?.setPointerCapture?.(e.pointerId); } catch (_) {}
  }

  function releaseCapture(id, p) {
    try { p.capture?.releasePointerCapture?.(id); } catch (_) {}
  }

  function onPointerMove(e) {
    const p = pointers.get(e.pointerId);
    if (!p) return;
    const dx = e.clientX - p.x;
    const dy = e.clientY - p.y;
    p.x = e.clientX;
    p.y = e.clientY;
    if (p.role === 'look') {
      input.lookX += dx * LOOK_SENS;
      input.lookY += dy * LOOK_SENS;
    } else if (p.role === 'stick') {
      syncMove();
    }
    e.preventDefault();
  }

  function onPointerUp(e) {
    const p = pointers.get(e.pointerId);
    if (!p) return;
    // Remove ownership before releasing capture: lostpointercapture may fire
    // during cleanup, and must not release another held action or toggle RUN.
    pointers.delete(e.pointerId);
    if (p.role === 'btn') {
      if (![...pointers.values()].some(other => other.btn === p.btn)) p.btn?.classList.remove('is-down');
      handleBtn(p.name, false, e.pointerId);
    }
    if (stick && stick.id === e.pointerId) {
      stick = null;
      setRunLatch(false); // let go of the stick and she stops running
    }
    releaseCapture(e.pointerId, p);
    syncMove();
  }

  // Modern browsers emit both PointerEvents and compatibility TouchEvents.
  // Choose one owner for the whole gesture; timing guesses cancel slow native
  // menu clicks and can double-toggle RUN while another finger is moving.
  function touchToPointer(type, touch, target) {
    const id = 'touch:' + touch.identifier;
    const ev = {
      pointerId: id,
      legacyTouch: true,
      button: 0,
      clientX: touch.clientX,
      clientY: touch.clientY,
      target: touch.target || target,
      preventDefault() { },
    };
    if (type === 'start') {
      onPointerDown(ev);
      return pointers.has(id);
    }
    if (!pointers.has(id)) return false;
    if (type === 'move') onPointerMove(ev);else onPointerUp(ev);
    return true;
  }
  function onTouchStart(e) {
    if (blocked()) return;
    let owned = false;
    for (const t of e.changedTouches) owned = touchToPointer('start', t, e.target) || owned;
    if (owned) e.preventDefault();
  }
  function onTouchMove(e) {
    let owned = false;
    for (const t of e.changedTouches) owned = touchToPointer('move', t, e.target) || owned;
    if (owned) e.preventDefault();
  }
  function onTouchEnd(e) {
    let owned = false;
    for (const t of e.changedTouches) owned = touchToPointer('end', t, e.target) || owned;
    if (owned) e.preventDefault();
  }

  function onKeyDown(e) {
    const code = e.code;
    if (code === 'Escape') {
      // A menu takes Esc as "back one step" before the game sees it as pause or resume.
      const handled = !e.repeat && ctx.onEscape?.() === true;
      if (!e.repeat && !handled) pulse('pausePressed');
      if (document.pointerLockElement) document.exitPointerLock();
      e.preventDefault();
      return;
    }
    if (code === 'KeyM' && ctx.mapOpen?.()) {
      if (!e.repeat) ctx.closeMap();
      e.preventDefault();
      return;
    }
    if (blocked()) return;
    const button = e.target?.closest?.('[data-touch]');
    if (button && (code === 'Enter' || code === 'Space')) {
      if (!e.repeat) handleBtn(button.dataset.touch, true, code);
      e.preventDefault();
      return;
    }
    const grouped = groupedCodes.has(code);
    if (grouped) { pressedKeys.add(code); syncKeys(); }
    if (e.repeat) { syncMove(); return; }
    let used = true;
    if (grouped) {
      if (code === 'KeyE' || code === 'Space') {
        input.action = true;
        input.actionHeld = true;
      }
    } else if (code === 'KeyR') setRunLatch(!runHeld);
    else if (code === 'KeyF') pulse('flashlightPressed');
    else if (code === 'KeyQ') pulse('quickTurnPressed');
    else if (code === 'KeyM') pulse('mapPressed');
    else used = false;
    if (used) {
      e.preventDefault();
      syncMove();
    }
  }

  function onKeyUp(e) {
    const code = e.code;
    actionHolds.delete(code); // the focused action button may have disappeared while held
    if (groupedCodes.has(code)) { pressedKeys.delete(code); syncKeys(); }
    const button = e.target?.closest?.('[data-touch]');
    if (button && (code === 'Enter' || code === 'Space')) {
      handleBtn(button.dataset.touch, false, code);e.preventDefault();return;
    }
    syncMove();
  }

  function onMouseMove(e) {
    if (!document.pointerLockElement) return;
    input.lookX += e.movementX || 0;
    input.lookY += e.movementY || 0;
  }

  function onGameClick() {
    if (blocked() || !playing()) return;
    if (touchOn() || ctx.dragLook) return;
    const el = ctx.gameEl || document.getElementById('game');
    // Too soon after Esc the browser refuses. A later click on the game takes it again.
    if (el && el.requestPointerLock) el.requestPointerLock()?.catch?.(() => {});
  }

  // With the mouse captured the browser keeps Esc for itself and only tells us the capture ended.
  function onLockChange() {
    if (!document.pointerLockElement && playing()) input.lockLost = true;
  }

  function onContext(e) { if (!blocked() && playing()) e.preventDefault(); }
  function onGesture(e) { if (!blocked() && pointers.size) e.preventDefault(); }

  const touchRoot = ctx.uiRoot || ctx.touchEl || document.getElementById('ui');
  const gameEl = ctx.gameEl || document.getElementById('game');

  listen(touchRoot, 'pointerdown', onPointerDown);
  listen(window, 'pointermove', onPointerMove);
  listen(window, 'pointerup', onPointerUp);
  listen(window, 'pointercancel', onPointerUp);
  listen(window, 'lostpointercapture', onPointerUp);
  if (typeof window.PointerEvent !== 'function') {
    listen(touchRoot, 'touchstart', onTouchStart, { passive: false });
    if (gameEl && gameEl !== touchRoot) listen(gameEl, 'touchstart', onTouchStart, { passive: false });
    // Touches keep their original target, but finish/cancel can occur beyond
    // either surface. Only identifiers claimed at touchstart suppress default.
    listen(window, 'touchmove', onTouchMove, { passive: false });
    listen(window, 'touchend', onTouchEnd, { passive: false });
    listen(window, 'touchcancel', onTouchEnd, { passive: false });
  }
  // Also listen on the game view so portrait look-drag on the picture works.
  if (gameEl) {
    if (gameEl !== touchRoot) listen(gameEl, 'pointerdown', onPointerDown);
    listen(gameEl, 'click', onGameClick);
  }
  listen(window, 'keydown', onKeyDown);
  listen(window, 'keyup', onKeyUp);
  listen(window, 'mousemove', onMouseMove);
  listen(document, 'pointerlockchange', onLockChange);
  listen(window, 'contextmenu', onContext);
  listen(window, 'gesturestart', onGesture);

  listen(window, 'blur', () => resetPointers({ keepRun: true }));
  let lastLayout=stickLayout(ctx.stickEl);
  function onLayoutChange(){
    // The touch layer is put away for a film and brought back: a resting thumb keeps its stick.
    const r=ctx.stickEl?.getBoundingClientRect?.();
    if(r&&!r.width&&!r.height)return;
    const layout=stickLayout(ctx.stickEl);
    if(layout!==lastLayout)resetPointers({ keepRun: true });
    lastLayout=layout;
  }
  listen(window,'resize',onLayoutChange);
  if(window.visualViewport?.addEventListener)listen(window.visualViewport,'resize',onLayoutChange);

  function setLight(on) {
    lightOn = !!on;
    if (ctx.onLight) ctx.onLight(lightOn);
  }

  function releasePointerLock() {
    if (document.pointerLockElement) document.exitPointerLock();
  }

  // keepRun: RUN is a switch the player set, not a held key. It stays on through the map, a pause,
  // a film or a change of window; it is cleared only when a night ends or begins.
  function resetPointers({ keepRun = false } = {}) {
    const owned = [...pointers];
    pointers.clear();
    for (const [id, p] of owned) { p.btn?.classList.remove('is-down');releaseCapture(id, p); }
    stick = null;
    if (!keepRun) setRunLatch(false);
    actionHolds.clear();
    pressedKeys.clear();syncKeys();
    input.moveX = input.moveY = input.lookX = input.lookY = 0;
    input.run = keepRun && runHeld;
    input.sneak = input.action = input.actionHeld = false;
    input.flashlightPressed = input.mapPressed = input.quickTurnPressed = false;
    input.pausePressed = input.lockLost = false;
    if (ctx.stickEl) {
      ctx.stickEl.hidden = !ctx.stickZone;
      ctx.stickEl.classList.remove('is-active');
      const knob=ctx.stickEl.querySelector('.stick-knob');
      if(knob)knob.style.transform='';
    }
  }

  function dispose() {
    if (disposed) return;
    disposed = true;
    for (const remove of removeListeners.splice(0)) remove();
    resetPointers();releasePointerLock();
  }

  return { syncMove, pulse, setLight, releasePointerLock, resetPointers, dispose, capture: onGameClick, peek: () => peekInput(input) };
}
