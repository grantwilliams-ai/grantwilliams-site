import { displayMode, displayHelp, enterFullscreen, exitFullscreen, FULLSCREEN_FAILURE } from './display-mode.js';
import { BRIGHTNESS_RANGE } from '../campaign/state.js';
import { UI_CSS } from './css.js';
import { drawCampMap } from './map.js';
import { createBlood } from './blood.js';
import { createHide } from './hide.js';
import { createInputState, bindInput, peekInput } from './input.js';
import { createMessages } from './messages.js';
import { resolveInputMode } from './input-mode.js';
import { controlRows, keyStrip, flashlightState, promptText } from './controls.js';
import { createCompass } from './compass.js';

const STORAGE = 'goomw-v3-settings';
const DEFAULTS = {
  brightness: 1,
  sound: 0.8,
  steps: 0.45,
  weather: 0.7,
  picture: 'retro',
  tape: true,
  flashes: 'full',
  difficulty: 'normal',
  inputMode: 'auto',
  hints: true,
  compass: true,
};

const DEATH_LINES = [
  'The woods keep what they catch.',
  'Last bus left at sundown. You missed it twice.',
  'He does not run. He does not need to.',
  'Nobody checks the woods after Labor Day.',
  'Counselor of the week. Closed casket.',
  'You should have taken the day shift.',
  'Stillwater does not give refunds.',
  'They told you not to go in the woods.',
  'The pitchfork found what the flashlight missed.',
  'Camp’s closed. You are not.',
  'Nobody heard you. Nobody was left to.',
  'You packed a flashlight. You packed nothing else.',
  'The sack does not change its mind.',
  'Lights out means lights out.',
  'You were supposed to lock the gate.',
  'He waited at the end of the path you chose.',
];

function injectCss() {
  if (document.getElementById('goomw-ui-css')) return;
  const s = document.createElement('style');
  s.id = 'goomw-ui-css';
  s.textContent = UI_CSS;
  document.head.appendChild(s);
}

function loadSettings() {
  let s = { ...DEFAULTS };
  try {
    const raw = localStorage.getItem(STORAGE);
    if (raw) s = { ...DEFAULTS, ...JSON.parse(raw) };
  } catch (_) { /* private mode */ }
  if (typeof s.brightness === 'number' && s.brightness > 2) s.brightness = 1;
  if (typeof s.sound === 'number' && s.sound > 1) s.sound = Math.min(1, s.sound / 100);
  if (s.tape === 'on') s.tape = true;
  if (s.tape === 'off') s.tape = false;
  return s;
}

function saveSettings(s) {
  try { localStorage.setItem(STORAGE, JSON.stringify(s)); } catch (_) { /* */ }
}

function fmtTime(sec) {
  const s = Math.max(0, Math.floor(Number(sec) || 0));
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}

function endingRank({ time = 0, seen = 0 }) {
  const t = Number(time) || 0;
  const s = Number(seen) || 0;
  if (s === 0 && t <= 240) return { name: 'GHOST', line: 'Out before he knew the camp had a guest.' };
  if (s === 0) return { name: 'QUIET FEET', line: 'Every twig that did not snap was a small mercy.' };
  if (s <= 1 && t <= 360) return { name: 'CLOSE CALL', line: 'He saw you. Then he did not. Keep it that way.' };
  if (s <= 2) return { name: 'SLIPPED THE FORK', line: 'You leave. The pitchfork stays hungry.' };
  if (t >= 720) return { name: 'TOOK THE SCENIC ROUTE', line: 'Five more minutes and the sun would have had to do it.' };
  if (s >= 7) return { name: 'WALKING DINNER BELL', line: 'He got a full tour. You got a car.' };
  return { name: 'LAST BUS OUT', line: 'Not clean. Not quiet. Gone anyway.' };
}

export function createUI(root, handlers = {}) {
  injectCss();
  root.classList.add('goomw-ui');
  const campaign = handlers.campaign || null;
  // Campaign settings belong to the connected V4 save, never the preserved V3 key.
  const settings = campaign ? {...DEFAULTS, ...campaign.preferences,
    sound:campaign.preferences?.volume ?? DEFAULTS.sound} : loadSettings();
  delete settings.volume;
  let disposed = false;
  let mapRaf = 0;
  const input = createInputState();
  const h = handlers;

  // One rule for touch or keyboard words and HUD: the player's Settings choice, else the primary pointer.
  const inputMode = () => resolveInputMode(settings.inputMode);
  const messages = createMessages();

  root.innerHTML = `
    <div class="hud" hidden>
      <div class="hud-top">
        <div class="hud-obj" hidden></div>
        <div class="hud-hint" hidden>${campaign ? 'Drag the picture to look around.' : 'Move the mouse to look around.'}</div>
        <div class="hud-pursuit" role="status" aria-live="polite" hidden></div>
        <div class="hud-inv">
          <span data-inv="keys" hidden>KEYS</span>
          <span data-inv="battery" hidden>BATTERY</span>
        </div>
        <div class="hud-toast" hidden></div>
      </div>
      <div class="hud-stack">
        <div class="hud-stam" hidden><i></i></div>
        <button type="button" class="hud-prompt" data-touch="action" hidden>
          <span class="prompt-word"></span>
          <span class="hold-bar" hidden><i></i></span>
        </button>
        <div class="hud-cap" hidden></div>
      </div>
      <div class="hud-keys" hidden><b class="keys-light"></b><b class="keys-run" hidden></b><span class="keys-line"></span></div>
    </div>

    <div class="touch-layer" hidden>
      <button type="button" class="tbtn tbtn-map" data-touch="map">MAP</button>
      <button type="button" class="tbtn tbtn-pause" data-touch="pause">PAUSE</button>
      <button type="button" class="tbtn tbtn-action" data-touch="action" hidden>
        <span class="action-label">ACTION</span>
        <span class="hold-bar" hidden><i></i></span>
      </button>
      <button type="button" class="tbtn tbtn-run" data-touch="run">RUN</button>
      <button type="button" class="tbtn tbtn-light" data-touch="light" aria-pressed="true"><span class="light-label">FLASH<wbr>LIGHT</span><span class="light-state">ON</span></button>
      <div class="stick-zone">
        <div class="stick"><div class="stick-base"></div><div class="stick-knob"></div></div>
        <div class="stick-label">MOVE</div>
      </div>
    </div>

    <div class="screen screen-loading" data-screen="loading" hidden>
      <div class="loading-inner">
        <p class="loading-word">LOADING</p>
        <div class="loading-bar"><i></i></div>
        <p class="loading-sub">CAMP STILLWATER, 1984</p>
      </div>
    </div>

    <div class="screen screen-title" data-screen="title" hidden>
      <div class="title-layout">
        <div class="title-left">
          <h1 class="mark" aria-label="Get Out of My Woods">
            <span class="l1">GET OUT</span>
            <span class="l2">OF MY</span>
            <span class="l3">WOODS</span>
          </h1>
          ${campaign ? '' : '<p class="edition">V3 · THE LONG WAY OUT</p>'}
          <p class="place">CAMP STILLWATER · 1984</p>
          <p class="warn">Graphic violence, blood, flashing lights, jump scares.</p>
          ${campaign ? '<p class="title-credit">A GAME BY GRANT WILLIAMS</p>' : ''}
        </div>
        <div class="title-right">
          ${campaign ? '<button type="button" class="btn btn-continue" data-act="continue" hidden>CONTINUE FROM CRASH</button>' : ''}
          <button type="button" class="btn btn-play" data-act="play">${campaign ? 'NEW GAME' : 'PLAY'}</button>
          <button type="button" class="btn" data-act="howto">HOW TO PLAY</button>
          <button type="button" class="btn" data-act="settings">SETTINGS</button>
          <button type="button" class="btn btn-display" data-act="fullscreen">FULLSCREEN</button>
        </div>
      </div>
    </div>

    <div class="screen screen-menu" data-screen="difficulty" hidden>
      <div class="menu-card">
        <h2 class="menu-title">HOW BAD</h2>
        <p class="menu-kicker">Last night of the season.</p>
        <button type="button" class="btn diff-btn" data-diff="easy"><strong>EASY</strong><span>For a first night. He is slower and duller, and you can run longer.</span></button>
        <button type="button" class="btn diff-btn" data-diff="normal"><strong>NORMAL</strong><span>He hunts. Break sight and keep moving.</span></button>
        <button type="button" class="btn diff-btn" data-diff="hard"><strong>HARD</strong><span>Sharper senses. He searches longer. Relentless pursuit.</span></button>
        <button type="button" class="btn" data-act="back">BACK</button>
      </div>
    </div>

    <div class="screen screen-menu" data-screen="howto" hidden>
      <div class="menu-card wide">
        <h2 class="menu-title">HOW TO PLAY</h2>
        <div class="how-cols">
          <div class="how-block is-first" data-how="primary"></div>
          <div class="how-block" data-how="secondary"></div>
          <div class="how-block" data-how="night">
            <h3>STAY ALIVE</h3>
            <p>Find your keys and a car battery. Things worth searching catch your flashlight. Hold the action to search. Searching makes noise and does not protect you. The battery goes under the hood.</p>
            <p>He hears you run and sees your flashlight. With the light off he has to get much closer.</p>
            <p>Run around a cabin or dense trees to break his view. When he loses you, slow down, switch off the light, then hide.</p>
            <p>Hide where he cannot see you go in. If he saw you enter, leave before he checks. Resting restores your breath.</p>
          </div>
        </div>
        <button type="button" class="btn" data-act="back">BACK</button>
      </div>
    </div>

    <div class="screen screen-menu" data-screen="display" hidden>
      <div class="menu-card wide">
        <h2 class="menu-title">FULL SCREEN</h2>
        <button type="button" class="btn btn-play" data-act="enter-fullscreen" hidden>ENTER FULLSCREEN</button>
        <p class="display-status" role="status" hidden></p>
        <div class="display-help"></div>
        <button type="button" class="btn" data-act="display-back">BACK</button>
      </div>
    </div>

    <div class="screen screen-menu" data-screen="controls" hidden>
      <div class="menu-card wide">
        <h2 class="menu-title">CONTROLS</h2>
        <div class="how-cols controls-cols">
          <div class="how-block is-first" data-how="primary"></div>
          <div class="how-block" data-how="secondary"></div>
        </div>
        <button type="button" class="btn" data-act="controls-back">BACK</button>
      </div>
    </div>

    <div class="screen screen-menu" data-screen="confirm" hidden>
      <div class="menu-card">
        <h2 class="menu-title confirm-title"></h2>
        <p class="confirm-text"></p>
        <button type="button" class="btn btn-play" data-act="confirm-yes"></button>
        <button type="button" class="btn" data-act="confirm-no">CANCEL</button>
      </div>
    </div>

    <div class="screen screen-menu" data-screen="settings" hidden>
      <div class="menu-card wide">
        <h2 class="menu-title">SETTINGS</h2>
        <div class="set-grid">
          <div class="set-row" data-set="brightness">
            <span class="set-label">Brightness</span>
            <div class="stepper">
              <button type="button" class="step" data-step="brightness" data-d="-0.1" aria-label="Brightness down">−</button>
              <span class="step-val" data-val="brightness">100</span>
              <button type="button" class="step" data-step="brightness" data-d="0.1" aria-label="Brightness up">+</button>
            </div>
          </div>
          <div class="set-row" data-set="sound">
            <span class="set-label">Sound</span>
            <div class="stepper">
              <button type="button" class="step" data-step="sound" data-d="-0.1" aria-label="Sound down">−</button>
              <span class="step-val" data-val="sound">80</span>
              <button type="button" class="step" data-step="sound" data-d="0.1" aria-label="Sound up">+</button>
            </div>
          </div>
          <div class="set-row" data-set="steps">
            <span class="set-label">Your footsteps</span>
            <div class="stepper">
              <button type="button" class="step" data-step="steps" data-d="-0.1" aria-label="Your footsteps down">−</button>
              <span class="step-val" data-val="steps">45</span>
              <button type="button" class="step" data-step="steps" data-d="0.1" aria-label="Your footsteps up">+</button>
            </div>
          </div>
          <div class="set-row" data-set="weather">
            <span class="set-label">Rain and wind</span>
            <div class="stepper">
              <button type="button" class="step" data-step="weather" data-d="-0.1" aria-label="Rain and wind down">−</button>
              <span class="step-val" data-val="weather">70</span>
              <button type="button" class="step" data-step="weather" data-d="0.1" aria-label="Rain and wind up">+</button>
            </div>
          </div>
          <p class="set-note">Changes what you hear, not what he hears. His footsteps stay audible.</p>
          <div class="set-row" data-set="picture">
            <span class="set-label">Picture</span>
            <div class="pills">
              <button type="button" class="pill" data-pill="picture" data-v="sharp">Clean</button>
              <button type="button" class="pill" data-pill="picture" data-v="retro">Retro</button>
            </div>
          </div>
          <div class="set-row" data-set="tape">
            <span class="set-label">Tape effect</span>
            <div class="pills">
              <button type="button" class="pill" data-pill="tape" data-v="false">Off</button>
              <button type="button" class="pill" data-pill="tape" data-v="true">On</button>
            </div>
          </div>
          <div class="set-row" data-set="flashes">
            <span class="set-label">Flashes</span>
            <div class="pills">
              <button type="button" class="pill" data-pill="flashes" data-v="full">Full</button>
              <button type="button" class="pill" data-pill="flashes" data-v="reduced">Reduced</button>
            </div>
          </div>
          <div class="set-row" data-set="inputMode">
            <span class="set-label">Controls shown</span>
            <div class="pills">
              <button type="button" class="pill" data-pill="inputMode" data-v="auto">Automatic</button>
              <button type="button" class="pill" data-pill="inputMode" data-v="keyboard">Keyboard &amp; mouse</button>
              <button type="button" class="pill" data-pill="inputMode" data-v="touch">Touch</button>
            </div>
          </div>
          <div class="set-row" data-set="hints">
            <span class="set-label">Control hints</span>
            <div class="pills">
              <button type="button" class="pill" data-pill="hints" data-v="true">On</button>
              <button type="button" class="pill" data-pill="hints" data-v="false">Off</button>
            </div>
          </div>
          <div class="set-row" data-set="compass">
            <span class="set-label">Compass</span>
            <div class="pills">
              <button type="button" class="pill" data-pill="compass" data-v="true">On</button>
              <button type="button" class="pill" data-pill="compass" data-v="false">Off</button>
            </div>
          </div>
        </div>
        <button type="button" class="btn" data-act="display">FULLSCREEN / PHONE SETUP</button>
        <p class="credits">© 2026 Grant Williams. Free and open source under the MIT License. A non-profit fan homage, not connected with any film or studio. Fonts: VT323, Oswald and Anton (SIL Open Font License), Special Elite and Rock Salt (Apache License 2.0). Built with three.js (MIT). All art, sound and music were made for this game.</p>
        <button type="button" class="btn" data-act="back">BACK</button>
      </div>
    </div>

    <div class="screen screen-pause" data-screen="pause" hidden>
      <div class="menu-card">
        <h2 class="menu-title">PAUSED</h2>
        <p class="pause-obj" hidden></p>
        <ul class="pause-recent" hidden></ul>
        <button type="button" class="btn btn-play" data-act="resume">RESUME</button>
        <button type="button" class="btn" data-act="controls">CONTROLS</button>
        <button type="button" class="btn" data-act="settings">SETTINGS</button>
        <button type="button" class="btn" data-act="quit">QUIT</button>
      </div>
    </div>

    <div class="map-wrap" data-screen="map" hidden>
      <canvas class="map-paper" width="800" height="560"></canvas>
      <button type="button" class="btn map-close" data-act="mapclose">CLOSE</button>
    </div>

    <div class="screen screen-gameover" data-screen="gameover" hidden>
      <div class="menu-card">
        <h2 class="menu-title red">GAME OVER</h2>
        <p class="death-line"></p>
        <div class="stat-list"></div>
        <div class="btn-row">
          <button type="button" class="btn btn-play" data-act="retry">TRY AGAIN</button>
          <button type="button" class="btn" data-act="quit">QUIT</button>
        </div>
      </div>
    </div>

    <div class="screen screen-ending" data-screen="ending" hidden>
      <div class="menu-card ending-card">
        <h2 class="menu-title">YOU GOT OUT</h2>
        <div class="stat-list"></div>
        <div class="rank-name"></div>
        <p class="rank-line"></p>
      </div>
      <div class="ending-last" hidden>
        <p class="stay-out">AND STAY OUT.</p>
        <button type="button" class="btn btn-play" data-act="retry">PLAY AGAIN</button>
      </div>
    </div>

    <div class="titlecard" hidden>
      <div class="titlecard-text"></div>
    </div>
    <div class="more-cue" aria-hidden="true" hidden>MORE ↓</div>
  `;

  const screens = {};
  for (const node of root.querySelectorAll('[data-screen]')) screens[node.dataset.screen] = node;
  const hud = root.querySelector('.hud');
  const hudObj = root.querySelector('.hud-obj');
  const hudHint = root.querySelector('.hud-hint');
  const hudPursuit = root.querySelector('.hud-pursuit');
  let pursuit = '';
  function setPursuit(state) {
    if (state === pursuit) return;
    pursuit = state;
    const labels = {spotted: 'HE SAW YOU · Break his view', pursuit: 'PURSUIT · Find cover', searching: 'HE LOST SIGHT · Move quietly', hidden: 'HIDDEN · Listen before leaving', hideSeen: 'HE SAW YOU HIDE · Leave before he checks'};
    hudPursuit.textContent = labels[state] || '';
    hudPursuit.dataset.state = state;
    hudPursuit.hidden = !labels[state];
  }
  let hintTimer = 0;
  let objTimer = 0;
  let objText = '';
  let toastLeft = 0;
  const hudStam = root.querySelector('.hud-stam');
  const hudPrompt = root.querySelector('.hud-prompt');
  const promptWord = root.querySelector('.prompt-word');
  const holdBars = [...root.querySelectorAll('.hold-bar')];
  const hudToast = root.querySelector('.hud-toast');
  const hudCap = root.querySelector('.hud-cap');
  const hudKeys = root.querySelector('.hud-keys');
  const keysLine = root.querySelector('.keys-line');
  const keysLight = root.querySelector('.keys-light');
  const keysRun = root.querySelector('.keys-run');
  const runBtn = root.querySelector('.tbtn-run');
  const moreCue = root.querySelector('.more-cue');
  const invKeys = root.querySelector('[data-inv="keys"]');
  const invBat = root.querySelector('[data-inv="battery"]');
  const touchEl = root.querySelector('.touch-layer');
  const actionBtn = root.querySelector('.tbtn-action');
  const actionLabel = root.querySelector('.action-label');
  const lightBtn = root.querySelector('.tbtn-light');
  const stickEl = root.querySelector('.stick');
  const mapCanvas = root.querySelector('.map-paper');
  const titlecard = root.querySelector('.titlecard');
  const titlecardText = root.querySelector('.titlecard-text');
  const loadBar = root.querySelector('.loading-bar > i');

  const blood = createBlood(root);
  const hide = createHide(root);
  // The heading tape sits above the objective. Its room is kept whenever the setting is on, so the
  // objective does not jump each time the tape rests (indoors, in a film, in a hiding place).
  const compass = createCompass(hud);
  function syncCompass() {
    hud.classList.toggle('has-compass', settings.compass !== false);
    if (settings.compass === false) compass.set(null);
  }
  function setCompass(view) { compass.set(settings.compass === false ? null : view); }
  syncCompass();

  let mode = 'none';
  let settingsBack = 'title';
  let displayBack = 'title';
  let touchVisible = false;
  let promptLabel = null;
  let cardTimer = 0;
  let endingTimer = 0;
  let lightLit = true;
  let keysAllowed = false; // the app says the night is in ordinary play (no film, death or car)
  let confirmBack = 'title';
  let confirmYes = null;
  let controlsBack = 'pause';

  function setMode(name) {
    mode = name;
    for (const [k, node] of Object.entries(screens)) node.hidden = k !== name;
    titlecard.hidden = name !== 'titlecard';
    const play = name === 'play';
    hud.hidden = !play && name !== 'map' && name !== 'hide';
    if (name === 'play') hud.hidden = false;
    if (name === 'map') hud.hidden = true;
    document.body.classList.toggle('ui-playing', play);
    document.body.classList.toggle('ui-touch-on', play && touchVisible);
    if (name !== 'play') {
      io.releasePointerLock();
      // Screens you come back from keep RUN as it was; the ones that end or start a night clear it.
      io.resetPointers({ keepRun: ['map', 'pause', 'settings', 'controls', 'howto', 'display', 'confirm', 'hide'].includes(name) });
    }
    updateKeys();
    updateMore();
    window.dispatchEvent(new Event('resize'));
  }

  function hideScreens() {
    for (const node of Object.values(screens)) node.hidden = true;
    titlecard.hidden = true;
  }

  function paintSettings() {
    root.querySelector('[data-val="brightness"]').textContent = String(Math.round(settings.brightness * 100));
    root.querySelector('[data-val="sound"]').textContent = String(Math.round(settings.sound * 100));
    root.querySelector('[data-val="steps"]').textContent = String(Math.round(settings.steps * 100));
    root.querySelector('[data-val="weather"]').textContent = String(Math.round((settings.weather ?? 0.7) * 100));
    for (const pill of root.querySelectorAll('.pill')) {
      pill.classList.toggle('is-on', String(settings[pill.dataset.pill]) === pill.dataset.v);
    }
  }
  paintSettings();

  function applySetting(key, value) {
    settings[key] = value;
    if (!campaign) saveSettings(settings);
    paintSettings();
    if (key === 'inputMode' || key === 'hints') refreshInputUi();
    if (key === 'compass') syncCompass();
    h.onSetting?.(key, value);
  }

  // Controls the player is shown follow one rule (Settings choice, else the primary pointer). A change
  // takes effect at once: the key strip, the prompt words, and the help pages.
  function refreshInputUi() {
    updateKeys();
    renderPromptWords();
    fillControls(screens.howto);
    fillControls(screens.controls);
    updateMore();
  }

  function fillControls(container) {
    if (!container) return;
    const here = inputMode();
    const there = here === 'touch' ? 'keyboard' : 'touch';
    const put = (el, m, first) => {
      if (!el) return;
      el.replaceChildren();
      el.classList.toggle('is-first', first);
      const head = document.createElement('h3');
      head.textContent = m === 'touch' ? 'TOUCH' : 'KEYBOARD AND MOUSE';
      if (!first) head.classList.add('minor');
      el.append(head);
      for (const row of controlRows(1, m)) {
        const line = document.createElement('p');
        const what = document.createElement('b');
        what.textContent = row.does + ': ';
        line.append(what, row.how);
        el.append(line);
      }
    };
    put(container.querySelector('[data-how="primary"]'), here, true);
    put(container.querySelector('[data-how="secondary"]'), there, false);
  }

  // The always-visible key reminder (keyboard mode, ordinary play only) with the flashlight's state.
  function updateKeys() {
    const show = keysAllowed && mode === 'play' && !carOn && inputMode() === 'keyboard' && settings.hints !== false;
    hudKeys.hidden = !show;
    if (show) {
      keysLine.textContent = keyStrip(1);
      keysLight.textContent = flashlightState(lightLit).text;
    }
    root.style.setProperty('--keys-h', show ? Math.ceil(hudKeys.offsetHeight) + 'px' : '0px');
  }

  function setKeyStrip(on) {
    on = !!on;
    if (on === keysAllowed) return;
    keysAllowed = on;
    updateKeys();
  }

  function setLightUi(on) {
    lightLit = !!on;
    const st = flashlightState(lightLit);
    lightBtn.setAttribute('aria-pressed', String(lightLit));
    lightBtn.querySelector('.light-state').textContent = st.state;
    lightBtn.setAttribute('aria-label', st.text);
    if (!hudKeys.hidden) keysLight.textContent = st.text;
  }

  // A visible cue when a menu is longer than the screen: "MORE ↓" until the bottom is reached.
  function updateMore() {
    const node = screens[mode];
    let more = false;
    if (node && !node.hidden && mode !== 'map' && mode !== 'loading') {
      const card = node.querySelector(':scope > .menu-card');
      for (const el of [card, node]) {
        if (!el) continue;
        const style = getComputedStyle(el);
        if (!/auto|scroll/.test(style.overflowY)) continue;
        if (el.scrollHeight - el.clientHeight > 4 && el.scrollTop + el.clientHeight < el.scrollHeight - 6) more = true;
      }
    }
    moreCue.hidden = !more;
    if (more) {
      // Sit just above the BACK button that stays in reach, never over it.
      const back = node.querySelector(':scope > .menu-card > .btn[data-act$="back"]');
      const gap = back ? Math.max(10, Math.round(window.innerHeight - back.getBoundingClientRect().top) + 8) : 10;
      moreCue.style.bottom = gap + 'px';
      // A wide card keeps its buttons on the left: sit at its right edge, clear of them.
      const rect = node.querySelector(':scope > .menu-card')?.getBoundingClientRect();
      const wide = !!rect && rect.width >= 700;
      moreCue.style.left = wide ? 'auto' : '';
      moreCue.style.right = wide ? Math.round(window.innerWidth - rect.right + 24) + 'px' : '';
      moreCue.style.transform = wide ? 'none' : '';
    }
  }

  function statsHtml(stats) {
    return `
      <div class="stat-row"><span>Time survived</span><b>${fmtTime(stats.time)}</b></div>
      <div class="stat-row"><span>Places searched</span><b>${stats.searched ?? 0}</b></div>
      <div class="stat-row"><span>Times he saw you</span><b>${stats.seen ?? 0}</b></div>
    `;
  }

  function showScreen(name) {
    if (name === 'title' && campaign) {
      const cont = root.querySelector('[data-act="continue"]');
      cont.hidden = !campaign.canContinue?.();
      // Never promise a save the browser would not keep.
      cont.textContent = campaign.checkpointSaved?.() === false ? 'CONTINUE FROM CRASH · THIS SESSION ONLY' : 'CONTINUE FROM CRASH';
    }
    hideScreens();
    setMode(name);
  }

  function beginPlay() {
    hideScreens();
    io.resetPointers({ keepRun: true });
    showObjective();
    mode = 'play';
    hud.hidden = false;
    touchEl.hidden = !touchVisible;
    document.body.classList.add('ui-playing');
    document.body.classList.toggle('ui-touch-on', touchVisible);
    updateKeys();
    updateMore();
    window.dispatchEvent(new Event('resize'));
  }

  const io = bindInput(input, {
    mapOpen: () => mode === 'map',
    closeMap: () => closeMap(),
    blocked: () => mode !== 'play' && mode !== 'hide',
    playing: () => mode === 'play' || mode === 'hide',
    touchOn: () => touchVisible && (mode === 'play' || mode === 'hide'),
    touchEl,
    uiRoot:root,
    dragLook:!!campaign,
    stickEl,
    stickZone:root.querySelector('.stick-zone'),
    gameEl: document.getElementById('game'),
    onLight(on) { setLightUi(on); },
    // Esc goes back one step in menus; in play it falls through to the game, which pauses or resumes.
    onEscape: () => handleEscape(),
  });
  fillControls(screens.howto);
  fillControls(screens.controls);

  function handleEscape() {
    if (mode === 'confirm') { cancelConfirm(); return true; }
    if (mode === 'settings') { backFromSettings(); return true; }
    if (mode === 'controls') { showScreen(controlsBack); return true; }
    if (mode === 'howto') { backFromSettings(); return true; }
    if (mode === 'display') { showScreen(displayBack); return true; }
    if (mode === 'difficulty') { showScreen('title'); return true; }
    if (mode === 'map') { closeMap(); return true; }
    // Nothing to pause or resume on these.
    if (['title', 'loading', 'gameover', 'ending', 'none', 'disposed'].includes(mode)) return true;
    return false;
  }

  function backFromSettings() {
    if (settingsBack === 'pause') showScreen('pause');
    else if (settingsBack === 'play') { beginPlay(); h.onResume?.(); }
    else showScreen('title');
  }

  // The fullscreen page: every device's steps, this device's first.
  function showDisplay(status = '') {
    if (mode !== 'display') displayBack = mode;
    const display = displayMode();
    root.querySelector('.display-help').innerHTML = displayHelp(display);
    root.querySelector('[data-act="enter-fullscreen"]').hidden = display !== 'native' || !!document.fullscreenElement;
    const line = root.querySelector('.display-status');
    line.textContent = status;
    line.hidden = !status;
    showScreen('display');
  }

  // The title's button says what a press will do; a Home Screen launch has nothing left to offer.
  function syncFullscreenButton() {
    if (disposed) return;
    const btn = root.querySelector('[data-act="fullscreen"]');
    if (!btn) return;
    btn.hidden = displayMode() === 'standalone' && !document.fullscreenElement;
    btn.textContent = document.fullscreenElement ? 'EXIT FULLSCREEN' : 'FULLSCREEN';
  }
  document.addEventListener('fullscreenchange', syncFullscreenButton);
  syncFullscreenButton();

  function showConfirm({ title, text, yes, onYes }) {
    confirmBack = mode;
    confirmYes = onYes;
    screens.confirm.querySelector('.confirm-title').textContent = title;
    screens.confirm.querySelector('.confirm-text').textContent = text;
    screens.confirm.querySelector('[data-act="confirm-yes"]').textContent = yes;
    showScreen('confirm');
  }

  function cancelConfirm() {
    confirmYes = null;
    showScreen(confirmBack);
  }

  // If a menu is up, Esc should close it rather than only pulsing pause.
  // bindInput already pulses pausePressed on Esc; the game decides. We also
  // handle BACK locally for our own screens.

  function onClick(e) {
    const btn = e.target.closest('button');
    if (!btn) return;
    const act = btn.dataset.act;
    const diff = btn.dataset.diff;
    const step = btn.dataset.step;
    const pill = btn.dataset.pill;
    if (diff) {
      applySetting('difficulty', diff);
      h.onStart?.(diff);
      beginPlay();
      io.capture();
      return;
    }
    if (step) {
      const d = Number(btn.dataset.d);
      if (step === 'brightness') {
        const range = campaign ? BRIGHTNESS_RANGE : { min: .4, max: 1.6 };
        applySetting(step, Math.max(range.min, Math.min(range.max, +(settings.brightness + d).toFixed(1))));
      } else if (step === 'sound' || step === 'steps' || step === 'weather') {
        applySetting(step, Math.max(0, Math.min(1, +((settings[step] ?? 0.7) + d).toFixed(2))));
      }
      return;
    }
    if (pill) {
      let v = btn.dataset.v;
      if (pill === 'tape' || pill === 'hints' || pill === 'compass') v = v === 'true' || v === 'on';
      applySetting(pill, v);
      return;
    }
    if (act === 'continue') { if(campaign?.canContinue?.()) campaign.onResumeCheckpoint?.(); }
    else if (act === 'play') {
      if (campaign?.canContinue?.()) {
        showConfirm({ title: 'NEW GAME?', text: 'Start a new game? This replaces your crash checkpoint.', yes: 'NEW GAME', onYes: () => showScreen('difficulty') });
      } else showScreen('difficulty');
    }
    else if (act === 'howto') { settingsBack = mode; showScreen('howto'); }
    else if (act === 'controls') { controlsBack = mode; fillControls(screens.controls); showScreen('controls'); }
    else if (act === 'controls-back') showScreen(controlsBack);
    else if (act === 'confirm-yes') { const go = confirmYes; confirmYes = null; go?.(); }
    else if (act === 'confirm-no') cancelConfirm();
    else if (act === 'display') showDisplay();
    else if (act === 'fullscreen') {
      // The title's button does the thing itself wherever the browser allows it. Where it cannot
      // (an iPhone, an in-app browser) or the request is refused, it opens the steps instead.
      if (document.fullscreenElement) exitFullscreen().then(syncFullscreenButton);
      else if (displayMode() !== 'native') showDisplay();
      else enterFullscreen().then(ok => {
        if (disposed) return;
        syncFullscreenButton();
        if (!ok && mode === 'title') showDisplay(FULLSCREEN_FAILURE);
      });
    }
    else if (act === 'display-back') showScreen(displayBack);
    else if (act === 'enter-fullscreen') {
      enterFullscreen().then(ok => {
        if (disposed || mode !== 'display') return;
        syncFullscreenButton();
        const status = root.querySelector('.display-status');
        status.textContent = ok ? 'Fullscreen is on. Tap Back to continue.' : FULLSCREEN_FAILURE;
        status.hidden = false;
      });
    }
    else if (act === 'settings') { settingsBack = mode === 'settings' ? 'title' : mode; showScreen('settings'); }
    else if (act === 'back') backFromSettings();
    else if (act === 'resume') { beginPlay(); h.onResume?.(); io.capture(); }
    else if (act === 'quit') {
      const quit = () => { h.onQuit?.(); showScreen('title'); };
      if (mode === 'pause') showConfirm({ title: 'QUIT?', text: "Quit to the title? Tonight's progress at the camp will be lost.", yes: 'QUIT', onYes: quit });
      else quit();
    }
    else if (act === 'retry') {
      h.onRetry?.();
      beginPlay();
      io.capture();
    }
    else if (act === 'mapclose') closeMap();
  }
  root.addEventListener('click', onClick);

  // An objective says its piece and goes. The map and the pause menu bring it back for a moment.
  function setObjective(text) {
    clearTimeout(objTimer);
    objText = text || '';
    if (!text) { hudObj.hidden = true; hudObj.textContent = ''; return; }
    hudObj.hidden = false;
    hudObj.textContent = text;
    showObjective();
  }

  function showObjective() {
    clearTimeout(objTimer);
    hudObj.classList.remove('is-gone');
    objTimer = setTimeout(() => hudObj.classList.add('is-gone'), 8000);
  }

  // In the driver's seat there is one thing left to do. Everything else gets out of the way.
  let carOn = false;
  function setCarMode(on) {
    carOn = !!on;
    document.body.classList.toggle('ui-car', carOn);
    updateKeys();
  }

  // The sign slot. Its seconds are game seconds, so a pause does not use them up.
  function toast(text, seconds = 2.5) {
    if (!text) { hudToast.hidden = true; hudToast.textContent = ''; toastLeft = 0; return; }
    hudToast.hidden = false;
    hudToast.textContent = text;
    toastLeft = seconds || 2.5;
  }

  // One caption line, three kinds (urgent, essential, flavor); see messages.js. Game time only.
  function renderCaption() {
    const text = messages.text;
    hudCap.hidden = !text;
    hudCap.textContent = text;
    hudCap.dataset.kind = messages.kind || '';
  }

  function caption(text, seconds = 3, opts = {}) {
    if (!text) { messages.clear(); renderCaption(); return; }
    messages.say(text, { kind: opts?.kind, seconds, key: opts?.key, keep: opts?.keep });
    renderCaption();
  }

  function clearCaptions({ keepRecent = true } = {}) {
    messages.clear({ keepRecent });
    renderCaption();
  }

  // The frame loop calls this with game time only while the night runs.
  function tickMessages(dt) {
    if (!(dt > 0)) return;
    messages.update(dt);
    renderCaption();
    if (toastLeft > 0) {
      toastLeft -= dt;
      if (toastLeft <= 0) { hudToast.hidden = true; toastLeft = 0; }
    }
  }

  let promptHold = false;
  function renderPromptWords() {
    if (!promptLabel) return;
    const say = promptText(inputMode(), promptLabel, { hold: promptHold });
    promptWord.textContent = say;
    if (actionLabel) actionLabel.textContent = say;
    else actionBtn.textContent = say;
  }

  function setPrompt(label, hold = false) {
    promptLabel = label || null;
    promptHold = !!hold;
    if (!promptLabel) {
      hudPrompt.hidden = true;
      actionBtn.hidden = true;
      return;
    }
    renderPromptWords();
    hudPrompt.hidden = false;
    actionBtn.hidden = false;
  }

  function setShown(el, on) {
    if (!el) return;
    if (on) el.removeAttribute('hidden');
    else el.setAttribute('hidden', '');
  }

  function setHold(v) {
    const t = Math.max(0, Math.min(1, Number(v) || 0));
    for (const bar of holdBars) {
      setShown(bar, t > 0);
      const fill = bar.querySelector('i');
      if (fill) fill.style.width = (t * 100) + '%';
    }
  }

  // Says what RUN is doing, so a winded walk does not read as RUN having switched itself off.
  let runSaid = '';
  function setRun(on, winded) {
    const say = !on ? '' : winded ? 'RUN: ON · CATCHING BREATH' : 'RUN: ON';
    if (say === runSaid) return;
    runSaid = say;
    keysRun.textContent = say;
    keysRun.hidden = !say;
    keysRun.classList.toggle('is-winded', !!(on && winded));
    runBtn?.classList.toggle('is-winded', !!(on && winded));
    updateKeys();
  }

  function setStamina(v, visible) {
    const t = Math.max(0, Math.min(1, Number(v) || 0));
    const bar = hudStam.querySelector('i');
    bar.style.width = (t * 100) + '%';
    hudStam.classList.toggle('is-low', t < 0.35);
    const show = visible === undefined ? t < 0.99 : !!visible;
    hudStam.hidden = !show;
  }

  function setInventory({ keys, battery } = {}) {
    invKeys.hidden = !keys;
    invBat.hidden = !battery;
  }

  function setHide(type) {
    hide.set(type);
    if (type) {
      mode = 'hide';
      document.body.classList.add('ui-playing');
      document.body.classList.toggle('ui-touch-on', touchVisible);
      setPrompt('LEAVE');
    } else if (mode === 'hide') {
      mode = 'play';
      if (promptLabel === 'LEAVE') setPrompt(null);
    }
  }

  function setTouchVisible(on) {
    touchVisible = !!on;
    touchEl.hidden = !touchVisible || (mode !== 'play' && mode !== 'hide');
    document.body.classList.toggle('ui-touch-on', touchVisible && (mode === 'play' || mode === 'hide'));
    window.dispatchEvent(new Event('resize'));
  }

  function closeMap() {
    beginPlay(); // brings the current objective back for a moment (K7)
    h.onMapClose?.();
    io.capture();
  }

  // First night, on a keyboard: the keys, under the objective, until the walk is under way.
  function showControlsHint(seconds = 16) {
    clearTimeout(hintTimer);
    hudHint.hidden = inputMode() === 'touch' || settings.hints === false || seconds <= 0;
    if (hudHint.hidden) return;
    hintTimer = setTimeout(() => { hudHint.hidden = true; }, seconds * 1000);
  }

  function showTitle() {
    settingsBack = 'title';
    io.releasePointerLock();
    hide.set(null);
    blood.clear();
    hud.hidden = true;
    touchEl.hidden = true;
    showScreen('title');
  }

  function hideAll() {
    hideScreens();
    hide.set(null);
    titlecard.hidden = true;
    mode = 'play';
    hud.hidden = false;
    document.body.classList.add('ui-playing');
    document.body.classList.toggle('ui-touch-on', touchVisible);
    touchEl.hidden = !touchVisible;
    io.resetPointers({ keepRun: true });
    updateKeys();
  }

  function showPause() {
    io.releasePointerLock();
    settingsBack = 'pause';
    const obj = screens.pause.querySelector('.pause-obj');
    obj.hidden = !objText;
    obj.textContent = objText ? 'NOW: ' + objText : '';
    const list = screens.pause.querySelector('.pause-recent');
    list.replaceChildren(...messages.recent().slice(0, 4).map((t) => { const li = document.createElement('li'); li.textContent = t; return li; }));
    list.hidden = !list.children.length;
    showScreen('pause');
  }

  function showGameOver(stats = {}) {
    io.releasePointerLock();
    hide.set(null);
    hud.hidden = true;
    touchEl.hidden = true;
    const line = DEATH_LINES[Math.floor(Math.random() * DEATH_LINES.length)];
    screens.gameover.querySelector('.death-line').textContent = line;
    screens.gameover.querySelector('.stat-list').innerHTML = statsHtml(stats);
    showScreen('gameover');
  }

  function showEnding(stats = {}) {
    io.releasePointerLock();
    hide.set(null);
    hud.hidden = true;
    touchEl.hidden = true;
    const rank = endingRank(stats);
    const card = screens.ending.querySelector('.ending-card');
    const last = screens.ending.querySelector('.ending-last');
    card.hidden = false;
    last.hidden = true;
    screens.ending.classList.remove('beat-black');
    screens.ending.querySelector('.stat-list').innerHTML = statsHtml(stats);
    screens.ending.querySelector('.rank-name').textContent = rank.name;
    screens.ending.querySelector('.rank-line').textContent = rank.line;
    showScreen('ending');
    clearTimeout(endingTimer);
    endingTimer = setTimeout(() => {
      card.hidden = true;
      screens.ending.classList.add('beat-black');
      endingTimer = setTimeout(() => {
        last.hidden = false;
      }, 700);
    }, 3200);
  }

  // animate: false brings a card back after a pause without slamming it in a second time.
  function showTitleCard(text, { seconds = 3, animate = true } = {}) {
    titlecardText.textContent = text || '';
    titlecard.hidden = false;
    titlecardText.style.animation = 'none';
    void titlecardText.offsetWidth;
    titlecardText.style.animation = animate ? '' : 'none';
    clearTimeout(cardTimer);
    cardTimer = setTimeout(() => { titlecard.hidden = true; }, seconds * 1000);
  }

  let lastMap = { player: { x: 3.4, z: 11.4 }, searched: [] };
  function openMap(state = {}) {
    lastMap = state;
    io.releasePointerLock();
    screens.map.hidden = false;
    for (const [k, node] of Object.entries(screens)) if (k !== 'map') node.hidden = true;
    titlecard.hidden = true;
    hud.hidden = true;
    mode = 'map';
    document.body.classList.remove('ui-playing');
    document.body.classList.remove('ui-touch-on');
    io.resetPointers({ keepRun: true });
    cancelAnimationFrame(mapRaf);mapRaf = requestAnimationFrame(() => {if(!disposed) drawCampMap(mapCanvas, lastMap);});
  }

  function showLoading(progress) {
    showScreen('loading');
    const p = progress == null ? 0.15 : Math.max(0, Math.min(1, progress));
    loadBar.style.width = (p * 100) + '%';
  }

  function showHowTo() { showScreen('howto'); }
  function showSettings() { settingsBack = mode; showScreen('settings'); }
  function showDifficulty() { showScreen('difficulty'); }

  // Push remembered settings so the game can apply them on boot.
  for (const [k, v] of Object.entries(settings)) h.onSetting?.(k, v);

  let raf = 0;
  function tick(now) {
    if (disposed) return;
    blood.update(now);
    if (touchVisible) {
      touchEl.hidden = !(mode === 'play' || mode === 'hide');
    }
    raf = requestAnimationFrame(tick);
  }
  raf = requestAnimationFrame(tick);
  function onResize() {
    if (mode === 'map') drawCampMap(mapCanvas, lastMap);
    hide.redraw();
    updateKeys();
    updateMore();
  }
  window.addEventListener('resize', onResize);
  root.addEventListener('scroll', updateMore, true);

  function dispose() {
    if (disposed) return;
    disposed = true;mode = 'disposed';
    cancelAnimationFrame(raf);cancelAnimationFrame(mapRaf);
    for(const timer of [hintTimer,objTimer,cardTimer,endingTimer]) clearTimeout(timer);
    io.dispose();hide.dispose();blood.clear();
    root.removeEventListener('click',onClick);window.removeEventListener('resize',onResize);document.removeEventListener('fullscreenchange',syncFullscreenButton);root.removeEventListener('scroll',updateMore,true);
    document.body.classList.remove('ui-playing','ui-touch-on','ui-car');
    document.getElementById('goomw-ui-css')?.remove();
    root.classList.remove('goomw-ui');root.replaceChildren();
  }

  const ui = {
    input,
    showTitle,
    hideAll,
    showPause,
    showGameOver,
    showEnding,
    showTitleCard,
    showMap: openMap,
    showLoading,
    showHowTo,
    showSettings,
    showDifficulty,
    setObjective,
    setPursuit,
    setCarMode,
    toast,
    caption,
    clearCaptions,
    tickMessages,
    setKeyStrip,
    setCompass,
    recentCaptions: () => messages.recent(),
    setPrompt,
    showControlsHint,
    mapOpen: () => mode === 'map',
    setStamina,
    setRun,
    setInventory,
    setHide,
    setHold,
    bloodSplat(amount) { blood.splat(amount); },
    setTouchVisible,
    setFlashlight(on) { io.setLight(on); },
    getSettings: () => ({ ...settings }),
    peekInput: () => peekInput(input),
    dispose,
    destroy:dispose,
  };

  // Wrap showMap after object created — already assigned above as method.
  // Fix: the method above calls the local showMap. Good.

  return ui;
}

export { peekInput };
