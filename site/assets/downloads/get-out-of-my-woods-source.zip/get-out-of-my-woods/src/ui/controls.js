// The words for every control, written once for both chapters. The keyboard strip, the pause
// screen's Controls page, How to Play and the action prompts read from here, so one control is
// never called two things. Atmosphere belongs in the fiction; these stay plain.
//
// chapter 1 = Camp Stillwater, chapter 2 = the Annex. A null entry means the control does not
// exist there in that input mode.
const ROWS = [
  { id: 'move', does: 'Move', keys: 'W A S D or arrow keys', touch: 'The left circle' },
  { id: 'look', does: 'Look around', keys: 'Drag the picture', touch: 'Drag the picture' },
  { id: 'run', does: 'Run', keys: 'Hold Shift, or press R to keep running', touch: 'Tap RUN. It stays on until you let go of the circle' },
  { id: 'sneak', does: 'Sneak (quieter)', keys: 'Hold C', touch: { 1: 'Push the circle only a little', 2: null } },
  { id: 'use', does: 'Use, open, hide', keys: 'E, or click the prompt', touch: { 1: 'Tap the ACTION button', 2: 'Tap USE' } },
  { id: 'search', does: 'Search', keys: { 1: 'Hold E until the bar fills', 2: null }, touch: { 1: 'Hold ACTION until the bar fills', 2: null } },
  { id: 'keys', does: 'Take the van keys', keys: { 1: null, 2: 'Hold E until the bar fills' }, touch: { 1: null, 2: 'Hold USE until the bar fills' } },
  { id: 'light', does: 'Flashlight on or off', keys: 'F', touch: 'Tap FLASHLIGHT' },
  { id: 'turn', does: 'Quick turn', keys: 'Q', touch: null },
  { id: 'map', does: { 1: 'Camp map (the night waits while it is open)', 2: 'Bearings (the night keeps moving)' }, keys: 'M', touch: { 1: 'Tap MAP', 2: 'Tap BEARINGS' } },
  { id: 'swing', does: 'Swing the crowbar, once you have it', keys: { 1: null, 2: 'Space' }, touch: { 1: null, 2: 'Tap SWING' } },
  { id: 'pause', does: 'Pause', keys: 'Esc', touch: 'Tap PAUSE' },
];

const pick = (value, chapter) => (value && typeof value === 'object' ? value[chapter] ?? null : value ?? null);

// [{id, does, how}] for one chapter and input mode, in a fixed order.
export function controlRows(chapter, mode) {
  const field = mode === 'touch' ? 'touch' : 'keys';
  return ROWS.map((r) => ({ id: r.id, does: pick(r.does, chapter), how: pick(r[field], chapter) })).filter((r) => r.how);
}

// The always-visible keyboard reminder: short, in the same order in both chapters.
export function keyStrip(chapter) {
  const parts = ['WASD move', 'Shift/R run', 'C sneak', 'E use', 'F flashlight', 'Q turn', chapter === 2 ? 'M bearings' : 'M map'];
  if (chapter === 2) parts.push('Space swing');
  parts.push('Esc pause');
  return parts.join(' · ');
}

// The flashlight's state, never just a colour: "FLASHLIGHT: ON" / "FLASHLIGHT: OFF".
export function flashlightState(on) {
  const state = on ? 'ON' : 'OFF';
  return { label: 'FLASHLIGHT', state, text: `FLASHLIGHT: ${state}` };
}

// One prompt convention: what to press, then what it does. Hold is always said.
export function promptText(mode, label, { hold = false } = {}) {
  if (!label) return '';
  if (mode === 'touch') return hold ? `HOLD: ${label}` : label;
  return `${hold ? 'HOLD E' : 'E'}: ${label}`;
}
