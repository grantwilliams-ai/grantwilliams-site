// Captions for both chapters: one line on screen, three kinds, and clocks that run on game time.
//
//   urgent     Something happening now: a threat, or the answer to the player's own press.
//              Shows at once, never waits behind reading, and is never kept for later.
//   essential  An instruction, a found item or a clue. Never lost: a warning that cuts in hands it
//              back afterwards with the reading time it had left, and it is kept in recent() for
//              the pause screen.
//   flavor     Atmosphere and empty searches. Shown only when nothing more important is up.
//
// Time moves only through update(dt), fed with game time, so a pause keeps every remaining second
// and resuming shows the same line again. The same line pressed again while it is up just stays
// up; an essential or flavor line is not repeated for a few seconds after it goes, so a door
// pressed five times cannot flood the screen. Urgent lines are never held back: a second sighting
// is new information.
export const MESSAGE_KINDS = Object.freeze(['urgent', 'essential', 'flavor']);

export function createMessages({ recentLimit = 5, waitingLimit = 2, repeatGap = 3, minResume = 1.2 } = {}) {
  let now = 0;
  let current = null; // {text, kind, key, until}
  let waiting = []; // essentials waiting their turn; an interrupted one goes to the front
  let recent = []; // essential lines worth recalling, newest first
  const gone = new Map(); // key -> game time it left the screen
  let version = 0;

  function show(m) {
    current = { text: m.text, kind: m.kind, key: m.key, until: now + m.left };
    version++;
  }

  function next() {
    current = null;
    const m = waiting.shift();
    if (m) show(m);
    else version++;
  }

  function trim() {
    // Keep the line that was interrupted mid-read; let older waiting lines go (they stay in recent()).
    while (waiting.length > waitingLimit) waiting.splice(waiting[0]?.resumed ? 1 : 0, 1);
  }

  function remember(m) {
    recent = [m.text, ...recent.filter((t) => t !== m.text)].slice(0, recentLimit);
  }

  return {
    say(text, { kind = 'essential', seconds = 3.5, key = text, keep } = {}) {
      if (!text) return false;
      if (!MESSAGE_KINDS.includes(kind)) kind = 'essential';
      const left = Math.max(0.5, Number.isFinite(seconds) ? seconds : 3.5);
      const m = { text, kind, key, left };
      if (keep ?? kind === 'essential') remember(m);
      if (current && current.key === key) {
        current.until = Math.max(current.until, now + left);
        return true;
      }
      if (kind !== 'urgent' && gone.has(key) && now - gone.get(key) < repeatGap) return false;
      if (waiting.some((w) => w.key === key)) return false;
      if (!current) {
        show(m);
        return true;
      }
      if (kind === 'urgent') {
        const remaining = current.until - now;
        if (current.kind === 'essential' && remaining >= minResume) {
          waiting.unshift({ text: current.text, kind: current.kind, key: current.key, left: remaining, resumed: true });
        }
        show(m);
        trim();
        return true;
      }
      if (kind === 'essential') {
        if (current.kind === 'flavor') {
          show(m);
          return true;
        }
        waiting.push(m);
        trim();
        return true;
      }
      if (current.kind === 'flavor') {
        show(m);
        return true;
      }
      return false;
    },

    // Advance with game time only. Paused frames pass nothing.
    update(dt) {
      if (!(dt > 0)) return;
      now += dt;
      while (current && now >= current.until) {
        gone.set(current.key, now);
        next();
      }
    },

    // Retry, scene change or chapter change: nothing stale stays on screen or in line.
    clear({ keepRecent = true } = {}) {
      current = null;
      waiting = [];
      gone.clear();
      if (!keepRecent) recent = [];
      version++;
    },

    recent() {
      return [...recent];
    },
    get text() {
      return current?.text || '';
    },
    get kind() {
      return current?.kind || null;
    },
    get timeLeft() {
      return current ? Math.max(0, current.until - now) : 0;
    },
    get waiting() {
      return waiting.map((w) => w.text);
    },
    // Changes whenever the visible line changes, so a UI can redraw only then.
    get version() {
      return version;
    },
  };
}
