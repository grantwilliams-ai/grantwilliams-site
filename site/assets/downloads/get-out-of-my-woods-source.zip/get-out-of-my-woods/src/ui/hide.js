// Full-screen hide overlays: closet, bed, outhouse, canoe, bush.
import { makeRng } from '../core/rng.js';

function sizeCanvas(canvas, parent) {
  const w = parent.clientWidth || 1;
  const h = parent.clientHeight || 1;
  const dpr = Math.min(2, typeof devicePixelRatio === 'number' ? devicePixelRatio : 1);
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  const g = canvas.getContext('2d');
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, w, h);
  return { g, w, h };
}

// A louvred door from the inside. The gaps are real gaps: the game shows through them.
function closet(g, w, h) {
  const pitch = Math.max(24, Math.round(h / 15));
  const slat = Math.round(pitch * 0.56);
  for (let y = -slat * 0.4; y < h; y += pitch) {
    g.fillStyle = '#090705';
    g.fillRect(0, y, w, slat);
    g.fillStyle = '#1b140d'; // a little light caught on the top edge
    g.fillRect(0, y, w, 2);
    g.fillStyle = 'rgba(0,0,0,0.5)';
    g.fillRect(0, y + slat, w, 3);
  }
  // Where the two doors meet, and the frame around them.
  g.fillStyle = '#070503';
  g.fillRect(w * 0.5 - h * 0.022, 0, h * 0.044, h);
  g.fillRect(0, 0, h * 0.09, h);
  g.fillRect(w - h * 0.09, 0, h * 0.09, h);
}

function bed(g, w, h) {
  const top = h * 0.66;
  const slatH = 20;
  const gap = 5;
  g.fillStyle = '#070604';
  g.fillRect(0, 0, w, top);
  let y = 0;
  let i = 0;
  while (y < top) {
    g.fillStyle = i % 2 ? '#1a120c' : '#140e0a';
    g.fillRect(0, y, w, slatH);
    g.strokeStyle = 'rgba(0,0,0,0.45)';
    g.lineWidth = 1;
    g.beginPath();
    g.moveTo(0, y + slatH * 0.45);
    g.lineTo(w, y + slatH * 0.5);
    g.stroke();
    g.fillStyle = '#3a2a1c';
    g.beginPath();
    g.arc(28, y + slatH * 0.5, 3, 0, 7);
    g.arc(w - 28, y + slatH * 0.5, 3, 0, 7);
    g.fill();
    y += slatH + gap;
    i++;
  }
  g.fillStyle = '#100c08';
  g.fillRect(0, 0, 22, top);
  g.fillRect(w - 22, 0, 22, top);
  g.fillRect(0, 0, w, 10);
}

function outhouse(g, w, h) {
  g.fillStyle = '#000';
  g.fillRect(0, 0, w, h);
  const cx = w * 0.5;
  const cy = h * 0.36;
  const r = Math.min(w, h) * 0.17;
  g.globalCompositeOperation = 'destination-out';
  g.beginPath();
  g.arc(cx, cy, r, 0, 7);
  g.fill();
  g.globalCompositeOperation = 'source-over';
  g.fillStyle = '#000';
  g.beginPath();
  g.arc(cx + r * 0.38, cy - r * 0.1, r * 0.84, 0, 7);
  g.fill();
}

function canoe(g, w, h) {
  g.fillStyle = '#080706';
  g.fillRect(0, 0, w, h);
  const y = h * 0.5;
  const rx = w * 0.46;
  const ry = Math.max(7, h * 0.028);
  g.globalCompositeOperation = 'destination-out';
  g.beginPath();
  g.ellipse(w / 2, y, rx, ry, 0, 0, 7);
  g.fill();
  g.globalCompositeOperation = 'source-over';
  g.strokeStyle = '#1c1612';
  g.lineWidth = 16;
  g.beginPath();
  g.ellipse(w / 2, y, rx, ry, 0, 0, 7);
  g.stroke();
  g.strokeStyle = '#2a2018';
  g.lineWidth = 3;
  g.stroke();
  // hull ribs
  g.strokeStyle = 'rgba(20,14,10,0.8)';
  g.lineWidth = 8;
  for (const t of [-0.55, -0.25, 0.25, 0.55]) {
    g.beginPath();
    g.moveTo(w / 2 + rx * t, 0);
    g.lineTo(w / 2 + rx * t * 0.7, h);
    g.stroke();
  }
}

function bush(g, w, h) {
  const rng = makeRng(1984);
  const blobs = [];
  const edge = (side) => {
    for (let i = 0; i < 28; i++) {
      let x, y;
      if (side === 0) { x = rng() * w; y = rng() * h * 0.22; }
      else if (side === 1) { x = rng() * w; y = h - rng() * h * 0.24; }
      else if (side === 2) { x = rng() * w * 0.22; y = rng() * h; }
      else { x = w - rng() * w * 0.22; y = rng() * h; }
      blobs.push({ x, y, rx: 18 + rng() * 42, ry: 14 + rng() * 34, rot: rng() * 6 });
    }
  };
  edge(0); edge(1); edge(2); edge(3);
  for (const b of blobs) {
    g.fillStyle = rng() > 0.5 ? '#050806' : '#0a100c';
    g.beginPath();
    g.ellipse(b.x, b.y, b.rx, b.ry, b.rot, 0, 7);
    g.fill();
  }
  // a few nearer leaves
  for (let i = 0; i < 18; i++) {
    const x = rng() < 0.5 ? rng() * w * 0.12 : w - rng() * w * 0.12;
    const y = rng() * h;
    g.fillStyle = '#030504';
    g.beginPath();
    g.ellipse(x, y, 22 + rng() * 28, 12 + rng() * 20, rng() * 6, 0, 7);
    g.fill();
  }
}

const DRAW = { closet, bed, outhouse, canoe, bush };

export function createHide(parent) {
  const wrap = document.createElement('div');
  wrap.className = 'hide-layer';
  wrap.hidden = true;
  const canvas = document.createElement('canvas');
  canvas.className = 'hide-canvas';
  wrap.appendChild(canvas);
  const leave = document.createElement('div');
  leave.className = 'hide-leave';
  leave.hidden = true;
  wrap.appendChild(leave);
  parent.appendChild(wrap);

  let type = null, raf = 0, disposed = false;

  function redraw() {
    if (!type || disposed) return;
    const { g, w, h } = sizeCanvas(canvas, wrap);
    (DRAW[type] || closet)(g, w, h);
  }

  function set(t) {
    type = t || null;
    wrap.hidden = !type;
    if (type) {
      cancelAnimationFrame(raf);raf = requestAnimationFrame(redraw);
    }
  }

  function onResize() { if (type) redraw(); }
  window.addEventListener('resize', onResize);

  function dispose() {
    if(disposed)return;disposed=true;type=null;cancelAnimationFrame(raf);
    window.removeEventListener('resize',onResize);wrap.remove();
  }
  return { set, wrap, redraw, dispose };
}
