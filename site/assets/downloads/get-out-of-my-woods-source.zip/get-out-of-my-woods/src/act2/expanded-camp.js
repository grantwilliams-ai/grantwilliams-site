// Physical landmarks for the expanded route. All large silhouettes follow layout footprints.
import * as THREE from 'three';
import { EXPANSION_PROPS, INSPECT_SPOTS, orientedBox } from './layout.js';

export function buildExpandedCamp({root,materials,mesh,box,tube,lamp,sign,canvasTexture,mat,propColliders}) {
  const camp=new THREE.Group();camp.name='Lower camp, creek crossings and service yard';root.add(camp);
  const moss=mat(0x46584d,{roughness:1}),concrete=mat(0x66716b,{roughness:1}),canvas=mat(0x59675d,{roughness:1}),paper=mat(0xc4bda4),reflector=new THREE.MeshBasicMaterial({color:0xb9be9e});
  function solid(id,size,material,x,y,z){
    const result=box(camp,size,material,x,y,z);
    propColliders.push({...orientedBox(id,x,z,size[0],size[2],0,y+size[1]/2),minHeight:Math.max(0,y-size[1]/2)});
    return result;
  }
  for(const p of EXPANSION_PROPS){
    const group=new THREE.Group();group.name=p.id;group.position.set(p.x,0,p.z);camp.add(group);
    if(p.type==='rock'){
      // Weathered, irregular strata stay inside the shared footprint. The base
      // meets its collision edge, while the upper profile slopes and fractures.
      const rockGeo=new THREE.BoxGeometry(p.width,p.height,p.depth,7,4,4),positions=rockGeo.attributes.position;
      for(let i=0;i<positions.count;i++){
        const x=positions.getX(i),z=positions.getZ(i),y=positions.getY(i)+p.height/2,t=y/p.height;
        const hash=(Math.sin(x*1.73+z*3.17)*.5+.5),bevel=Math.max(0,t-.22)/.78;
        positions.setXYZ(i,x*(1-.26*bevel)+Math.sin(z*2.3+x)*.13*bevel,y*(.77+.22*hash),z*(1-.30*bevel)+Math.sin(x*1.4)*.1*bevel);
      }
      rockGeo.computeVertexNormals();mesh(group,rockGeo,materials.stone);
      for(let i=0;i<6;i++){
        const x=-p.width*.29+i*p.width*.116,angle=i*.47,depth=p.depth*.11;
        const height=p.height*(.16+.07*Math.sin(i*1.9)**2),zExtent=Math.abs(Math.sin(angle))*p.width*.12+Math.abs(Math.cos(angle))*depth;
        const stone=mesh(group,new THREE.IcosahedronGeometry(1,1),i%3?materials.stone:moss,x,p.height*(.4+.18*Math.sin(i*1.9)**2),p.depth/2-zExtent-.03);
        stone.scale.set(p.width*.12,height,depth);stone.rotation.y=angle;
      }
    }
    if(p.type==='creek-bank'){
      // A steep stone revetment makes the non-wadeable bank explicit. The only
      // level routes across are the two planked bridges.
      for(const side of [-1,1]){
        box(group,[p.width,p.height,.5],concrete,0,p.height/2,side*(p.depth/2-.25));
        box(group,[p.width,.1,.58],moss,0,p.height+.03,side*(p.depth/2-.25));
      }
      for(let x=-p.width/2+.6;x<p.width/2;x+=1.25){
        for(const side of [-1,1])box(group,[.07,p.height+.03,.52],materials.stone,x,p.height/2,side*(p.depth/2-.25));
        const stone=mesh(group,new THREE.IcosahedronGeometry(.55,0),materials.stone,x,.32,p.depth/2-.04);stone.scale.set(1,.65,.55);
      }
    }
    if(p.type==='bridge-rail'){
      for(const side of [-1,1])box(group,[p.width,.13,p.depth],materials.wood,0,side<0?.38:.93,0);
      for(let z=-p.depth/2;z<=p.depth/2;z+=2)box(group,[p.width,1,.18],materials.wood,0,.5,z);
    }
    if(p.type==='service-building'){
      box(group,[p.width,p.height,p.depth],materials.trim,0,p.height/2,0);
      box(group,[p.width+.4,.16,p.depth+.5],materials.iron,0,p.height+.08,0);
      for(const side of [-1,1]){
        for(let z=-p.depth/2+.35;z<p.depth/2;z+=.55)box(group,[.04,p.height,.055],materials.wood,side*(p.width/2+.025),p.height/2,z);
        for(let x=-p.width/2+.35;x<p.width/2;x+=.55)box(group,[.055,p.height,.04],materials.wood,x,p.height/2,side*(p.depth/2+.025));
      }
      // Sealed utility doors are legible as backdrop; paths continue around both ends.
      for(const x of [-4,4]){
        box(group,[2.5,2.6,.08],concrete,x,1.3,p.depth/2+.05);
        box(group,[.04,2.6,.1],materials.black,x,1.3,p.depth/2+.11);
        for(const s of [-1,1])box(group,[.05,.38,.1],materials.iron,x+s*.15,1.25,p.depth/2+.15);
      }
      for(const x of [-5,0,5]){
        box(group,[1.7,.6,.07],materials.black,x,2.8,-p.depth/2-.05);
        for(let i=0;i<6;i++)box(group,[1.65,.04,.09],concrete,x,2.54+i*.1,-p.depth/2-.09);
      }
      sign('SERVICE YARD',0,2.95,p.z+p.depth/2+.16,4.2,.65,0,'',false);
      sign('NORTH PARKING  ↑',-8.04,2.0,p.z,4.1,.8,-Math.PI/2,'FOLLOW THE TIRE TRACKS',false);
      // Small fittings stay flush to the same collision footprint.
      for(const x of [-6.5,6.5])tube(group,[x,.1,-p.depth/2-.07],[x,3.5,-p.depth/2-.07],.055,materials.iron);
    }
  }

  const waterTexture=canvasTexture(512,256,(c,w,h)=>{
    c.fillStyle='#1c343a';c.fillRect(0,0,w,h);
    for(let i=0;i<100;i++){
      c.strokeStyle=i%4?'rgba(133,175,174,.15)':'rgba(198,209,184,.25)';c.lineWidth=i%3+1;
      const y=(i*29)%h,x=(i*73)%w;c.beginPath();c.moveTo(x,y);c.bezierCurveTo(x+13,y-3,x+27,y+3,x+48,y);c.stroke();
    }
  });
  waterTexture.wrapS=waterTexture.wrapT=THREE.RepeatWrapping;waterTexture.repeat.set(12,1);
  const water=mesh(camp,new THREE.PlaneGeometry(96,5.8),mat(0xb8c9c4,{map:waterTexture,metalness:.1,roughness:.38,emissive:0x16343a,emissiveIntensity:.08}),0,.016,-58);water.rotation.x=-Math.PI/2;
  for(const x of [-20,20]){
    const bridge=new THREE.Group();bridge.name=x<0?'West footbridge':'East service crossing';bridge.position.set(x,0,-58);camp.add(bridge);
    for(let z=-4.2;z<4.21;z+=.28)box(bridge,[5.5,.055,.26],materials.wood,0,.025,z);
    for(const side of [-1,1]){
      box(bridge,[.16,.13,8.6],materials.iron,side*2.45,-.015,0);
      for(const z of [-4,4])box(bridge,[.19,.16,.025],reflector,side*2.75,.86,z+(z>0?.11:-.11));
    }
  }
  sign('TWO WAYS NORTH',4.8,1.9,-27,4.6,1.1,0,'← FOOTBRIDGE     SERVICE CROSSING →');
  sign('SERVICE YARD  ↑',-25,1.8,-66.5,3.4,.85,0,'NORTH PARKING BEYOND');
  sign('SERVICE YARD  ↑',25,1.8,-66.5,3.4,.85,0,'KEEP TO THE PATH');
  sign('PARKING  ↑',8,1.8,-104.5,3.4,.85,0,'MAINTENANCE VEHICLES');
  sign('CANVAS SHELTER  ←',-18.5,1.55,-83.7,2.6,.7,.18,'',true);

  // Abandoned campers left ordinary things behind: an overturned chair, a cooler,
  // hanging drying line, and a cold fire. Nothing here adds a required fetch step.
  solid('lower-camp-cooler',[1.2,.65,.7],canvas,-10.2,.325,-27.5);
  box(camp,[1.26,.09,.76],paper,-10.2,.69,-27.5);
  solid('lower-camp-bench',[3.0,.5,.65],materials.wood,4.5,.25,-27.92);
  box(camp,[3.05,.07,.7],materials.trim,4.5,.53,-27.92);
  const chair=new THREE.Group();chair.position.set(-12.4,.3,-27);chair.rotation.z=-Math.PI/2;camp.add(chair);
  box(chair,[.7,.05,.7],canvas,0,.42,0);box(chair,[.7,.7,.05],canvas,0,.78,-.34);
  for(const x of [-.3,.3])for(const z of [-.3,.3])tube(chair,[x,0,z],[x,.45,z],.025,materials.iron);
  propColliders.push(orientedBox('fallen-camp-chair',-11.85,-27,1.3,.75,0,.72));
  const fire=mesh(camp,new THREE.CircleGeometry(1.25,18),mat(0x1a2422),7,.023,-29);fire.rotation.x=-Math.PI/2;
  for(let i=0;i<9;i++){const angle=i/9*Math.PI*2;const stone=mesh(camp,new THREE.IcosahedronGeometry(.2,0),materials.stone,7+Math.cos(angle)*1.1,.1,-29+Math.sin(angle)*1.1);stone.scale.y=.6;}
  for(let i=0;i<3;i++){const log=box(camp,[1.6,.14,.16],materials.black,7,.10,-29);log.rotation.y=i*1.9;}
  tube(camp,[-10.6,0,-28.3],[-10.6,1.1,-28.3],.035,materials.iron);
  propColliders.push(orientedBox('lower-camp-lantern-stand',-10.6,-28.3,.07,.07,0,1.2));
  lamp(-10.6,1.1,-28.3,13,10);
  lamp(-8.1,2.8,-77,20,12);

  // Papers are distinct bright shapes at the exact optional inspection locations.
  for(const spot of INSPECT_SPOTS){
    if(spot.prop==='map'){
      const mapTexture=canvasTexture(512,384,(c,w,h)=>{
        c.fillStyle='#bdb99c';c.fillRect(0,0,w,h);c.fillStyle='#263d36';c.textAlign='center';c.font='bold 40px sans-serif';c.fillText('STILLWATER ANNEX',w/2,57);
        c.strokeStyle='#4d6656';c.lineWidth=13;c.beginPath();c.moveTo(250,325);c.lineTo(250,260);c.lineTo(150,210);c.lineTo(150,135);c.lineTo(260,95);c.moveTo(250,260);c.lineTo(360,210);c.lineTo(360,135);c.lineTo(260,95);c.stroke();
        c.fillStyle='#263d36';c.font='bold 25px sans-serif';c.fillText('NORTH PARKING',w/2,91);c.fillText('YOU ARE HERE',w/2,365);
        c.strokeStyle='#527a82';c.lineWidth=7;c.beginPath();c.moveTo(25,180);c.lineTo(487,180);c.stroke();
      });
      const board=mesh(camp,new THREE.PlaneGeometry(1.75,1.3),mat(0xffffff,{map:mapTexture}),spot.x,1.8,7.72);board.rotation.y=Math.PI;
    }else if(spot.prop==='bags'){
      solid('abandoned-bag',[.9,.44,.7],canvas,spot.x+1.05,.22,spot.z+1.0);
      box(camp,[.95,.035,.055],materials.black,spot.x+1.05,.46,spot.z+1.0);
      tube(camp,[spot.x+.85,.47,spot.z+1.02],[spot.x+1.25,.47,spot.z+1.02],.035,materials.iron);
      box(camp,[.19,.09,.32],mat(0x9e795f),spot.x+.5,.055,spot.z+.65);
      box(camp,[.4,.015,.3],paper,spot.x+.25,.025,spot.z-.35);
    }else if(spot.prop==='sign'){
      sign('BRIDGES OPEN',spot.x-1.6,1.6,spot.z-.8,2.7,.9,0,'BOTH ROUTES  →  SERVICE YARD');
    }else{
      sign('NORTH PARKING',spot.x+1.6,1.65,spot.z-1.2,2.6,.95,0,'VAN 04  •  KEYS WITH DRIVER');
      const page=box(camp,[.45,.015,.6],paper,spot.x+.45,.028,spot.z+.2);page.rotation.y=.25;
    }
  }
  // Safe stretches of the exit drive are real scene geometry beyond the playable boundary.
  // The road remains unobstructed at x[-8,8] all the way to the ending tableau.
  for(const z of [-145,-166,-188,-208])for(const x of [-7,7]){
    tube(camp,[x,0,z],[x,1.2,z],.065,materials.wood);
    box(camp,[.18,.3,.03],reflector,x,1.02,z+.08);
  }
  sign('LEAVING STILLWATER',-7.8,2.5,-159,5.2,1.25,0,'PUBLIC ROAD  •  ONE MILE');
  const countySign=sign('COUNTY ROAD 12',8.9,2.1,-207,4.6,1.05,0,'TOWN  →  6 MILES');
  const countyReverseTexture=canvasTexture(768,256,(c,W,H)=>{
    c.fillStyle='#182a27';c.fillRect(0,0,W,H);c.strokeStyle='#b4ad8a';c.lineWidth=7;c.strokeRect(13,13,W-26,H-26);
    c.textAlign='center';c.fillStyle='#ded8b6';c.font='700 68px Oswald, sans-serif';c.fillText('COUNTY ROAD 12',W/2,117);
    c.font='500 29px Oswald, sans-serif';c.fillStyle='#a4ad91';c.fillText('TOWN  ←  6 MILES',W/2,185);
  });
  const countyReverse=mesh(countySign,new THREE.PlaneGeometry(4.6,1.05),mat(0xffffff,{map:countyReverseTexture}),0,0,-.067);countyReverse.rotation.y=Math.PI;
  // A crossroad and distant illuminated marker distinguish safety from another camp loop.
  const publicRoad=mesh(camp,new THREE.PlaneGeometry(100,8),mat(0x3d4849),0,.02,-216);publicRoad.rotation.x=-Math.PI/2;
  for(let x=-48;x<50;x+=7)box(camp,[3,.012,.12],reflector,x,.03,-216);
  return {root:camp,water};
}
