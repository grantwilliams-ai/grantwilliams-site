import { Vector3 } from 'three';

// Clip the rendered trunk triangles to the height occupied by a person. Using
// the complete tree bounds would include its leaning crown and block empty air.
export function trunkFootprint(geometry,matrix,id,bodyHeight=2.4){
  const positions=geometry.attributes.position,indices=geometry.index;
  const bounds={id,minX:Infinity,maxX:-Infinity,minZ:Infinity,maxZ:-Infinity};
  let top=0;
  const include=p=>{bounds.minX=Math.min(bounds.minX,p.x);bounds.maxX=Math.max(bounds.maxX,p.x);bounds.minZ=Math.min(bounds.minZ,p.z);bounds.maxZ=Math.max(bounds.maxZ,p.z);};
  const count=indices?indices.count:positions.count;
  for(let i=0;i<count;i+=3){
    const triangle=[0,1,2].map(j=>new Vector3().fromBufferAttribute(positions,indices?indices.getX(i+j):i+j).applyMatrix4(matrix));
    for(const p of triangle){top=Math.max(top,p.y);if(p.y>=0&&p.y<=bodyHeight)include(p);}
    for(let j=0;j<3;j++){
      const a=triangle[j],b=triangle[(j+1)%3];
      for(const height of [0,bodyHeight])if((a.y<height&&b.y>height)||(b.y<height&&a.y>height))include(a.clone().lerp(b,(height-a.y)/(b.y-a.y)));
    }
  }
  return Number.isFinite(bounds.minX)?{...bounds,height:top}:null;
}
