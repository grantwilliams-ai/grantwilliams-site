import { aimBeam } from '../core/beam.js';
import { enterFullscreen, FULLSCREEN_FAILURE } from '../ui/display-mode.js';
import * as THREE from 'three';
import { GameRenderer } from '../render/renderer.js';
import { createPlayer } from '../characters/player.js';
import { audio } from '../audio/index.js';
import { createFootfallSync, readFootSoles } from '../audio/footfall-sync.js';
import { buildAct2World, STUDY_SHOTS } from './world.js';
import { createAct2Killer } from './killer.js';
import { Act2Sim, obstacleContainsPoint } from './sim.js';
import { LOCATIONS } from './layout.js';
import { createPreviewUI } from './ui.js';
import { createHeldCrowbar, poseCrowbarSwing } from './player-defense.js';
import { createDeathScene } from './death-scene.js';
import { createEscapeScene } from './escape-scene.js';
import { DEFAULT_PREFERENCES, cleanPreferences } from '../campaign/state.js';
import { createMessages } from '../ui/messages.js';
// The office cabin's room: the inside faces of its walls (see OBSTACLES in layout.js).
const CABIN_INSIDE=Object.freeze({minX:-17.8,maxX:-6.2,minZ:-1.8,maxZ:7.8});

export const SESSION_CHECKPOINT = 'Checkpoint kept for this session only. Your browser would not save it.';

export function captionFor(event) {
  if (!event) return null;
  const text = event.text;
  switch (event.type) {
    case 'bridgeNoise': return text ? { text, seconds: 3, kind: 'flavor', key: `bridge:${event.x < 0 ? 'w' : 'e'}` } : null;
    case 'route': return text ? { text, seconds: 5, kind: 'essential', key: `route:${event.id || event.stage || text}` } : null;
    case 'inspect':
      if (!text) return null;
      return event.clue
        ? { text, seconds: 8, kind: 'essential', key: `clue:${event.id || text}` }
        : { text, seconds: 3, kind: 'urgent', key: 'hide-open' };
    case 'killerArrival': return { text: 'A branch breaks on the footpath.', seconds: 3.5, kind: 'urgent', key: 'arrival' };
    case 'spotted': return { text: 'He has seen you.', seconds: 2, kind: 'urgent', key: 'spotted' };
    case 'investigate': return { text: 'He heard something. Keep quiet.', seconds: 2.5, kind: 'urgent', key: 'investigate' };
    case 'lost': return { text: 'He lost sight of you. Keep quiet.', seconds: 3, kind: 'urgent', key: 'lost' };
    case 'hideSeen': return { text: 'He saw you hide. Leave before he reaches you.', seconds: 4, kind: 'urgent', key: 'hideSeen' };
    case 'weapon': return { text: 'Crowbar ready. Face him, then swing when he is close. A hit stuns him for four seconds and uses it up. A miss does not.', seconds: 8, kind: 'essential', key: 'weapon' };
    case 'defend': return text ? { text, seconds: 3, kind: 'urgent', key: 'defend' } : null;
    case 'defendMiss': return { text: text || 'Swing missed. The crowbar is not used up. Face him and wait until he is close.', seconds: 3, kind: 'urgent', key: `defendMiss:${event.reason || text || 'miss'}` };
    case 'keys': return { text: 'The van. Driver\u2019s side. Now.', seconds: 3, kind: 'essential', key: 'keys' };
    case 'locked': return { text: 'Keys. Check the hand beside the van.', seconds: 3, kind: 'urgent', key: 'locked' };
    case 'attackWindup': return { text: 'Move!', seconds: 1.5, kind: 'urgent', key: 'windup' };
    case 'attackMiss': return { text: text || 'He missed. Keep moving.', seconds: 2.5, kind: 'urgent', key: 'attackMiss' };
    default: return null;
  }
}

const SAVE_KEY='goomw.v4.preview01';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const mix=(a,b,t)=>a+(b-a)*t;
const vec=(v)=>new THREE.Vector3(...v);
export function loadPreferences(storage=globalThis.localStorage){
  try{const s=JSON.parse(storage.getItem(SAVE_KEY)||'null');if(s?.version!==1)return {};return cleanPreferences(s);}catch{return {};}
}

export function presentationYawStep(previous,target,dt,{rate=10,x=0,z=0,snap=false}={}) {
  const yaw=Number.isFinite(target)?target:(previous?.yaw??0);
  if(!previous||snap||!Number.isFinite(previous.yaw)||Math.hypot(x-previous.x,z-previous.z)>.75)return {yaw,x,z};
  const delta=Math.atan2(Math.sin(yaw-previous.yaw),Math.cos(yaw-previous.yaw));
  const limit=Math.max(0,(Number.isFinite(rate)?rate:0)*(Number.isFinite(dt)?dt:0));
  return {yaw:previous.yaw+clamp(delta,-limit,limit),x,z};
}

export class PreviewApp {
  constructor({campaign=null}={}){
    this.campaign=campaign;this.disposed=false;this.listeners=new AbortController();this.playerFootfalls=createFootfallSync();
    let saved={};try{saved=campaign?.preferences||loadPreferences();}catch{/* Private browsing can deny the storage getter itself. */}
    this.settings={...DEFAULT_PREFERENCES,...saved};this.state='title';this.time=0;this.cineTime=0;this.viewYaw=Math.PI;this.pitch=.24;this.lightOn=true;this.captionUntil=0;this.messages=createMessages();this.checkpointNoted=false;this.killerFoot=0;this.studyIndex=0;this.pausedFrom='play';this.storageAvailable=true;
    const mobile=matchMedia('(pointer:coarse)').matches;
    this.renderer=new GameRenderer(document.querySelector('#game canvas'),{tier:mobile?'med':'high',internalHeight:400,maxPixelHeight:mobile?720:900,shadowSize:0,isTouch:mobile});
    this.renderer.setSharp(true);this.renderer.adaptiveSharp=true;this.post=this.renderer.post.uniforms;this.post.uVhs.value=0;this.post.uBrightness.value=this.settings.brightness;
    this.scene=new THREE.Scene();this.camera=new THREE.PerspectiveCamera(58,innerWidth/innerHeight,.08,210);
    this.world=buildAct2World(this.scene);
    this.figure=createPlayer();this.scene.add(this.figure.root);
    this.heldCrowbar=createHeldCrowbar();
    this.figure.rig.b('handL').add(this.heldCrowbar);this.heldCrowbar.visible=false;this.defendUntil=0;
    this.killerFigure=createAct2Killer();this.scene.add(this.killerFigure.root);
    this.flash=new THREE.SpotLight(0xffe4b6,11,24,.47,.65,1.2);this.flash.position.set(0,1.4,34);this.scene.add(this.flash,this.flash.target);
    this.studyKey=new THREE.PointLight(0xcbd9ec,3,11,1.3);this.studyKey.visible=false;this.scene.add(this.studyKey);
    this.ui=createPreviewUI({campaign,inputMode:this.settings.inputMode,hints:this.settings.hints,compass:this.settings.compass,command:cmd=>this.command(cmd),setting:(k,v)=>this.setting(k,v)});
    this.shots=[...STUDY_SHOTS,
      {id:'sackhead',title:'The man under the sack',position:[-2.6,1.9,-8.8],target:[-3.2,1.87,-11],killer:{x:-3.2,z:-11,yaw:.1},caption:'Worn olive canvas. Uneven eye cuts. A pitchfork that catches the moon. Close-up detail, built into the playable character.'},
      {id:'silhouette',title:'Recognizable before he reaches you',position:[.4,2.3,12],target:[-2,1.35,-2],killer:{x:-2,z:-2,yaw:.16},caption:'A broad, human silhouette at playing distance. His presence is carried by shape, movement, and sound.'},
      {id:'bearings',title:'A way out, from where you stand',position:[17,3.4,18],target:[11,1,4],player:{x:12,z:15,yaw:Math.PI},navigation:true,caption:'Your bearings follow the camera toward the next landmark. Find another path through the camp when he sees you.'},
    ];
    this.sim=new Act2Sim({extraObstacles:this.world.colliders,difficulty:this.campaign?.difficulty||'standard'});this.deathScene=createDeathScene(this,{audio});this.escapeScene=createEscapeScene(this,{audio});this.ui.menu('title');this.setting('volume',this.settings.volume,false);this.setting('weather',this.settings.weather,false);this.resetScene();
    audio.ambience('forest');audio.music('title');
    document.addEventListener('visibilitychange',()=>{if(document.hidden&&['play','intro','death','escape'].includes(this.state))this.pause();},{signal:this.listeners.signal});
    window.addEventListener('blur',()=>{if(['play','intro','death','escape'].includes(this.state))this.pause();},{signal:this.listeners.signal});
    this.renderer.canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();this.pause();this.say('The picture was interrupted. Reload the game to restart at the crash.',8,{kind:'urgent',key:'context-lost'});this.ui.caption(this.messages.text);},{signal:this.listeners.signal});
    for(const key of ['brightness','picture','tape','flashes'])if(this.settings[key]!==undefined)this.setting(key,this.settings[key],false);
    this.last=performance.now();this.frame=this.frame.bind(this);this.raf=requestAnimationFrame(this.frame);
  }
  save(){if(this.campaign)return;try{localStorage.setItem(SAVE_KEY,JSON.stringify({version:1,...this.settings,checkpoint:'crash'}));}catch{this.storageAvailable=false;}}
  inspectAudio(){return audio.inspect();}
  setting(key,value,persist=true){this.settings[key]=value;if(key==='volume')audio.setVolume(value);if(key==='brightness')this.post.uBrightness.value=value;if(key==='picture'){this.renderer.setSharp(value==='sharp');this.renderer.adaptiveSharp=true;}if(key==='tape')this.post.uVhs.value=value?.08:0;if(key==='flashes')this.post.uFlashScale.value=value==='full'?1:.2;if(key==='weather')audio.setWeather(value);if(key==='inputMode'||key==='hints'||key==='compass')this.ui.applyInput(this.settings);if(persist){this.campaign?.onSetting(key,value);this.save();}}
  command(cmd){
    if(cmd==='start'){this.start(true);return;}
    if(cmd==='retry'){this.campaign?.onRetry();this.start(false);return;}
    if(cmd==='newgame'){this.campaign?.onNewGame();return;}
    if(cmd==='skip'){if(this.state==='intro')this.beginPlay();else if(this.state==='death'){this.deathScene.skip();this.finishDeath();}else if(this.state==='escape'){this.escapeScene.skip();this.finishEscape();}return;}
    if(cmd==='pause'){if(['play','intro','death','escape'].includes(this.state))this.pause();else if(this.state==='pause')this.resume();return;}
    if(cmd==='resume'){this.resume();return;}
    if(cmd==='home'){if(this.campaign)this.campaign.onHome();else this.home();return;}
    if(cmd==='studies'){this.stopEngine();this.sim=new Act2Sim({extraObstacles:this.world.colliders,difficulty:this.campaign?.difficulty||'standard'});this.state='study';audio.unlock();audio.resumeAll();audio.ambience('forest');audio.music('dread');audio.setIntensity(0);this.showStudy(0);return;}
    if(cmd==='next'||cmd==='prev'){this.showStudy(this.studyIndex+(cmd==='next'?1:-1));return;}
    if(cmd==='settings'){this.settingsBack=this.state;this.state='settings';this.ui.settings(this.settings);return;}
    if(cmd==='soundcheck'){this.testSound();return;}
    if(cmd==='back'){if(this.settingsBack==='pause'){this.state='pause';audio.pauseAll();this.ui.menu('pause');}else if(this.campaign)this.campaign.onHome();else this.home();return;}
    if(cmd==='fullscreen'){enterFullscreen().then(ok=>{if(!this.disposed&&this.state==='settings')this.ui.displayStatus(ok?'Fullscreen is on.':FULLSCREEN_FAILURE);});}
  }
  async testSound(){
    if(this.soundCheckPending)return;
    this.soundCheckPending=true;this.ui.soundCheck('Trying sound…');
    const result=await audio.testOutput();
    this.soundCheckPending=false;
    if(this.state!=='settings')return;
    if(this.disposed)return;
    const messages={running:'Listen for three notes. If silent, check the browser or tab mute and your output volume.',muted:'Sound is turned off. Raise the Sound slider, then try again.',blocked:'Sound is still blocked. Tap Test Sound again or open this game in your regular browser.',unavailable:'Sound could not start here. Try opening this game in your regular browser.'};
    this.ui.soundCheck(messages[result]);
    // The test wakes the sound. From the pause menu, put the frozen game's sound back to sleep after the notes.
    if(this.settingsBack==='pause')setTimeout(()=>{if(!this.disposed&&this.state==='settings'&&this.settingsBack==='pause'&&!this.soundCheckPending)audio.pauseAll();},1000);
  }
  resetPresentationYaw(){this.presentationYaw={player:null,killer:null};}
  resetScene(){
    this.resetPresentationYaw();
    this.playerFootfalls?.reset();
    this.figure?.resetStance?.();
    this.killerFigure?.resetStance?.();
    this.escapeScene?.reset();
    this.deathScene?.reset();
    this.world.car.position.set(LOCATIONS.crash.x,0,LOCATIONS.crash.z);this.world.car.rotation.set(0,0,0);
    this.world.van.position.set(LOCATIONS.van.x,0,LOCATIONS.van.z);this.world.van.rotation.set(0,0,0);
    this.post.uRed.value=this.post.uDanger.value=this.post.uLetterbox.value=this.post.uFlash.value=0;this.post.uFade.value=1;
    this.figure.root.rotation.set(0,Math.PI,0);this.figure.setWounded(false);this.figure.root.visible=false;this.heldCrowbar.visible=false;this.defendUntil=0;
    this.killerFigure.reset();for(let i=0;i<45;i++)this.killerFigure.update(1/60,{state:'patrol',speed:0});this.killerFigure.root.visible=false;this.studyKey.visible=false;this.flash.visible=false;
    this.world.update(this.time,this.sim);this.camera.position.set(9,5,47);this.camera.lookAt(-3,1.8,17);
  }
  stopEngine(){this.engine?.stop(.2);this.engine=null;}
  home(){this.stopEngine();this.sim=new Act2Sim({extraObstacles:this.world.colliders,difficulty:this.campaign?.difficulty||'standard'});this.state='title';this.resetScene();this.ui.menu('title');audio.setIntensity(0);audio.music('title');audio.ambience('forest');audio.resumeAll();}
  start(withIntro=true){
    this.stopEngine();this.sim=new Act2Sim({extraObstacles:this.world.colliders,difficulty:this.campaign?.difficulty||'standard'});this.time=0;this.cineTime=0;this.messages.clear({keepRecent:!withIntro});this.captionUntil=0;this.viewYaw=Math.PI;this.pitch=.24;this.lightOn=true;this.killerFoot=0;this.resetScene();this.save();
    audio.unlock();audio.resumeAll();audio.setVolume(this.settings.volume);audio.ambience('forest');audio.music('dread');audio.setIntensity(0);audio.setThreat(0);
    if(withIntro){this.state='intro';this.ui.setMode('intro');this.post.uLetterbox.value=1;this.engine=audio.loop('engine_rev',{volume:.22});this.say('Beyond the broken gate. The road should have been clear.',4,{kind:'essential',key:'intro'});}
    else this.beginPlay();
  }
  beginPlay(){this.stopEngine();this.resetPresentationYaw();this.world.car.position.set(0,0,41);this.state='play';this.cineTime=0;this.post.uLetterbox.value=0;this.post.uFade.value=1;this.figure.root.visible=true;this.ui.setMode('play');this.camera.position.set(0,2.8,39);this.messages.clear({keepRecent:true});this.noteSessionCheckpoint();this.say('The camp office. Someone there might know another way out.',6,{kind:'essential',key:'office'});}
   pause(){if(!['play','intro','death','escape'].includes(this.state))return;this.pausedFrom=this.state;this.state='pause';this.resetPresentationYaw();this.playerFootfalls?.reset();const p=this.sim.player,nav=this.sim.navigation||{};this.ui.menu('pause',{objective:this.sim.objective||(this.sim.keys?'Get to the van.':'Find a way through the camp.'),recent:(this.messages?.recent?.()||[]).slice(0,4),destination:nav.label||'',distance:Number.isFinite(nav.x)?Math.round(Math.hypot((nav.x-p.x),(nav.z-p.z))):null});audio.pauseAll();}
  resume(){this.state=this.pausedFrom||'play';this.resetPresentationYaw();this.ui.setMode(this.state);audio.unlock();audio.resumeAll();if(this.state==='escape')this.escapeScene.refresh();if(this.state==='intro'&&this.cineTime>=7)this.ui.filmTitle('THE ROAD ENDS HERE.');this.syncCaption();this.last=performance.now();}
  say(text,seconds=3.5,opts={}){
    if(!text){this.messages.clear({keepRecent:true});this.captionUntil=this.time;this.syncCaption();return false;}
    const film=['intro','death','escape'].includes(this.state);
    if(film&&this.messages.text&&this.messages.text!==text)this.messages.clear({keepRecent:true});
    const kind=opts.kind||(film?'urgent':'essential');
    this.messages.say(text,{kind,seconds,key:opts.key??text,keep:opts.keep});
    this.captionUntil=this.time+Math.max(.5,Number(seconds)||3.5);
    this.syncCaption();
    return true;
  }
   syncCaption(){if(!['play','intro','death','escape'].includes(this.state)||!this.messages||typeof this.ui?.caption!=='function')return;this.ui.caption(this.messages.text);}
  advanceCaptions(dt){if(!['play','intro','death','escape'].includes(this.state))return;this.messages.update(dt);this.syncCaption();}
  noteSessionCheckpoint(){
    if(this.checkpointNoted||typeof this.campaign?.checkpointSaved!=='function'||this.campaign.checkpointSaved()!==false)return;
    this.checkpointNoted=true;this.say(SESSION_CHECKPOINT,6,{kind:'essential',key:'checkpoint-session'});
  }
  showStudy(index){
    this.studyIndex=(index+this.shots.length)%this.shots.length;this.resetScene();const shot=this.shots[this.studyIndex];
    this.camera.position.copy(vec(shot.position));this.camera.lookAt(vec(shot.target));
    if(shot.killer){const k=shot.killer;this.killerFigure.root.visible=true;this.killerFigure.root.position.set(k.x,0,k.z);this.killerFigure.root.rotation.y=k.yaw;this.studyKey.position.set(k.x+2,3,k.z+2);this.studyKey.visible=true;}
    if(shot.player){this.figure.root.visible=true;this.figure.root.position.set(shot.player.x,0,shot.player.z);this.figure.root.rotation.y=shot.player.yaw;}
    this.ui.study(shot,this.studyIndex,this.shots.length);
    if(shot.navigation){const s=new Act2Sim({extraObstacles:this.world.colliders,difficulty:this.campaign?.difficulty||'standard'});Object.assign(s.player,shot.player);this.ui.root.querySelector('.map-card').hidden=false;const dir=vec(shot.target).sub(vec(shot.position));this.ui.hud(s,Math.atan2(dir.x,dir.z));}
  }
  updateActors(dt){
    const p=this.sim.player,k=this.sim.killer,ordinary=this.state==='play'&&this.sim.phase==='play';
    const combat=!!p.defending||!!k.attackPhase||['attack','strike','windup','stagger','staggered'].includes(k.state);
    if(ordinary){const want=k.state==='chase'||k.attackPhase?'chase':['search','check-hide','stagger'].includes(k.state)?'stalk':'dread';if(want==='dread'){this.calmFor=(this.calmFor||0)+dt;}else this.calmFor=0;if(want!=='dread'||this.calmFor>6)audio.music(want);}
    this.presentationYaw??={player:null,killer:null};
    this.presentationYaw.player=presentationYawStep(this.presentationYaw.player,p.yaw,dt,{rate:10,x:p.x,z:p.z,snap:!ordinary||!!p.hidden||combat});
    this.figure.root.visible=!p.hidden&&this.state!=='escape';this.figure.root.position.set(p.x,0,p.z);this.figure.root.rotation.y=this.presentationYaw.player.yaw;
    this.figure.setFlashlight(this.lightOn);this.figure.setAnim(p.hidden?'hide':p.speed>.1?(p.run||p.gait==='jog'?'run':p.gait==='sneak'?'sneak':'walk'):'idle',{travelDriven:true});this.figure.update(dt,{speed:p.speed||0});
    this.heldCrowbar.visible=this.sim.weapon==='ready'||p.defending;
    if(p.defending)poseCrowbarSwing(this.figure,p.defendProgress);
    this.figure.stabilizeStance?.(dt,{enabled:this.state==='play'&&this.sim.phase==='play'&&!p.hidden});
    this.presentationYaw.killer=presentationYawStep(this.presentationYaw.killer,k.yaw,dt,{rate:7,x:k.x,z:k.z,snap:!ordinary||!k.active||combat});
    this.killerFigure.root.visible=k.active;this.killerFigure.root.position.set(k.x,0,k.z);this.killerFigure.root.rotation.y=this.presentationYaw.killer.yaw;this.killerFigure.update(dt,{time:this.time,state:k.state==='check-hide'?'inspect':k.state,attackPhase:k.attackPhase,attackProgress:k.attackProgress,speed:k.speed||0,moving:k.speed>.1});
    this.killerFigure.stabilizeStance?.(dt,{enabled:this.state==='play'&&this.sim.phase==='play'&&k.active});
    this.flash.visible=this.lightOn&&!p.hidden;this.flash.position.set(p.x,1.35,p.z);{const beam=this.beam=aimBeam(this.beam,p.yaw,this.viewYaw,p.speed>.3,dt);this.flash.target.position.set(p.x+Math.sin(beam)*12,.8,p.z+Math.cos(beam)*12);}
    audio.setListener(p.x,1.5,p.z,this.viewYaw);audio.setRoom(p.x>-18&&p.x<-6&&p.z>-2&&p.z<8?'room':'outside');
    const cur=this.figure.animator?.cur;
    const contact=this.playerFootfalls?.sample({phase:cur?.phase,gait:cur?.name,x:p.x,z:p.z,dt,soles:this.playerFootfalls?readFootSoles(this.figure):null,
      active:this.state==='play'&&this.sim.phase==='play'&&!p.hidden&&!this.disposed});
    if(contact&&(this.settings.steps??.45)>0)audio.sfx(p.x>-18&&p.x<-6&&p.z>-2&&p.z<8?'step_wood':'step_dirt',{volume:(p.run?.32:.18)*(this.settings.steps??.45)/.45});
    if(k.active&&k.speed>.1){this.killerFoot+=dt*k.speed;if(this.killerFoot>1.3){this.killerFoot=0;audio.sfx('killer_step',{x:k.x,y:.1,z:k.z,volume:.65});}}
    const danger=k.state==='chase'?clamp(1-Math.hypot(k.x-p.x,k.z-p.z)/22,.15,1):k.state==='search'?.2:0;audio.setIntensity(danger);
    // The wind sinks a little as he closes in, as in the first chapter, so his steps carry.
    audio.setThreat(k.active&&ordinary?clamp(1-(Math.hypot(k.x-p.x,k.z-p.z)-8)/24,0,1):0);this.post.uDanger.value=danger*.28;
  }
  cameraPlay(dt){
    const p=this.sim.player,behind=5.1;
    if(p.hidden){const spot=p.hidden;const v=spot.view||{x:p.x,y:1.3,z:p.z};this.camera.position.set(v.x,v.y,v.z);this.camera.lookAt(v.x+Math.sin(this.viewYaw)*8,v.y-.1,v.z+Math.cos(this.viewYaw)*8);return;}
    const target=new THREE.Vector3(p.x,1.35,p.z);const ideal=new THREE.Vector3(p.x-Math.sin(this.viewYaw)*behind,1.55+Math.sin(this.pitch)*behind,p.z-Math.cos(this.viewYaw)*behind);
    // Keep the shoulder camera on the player's side of physical walls. Inside the office cabin (F11) the camera
    // stays in the room: it may rise to look down into the roofless room, but it no longer slips over a wall or
    // out through a doorway, where the OFFICE sign filled the screen and hid the player.
    const R=CABIN_INSIDE,inCabin=p.x>R.minX&&p.x<R.maxX&&p.z>R.minZ&&p.z<R.maxZ;
    const outOfRoom=(x,z)=>x<R.minX+.18||x>R.maxX-.18||z<R.minZ+.18||z>R.maxZ-.18;
    let fraction=1;for(let i=1;i<=24;i++){const t=i/24,x=mix(target.x,ideal.x,t),z=mix(target.z,ideal.z,t),y=mix(target.y,ideal.y,t);if(inCabin&&outOfRoom(x,z)||this.sim.obstacles.some(o=>obstacleContainsPoint(o,x,z,.18)&&y>(o.minHeight??0)&&y<(o.height??(o.id.startsWith('cabin')?3.3:2.6)))){fraction=Math.max(.14,(i-1)/24);break;}}
    ideal.lerpVectors(target,ideal,fraction);
    const snap=this.snapCamera;this.snapCamera=false;
    if(snap)this.camera.position.copy(ideal);else this.camera.position.lerp(ideal,1-Math.exp(-12*dt));
    this.camera.lookAt(p.x+Math.sin(this.viewYaw)*2.4,1.4-Math.sin(this.pitch)*1.3,p.z+Math.cos(this.viewYaw)*2.4);
  }
  events(){for(const event of this.sim.events.splice(0)){
    if(event.type==='bridgeNoise')audio.sfx('wood_crack',{x:event.x,z:event.z,volume:.32});
    if(event.type==='killerArrival')audio.sfx('branch_snap',{x:this.sim.killer.x,z:this.sim.killer.z,volume:.7});
    if(event.type==='spotted'){audio.music('chase');audio.sfx('stinger_spot',{volume:.5});}
    if(event.type==='hide'){audio.sfx('closet_close',{volume:.3});this.viewYaw=this.sim.player.hidden?.kind==='tent'?0:-Math.PI/2;}
    if(event.type==='weapon')audio.sfx('fork_ting',{volume:.25});
    if(event.type==='defend'){this.defendUntil=this.time+.5;audio.sfx('metal_crash',{volume:.5});}
    if(event.type==='defendMiss'){if(event.swing){this.defendUntil=this.time+.5;audio.sfx('fork_swing',{volume:.2});}}
    if(event.type==='keys')audio.sfx('item_keys',{volume:.6});
    if(event.type==='attack')audio.sfx('fork_swing',{volume:.6});
    if(event.type==='attackWindup')audio.sfx('fork_swing',{x:this.sim.killer.x,y:1.2,z:this.sim.killer.z,volume:.4});
    if(event.type==='attackMiss')audio.sfx('fork_thunk',{x:this.sim.killer.x,y:1.2,z:this.sim.killer.z,volume:.55});
    if(event.type==='death')this.beginDeath(event);
    if(event.type==='escape')this.beginEscape();
    const line=captionFor(event);if(line)this.say(line.text,line.seconds,{kind:line.kind,key:line.key});
  }}
  beginDeath(event){
    this.messages.clear({keepRecent:true});
    this.figure?.resetStance?.();this.killerFigure?.resetStance?.();
    this.state='death';this.cineTime=0;this.deathKind=event.kind||this.sim.deathKind||'outdoors';
    this.ui.setMode('death');this.deathScene.begin(event);
  }
  finishDeath(){this.state='dead';this.flash.visible=false;this.post.uFade.value=0;this.post.uRed.value=0;audio.setIntensity(0);audio.setThreat(0);audio.ambience('none');this.ui.menu('dead',this.deathKind==='tent'?'Canvas will conceal you only if he never sees you enter. Leave when he starts checking.':'Use the cabin’s back door or the creek loop to break his view. Hide once he has lost you.');}

  beginEscape(){this.messages.clear({keepRecent:true});this.figure?.resetStance?.();this.killerFigure?.resetStance?.();this.state='escape';this.cineTime=0;this.ui.setMode('escape');this.escapeScene.begin();}
  finishEscape(){
    this.stopEngine();this.sim.phase='won';this.state='won';audio.setIntensity(0);
    this.campaign?.onComplete();const total=(this.campaign?.act1Time||0)+this.sim.time;
    this.ui.menu('won',`${Math.floor(total/60)}m ${Math.floor(total%60)}s through Stillwater · ${this.sim.weapon==='spent'?'The crowbar bought you a way out.':'You found your way through.'}`);
  }
  tickCinematic(dt){
    const before=this.cineTime;this.cineTime+=dt;const t=this.cineTime;
    if(this.state==='intro'){
      this.world.car.position.z=mix(29,41,clamp(t/3.2,0,1));
      if(t<3.2){this.camera.position.set(5.8,3.1,this.world.car.position.z-6);this.camera.lookAt(0,1.2,44);}
      else if(t<6.7){this.camera.position.set(4.7,2.4,44.5);this.camera.lookAt(0,1,41);if(t<3.7)this.camera.position.x+=Math.sin(t*62)*.16;}
      else{this.camera.position.set(0,2.8,38);this.camera.lookAt(-2,1.2,-9);}
      if(before<3.2&&t>=3.2){this.stopEngine();audio.sfx('metal_crash',{volume:.7});audio.sfx('wood_crack',{volume:.65});this.say('That tree was dragged here.',3.4,{kind:'essential',key:'crash-tree'});}
      if(before<7&&t>=7){this.ui.filmTitle('THE ROAD ENDS HERE.');this.say('',0);}
      if(t>10)this.beginPlay();
    }else if(this.state==='death'){
      if(this.deathScene.tick(dt))this.finishDeath();
    }else if(this.state==='escape'){
      if(this.escapeScene.tick(dt))this.finishEscape();
    }
  }
  tryQuickTurn(input){
    const p=this.sim?.player;
    if(!input?.quickTurn||this.state!=='play'||this.ui?.mapOpen||p?.hidden||p?.defending||input.defend)return false;
    p.yaw+=Math.PI;this.viewYaw+=Math.PI;this.snapCamera=true;
    this.presentationYaw=this.presentationYaw||{};
    this.presentationYaw.player={yaw:p.yaw,x:p.x,z:p.z};
    audio.sfx('ui_click',{volume:.2,rate:.8});
    return true;
  }
  tickPlay(dt){
      const input=this.ui.read();this.viewYaw-=input.lookX*.005;this.pitch=clamp(this.pitch+input.lookY*.003,-.06,.65);if(input.light)this.lightOn=!this.lightOn;this.tryQuickTurn(input);
      let mx=Math.sin(this.viewYaw)*input.forward-Math.cos(this.viewYaw)*input.strafe,mz=Math.cos(this.viewYaw)*input.forward+Math.sin(this.viewYaw)*input.strafe;const len=Math.hypot(mx,mz);if(len>1){mx/=len;mz/=len;}
      this.sim.step(dt,{moveX:mx,moveZ:mz,run:input.run,sneak:input.sneak,action:input.action,actionHeld:input.actionHeld,defend:input.defend,flashlight:this.lightOn,yaw:len>.1?Math.atan2(mx,mz):this.sim.player.yaw});
      this.updateActors(dt);this.events();this.world.update(this.time,this.sim);if(this.state==='play'){this.cameraPlay(dt);const view=this.camera.getWorldDirection(new THREE.Vector3());this.ui.hud(this.sim,Math.atan2(view.x,view.z),this.lightOn);}
  }
  dispose(){
    if(this.disposed)return;this.disposed=true;this.playerFootfalls?.reset();this.figure?.resetStance?.();this.killerFigure?.resetStance?.();
    cancelAnimationFrame(this.raf);this.listeners.abort();this.stopEngine();
    this.escapeScene.dispose();this.deathScene.dispose();this.ui.dispose();this.state='disposed';
  }
  frame(now){
    if(this.disposed)return;
    this.raf=requestAnimationFrame(this.frame);const dt=clamp((now-this.last)/1000,0,.1);this.last=now;
    if(!['pause','settings','dead','won'].includes(this.state))this.time+=dt;
    this.advanceCaptions(dt);
    if(this.state==='play'){this.tickPlay(dt);
    }else if(['intro','death','escape'].includes(this.state)){this.tickCinematic(dt);this.world.update(this.time,this.sim);}
    else if(this.state==='title'){this.camera.position.set(9+Math.sin(this.time*.08)*1.2,4.5,46);this.camera.lookAt(-3,1.5,13);this.world.update(this.time,this.sim);}
    else if(this.state==='study'){this.killerFigure.update(dt,{state:'patrol',speed:0,moving:false});this.figure.update(dt,{speed:0});}
    this.renderer.render(this.scene,this.camera,dt);
  }
}
