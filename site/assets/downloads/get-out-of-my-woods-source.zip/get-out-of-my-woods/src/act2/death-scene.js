// Authored V4 fatalities. This owns a paused, deterministic scene clock; it never
// advances simulation, moves the killer through scenery, or changes V3's poses.
import * as THREE from 'three';
import { Pose } from '../characters/rig.js';
import { audio as defaultAudio } from '../audio/index.js';
import { ATTACK_TIMING, obstacleContainsPoint, clearSegment } from './sim.js';

const clamp = v => Math.max(0, Math.min(1, v));
const smooth = (a, b, t) => { const x = clamp((t - a) / (b - a)); return x * x * (3 - 2 * x); };
const mix = (a, b, t) => a + (b - a) * t;
const V = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
export const DEATH_SCENES = Object.freeze({
  outdoors: Object.freeze({ duration: 4.4, windup: null, impact: 0, fall: .38, floor: 1.5, fade: 3.55 }),
  tent: Object.freeze({ duration: 4.8, windup: 1.25, impact: 1.99, fall: 2.08, floor: 2.85, fade: 3.95 }),
  wardrobe: Object.freeze({ duration: 4.9, windup: 1.15, impact: 1.89, fall: 2.02, floor: 2.9, fade: 4.05 }),
});

// One deliberate approach to the tent mouth, bounded by the same expanded
// obstacles as live movement. A blocked approach stops short; it never repairs
// a shot by teleporting the actor or stepping through canvas. Wardrobe stays put.
export function deathApproach(kind, start, hide, obstacles = []) {
  const from = { x: start.x, z: start.z };
  if (kind !== 'tent' || !hide) return from;
  const tent = obstacles.find(o => o.id === (hide.colliderId || hide.id || 'tent'));
  const mouth = { x: hide.view?.x ?? hide.x, z: (tent?.maxZ ?? hide.z - 1.2) + .48 };
  const dx = mouth.x - from.x, dz = mouth.z - from.z, distance = Math.hypot(dx, dz);
  if (distance < .01) return from;
  const amount = Math.min(1, 2.2 / distance), end = { x: from.x + dx * amount, z: from.z + dz * amount };
  let last = from;
  for (let i = 1; i <= 80; i++) {
    const f = i / 80, next = { x: mix(from.x, end.x, f), z: mix(from.z, end.z, f) };
    if (!clearSegment(from, next, .42, obstacles)) break;
    last = next;
  }
  return last;
}

// Exported for CPU-only timing checks. Attack progress is the same contract used
// by live play: windup .62s, strike .20s, contact at strike .6, recover .42s.
export function sampleDeathScene(kind, time, contactProgress = ATTACK_TIMING.contact) {
  const plan = DEATH_SCENES[kind] || DEATH_SCENES.outdoors;
  const t = Math.max(0, time), hidden = plan.windup !== null;
  let phase = null, progress = 0;
  if (hidden) {
    const a = t - plan.windup;
    if (a >= 0 && a < ATTACK_TIMING.windup) { phase = 'windup'; progress = a / ATTACK_TIMING.windup; }
    else if (a >= ATTACK_TIMING.windup && a < ATTACK_TIMING.windup + ATTACK_TIMING.strike) {
      phase = 'strike'; progress = (a - ATTACK_TIMING.windup) / ATTACK_TIMING.strike;
    } else if (a >= ATTACK_TIMING.windup + ATTACK_TIMING.strike && a < ATTACK_TIMING.windup + ATTACK_TIMING.strike + ATTACK_TIMING.recover) {
      phase = 'recover'; progress = (a - ATTACK_TIMING.windup - ATTACK_TIMING.strike) / ATTACK_TIMING.recover;
    }
  } else {
    const remainingStrike = (1 - clamp(contactProgress)) * ATTACK_TIMING.strike;
    if (t < remainingStrike) { phase = 'strike'; progress = clamp(contactProgress) + t / ATTACK_TIMING.strike; }
    else if (t < remainingStrike + ATTACK_TIMING.recover) { phase = 'recover'; progress = (t - remainingStrike) / ATTACK_TIMING.recover; }
  }
  const sinceImpact = t - plan.impact;
  return {
    time: t, duration: plan.duration, finished: t >= plan.duration,
    attackPhase: phase, attackProgress: clamp(progress),
    fall: smooth(plan.fall, plan.floor, t),
    impact: sinceImpact >= 0 ? Math.exp(-sinceImpact * 8) : 0,
    fade: 1 - smooth(plan.fade, plan.duration, t),
    reveal: hidden ? smooth(.55, 1.25, t) : 1,
    beat: t < plan.impact ? 'anticipation' : t < plan.fall ? 'impact' : t < plan.floor ? 'fall' : 'aftermath',
  };
}

function propSnapshot(object) {
  return { object, position: object.position.clone(), quaternion: object.quaternion.clone(),
    points: object.geometry?.attributes.position?.array.slice() };
}

export function createDeathScene(app, { audio = defaultAudio } = {}) {
  let shot = null;
  const shadowMaterial = new THREE.MeshBasicMaterial({ color: 0x000201, transparent: true, opacity: 0,
    depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
  const shadows = [];
  const position = V(), target = V(), end = V(), scratch = V(), look = new THREE.PerspectiveCamera();
  const writePost = (name, value) => { if (app.post[name]) app.post[name].value = value; };

  function reset() {
    if (shot) {
      for (const p of shot.props) {
        p.object.position.copy(p.position); p.object.quaternion.copy(p.quaternion);
        if (p.points) { p.object.geometry.attributes.position.array.set(p.points); p.object.geometry.attributes.position.needsUpdate = true; p.object.geometry.computeVertexNormals(); }
      }
      app.camera.up.copy(shot.cameraUp); app.camera.fov = shot.fov; app.camera.updateProjectionMatrix();
      if (app.flash && shot.flash) {
        app.flash.intensity = shot.flash.intensity; app.flash.visible = shot.flash.visible;
        app.flash.position.copy(shot.flash.position); app.flash.target.position.copy(shot.flash.target);
      }
    }
    for (const shadow of shadows) shadow.removeFromParent();
    shadows.length = 0; shadowMaterial.opacity = 0; shot = null;
  }

  function sound(name, volume, world = false) {
    const k = shot.killer;
    audio.sfx(name, world ? { volume, x: k.x, y: name.includes('step') ? .1 : 1.3, z: k.z } : { volume });
  }

  function begin(event = {}) {
    reset();
    const p = app.sim.player, k = app.sim.killer;
    const kind = event.kind || app.sim.deathKind || 'outdoors';
    const plan = DEATH_SCENES[kind] || DEATH_SCENES.outdoors;
    const hidden = kind === 'tent' || kind === 'wardrobe';
    const actor = app.figure, animator = actor.animator;
    const pose = () => new Pose(actor.rig.idx, actor.rig.bones.length);
    const from = pose(), recoil = pose(), floor = pose(), blended = pose();
    from.copy(animator.prev && animator.fade < 1 ? animator.Q : animator.P);
    animator.anims.flinch.fn(recoil, { t: .26, phase: 0 }, animator.extra);
    animator.anims.dead.fn(floor, { t: 1, phase: 0 }, animator.extra);
    const tentFlaps = app.world.deathProps?.tents?.[p.hidden?.id]?.tentFlaps || app.world.deathProps?.tentFlaps || [];
    const props = (kind === 'tent' ? tentFlaps : kind === 'wardrobe' ? [app.world.deathProps?.wardrobeDoor].filter(Boolean) : []).map(propSnapshot);
    const view = p.hidden?.view;
    shot = { kind, plan, time: 0, hidden, props, from, recoil, floor, blended,
      player: { x: p.x, z: p.z, yaw: p.yaw }, killer: { x: k.x, z: k.z, yaw: k.yaw },
      killerStart: { x: k.x, z: k.z }, approach: deathApproach(kind, k, p.hidden, app.sim.obstacles || []),
      contactProgress: k.attackPhase === 'strike' ? Math.max(ATTACK_TIMING.contact, k.attackProgress || 0) : ATTACK_TIMING.contact,
      cameraStart: app.camera.position.clone(), cameraQ: app.camera.quaternion.clone(), cameraUp: app.camera.up.clone(), fov: app.camera.fov,
      interior: view ? V(view.x, view.y, view.z) : app.camera.position.clone(),
      cues: [], cueIndex: 0, flash: app.flash ? { intensity: app.flash.intensity, visible: app.flash.visible, position: app.flash.position.clone(), target: app.flash.target.position.clone() } : null,
    };
    for (const p of props) {
      const shadow = new THREE.Mesh(p.object.geometry, shadowMaterial); shadow.name = 'Fatal-scene cloth or door shadow';
      p.object.add(shadow); shadows.push(shadow);
    }
    app.figure.root.visible = !hidden; app.heldCrowbar && (app.heldCrowbar.visible = false);
    app.killerFigure.root.visible = true;
    app.killerFigure.root.position.set(k.x, 0, k.z); app.killerFigure.root.rotation.y = k.yaw;
    if (hidden) {
      // Turn in place toward the real entrance; never translate him to a shot mark.
      app.killerFigure.root.rotation.y = Math.atan2(shot.interior.x - k.x, shot.interior.z - k.z);
      shot.killer.yaw = app.killerFigure.root.rotation.y;
    }
    writePost('uLetterbox', 1); writePost('uFade', 1); writePost('uDanger', .25);
    audio.music('none'); audio.setIntensity(0); audio.setRoom(kind === 'wardrobe' ? 'closet' : 'outside');
    const cues = hidden ? [
      [.14, 'killer_step', .38, true], [.52, 'killer_breath', .28, true],
      [.72, kind === 'tent' ? 'rummage' : 'closet_open', .38, true],
      ...(kind === 'tent' && Math.hypot(shot.approach.x - k.x, shot.approach.z - k.z) > .6 ? [[.76, 'killer_step', .42, true]] : []),
      [plan.windup + .54, 'fork_swing', .45, true], [plan.impact, 'body_hit', .62],
      [plan.impact + .025, 'scream_death', .48], [plan.floor - .12, 'body_fall', .5],
      [plan.floor + .55, kind === 'tent' ? 'step_leaf' : 'step_wood', .25, true],
    ] : [[0, 'body_hit', .62], [.04, 'scream_death', .48], [.42, 'stumble', .3], [1.35, 'body_fall', .55], [2.35, 'killer_breath', .27, true]];
    shot.cues = cues;
    app.say(kind === 'tent' ? 'The shadow stops at the canvas.' : kind === 'wardrobe' ? 'A hand finds the door.' : 'Your legs give way.', hidden ? 1.55 : 1.8);
    fireCues(); render(0); return plan.duration;
  }

  function fireCues() {
    while (shot.cueIndex < shot.cues.length && shot.cues[shot.cueIndex][0] <= shot.time + 1e-8) {
      const [, name, volume, world] = shot.cues[shot.cueIndex++]; sound(name, volume, world);
    }
  }

  // The shoulder cut is checked at its actual height, so a nearby cabin wall or
  // tree cannot swallow the camera during the fall. Hidden cameras never leave
  // their authored interior volume and do not use the walking obstruction box.
  function keepCameraClear(anchor, desired) {
    for (let i = 1; i <= 28; i++) {
      const f = i / 28; scratch.lerpVectors(anchor, desired, f);
      if ((app.sim.obstacles || []).some(o => scratch.y > (o.minHeight ?? 0) && scratch.y < (o.height ?? 2.6) && obstacleContainsPoint(o, scratch.x, scratch.z, .13))) {
        return desired.lerpVectors(anchor, desired, Math.max(0, (i - 1) / 28));
      }
    }
    return desired;
  }

  function render(dt) {
    const s = shot, t = s.time, sample = sampleDeathScene(s.kind, t, s.contactProgress), p = s.player, k = s.killer;
    const move = smooth(.05, 1.22, t), previousX = k.x, previousZ = k.z;
    const next = { x: mix(s.killerStart.x, s.approach.x, move), z: mix(s.killerStart.z, s.approach.z, move) };
    // Validate the actual frame sweep too: even a newly introduced obstacle or
    // an unusually long frame must not tunnel through a thin prop.
    if (clearSegment(k, next, .42, app.sim.obstacles || [])) { k.x = next.x; k.z = next.z; }
    if (s.hidden) k.yaw = Math.atan2(s.interior.x - k.x, s.interior.z - k.z);
    const walkingSpeed = dt > 0 ? Math.min(3.1, Math.hypot(k.x - previousX, k.z - previousZ) / dt) : 0;
    app.sim.killer.x = k.x; app.sim.killer.z = k.z; app.sim.killer.yaw = k.yaw;
    app.killerFigure.root.position.set(k.x, 0, k.z); app.killerFigure.root.rotation.y = k.yaw;
    // 'inspect' has no fallback attack clock; explicit phases are authoritative.
    app.killerFigure.update(dt, { state: sample.attackPhase ? 'attack' : t < s.plan.impact ? 'inspect' : 'patrol', attackPhase: sample.attackPhase, attackProgress: sample.attackProgress, speed: walkingSpeed });
    if (!s.hidden) {
      s.blended.copy(s.from).lerp(s.recoil, smooth(0, .13, t)).lerp(s.floor, sample.fall);
      app.figure.animator.apply(s.blended, 0, {});
      app.figure.root.position.set(p.x, 0, p.z); app.figure.root.rotation.set(0, p.yaw, 0);
      const a = Math.atan2(k.x - p.x, k.z - p.z), sideX = Math.cos(a), sideZ = -Math.sin(a);
      target.set(mix(p.x, k.x, .36), mix(1.15, .58, sample.fall), mix(p.z, k.z, .36));
      end.set(p.x - Math.sin(a) * 1.85 + sideX * 1.45, mix(1.5, .43, sample.fall), p.z - Math.cos(a) * 1.85 + sideZ * 1.45);
      position.lerpVectors(s.cameraStart, end, smooth(0, .55, t)); keepCameraClear(V(p.x, 1.2 - sample.fall * .5, p.z), position);
    } else {
      position.copy(s.interior);
      if (s.kind === 'tent') {
        position.x += sample.fall * .17; position.z -= sample.fall * .22; position.y = mix(s.interior.y, .22, sample.fall);
        target.set(k.x, mix(1.65, .76, sample.fall), k.z);
        for (let j = 0; j < s.props.length; j++) {
          const prop = s.props[j], a = prop.object.geometry.attributes.position, base = prop.points;
          const flutter = Math.sin(t * 25 + j * 2) * .04 * (smooth(.7, 1.0, t) - smooth(2.3, 2.7, t));
          for (let i = 0; i < a.count; i++) {
            const x = base[i * 3], y = base[i * 3 + 1], weight = clamp(1 - y / 2.3);
            a.setXYZ(i, x + Math.sign(x) * sample.reveal * .12 * weight, y, base[i * 3 + 2] + flutter * weight);
          }
          a.needsUpdate = true; prop.object.geometry.computeVertexNormals();
        }
      } else {
        position.x += sample.fall * .14; position.z += sample.fall * .11; position.y = mix(s.interior.y, .28, sample.fall);
        target.set(k.x, mix(1.75, .95, sample.fall), k.z);
        const door = s.props[0];
        if (door) {
          const hingeLocal = V(0, 0, -.675), hinge = hingeLocal.clone().applyQuaternion(door.quaternion).add(door.position);
          door.object.quaternion.copy(door.quaternion).multiply(new THREE.Quaternion().setFromAxisAngle(V(0, 1, 0), -sample.reveal * .95));
          door.object.position.copy(hinge).sub(hingeLocal.applyQuaternion(door.object.quaternion));
        }
      }
      shadowMaterial.opacity = (.12 + .48 * smooth(.1, 1.25, t)) * (1 - .6 * sample.fall);
    }
    const kick = sample.impact;
    position.x += Math.sin(t * 83) * .035 * kick; position.y += Math.sin(t * 71) * .025 * kick;
    app.camera.position.copy(position); app.camera.up.set(0, 1, 0);
    look.position.copy(position); look.up.set(0, 1, 0); look.lookAt(target);
    app.camera.quaternion.slerpQuaternions(s.cameraQ, look.quaternion, smooth(0, s.hidden ? .45 : .3, t));
    app.camera.rotateZ((s.hidden ? .65 : -.22) * sample.fall + Math.sin(t * 47) * .035 * kick);
    app.camera.fov = s.fov + kick * 3; app.camera.updateProjectionMatrix();
    writePost('uRed', .16 * kick + .14 * smooth(s.plan.impact, s.plan.floor, t));
    writePost('uFlash', .08 * kick); writePost('uDanger', .25 * (1 - sample.fall)); writePost('uFade', sample.fade);
    if (app.flash) {
      app.flash.visible = !s.hidden && !!s.flash?.visible;
      app.flash.position.set(p.x, mix(1.35, .18, sample.fall), p.z);
      app.flash.target.position.set(p.x + Math.sin(p.yaw + sample.fall * 1.2) * 9, .05, p.z + Math.cos(p.yaw + sample.fall * 1.2) * 9);
      app.flash.intensity = (s.flash?.intensity || 0) * (1 - sample.fall * .35);
    }
    audio.setListener(position.x, position.y, position.z, Math.atan2(target.x - position.x, target.z - position.z));
    return sample.finished;
  }

  return {
    begin, reset,
    tick(dt) { if (!shot) return true; shot.time = Math.min(shot.plan.duration, shot.time + Math.max(0, Number.isFinite(dt) ? dt : 0)); fireCues(); return render(Math.max(0, Number.isFinite(dt) ? dt : 0)); },
    // Skipping advances the picture only: unreached screams/impacts never fire.
    skip() { if (shot) { shot.time = shot.plan.duration; shot.cueIndex = shot.cues.length; render(0); } return true; },
    get time() { return shot?.time || 0; }, get duration() { return shot?.plan.duration || 0; },
    get kind() { return shot?.kind || null; },
    dispose() { reset(); shadowMaterial.dispose(); },
  };
}
