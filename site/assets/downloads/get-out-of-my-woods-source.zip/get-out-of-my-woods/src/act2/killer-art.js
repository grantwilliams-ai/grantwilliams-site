// Small deterministic material studies. No downloads or image-generation assets.
import * as THREE from 'three';

const cache = new Map();
function rand(seed) {
  let n = seed >>> 0;
  return () => { n = (Math.imul(n, 1664525) + 1013904223) >>> 0; return n / 4294967296; };
}
function dataTexture(data, size, color = false) {
  const texture = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.generateMipmaps = true;
  texture.colorSpace = color ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  texture.anisotropy = 4;
  texture.needsUpdate = true;
  return texture;
}

/** Neutral weave: material/vertex colours carry the garment colour. */
export function killerWeave(kind = 'burlap') {
  if (cache.has(kind)) return cache.get(kind);
  const size = 256, noise = rand(kind === 'burlap' ? 912 : 524);
  const color = new Uint8Array(size * size * 4), height = new Uint8Array(color.length), rough = new Uint8Array(color.length);
  const cell = kind === 'burlap' ? 6 : 5;
  const stains = Array.from({ length: 13 }, () => ({
    x: noise() * size, y: noise() * size, rx: 12 + noise() * 50, ry: 8 + noise() * 27,
    a: 4 + noise() * 10,
  }));
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const i = (y * size + x) * 4;
    // Uneven spun yarn: the gaps wander, so the weave never becomes a perfect checkerboard.
    const xx = (x + .7 * Math.sin(y * .043) + cell) % cell;
    const yy = (y + .65 * Math.sin(x * .071) + cell) % cell;
    const cross = ((x / cell | 0) + (y / cell | 0)) % 2;
    const warp = Math.sin((xx + 0.5) / cell * Math.PI);
    const weft = Math.sin((yy + 0.5) / cell * Math.PI);
    const weave = cross ? warp * 0.72 + weft * 0.28 : weft * 0.72 + warp * 0.28;
    const strand = Math.sin(x * 1.8 + y * 0.2) * 2 + Math.sin(y * 2.4 + x * 0.1) * 2;
    const grain = (noise() - 0.5) * 9;
    let dirt = 0;
    for (const s of stains) {
      // Repeat the handling marks at the tile boundary as well.
      const dx = Math.min(Math.abs(x - s.x), size - Math.abs(x - s.x));
      const dy = Math.min(Math.abs(y - s.y), size - Math.abs(y - s.y));
      dirt += Math.max(0, 1 - (dx * dx / (s.rx * s.rx) + dy * dy / (s.ry * s.ry))) * s.a;
    }
    const slub = Math.sin(x * .031 + y * .005) * Math.sin(y * .019) * 5;
    const burlap = kind === 'burlap';
    // A few broken fibres interrupt the repeating weave; broad handling marks
    // survive downsampling without making the sack look like a plastic mask.
    const fibre = Math.pow(Math.max(0,Math.sin(x*.217+y*.027)*Math.sin(y*.173)),12);
    const value = Math.max(0, Math.min(255, (burlap ? 194 : 203) + weave * (burlap ? 26 : 16) + strand + grain + slub + fibre*9 - dirt * (burlap ? 1.3 : 1)));
    color[i] = value; color[i + 1] = burlap ? value * .95 : value - 1; color[i + 2] = burlap ? value * .87 : value - 4; color[i + 3] = 255;
    const h = 112 + weave * 39 + grain + fibre*8;
    height[i] = height[i + 1] = height[i + 2] = h; height[i + 3] = 255;
    // Worn threads catch a softer highlight than packed dirt. Both remain matte.
    const r = Math.max(222,Math.min(253,247-dirt*.55-fibre*8+grain*.4));
    rough[i] = rough[i + 1] = rough[i + 2] = r; rough[i + 3] = 255;
  }
  const textures = { map: dataTexture(color, size, true), bumpMap: dataTexture(height, size), roughnessMap:dataTexture(rough,size) };
  if (kind === 'burlap') for (const texture of Object.values(textures)) texture.repeat.set(2.2, 2.2);
  cache.set(kind, textures);
  return textures;
}
