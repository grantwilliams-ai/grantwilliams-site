// V4 appearance for the established skinned figure. Original character sources
// stay untouched; only the Act II adapter below installs preview combat poses.
import * as THREE from 'three';
import { createKiller, KILLER_JOINTS } from '../characters/killer.js';
import { Pose } from '../characters/rig.js';
import { killerWeave } from './killer-art.js';
import { tailorKillerClothes } from './killer-tailoring.js';
import { createBoxClearance } from '../characters/wall-clearance.js';
import { OBSTACLES } from './layout.js';

const clamp01 = (v) => Math.max(0, Math.min(1, v));
const smooth = (v) => { const t = clamp01(v); return t * t * (3 - 2 * t); };

// These poses belong to the preview, not the shared V3 animation library. The old
// chase held its tines two metres in front of a harmless walking collision body.
function installPreviewPoses(figure) {
  const animator = figure.animator, original = animator.anims;
  const scratch = () => new Pose(figure.rig.idx, figure.rig.bones.length);
  const from = scratch(), ready = scratch(), carry = scratch();
  const euler = new THREE.Euler(0, 0, 0, 'YXZ');
  const pelvisQ = new THREE.Quaternion(), forkQ = new THREE.Quaternion();
  const origin = new THREE.Vector3(), tipOffset = new THREE.Vector3();
  const combat = { phase: null, progress: 0, begin() {
    from.copy(animator.prev && animator.fade < 1 ? animator.Q : animator.P);
  } };

  function placeFork(P, x, y, z, pitch, gripR, gripL = 0, leftWeight = 0) {
    // Aim the tip in actor space, then undo the authored pelvis movement. This
    // keeps visible reach equal to the simulation even while the torso lunges.
    // Pose's rotation block begins at 17; fork has the pelvis as its parent.
    const a = P.a, r = 17 + P.idx.pelvis * 3;
    pelvisQ.setFromEuler(euler.set(a[r], a[r + 1], a[r + 2])).invert();
    forkQ.setFromEuler(euler.set(pitch, 0, 0));
    tipOffset.set(0, 1.99, .05).applyQuaternion(forkQ);
    origin.set(x - tipOffset.x - a[0], y - tipOffset.y - 1 - a[1], z - tipOffset.z - a[2]).applyQuaternion(pelvisQ);
    forkQ.premultiply(pelvisQ);
    euler.setFromQuaternion(forkQ, 'YXZ');
    P.fork(origin.x, origin.y, origin.z, euler.x, euler.y, euler.z);
    P.grip(1, gripR, leftWeight, gripL);
  }
  function carried(P, st) {
    // Upright at his right side: no forward blade during harmless pursuit.
    // He holds it at chest height, a hand's width out from the shoulder and a
    // forearm's length forward: gripped low beside the hip (-.55, 2.42, .06, -.09,
    // grip .58) the handle ran up through his own forearm and upper arm in every
    // state. These numbers also keep his elbow inside the old body envelope
    // (tests/act2-killer-art): a centimetre either way in z leaves it.
    const sway = Math.sin(st.phase * Math.PI * 2) * .025;
    placeFork(P, -.58, 2.42 + sway, .24, -.06, .9);
  }
  function raised(P, st, ex) {
    original.raise.fn(P, { ...st, t: .35 }, ex);
    placeFork(P, -.36, 2.54, .18, .42, .68, 1.05, 1);
  }
  const anims = { ...original };
  for (const name of ['idle', 'standStill', 'walk', 'stalk', 'chase', 'lookAround', 'searchCloset']) {
    const source = original[name];
    if (source) anims[name] = { ...source, fn(P, st, ex) { source.fn(P, st, ex); carried(P, st); } };
  }
  anims.previewAttack = { fade: .001, fn(P, st, ex) {
    if (!combat.phase) { original.idle.fn(P, st, ex); carried(P, st); return; }
    const p = clamp01(combat.progress);
    if (combat.phase === 'windup') {
      raised(ready, st, ex);
      P.copy(from).lerp(ready, smooth(p));
    } else if (combat.phase === 'strike') {
      // The one dangerous instant is strike progress .6 (.12s after windup).
      // Withdraw immediately after contact instead of holding through her body.
      const extension = p <= .6 ? smooth(p / .6) : 1 - smooth((p - .6) / .4);
      original.jab.fn(P, { ...st, t: .22 * extension }, ex);
      placeFork(P, -.36 * (1 - extension), 2.54 - 1.36 * extension, .18 + 1.62 * extension,
        .42 + .95 * extension, .68, 1.05, 1);
    } else {
      raised(P, st, ex);
      carry.clear(); original.idle.fn(carry, st, ex); carried(carry, st);
      P.lerp(carry, smooth(p));
    }
  } };
  animator.anims = anims;
  if (animator.cur) animator.cur.def = anims[animator.cur.name];
  return combat;
}

function vertexEmissive(material) {
  // Keep black eye cuts truly dark even when a little ambient fill lifts the cloth.
  material.onBeforeCompile = (shader) => {
    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <emissivemap_fragment>',
      '#include <emissivemap_fragment>\n totalEmissiveRadiance *= vColor.rgb;',
    );
  };
  material.customProgramCacheKey = () => 'act2-killer-vertex-fill-v1';
  return material;
}

function softenSurface(geometry) {
  // Average coincident surface normals without merging UVs, decals or skinning attributes.
  const pos = geometry.attributes.position, normals = geometry.attributes.normal;
  const skin = geometry.attributes.skinIndex, sums = new Map(), keys = [];
  for (let i = 0; i < pos.count; i++) {
    const key = `${skin.getX(i)}:${Math.round(pos.getX(i) * 10000)},${Math.round(pos.getY(i) * 10000)},${Math.round(pos.getZ(i) * 10000)}`;
    keys.push(key);
    if (!sums.has(key)) sums.set(key, new THREE.Vector3());
    sums.get(key).add(new THREE.Vector3(normals.getX(i), normals.getY(i), normals.getZ(i)));
  }
  for (const normal of sums.values()) normal.normalize();
  for (let i = 0; i < pos.count; i++) {
    const n = sums.get(keys[i]); normals.setXYZ(i, n.x, n.y, n.z);
  }
  normals.needsUpdate = true;
}

function conformSackDetails(geometry) {
  // The shared sack starts with its 9-ring / 14-sided shell, then a folded
  // corner, then surface decals. Interpolate shell normals onto those decals:
  // stains and stitches should read as cloth, not sharp metallic facets.
  const shellCount=8*14*6+14*3,detailStart=shellCount+4*6*6+6*3;
  const p=geometry.attributes.position,n=geometry.attributes.normal;
  const triangles=[];
  for(let i=0;i<shellCount;i+=3)triangles.push({
    face:new THREE.Triangle(new THREE.Vector3().fromBufferAttribute(p,i),new THREE.Vector3().fromBufferAttribute(p,i+1),new THREE.Vector3().fromBufferAttribute(p,i+2)),
    normals:[0,1,2].map(offset=>new THREE.Vector3().fromBufferAttribute(n,i+offset)),
  });
  const point=new THREE.Vector3(),closest=new THREE.Vector3(),bary=new THREE.Vector3(),normal=new THREE.Vector3(),bestNormal=new THREE.Vector3();
  for(let i=detailStart;i<p.count;i++){
    point.fromBufferAttribute(p,i);let distance=Infinity;
    for(const triangle of triangles){
      triangle.face.closestPointToPoint(point,closest);const d=point.distanceToSquared(closest);
      if(d>=distance)continue;
      distance=d;triangle.face.getBarycoord(closest,bary);
      normal.copy(triangle.normals[0]).multiplyScalar(bary.x).addScaledVector(triangle.normals[1],bary.y).addScaledVector(triangle.normals[2],bary.z);
      bestNormal.copy(normal).normalize();
    }
    n.setXYZ(i,bestNormal.x,bestNormal.y,bestNormal.z);
  }
  n.needsUpdate=true;
}

const polishedFigures = new WeakSet();

// Reusable appearance only: keep each chapter's original rig, animator, root and
// combat interface. A reused figure must not be narrowed or tailored twice.
export function polishKillerAppearance(figure) {
  if (polishedFigures.has(figure)) return figure;
  tailorKillerClothes(figure);
  // Keep the established rig at unit scale: its hand-to-fork IK solves in world metres.
  const cloth = figure.meshes.find((m) => m.name === 'killer-cloth');
  const hard = figure.meshes.find((m) => m.name === 'killer-hard');
  const burlap = figure.meshes.find((m) => m.name === 'killer-burlap');
  const headIndex = figure.rig.idx.head;
  softenSurface(cloth.geometry);
  softenSurface(hard.geometry);

  // Slate denim becomes worn olive canvas. Keep seams, grime and sewn pockets separate.
  const colors = cloth.geometry.attributes.color;
  for (let i = 0; i < colors.count; i++) {
    const r = colors.getX(i), g = colors.getY(i), b = colors.getZ(i);
    if (b > r * 1.1 && b >= g) {
      const l = r * 0.21 + g * 0.72 + b * 0.07;
      colors.setXYZ(i, l * .58, l * .77, l * .64);
    }
    // Handling wear follows the garment rather than its texture tile: abraded
    // knees, darker cuffs/hem and restrained irregular dirt across the bib.
    const p=cloth.geometry.attributes.position,x=p.getX(i),y=p.getY(i),z=p.getZ(i);
    const knee=Math.exp(-(((y-.55)/.105)**2))*Math.max(0,z)*.75;
    const hem=Math.max(0,1-(y-.23)/.3)*.1;
    const dirt=(.5+.5*Math.sin(x*19+y*8)*Math.sin(z*23+y*4))*.055;
    const wear=1+knee-hem-dirt;
    colors.setXYZ(i,colors.getX(i)*wear,colors.getY(i)*wear,colors.getZ(i)*wear);
  }
  colors.needsUpdate = true;

  // Keep the two original knife cuts, but lessen the vertical offset that read as a mouth.
  // Each pure-black fan has its puckered rim immediately before it and frays after it.
  const sackPosition = burlap.geometry.attributes.position, sackColor = burlap.geometry.attributes.color;
  for (const side of [-1, 1]) {
    const indices = [];
    for (let i = 0; i < sackPosition.count; i++) {
      if (sackPosition.getX(i) * side > 0 && sackColor.getX(i) < .001 && sackColor.getY(i) < .001 && sackColor.getZ(i) < .001) indices.push(i);
    }
    if (indices.length === 30) {
      const centre = side < 0 ? 1.8 + .23 * .82 : 1.8 + .31 * .82;
      for (let i = indices[0] - 54; i <= indices[indices.length - 1] + 48; i++) {
        sackPosition.setY(i, centre + (sackPosition.getY(i) - centre) * .8 + (side < 0 ? .05 : 0));
        if (side < 0) sackPosition.setZ(i, sackPosition.getZ(i) + .009);
      }
    }
  }

  // Tighter sack outline. Transform rope, decals, morph and eye attachments together.
  const scale = [0.765, 1.0, 0.78];
  for (const mesh of [hard, burlap]) {
    const g = mesh.geometry, pos = g.attributes.position, skin = g.attributes.skinIndex;
    for (let i = 0; i < pos.count; i++) if (skin.getX(i) === headIndex) {
      for (let a = 0; a < 3; a++) pos.array[i * 3 + a] = KILLER_JOINTS.head[a] + (pos.array[i * 3 + a] - KILLER_JOINTS.head[a]) * scale[a];
    }
    for (const morph of g.morphAttributes.position || []) {
      for (let i = 0; i < morph.count; i++) if (skin.getX(i) === headIndex) {
        for (let a = 0; a < 3; a++) morph.array[i * 3 + a] *= scale[a];
      }
    }
    pos.needsUpdate = true;
    g.computeBoundingSphere();
  }
  // Long tension folds radiate from the tied neck. Deforming every surface/decal vertex
  // with one function keeps seams and knife cuts on the cloth instead of floating above it.
  for (let i = 0; i < sackPosition.count; i++) {
    const x = sackPosition.getX(i), y = sackPosition.getY(i) - KILLER_JOINTS.head[1], z = sackPosition.getZ(i) - KILLER_JOINTS.head[2];
    const angle = Math.atan2(x, z), radius = Math.hypot(x, z);
    const weight = Math.min(1, Math.max(0, (y - .045) / .11));
    const fold = weight * (.009 * Math.sin(angle * 7 + y * 8) + .004 * Math.sin(angle * 13 - y * 5));
    if (radius > .01) { sackPosition.setX(i, x * (1 + fold / radius)); sackPosition.setZ(i, KILLER_JOINTS.head[2] + z * (1 + fold / radius)); }
    if (y < -.035) sackPosition.setY(i, sackPosition.getY(i) - .009 * (1 + Math.sin(angle * 11)));
  }
  burlap.geometry.computeVertexNormals();
  softenSurface(burlap.geometry);
  conformSackDetails(burlap.geometry);
  figure.rig.b('head').children.forEach((child) => {
    // Only the reflection group and the head marker are attached outside the skinned meshes.
    if (child.isGroup) child.children.forEach((m) => {
      const lower = m.position.x < 0, centre = (lower ? .23 : .31) * .82;
      m.position.y = centre + (m.position.y - centre) * .8 + (lower ? .05 : 0);
      if (lower) m.position.z += .009;
      m.position.multiply(new THREE.Vector3(...scale));
    });
    else child.position.multiply(new THREE.Vector3(...scale));
  });

  const oldMaterials = figure.meshes.map((m) => m.material);
  const clothTex = killerWeave('canvas'), sackTex = killerWeave('burlap');
  cloth.material = vertexEmissive(new THREE.MeshStandardMaterial({
    ...clothTex, vertexColors: true, roughness: 0.95, metalness: 0,
    bumpScale: 0.0045, emissive: 0x10120f,
  }));
  burlap.material = vertexEmissive(new THREE.MeshStandardMaterial({
    ...sackTex, vertexColors: true, roughness: 0.98, metalness: 0,
    bumpScale: 0.008, emissive: 0x100e09,
  }));
  hard.material = vertexEmissive(new THREE.MeshStandardMaterial({
    map: hard.material.map, vertexColors: true, roughness: 0.77, metalness: 0.06,
    emissive: 0x0b0c0b,
  }));
  // Materials are per-figure; texture caches belong to the shared character library.
  for (const mat of oldMaterials) mat.dispose();
  figure.setEyeGlint(0);
  polishedFigures.add(figure);
  return figure;
}

export function createAct2Killer() {
  const figure = createKiller();
  const combat = installPreviewPoses(figure);
  polishKillerAppearance(figure);
  const root = new THREE.Group();
  root.name = 'Act II — the man in the sack';
  root.add(figure.root);
  const clearance = createBoxClearance(figure);
  let lastState = null, stateTime = 0;
  const vertexCount = figure.meshes.reduce((n, m) => n + m.geometry.attributes.position.count, 0);
  const actor = {
    root,
    height: 2.3,
    vertexCount,
    figure,
    update(dt, state = {}) {
      const speed = Math.max(0, state.speed || 0);
      const mode = state.state || 'patrol';
      if (mode !== lastState) { stateTime = 0; lastState = mode; }
      stateTime += Math.max(0, dt);
      let phase = state.attackPhase || null, progress = state.attackProgress || 0;
      // The staged death vignette can still request an attack without simulation
      // fields. Live play passes the exact phase/progress and never uses this clock.
      if (!phase && (mode === 'attack' || mode === 'strike' || mode === 'windup') && stateTime < 1.24) {
        phase = stateTime < .62 ? 'windup' : stateTime < .82 ? 'strike' : 'recover';
        progress = phase === 'windup' ? stateTime / .62 : phase === 'strike' ? (stateTime - .62) / .2 : (stateTime - .82) / .42;
      }
      if (phase && !combat.phase) combat.begin();
      combat.phase = phase; combat.progress = progress;
      let anim = 'idle';
      if (phase) anim = 'previewAttack';
      else if (mode === 'stagger' || mode === 'staggered') anim = 'standStill';
      else if (speed > 0.1 || state.moving) anim = mode === 'chase' ? 'chase' : 'walk';
      else if (mode === 'inspect') anim = 'searchCloset';
      else if (mode === 'search') anim = 'lookAround';
      if (figure.anim !== anim) figure.setAnim(anim, { fade: 0.18 });
      if (phase) { figure.animator.fade = 1; figure.animator.prev = null; }
      // Staged films place him exactly; only live play (stabilizeStance) steps him off a wall.
      figure.root.position.set(0, 0, 0);
      // The adapter adds an outer transform above the original rig. Its arm IK reads
      // world-space joints; update that parent before the rig solves either hand.
      root.updateWorldMatrix(true, true);
      figure.update(dt, { speed });
      figure.root.rotation.x = 0;
      figure.root.rotation.z = 0;
      if (mode === 'stagger' || mode === 'staggered') {
        // He recoils and shields the sack. The fork stays in his right hand; he never falls dead.
        const recoil = Math.exp(-stateTime * 3.5);
        figure.root.rotation.z = Math.sin(stateTime * 5) * 0.035;
        figure.rig.b('head').rotation.x -= 0.16 + recoil * 0.3;
        figure.rig.b('head').rotation.z += Math.sin(stateTime * 7) * 0.055;
        figure.rig.b('uarmL').rotation.x = -1.95;
        figure.rig.b('uarmL').rotation.z = -0.34;
        figure.rig.b('farmL').rotation.x = -0.92;
      }
      root.userData.state = mode;
      root.userData.attackPhase = phase;
      root.userData.attackProgress = progress;
    },
    // The live loop calls this straight after update(); the films never do.
    // Before the feet are steadied, step the drawn figure off any structure
    // his fork or arm would otherwise stand inside. The cabin, doors, wardrobe
    // and other built boxes are always known; pass options.obstacles (the sim's
    // full list) to include tree trunks and sign posts as well.
    stabilizeStance(dt, options) {
      if (options?.enabled) clearance.apply(options.obstacles || OBSTACLES, !!root.userData.attackPhase);
      return figure.stabilizeStance?.(dt, options);
    },
    resetStance() { figure.resetStance?.(); },
    reset() {
      figure.resetStance?.(); clearance.reset();
      lastState = null; stateTime = 0;
      combat.phase = null; combat.progress = 0;
      figure.root.rotation.set(0, 0, 0);
      figure.setBloody(0); figure.setEyeGlint(0);
      figure.setAnim('idle', { restart: true, fade: 0.001 });
      figure.update(0.016, { speed: 0 });
    },
  };
  actor.reset();
  return actor;
}
