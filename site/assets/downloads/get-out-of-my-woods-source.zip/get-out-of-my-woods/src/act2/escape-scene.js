// The escape is a complete, deterministic scene: the same counselor gets in,
// drives out, and keeps driving along a public road at daybreak. A roadside cut
// stages the final visual pursuit without creating a new gameplay encounter.
import * as THREE from 'three';
import { Pose } from '../characters/rig.js';
import { audio as defaultAudio } from '../audio/index.js';
import { clearSegment } from './sim.js';

const clamp = x => Math.max(0, Math.min(1, x));
const smooth = (a, b, t) => { const x = clamp((t - a) / (b - a)); return x * x * (3 - 2 * x); };
const mix = (a, b, t) => a + (b - a) * t;
const V = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
export const ESCAPE_SCENE = Object.freeze({ duration:24, seated:3.35, ignition:5.65, depart:6, roadside:7.8, chase:10.5, interior:12.7, dawn:16.4, publicRoad:17.3, survived:22 });

// The first ten seconds of driving retain the already-reviewed chase path.
// At dawn, join the existing east-west County Road 12 and keep moving through
// the fade. Hermite tangents match the approach and the constant-speed turn.
const ROAD_SPEED = 6.6, ROAD_RADIUS = 6; // eastbound lane is z=-214, south of the centre stripe
const TURN_END = ESCAPE_SCENE.publicRoad + Math.PI * ROAD_RADIUS / (2 * ROAD_SPEED);
function hermite(a,b,va,vb,seconds,u) {
  return {position:(2*u**3-3*u**2+1)*a+(u**3-2*u**2+u)*seconds*va+(-2*u**3+3*u**2)*b+(u**3-u**2)*seconds*vb,
    speed:((6*u**2-6*u)*a+(3*u**2-4*u+1)*seconds*va+(-6*u**2+6*u)*b+(3*u**2-2*u)*seconds*vb)/seconds};
}
function drivePath(t) {
  const q = clamp((Math.min(t,16)-ESCAPE_SCENE.depart)/12.4),road = smooth(13.5,18.4,Math.min(t,16));
  const distance = 90*q*q*(3-2*q),offsetX = 2.8*road;
  const speed = t>6 ? 90*6*q*(1-q)/12.4 : 0,vanYaw = -.07*Math.sin(road*Math.PI);
  if(t<=16)return {distance,offsetX,speed,vanYaw};
  if(t<ESCAPE_SCENE.publicRoad) {
    const r=(16-13.5)/4.9,seconds=ESCAPE_SCENE.publicRoad-16,u=(t-16)/seconds;
    const x=hermite(offsetX,2.8,2.8*6*r*(1-r)/4.9,0,seconds,u);
    const z=hermite(distance,90,speed,ROAD_SPEED,seconds,u);
    return {distance:z.position,offsetX:x.position,speed:Math.hypot(x.speed,z.speed),
      vanYaw:mix(vanYaw,-Math.atan2(x.speed,z.speed),smooth(16,16.3,t))};
  }
  const angle=Math.min(Math.PI/2,(t-ESCAPE_SCENE.publicRoad)*ROAD_SPEED/ROAD_RADIUS);
  return {distance:90+ROAD_RADIUS*Math.sin(angle),
    offsetX:2.8+ROAD_RADIUS*(1-Math.cos(angle))+Math.max(0,t-TURN_END)*ROAD_SPEED,
    speed:ROAD_SPEED,vanYaw:-angle};
}

// Positions are relative to the parked van, so the scene follows layout changes.
export function sampleEscapeScene(time) {
  const t = Math.min(ESCAPE_SCENE.duration,Math.max(0,Number.isFinite(time)?time:0));
  const door = smooth(.4,1.1,t)*(1-smooth(3.35,3.8,t));
  const daylightCut = t<16 ? 1-smooth(15.4,16,t) : smooth(16,16.6,t);
  return {
    time:t, finished:t>=ESCAPE_SCENE.duration, duration:ESCAPE_SCENE.duration,
    stage:t<3.35?'boarding':t<6?'ignition':t<7.8?'departure':t<10.5?'roadside':t<12.7?'last-pursuit':t<16?'on-the-road':t<22?'daybreak':'survived',
    ...drivePath(t),door:-1.23*door,entry:smooth(1.65,3.35,t),exit:0,
    seated:t>=3.35,dawn:smooth(15.6,16.6,t),fade:daylightCut*(1-smooth(22.4,24,t)),
  };
}

// Authored movie marks, relative to the parked van. The body stays on the
// shoulder until the rear bumper has passed; only then does he turn onto the road.
// Absolute time keeps pause/refresh and sparse frames on the same path.
export function sampleEscapePursuit(time) {
  const t = Number.isFinite(time) ? time : 0;
  const path = at => {
    const rush = smooth(ESCAPE_SCENE.roadside,10.2,at);
    const turn = clamp((at-10.2)/.4);
    const chase = at<10.6 ? 4.6*.4*(turn**3-.5*turn**4) : 4.6*(at-10.4);
    return {x:mix(-6.4,-2.8,rush) + 2.3 * smooth(10.8,11.5,at),
      z:mix(-26,-21,rush) - chase};
  };
  const p=path(t),before=path(t-.001),after=path(t+.001);
  const dx=(after.x-before.x)/.002,dz=(after.z-before.z)/.002;
  return {...p,visible:t>=ESCAPE_SCENE.roadside && t<ESCAPE_SCENE.interior,
    yaw:t<10.6 ? mix(Math.atan2(3.6,5),Math.PI,smooth(9.95,10.6,t)) : Math.atan2(dx,dz),speed:Math.hypot(dx,dz)};
}

// Keep a pursuer's real start, bound his short final approach, and sweep the
// entire body against scenery. A distant or blocked killer stays distant.
export function escapeApproach(start, goal, obstacles = []) {
  const from = { x:start.x, z:start.z }, dx = goal.x - from.x, dz = goal.z - from.z, d = Math.hypot(dx, dz);
  if (d < 2.2 || d > 30) return from;
  const amount = Math.min(7, d - 2.2) / d, end = { x:from.x + dx * amount, z:from.z + dz * amount };
  let last = from;
  for (let i = 1; i <= 100; i++) {
    const next = { x:mix(from.x, end.x, i / 100), z:mix(from.z, end.z, i / 100) };
    if (!clearSegment(from, next, .42, obstacles)) break;
    last = next;
  }
  return last;
}

const snapshot = object => object ? { object, position:object.position.clone(), quaternion:object.quaternion.clone(), visible:object.visible } : null;
const restore = s => { if (s) { s.object.position.copy(s.position);s.object.quaternion.copy(s.quaternion);s.object.visible = s.visible; } };

export function createEscapeScene(app, { audio = defaultAudio } = {}) {
  let shot = null, engine = null;
  const props = app.world.escapeProps || {}, van = app.world.van;
  const cameraEnd = new THREE.Quaternion();
  const position = V(), target = V(), local = V(), seated = V(-.65, .08, -.72), outside = V(-2.15, 0, -.75);
  const headlamp = new THREE.SpotLight(0xffe2ab, 30, 49, .48, .65, 1.5);
  headlamp.position.set(0, 1.0, -2.8);headlamp.target.position.set(0, .2, -35);headlamp.visible = false;
  const rearGlow = new THREE.PointLight(0xd14831, 5, 22, 1.5);
  rearGlow.position.set(0,1.1,2.65);rearGlow.visible = false;
  van.add(headlamp, headlamp.target, rearGlow);
  const writePost = (name, value) => { if (app.post[name]) app.post[name].value = value; };
  const stopEngine = () => { engine?.stop(.3);engine = null; };
  const sound = (name, volume) => audio.sfx(name, { volume });
  const toWorld = (v, out = V()) => { van.updateMatrixWorld(true);return out.copy(v).applyMatrix4(van.matrixWorld); };
  const setHeadlights = visible => { for (const lens of props.headlights || []) lens.visible = visible; };
  setHeadlights(false);

  function reset() {
    stopEngine();headlamp.visible = false;rearGlow.visible = false;setHeadlights(false);
    if (!shot) return;
    for (const p of shot.props) restore(p);
    restore(shot.figure);restore(shot.killerFigure);
    Object.assign(shot.playerRef, shot.player);Object.assign(shot.killerRef, shot.killer);
    if (app.scene.background?.isColor && shot.background) app.scene.background.copy(shot.background);
    if (app.scene.fog && shot.fog) { app.scene.fog.color.copy(shot.fog.color);app.scene.fog.density = shot.fog.density; }
    for (const light of shot.lights) { light.object.color.copy(light.color);light.object.intensity = light.intensity;if (light.groundColor) light.object.groundColor.copy(light.groundColor); }
    app.camera.position.copy(shot.camera.position);app.camera.quaternion.copy(shot.camera.quaternion);app.camera.up.copy(shot.camera.up);app.camera.fov = shot.camera.fov;app.camera.updateProjectionMatrix();
    for (const [name, value] of Object.entries(shot.post)) writePost(name, value);
    app.figure.setFlashlight(shot.playerLight);app.figure.animator.apply(shot.from, 0, {});
    if (app.heldCrowbar) app.heldCrowbar.visible = shot.crowbar;
    if (app.flash) app.flash.visible = shot.flash;
    shot = null;
  }

  function begin() {
    reset();
    const actor = app.figure, p = app.sim.player, k = app.sim.killer;
    const from = new Pose(actor.rig.idx, actor.rig.bones.length), pose = new Pose(actor.rig.idx, actor.rig.bones.length), sit = new Pose(actor.rig.idx, actor.rig.bones.length);
    from.copy(actor.animator.prev && actor.animator.fade < 1 ? actor.animator.Q : actor.animator.P);
    const lights = [];
    app.world.root?.traverse(o => { if (o.isHemisphereLight || o.isDirectionalLight) lights.push({ object:o, color:o.color.clone(), intensity:o.intensity, groundColor:o.groundColor?.clone() }); });
    const start = van.position.clone();
    shot = { time:0, from, pose, sit, start, props:[van, props.driverDoor, ...(props.wheels || [])].filter(Boolean).map(snapshot),
      playerRef:p, killerRef:k, player:{x:p.x,z:p.z,yaw:p.yaw}, killer:{x:k.x,z:k.z,yaw:k.yaw}, figure:snapshot(actor.root), killerFigure:snapshot(app.killerFigure.root),
      camera:{position:app.camera.position.clone(),quaternion:app.camera.quaternion.clone(),up:app.camera.up.clone(),fov:app.camera.fov},
      background:app.scene.background?.isColor ? app.scene.background.clone() : null,
      fog:app.scene.fog ? {color:app.scene.fog.color.clone(),density:app.scene.fog.density} : null,
      lights, post:Object.fromEntries(['uLetterbox','uFade','uDanger','uRed','uFlash'].filter(n=>app.post[n]).map(n=>[n,app.post[n].value])),
      playerLight:actor._light, crowbar:app.heldCrowbar?.visible, flash:app.flash?.visible,
      approach:escapeApproach(k,{x:start.x-2.5,z:start.z},app.sim.obstacles || []), delay:k.state === 'stagger' ? Math.max(0,k.stagger || 0) : 0,
      cues:[],cueIndex:0,caption:'',captionEnd:0,
    };
    actor.setFlashlight(false);actor.root.visible = true;
    if (app.heldCrowbar) app.heldCrowbar.visible = false;
    if (app.flash) app.flash.visible = false;
    app.killerFigure.root.visible = !!k.active;
    writePost('uLetterbox',1);writePost('uDanger',0);writePost('uRed',0);writePost('uFlash',0);writePost('uFade',1);
    audio.setIntensity(0);audio.setRoom('outside');audio.music('finale');
    const caption = (text, seconds) => { shot.caption = text;shot.captionEnd = shot.time + seconds;app.say(text,seconds); };
    shot.cues = [
      [.15,()=>caption('The door. Get inside.',2.5)], [.55,()=>sound('car_door',.4)],
      [3.65,()=>sound('car_door',.58)], [3.8,()=>{sound('crank_fail',.52);caption('Come on. Come on…',2.1);audio.setRoom('car');}],
      [5.65,()=>{sound('engine_start',.6);engine = audio.loop('engine_rev',{volume:.35});caption('GO.',1.4);}],
      [6.1,()=>sound('tires_gravel',.55)],
      [7.8,()=>{audio.setRoom('outside');sound('branch_snap',.24);sound('stinger_near',.26);}],
      [8.35,()=>sound('killer_step',.28)], [8.8,()=>sound('killer_step',.3)],
      [9.25,()=>sound('killer_step',.32)], [9.7,()=>sound('killer_step',.32)],
      [10.25,()=>sound('killer_step',.29)], [10.65,()=>sound('killer_step',.25)],
      [11.05,()=>sound('killer_step',.2)], [11.45,()=>sound('killer_step',.15)],
      [11.85,()=>sound('killer_step',.1)], [12.25,()=>sound('killer_step',.06)],
      [12.7,()=>{audio.setRoom('car');sound('player_breath_fast',.28);}],
      [12.7,()=>caption('Keep your eyes on the road.',2.5)],
      [16.4,()=>{audio.music('dawn');audio.ambience('none');caption('Daybreak. County Road 12.',3.1);}],
      [19.3,()=>{audio.setRoom('outside');stopEngine();engine = audio.loop('engine_rev',{volume:.12});}],
      [21.8,()=>caption('You made it out.',2.2)], [24,()=>stopEngine()],
    ];
    render(0);return ESCAPE_SCENE.duration;
  }

  function fireCues() {
    while (shot.cueIndex < shot.cues.length && shot.time >= shot.cues[shot.cueIndex][0]) shot.cues[shot.cueIndex++][1]();
  }

  function poseCounselor(sample, dt) {
    const a = app.figure, t = sample.time, into = sample.entry;
    const walking = t < 1.65;
    a.setAnim(walking ? 'walk' : 'idle');a.update(Math.min(dt,.1), {speed:walking ? 1.3 : 0});
    const base = a.animator.prev && a.animator.fade < 1 ? a.animator.Q : a.animator.P;
    shot.sit.clear();
    const breath = Math.sin(t * (t < 16 ? 4.2 : 1.9)) * (t < 16 ? .018 : .009);
    shot.sit.rot('pelvis',-.04,0,0).rot('spine',.12+breath,0,0).rot('chest',.02,0,0);
    shot.sit.rot('thighL',-1.42,0,-.05).rot('thighR',-1.42,0,.05).rot('shinL',1.42,0,0).rot('shinR',1.42,0,0);
    shot.sit.rot('uarmL',-1.12,0,-.12).rot('uarmR',-1.12,0,.12).rot('farmL',-.5,0,0).rot('farmR',-.5,0,0);
    shot.sit.rot('head',-.05 + breath, t > 12.7 && t < 13.5 ? .2 : .015 * Math.sin(t),0);
    // Stay in the driving pose after boarding, including skip and long frames.
    // A subtle reduction in breathing is the release; she never opens the door.
    shot.pose.copy(base).lerp(shot.sit,into);
    if (t > .5 && t < 1.65) shot.pose.addRot('uarmR',-.6,0,.1);
    a.animator.apply(shot.pose,dt,{});
    if (t < 1.65) {
      toWorld(outside, target);position.copy(shot.figure.position).lerp(target,smooth(0,1.65,t));
      const dx = target.x-shot.figure.position.x,dz = target.z-shot.figure.position.z;
      a.root.rotation.y = Math.hypot(dx,dz) > .1 ? Math.atan2(dx,dz) : Math.PI/2;
    } else if (t < 3.35) {
      local.copy(outside).lerp(seated,into);local.y += Math.sin(into*Math.PI)*.16;toWorld(local,position);
      a.root.rotation.y = mix(Math.PI/2,Math.PI,into) + van.rotation.y;
    } else { toWorld(seated,position);a.root.rotation.y = Math.PI + van.rotation.y; }
    a.root.position.copy(position);a.root.visible = true;
    pSync(position,a.root.rotation.y);
  }
  function pSync(position,yaw) { const p = shot.playerRef;p.x = position.x;p.z = position.z;p.yaw = yaw; }

  function moveKiller(dt) {
    const k = shot.killerRef, t = shot.time;
    const f = app.killerFigure;
    if (t >= ESCAPE_SCENE.roadside) {
      const pursuit = sampleEscapePursuit(t);
      f.root.visible = pursuit.visible;
      if (pursuit.visible) {
        f.root.position.set(shot.start.x+pursuit.x,shot.start.y,shot.start.z+pursuit.z);
        f.root.rotation.y = pursuit.yaw;
        f.update(Math.min(dt,.1),{state:'chase',speed:pursuit.speed,moving:true});
      }
      return; // Visual staging only; never write this path into the live AI.
    }
    if (!k.active) return;
    const amount = clamp((Math.min(t,5.8) - shot.delay) / 5.8), before = {x:k.x,z:k.z};
    const desired = { x:mix(shot.killer.x,shot.approach.x,amount),z:mix(shot.killer.z,shot.approach.z,amount) };
    if (clearSegment(before,desired,.42,app.sim.obstacles || [])) { k.x = desired.x;k.z = desired.z; }
    const moved = Math.hypot(k.x-before.x,k.z-before.z);
    if (moved > .00001) k.yaw = Math.atan2(k.x-before.x,k.z-before.z);
    f.root.position.set(k.x,0,k.z);f.root.rotation.y = k.yaw;
    f.update(Math.min(dt,.1),{state:t < shot.delay ? 'stagger' : 'chase',speed:dt > 0 ? moved/dt : 0,moving:moved>.0001});
  }

  function render(dt) {
    if (!shot) return true;
    const s = sampleEscapeScene(shot.time), t = s.time;
    van.position.set(shot.start.x+s.offsetX,shot.start.y,shot.start.z-s.distance);van.rotation.y = s.vanYaw;
    if (props.driverDoor) props.driverDoor.rotation.y = s.door;
    for (const original of shot.props) if (props.wheels?.includes(original.object)) original.object.quaternion.copy(original.quaternion).multiply(new THREE.Quaternion().setFromAxisAngle(V(1,0,0),s.distance/.44));
    headlamp.visible = t >= 5.65 && t < ESCAPE_SCENE.duration;
    setHeadlights(t >= 5.65);
    rearGlow.visible = t >= ESCAPE_SCENE.roadside && t < ESCAPE_SCENE.interior;
    poseCounselor(s,dt);moveKiller(dt);
    if (shot.background && app.scene.background?.isColor) app.scene.background.copy(shot.background).lerp(new THREE.Color(0xa7b8ba),s.dawn);
    if (shot.fog && app.scene.fog) { app.scene.fog.color.copy(shot.fog.color).lerp(new THREE.Color(0xb5bcb4),s.dawn);app.scene.fog.density = mix(shot.fog.density,.0035,s.dawn); }
    for (const l of shot.lights) {
      l.object.color.copy(l.color).lerp(new THREE.Color(l.object.isHemisphereLight ? 0xd3ddd8 : 0xffd3a1),s.dawn);
      l.object.intensity = mix(l.intensity,l.object.isHemisphereLight ? 1.7 : 2.1,s.dawn);
      if (l.groundColor) l.object.groundColor.copy(l.groundColor).lerp(new THREE.Color(0x697357),s.dawn);
    }
    let fov = 53;
    if (t < 3.35) {
      toWorld(V(-5.3,2.3,2.2),position);toWorld(V(-.9,1.2,-.75),target);
      const w = smooth(0,.7,t);position.lerpVectors(shot.camera.position,position,w);
      app.camera.position.copy(position);app.camera.lookAt(target);cameraEnd.copy(app.camera.quaternion);app.camera.quaternion.copy(shot.camera.quaternion).slerp(cameraEnd,w);
    } else if (t < 6) {
      toWorld(V(-3.8,1.9,-2.25),position);toWorld(V(-.65,1.55,-.7),target);
      app.camera.position.copy(position);app.camera.lookAt(target);fov = 48;
    } else if (t < ESCAPE_SCENE.roadside) {
      position.set(shot.start.x-7,2.65,shot.start.z-18);toWorld(V(0,1.3,0),target);
      app.camera.position.copy(position);app.camera.lookAt(target);fov = 59;
    } else if (t < ESCAPE_SCENE.chase) {
      position.set(shot.start.x-7.8,2.1,shot.start.z-14);
      target.set(shot.start.x-2.1,1.15,shot.start.z-22);
      if(app.camera.aspect<1.2) { target.copy(app.killerFigure.root.position);target.y+=1.2; }
      app.camera.position.copy(position);app.camera.lookAt(target);fov = 58;
    } else if (t < ESCAPE_SCENE.interior) {
      // Alongside the van, looking back: its rear and the receding pursuer share
      // the frame. Keep the camera outside both the body and the running path.
      toWorld(V(-5,2.6,-4),position);
      target.copy(app.killerFigure.root.position);target.y += 1.2;
      app.camera.position.copy(position);app.camera.lookAt(target);fov = 62;
    } else if (t < 14) {
      toWorld(V(.72,1.74,-1.5),position);toWorld(V(-.65,1.52,-.73),target);
      app.camera.position.copy(position);app.camera.lookAt(target);fov = 62;
    } else if (t < 16) {
      // Above the wheel and behind the windshield, with a clear view of the exit.
      toWorld(V(-.52,2.05,-1.58),position);toWorld(V(-.4,1.15,-45),target);
      app.camera.position.copy(position);app.camera.lookAt(target);fov = 67;
    } else if (t < 19.3) {
      toWorld(V(-5.8,2.35,-5.8),position);toWorld(V(-.5,1.15,-.5),target);
      app.camera.position.copy(position);app.camera.lookAt(target);fov = 54;
    } else {
      // A held roadside view lets the van get smaller as it drives away. Its
      // heading follows the real crossroad rather than running off the scenery.
      position.set(shot.start.x-4,2.5,shot.start.z-101);
      target.copy(van.position);target.y += 1.15;
      app.camera.position.copy(position);app.camera.lookAt(target);fov = 50;
    }
    app.camera.up.set(0,1,0);app.camera.fov = fov;app.camera.updateProjectionMatrix();
    writePost('uFade',s.fade);writePost('uLetterbox',1);writePost('uDanger',0);writePost('uRed',0);writePost('uFlash',0);
    audio.setListener(app.camera.position.x,app.camera.position.y,app.camera.position.z,Math.atan2(target.x-app.camera.position.x,target.z-app.camera.position.z));
    return s.finished;
  }

  return {
    begin,reset,
    tick(dt) { if (!shot) return true;const step = Math.max(0,Number.isFinite(dt) ? dt : 0);shot.time = Math.min(ESCAPE_SCENE.duration,shot.time+step);fireCues();return render(step); },
    skip() { if (shot) { shot.time = ESCAPE_SCENE.duration;shot.cueIndex = shot.cues.length;stopEngine();audio.music('dawn');audio.ambience('none');render(0); }return true; },
    refresh() { if (shot) { render(0);if (shot.time < shot.captionEnd && shot.caption) app.say(shot.caption,shot.captionEnd-shot.time); } },
    get time() { return shot?.time || 0; },get duration() { return ESCAPE_SCENE.duration; },get stage() { return shot ? sampleEscapeScene(shot.time).stage : null; },
    dispose() { reset();headlamp.removeFromParent();headlamp.target.removeFromParent();rearGlow.removeFromParent(); },
  };
}
