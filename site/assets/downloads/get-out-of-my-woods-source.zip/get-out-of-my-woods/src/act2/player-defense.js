import * as THREE from 'three';

const clamp=v=>Math.max(0,Math.min(1,v));
const smooth=v=>{const t=clamp(v);return t*t*(3-2*t);};
const mix=(a,b,t)=>a+(b-a)*t;

// A visible hook and taped grip make this read as the tool from the cabin.
// Local -Y points out of the closed hand, matching the counselor rig.
export function createHeldCrowbar(){
  const root=new THREE.Group();root.name='Counselor crowbar';
  const metal=new THREE.MeshStandardMaterial({color:0x939f9c,metalness:.78,roughness:.38});
  const path=new THREE.CatmullRomCurve3([
    new THREE.Vector3(0,.16,0),new THREE.Vector3(0,-.35,0),
    new THREE.Vector3(0,-.52,0),new THREE.Vector3(-.055,-.63,0),
    new THREE.Vector3(-.15,-.66,0),new THREE.Vector3(-.22,-.60,0),
  ]);
  root.add(new THREE.Mesh(new THREE.TubeGeometry(path,24,.026,7,false),metal));
  const grip=new THREE.Mesh(new THREE.CylinderGeometry(.034,.034,.17,10),new THREE.MeshStandardMaterial({color:0x222b27,roughness:.96}));
  grip.position.y=.015;root.add(grip);
  const chisel=new THREE.Mesh(new THREE.BoxGeometry(.055,.10,.019),metal);chisel.position.set(-.22,-.59,0);chisel.rotation.z=-.45;root.add(chisel);
  const tip=new THREE.Object3D();tip.name='Crowbar contact marker';tip.position.set(-.22,-.62,0);root.add(tip);root.tip=tip;
  return root;
}

// Apply after locomotion. The body's world yaw belongs to the simulation, so
// backpedaling can never turn this follow-through away from its committed target.
export function poseCrowbarSwing(figure,progress){
  const p=clamp(progress),sweep=smooth(p/.58),settle=smooth((p-.58)/.42);
  const rig=figure.rig;
  const arm=rig.b('uarmL'),forearm=rig.b('farmL'),wrist=rig.b('handL');
  const baseArm=arm.rotation.clone(),baseForearm=forearm.rotation.clone(),baseWrist=wrist.rotation.clone();
  arm.rotation.set(mix(-1.42,baseArm.x,settle),mix(.18-1.18*sweep,baseArm.y,settle),mix(.12,baseArm.z,settle));
  forearm.rotation.set(mix(-.06-.36*sweep,baseForearm.x,settle),mix(.10,baseForearm.y,settle),mix(0,baseForearm.z,settle));
  wrist.rotation.set(mix(-.08,baseWrist.x,settle),mix(0,baseWrist.y,settle),mix(-.12,baseWrist.z,settle));
  // Small torso counter-rotation sells the swing without reversing her facing.
  rig.b('chest').rotation.y+=(.10-.26*sweep)*(1-settle);
  rig.b('head').rotation.y-=.08*(1-settle);
  figure.root.updateMatrixWorld(true);
}
