// Independent expanded chapter definition. Distances are metres; north is -Z.
// V3's map and cached terrain are deliberately not imported by this scene.
export const MAP = Object.freeze({ minX:-40, maxX:40, minZ:-138, maxZ:48 });
export const LOCATIONS = Object.freeze({
  start: {x:0,z:34}, crash:{x:0,z:41}, log:{x:0,z:45},
  cabin:{x:-12,z:3}, tent:{x:12,z:11},
  van:{x:0,z:-118}, vanDoor:{x:-2.5,z:-118}, keys:{x:5,z:-115}, weapon:{x:-13,z:4},
  killer:{x:-28,z:-8}, overlook:{x:21,z:-15},
  lowerCamp:{x:0,z:-28}, westBridge:{x:-20,z:-58}, eastBridge:{x:20,z:-58}, serviceYard:{x:-14,z:-82}, parking:{x:0,z:-108},
});
// Retain an AABB envelope for scenery placement; collision uses the local frame
// when yaw is present, so rotated props do not acquire oversized invisible corners.
export function orientedBox(id,x,z,width,depth,yaw,height) {
  const c=Math.abs(Math.cos(yaw)),s=Math.abs(Math.sin(yaw));
  const ex=c*width/2+s*depth/2,ez=s*width/2+c*depth/2;
  return {id,x,z,halfX:width/2,halfZ:depth/2,yaw,height,minX:x-ex,maxX:x+ex,minZ:z-ez,maxZ:z+ez};
}
export const OBSTACLES = [
  // Cabin has front and rear doors, with a genuine route through the room.
  {id:'cabin-west',minX:-18.2,maxX:-17.8,minZ:-2,maxZ:8},
  {id:'cabin-east',minX:-6.2,maxX:-5.8,minZ:-2,maxZ:8},
  {id:'cabin-front-west',minX:-18,maxX:-13.2,minZ:7.8,maxZ:8.2},
  {id:'cabin-front-east',minX:-10.8,maxX:-6,minZ:7.8,maxZ:8.2},
  {id:'cabin-back-west',minX:-18,maxX:-13.2,minZ:-2.2,maxZ:-1.8},
  {id:'cabin-back-east',minX:-10.8,maxX:-6,minZ:-2.2,maxZ:-1.8},
  {id:'cabin-bed',minX:-17.4,maxX:-15.8,minZ:0,maxZ:3.2,height:.85},
  {id:'tent',minX:10,maxX:14,minZ:8,maxZ:12},
  {id:'van',minX:-1.5,maxX:1.5,minZ:-121,maxZ:-115},
  {id:'car',minX:-1.2,maxX:1.2,minZ:39,maxZ:43},
  {id:'rock-west',minX:-25,maxX:-20,minZ:-22,maxZ:-14},
  {id:'rock-east',minX:8,maxX:12,minZ:-20,maxZ:-12},
  {id:'shed',minX:17,maxX:23,minZ:-34,maxZ:-29},
  orientedBox('road-log',0,45,8.6,1.7,.08,1.49),
  orientedBox('office-front-door',-13.35,8.9,.12,1.9,-.18,2.65),
  orientedBox('office-rear-door',-13.35,-2.9,.12,1.9,.18,2.65),
  {id:'office-desk',minX:-9.65,maxX:-6.95,minZ:5.25,maxZ:6.35,height:.91},
  {id:'camp-table',minX:14.35,maxX:15.65,minZ:15.475,maxZ:16.125,height:.85},
  {id:'wardrobe-back',minX:-6.715,maxX:-6.585,minZ:.2,maxZ:1.8,height:2.5},
  {id:'wardrobe-north',minX:-8,maxX:-6.6,minZ:.135,maxZ:.265,height:2.5},
  {id:'wardrobe-south',minX:-8,maxX:-6.6,minZ:1.735,maxZ:1.865,height:2.5},
  orientedBox('wardrobe-door',-7.9,.55,.12,1.35,-.5,2.4),
  {id:'lower-tent',minX:-25,maxX:-21,minZ:-93,maxZ:-89,height:2.3},
];
// Environment and collision share one footprint. Banks prevent wading across
// the creek; the two broad bridge corridors remain traversable in both directions.
export const EXPANSION_PROPS = [
  {id:'lower-camp-rock',type:'rock',x:0,z:-39,width:14,depth:7,height:3},
  {id:'creek-bank-west',type:'creek-bank',x:-31.5,z:-58,width:17,depth:6,height:1.2},
  {id:'creek-bank-center',type:'creek-bank',x:0,z:-58,width:34,depth:6,height:1.2},
  {id:'creek-bank-east',type:'creek-bank',x:31.5,z:-58,width:17,depth:6,height:1.2},
  {id:'service-building',type:'service-building',x:0,z:-80,width:16,depth:10,height:3.4},
  {id:'north-parking-rock',type:'rock',x:9,z:-98,width:10,depth:5,height:2.8},
  ...[-22.75,-17.25,17.25,22.75].map((x,i)=>({id:`bridge-rail-${i}`,type:'bridge-rail',x,z:-58,width:.18,depth:8,height:1.0})),
];
for(const p of EXPANSION_PROPS)OBSTACLES.push({id:p.id,minX:p.x-p.width/2,maxX:p.x+p.width/2,minZ:p.z-p.depth/2,maxZ:p.z+p.depth/2,height:p.height});
export const HIDE_SPOTS = [
  {id:'tent',name:'Canvas tent',x:12,z:13.2,radius:2.2,kind:'tent',view:{x:12.35,y:.95,z:10.6}},
  {id:'wardrobe',name:'Cabin wardrobe',x:-8.8,z:1.5,radius:1.25,kind:'wardrobe',view:{x:-7.2,y:1.6,z:1}},
  {id:'lower-tent',colliderId:'lower-tent',name:'Service canvas tent',x:-23,z:-87.8,radius:2.2,kind:'tent',view:{x:-22.65,y:.95,z:-90.4}},
];
// These are physical circuits, never live-player destinations. Region changes
// choose a circuit entrance; search/chase retain their own remembered positions.
export const PATROL = [{x:-12,z:10},{x:5,z:9},{x:19,z:-18},{x:5,z:-30},{x:-18,z:-34},{x:-12,z:-13}];
export const PATROL_CIRCUITS = [
  PATROL,
  [{x:-18,z:-34},{x:-20,z:-48},{x:-20,z:-67},{x:-14,z:-84},{x:14,z:-89},{x:20,z:-68},{x:20,z:-44},{x:5,z:-30}],
  [{x:-14,z:-84},{x:-28,z:-96},{x:-9,z:-108},{x:5,z:-112},{x:18,z:-105},{x:20,z:-89},{x:20,z:-68},{x:-14,z:-68}],
];
export const TRAILS = [
  [{x:0,z:45},{x:0,z:25},{x:0,z:10},{x:0,z:-10},{x:-2,z:-27},{x:0,z:-30}],
  [{x:0,z:14},{x:-12,z:12},{x:-12,z:8},{x:-12,z:-2},{x:-12,z:-13},{x:-2,z:-27}],
  [{x:2,z:20},{x:16,z:17},{x:20,z:3},{x:22,z:-16},{x:14,z:-25},{x:4,z:-30}],
  [{x:0,z:-30},{x:-13,z:-32},{x:-20,z:-44},{x:-20,z:-58},{x:-20,z:-68},{x:-14,z:-74},{x:-14,z:-86},{x:-9,z:-102},{x:0,z:-108}],
  [{x:0,z:-30},{x:12,z:-33},{x:20,z:-43},{x:20,z:-58},{x:20,z:-68},{x:14,z:-74},{x:14,z:-87},{x:20,z:-98},{x:15,z:-108},{x:0,z:-108}],
  [{x:-20,z:-68},{x:0,z:-68},{x:20,z:-68}],
  [{x:-14,z:-86},{x:-23,z:-87.8},{x:-27,z:-87.8},{x:-28,z:-96},{x:-9,z:-105},{x:0,z:-108}],
  [{x:-14,z:-89},{x:0,z:-91},{x:14,z:-89}],
  [{x:0,z:-108},{x:-3,z:-113},{x:-3,z:-122},{x:0,z:-129},{x:0,z:-138}],
  [{x:0,z:-108},{x:5,z:-113},{x:5,z:-120}],
];
// Optional evidence answers where to search next without adding a fetch chain.
export const INSPECT_SPOTS = [
  {id:'camp-map',name:'Read campground map',prop:'map',x:-14.8,z:6.2,radius:1.8,text:'NORTH PARKING. Beyond the lower camp and creek. Both bridges lead to the service yard.'},
  {id:'abandoned-bags',name:'Search abandoned bags',prop:'bags',x:-8,z:-30,radius:1.8,text:'A packed bag. A child’s shoe. Everyone was heading for the maintenance van, beyond the creek.'},
  {id:'creek-marker',name:'Read bridge sign',prop:'sign',x:-24,z:-50,radius:1.8,text:'FOOTBRIDGE / SERVICE CROSSING. Either bridge reaches the yard. Canvas shelter beside the west building.'},
  {id:'service-log',name:'Search service notice',prop:'notice',x:-11,z:-87,radius:1.8,text:'The van is in NORTH PARKING. Someone took the keys there. Follow the tire tracks beyond this yard.'},
];
export const ROUTE_LANDMARKS = [
  {id:'arrival',label:'CABIN LIGHT',x:-12,z:10,threshold:14,objective:'Find a way through the camp.'},
  {id:'camp',label:'LOWER CAMP',x:0,z:-28,threshold:-25,objective:'Explore the lower camp.',text:'Beyond the cabin, the trail continues into the lower camp.'},
  {id:'creek',label:'CREEK CROSSINGS',x:-20,z:-58,threshold:-65,objective:'Cross the creek.',text:'The creek cuts across the grounds. There is a crossing on either side.'},
  {id:'service',label:'SERVICE YARD',x:-14,z:-82,threshold:-90,objective:'Find the parking trail.',text:'The service buildings break his view. Follow the tracks toward north parking.'},
  {id:'parking',label:'NORTH PARKING',x:0,z:-108,threshold:-108,objective:'Find the maintenance van.',text:'Tire tracks lead beyond the last trees. The parking area is close.'},
  {id:'van',label:'VAN KEYS',x:5,z:-115,threshold:-Infinity,objective:'Search beside the van for keys.',text:'The van. Someone is lying beside it. Check their hand.'},
];
