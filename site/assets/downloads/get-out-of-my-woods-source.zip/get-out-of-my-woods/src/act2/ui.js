import { stickCenter, stickVector, stickLayout } from '../ui/thumbstick.js';
import { displayMode, displayHelp } from '../ui/display-mode.js';
import { createCompass } from '../ui/compass.js';
import { BRIGHTNESS_RANGE } from '../campaign/state.js';
import { resolveInputMode } from '../ui/input-mode.js';
import { controlRows, keyStrip, flashlightState, promptText } from '../ui/controls.js';

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function confirmCopy(cmd) {
  const tail = 'You will lose your progress since the crash. Your crash checkpoint stays.';
  if (cmd === 'retry') return `Restart at the crash? ${tail}`;
  if (cmd === 'home') return `Return to the title? ${tail}`;
  return '';
}

export function escapeAction({ mode, mapOpen = false, confirming = false } = {}) {
  if (confirming) return 'cancel-confirm';
  if (mode === 'settings' || mode === 'controls') return 'back';
  if (mapOpen) return 'close-bearings';
  if (mode === 'play' || mode === 'intro' || mode === 'death' || mode === 'escape') return 'pause';
  if (mode === 'pause') return 'resume';
  return 'ignore';
}

export function act2PromptText(prompt, hiddenKind, mode) {
  if (!prompt) return '';
  const hold = prompt.kind === 'keys';
  let label = prompt.text || '';
  if (prompt.kind === 'hide' && label === 'Hide in tent') label = 'Hide in tent · entrance';
  if (prompt.kind === 'leave') label = `Leave ${hiddenKind === 'tent' ? 'tent' : 'wardrobe'}`;
  if (hold) label = 'TAKE VAN KEYS';
  return promptText(mode, label.toUpperCase(), { hold });
}

const CSS = `
:root{color-scheme:dark;--paper:#faf6e9;--dim:#dae5dc;--red:#ffa78d;--line:#cbd8cd66}
*{box-sizing:border-box}button,input,select{font:inherit}button{cursor:pointer;touch-action:manipulation}button:focus-visible,input:focus-visible,select:focus-visible{outline:3px solid #ffe0a6;outline-offset:4px}
#v4-ui{position:fixed;inset:0;z-index:10;pointer-events:none;color:var(--paper);font:18px/1.5 Arial,sans-serif;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none}
#v4-ui [hidden]{display:none!important}#v4-ui button,#v4-ui input,#v4-ui select{pointer-events:auto}
.panel{position:absolute;inset:0;display:flex;align-items:flex-start;padding:max(28px,env(safe-area-inset-top)) max(6vw,env(safe-area-inset-right)) max(28px,env(safe-area-inset-bottom)) max(6vw,env(safe-area-inset-left));background:linear-gradient(90deg,#07110ff7,#07110fd9 43%,#07110f55 78%,transparent);pointer-events:auto;overflow:auto;overscroll-behavior:contain;touch-action:pan-y}
.panel-content{max-width:660px;min-width:0;margin-block:auto}
.eyebrow{font:500 16px/1.5 Oswald,sans-serif;text-transform:uppercase;letter-spacing:.16em;color:var(--dim);margin-bottom:16px}.red{color:var(--red)}
h1{font:400 clamp(56px,7vw,96px)/.97 Anton,sans-serif;letter-spacing:.005em;margin:0 0 20px;text-shadow:0 3px 25px #0008}
h2{font:500 38px/1.15 Oswald,sans-serif;margin:8px 0 20px}
.panel p{max-width:600px;color:var(--paper);font-size:21px;line-height:1.55;margin:16px 0}
.chapter{font:400 26px/1.35 Oswald,sans-serif;letter-spacing:.05em}
.button-row{display:flex;gap:12px;flex-wrap:wrap;margin-top:22px}
.btn{padding:13px 22px;border:1px solid #c8d7c888;background:#091914ed;color:var(--paper);letter-spacing:.04em;font:500 19px/1.4 Oswald,sans-serif;min-height:52px}
.btn.primary{background:var(--paper);color:#13251e;border-color:var(--paper)}.btn:hover{border-color:#fff}
.small,.panel .small{font:18px/1.55 Arial,sans-serif;color:var(--dim)}
.panel .controls-copy{font:19px/1.6 Arial,sans-serif;margin-top:22px;border-top:1px solid var(--line);padding-top:17px;color:var(--paper)}
.panel .title-mark{font:500 18px/1.5 Oswald,sans-serif;letter-spacing:.1em;color:var(--paper);border-top:1px solid var(--line);padding-top:14px;margin:20px 0 0}
.hud{position:absolute;inset:0;text-shadow:0 2px 4px #000,0 0 10px #000}
.topline{position:absolute;top:max(24px,env(safe-area-inset-top));left:max(28px,env(safe-area-inset-left));right:max(28px,env(safe-area-inset-right));display:flex;justify-content:space-between;align-items:flex-start;gap:18px}
.topline>div:first-child{min-width:0;max-width:470px;background:linear-gradient(90deg,#05110edb,#05110e00);padding:8px 12px;margin:-8px -12px}
.objective-label{font:500 14px/1.4 Oswald;letter-spacing:.12em;color:var(--dim)}
.objective{font:500 27px/1.25 Oswald;margin:6px 0}.top-buttons{display:flex;gap:7px;flex-shrink:0}
.icon-btn{background:#06100ded;color:var(--paper);border:1px solid #c5d4c977;min-height:48px;min-width:48px;padding:9px 14px;font:500 17px/1.4 Oswald;letter-spacing:.05em}
.stamina{width:170px;max-width:100%;height:4px;background:#bbd0bc55;margin-top:13px}.stamina i{display:block;width:100%;height:100%;background:#e5efce}
.pocket{color:#ffe1a7;font:500 16px/1.4 Oswald;letter-spacing:.04em;margin-top:9px}
#v4-ui .goomw-compass{position:relative;margin:8px 0 0 -6px}
.prompt{z-index:3;color:var(--paper);touch-action:none;position:absolute;left:50%;bottom:max(118px,calc(env(safe-area-inset-bottom) + 118px));transform:translateX(-50%);min-width:210px;width:max-content;max-width:76vw;text-align:center;background:#05130ff5;border:1px solid #e2e7caaa;padding:13px 22px;font:500 21px/1.4 Oswald;letter-spacing:.02em}
.prompt:hover{border-color:#ffe8b4;background:#14281ff5}.prompt:active{background:#31433a}.prompt i{display:block;height:3px;background:#ffe2b4;width:0%;margin-top:8px}
.caption{position:absolute;left:50%;bottom:29%;transform:translateX(-50%);width:min(680px,84vw);text-align:center;font:20px/1.5 'Special Elite',serif;text-shadow:0 2px 3px #000;background:#020a06dc;padding:10px 16px}
.status{position:absolute;left:calc(max(12px,env(safe-area-inset-left)) + 188px);bottom:28px;font:500 16px/1.4 Oswald;letter-spacing:.06em;color:var(--paper);background:#04110bbd;padding:4px 8px}.danger{color:#ffb29a}
.film-title{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;flex-direction:column;background:#03090633;text-align:center}.film-title h2{font:400 clamp(36px,6vw,72px) Anton;letter-spacing:.02em}.film-pause{position:absolute;bottom:max(22px,env(safe-area-inset-bottom));left:max(28px,env(safe-area-inset-left))}.film-skip{position:absolute;bottom:max(22px,env(safe-area-inset-bottom));right:max(28px,env(safe-area-inset-right))}
.touch-controls{position:absolute;inset:0;pointer-events:none}.stick-zone{position:absolute;z-index:1;bottom:max(12px,env(safe-area-inset-bottom));left:max(12px,env(safe-area-inset-left));width:min(176px,40vw);height:176px;pointer-events:auto;touch-action:none}
.stick-ring{position:absolute;box-sizing:border-box;width:128px;height:128px;top:50%;left:50%;margin:-64px 0 0 -64px;border:2px solid #efe6d68c;border-radius:50%;background:#08090c59;pointer-events:none}.stick-ring.is-active{border-color:#efe6d6;background:#08090c8c}.stick-knob{position:absolute;box-sizing:border-box;left:50%;top:50%;width:48px;height:48px;margin:-24px 0 0 -24px;border:2px solid #07080b;border-radius:50%;background:#efe6d6d9}.stick-label{position:absolute;bottom:0;width:100%;text-align:center;color:#dae5dc;font:18px/1.2 Oswald,Arial,sans-serif;letter-spacing:.1em;pointer-events:none}
.touch-actions{position:absolute;z-index:5;right:max(25px,env(safe-area-inset-right));bottom:max(28px,env(safe-area-inset-bottom));display:grid;grid-template-columns:64px 76px;gap:10px;align-items:center}
.touch-btn{background:#0a171bf2;color:var(--paper);border:1px solid #cedfce99;border-radius:50%;height:62px;font:500 16px/1.4 Oswald;letter-spacing:.02em;touch-action:none}.touch-btn.big{height:76px;background:#e6efdff5;color:#10201c}.touch-btn.active{background:#e6d8ac;color:#14231d}
.touch-help{position:absolute;right:30px;top:43%;font:500 15px/1.4 Oswald;letter-spacing:.07em;color:var(--paper);background:#04110bc9;padding:5px 8px}
.stamina-label{font:500 14px/1.4 Oswald;letter-spacing:.04em;color:var(--dim);margin-top:6px;max-width:310px}.stamina-label.recovering{color:#ffe0a6}
.desktop-controls{position:absolute;left:50%;bottom:max(20px,env(safe-area-inset-bottom));transform:translateX(-50%);display:flex;gap:9px;align-items:center}
.desktop-btn{min-height:48px;background:#071712f5;border:1px solid #c8dcc888;color:var(--paper);padding:10px 16px;font:500 17px/1.4 Oswald;letter-spacing:.03em;white-space:nowrap}
.desktop-btn kbd{font:500 15px/1.4 Oswald;border:1px solid #cddfd38c;border-radius:3px;padding:2px 5px;margin-left:8px;color:var(--paper)}.desktop-btn.active{background:#e1e5c8;color:#10201c}.desktop-btn.active kbd{border-color:#52644b;color:#10201c}.desktop-btn:disabled{color:#b6c4bd;background:#0b1715e8;border-color:#657c6c;cursor:default}
.hud.desktop .status{left:50%;right:auto;bottom:max(76px,calc(env(safe-area-inset-bottom) + 76px));transform:translateX(-50%);text-align:center;white-space:nowrap;max-width:none}
.hud.desktop .prompt{bottom:max(116px,calc(env(safe-area-inset-bottom) + 116px))}
.key-strip{position:absolute;left:max(16px,env(safe-area-inset-left));bottom:max(12px,env(safe-area-inset-bottom));max-width:min(340px,42vw);color:var(--paper);background:#04110bd9;padding:6px 8px;font:500 15px/1.45 Oswald,Arial,sans-serif;letter-spacing:.03em;pointer-events:none;z-index:2}
.desktop-hint{position:absolute;left:max(16px,env(safe-area-inset-left));bottom:max(108px,calc(env(safe-area-inset-bottom) + 108px));max-width:min(320px,36vw);color:var(--dim);font:500 15px/1.5 Oswald,Arial,sans-serif;letter-spacing:.04em;pointer-events:none;z-index:2}
.touch-btn.flashlight{width:max-content;max-width:none;height:62px;margin-left:0;justify-self:end;border-radius:31px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;padding:0 6px;line-height:1.15;position:relative;z-index:3}
.touch-btn.flashlight .light-name,.touch-btn.flashlight .light-state{font:500 16px/1.15 Oswald,Arial,sans-serif;letter-spacing:.04em}
.touch-btn.flashlight .light-name{white-space:nowrap}
@media(max-width:359px){.touch-btn.flashlight{width:64px;padding:0 2px;justify-self:stretch}.touch-btn.flashlight .light-name{white-space:normal}.touch-btn.flashlight .light-name,.touch-btn.flashlight .light-state{line-height:1.08}}
.pause-objective{font:500 24px/1.3 Oswald,sans-serif;margin:8px 0}.pause-destination{font:500 18px/1.4 Oswald,sans-serif;color:var(--paper);margin:0 0 12px}
.recent{margin:8px 0 16px;padding-left:18px;color:var(--paper);font-size:18px;line-height:1.45}
.controls-subhead{font:500 16px/1.4 Oswald,sans-serif;letter-spacing:.12em;color:var(--dim);margin:22px 0 0}
.controls-list{list-style:none;padding:0;margin:8px 0 4px}
.controls-list li{display:grid;grid-template-columns:minmax(120px,1fr) 1.3fr;gap:12px;padding:8px 0;border-bottom:1px solid var(--line);font-size:18px;line-height:1.4}
.controls-list .how{color:var(--paper)}
.map-card{position:absolute;z-index:4;top:118px;right:28px;width:min(360px,calc(100vw - 56px));max-height:calc(100dvh - 136px);padding:22px;background:#091613fa;border:1px solid #cbd8b999;pointer-events:auto;box-shadow:0 20px 60px #0005;display:flex;flex-direction:column;overflow:hidden}.map-heading,.map-direction,.map-live{flex:0 0 auto}.map-body{overflow:auto;min-height:0;flex:1 1 auto}.map-body.can-scroll{mask-image:linear-gradient(#000 calc(100% - 22px),transparent)}.map-more,.controls-more{margin:6px 0 0;font:500 16px/1.4 Oswald,sans-serif;letter-spacing:.08em;color:var(--paper)}.map-card>button{position:static;flex:0 0 auto;align-self:flex-start;margin-top:12px;background:#091613;box-shadow:none}
.panel.is-controls,.panel.is-settings{flex-direction:column;align-items:stretch;overflow:hidden}
.panel.is-controls .panel-content,.panel.is-settings .panel-content{display:flex;flex-direction:column;flex:1 1 auto;min-height:0;max-height:100%;width:100%;margin-block:0}
.controls-scroll,.settings-scroll{overflow:auto;min-height:0;flex:1 1 auto}
.controls-back,.settings-back{flex:0 0 auto;margin-top:8px;padding-top:8px;background:#07110ff5}.settings-back .button-row{margin-top:0}.settings-back .settings-status{margin:0 0 8px;color:var(--paper)}
.controls-more,.settings-more{flex:0 0 auto;display:inline-block;margin:6px 0 0;padding:2px 0;background:#07110fe6}
.map-heading{font:500 18px/1.4 Oswald;letter-spacing:.1em;color:#ffe1ac}.map-direction{display:flex;gap:18px;align-items:center;margin:15px 0}.map-arrow{font:400 43px Arial;line-height:1;display:inline-block;width:48px;text-align:center;transform-origin:center}.map-distance{font:500 26px Oswald}.map-card p{font:18px/1.5 Arial,sans-serif;color:var(--dim)}.map-card .map-live{color:var(--paper);margin-top:10px}
.study-panel{position:absolute;bottom:0;left:0;right:0;padding:32px max(5vw,env(safe-area-inset-left)) max(26px,env(safe-area-inset-bottom));background:linear-gradient(transparent,#03100df5 20%);display:flex;justify-content:space-between;gap:28px;align-items:flex-end}.study-panel h2{margin:6px 0 12px;font:500 34px/1.2 Oswald}.study-panel p{font:19px/1.5 Arial,sans-serif;color:var(--paper);max-width:660px;margin:0}.study-count{font:500 16px/1.4 Oswald;letter-spacing:.12em;color:#ffe0a6}.study-top{position:absolute;top:max(28px,env(safe-area-inset-top));left:5vw;right:5vw;display:flex;justify-content:space-between;align-items:center;gap:20px}.settings-grid{display:grid;gap:22px;margin:24px 0}.settings-grid label{display:grid;grid-template-columns:130px 1fr;align-items:center;gap:16px;color:var(--paper);font-size:20px}.settings-grid input,.settings-grid select{width:100%;min-width:0}.settings-grid select{color:var(--paper);background:#0a1914;border:1px solid #c8d7c888;padding:10px 12px;font-size:18px;min-height:48px}.settings-grid label{grid-template-columns:160px 1fr}.settings-note{grid-column:1/-1;margin:0}
@media(max-width:1180px){.desktop-hint{display:none}}
@media(max-width:860px){.study-panel{display:block}.study-panel .button-row{margin-top:18px}}
@media(max-width:600px){
  .panel{padding:24px}.panel h1{font-size:60px}.panel-content{max-width:100%}.panel p{font-size:19px}.panel .small{font-size:18px}.panel .controls-copy{font-size:18px;margin-top:20px}.panel .title-mark{font-size:18px}.eyebrow{font-size:15px;letter-spacing:.1em}.chapter{font-size:24px}.button-row{gap:10px;margin-top:18px}.btn{font-size:18px;padding:12px 18px}
  .topline{top:max(18px,env(safe-area-inset-top));left:20px;right:20px;gap:12px}.objective{font-size:23px}.objective-label{font-size:14px;letter-spacing:.07em}.top-buttons{gap:6px}.icon-btn{min-width:44px;padding:9px 10px;font-size:16px}.stamina-label{max-width:200px}.pocket{font-size:15px}
  .prompt{bottom:218px;font-size:20px;max-width:88vw}.caption{bottom:330px;font-size:18px}.touch-help{top:200px;right:20px}.status{left:20px;bottom:184px;font-size:14px}.map-card{right:20px;top:150px;max-height:calc(100dvh - 176px);overflow:hidden}.map-card p{font-size:17px}
  .desktop-controls{width:calc(100% - 32px);gap:6px}.desktop-btn{flex:1;padding:9px 6px;font-size:16px;white-space:normal}.desktop-btn kbd{display:block;font-size:14px;margin:4px 0 0}.hud.desktop .status{bottom:100px;font-size:14px;letter-spacing:.03em;max-width:calc(100% - 32px);white-space:normal}.hud.desktop .prompt{bottom:148px}
  .study-panel{padding:24px}.study-panel h2{font-size:28px}.study-panel p{font-size:18px}.study-top{left:24px;right:24px}.study-top .eyebrow{max-width:190px}.film-title h2{font-size:42px}.settings-grid label{grid-template-columns:105px 1fr;font-size:19px}
}
@media(max-height:520px){
  .panel{padding:24px 5vw}.panel h1{font-size:56px;margin-bottom:16px}.panel .eyebrow{margin-bottom:12px}.button-row{margin-top:18px}
  .touch-actions{bottom:15px}.topline{top:14px}.prompt{bottom:50px;max-width:43vw;min-width:170px}.caption{bottom:auto;top:68px;left:348px;right:auto;transform:none;width:min(300px,42vw);text-align:left;font-size:18px;padding:4px 8px}.status{left:calc(max(12px,env(safe-area-inset-left)) + 184px);bottom:8px;font-size:14px}.touch-help{top:8px;left:auto;right:calc(max(28px,env(safe-area-inset-right)) + 167px);font-size:14px;max-width:max(0px,calc(100vw - 543px))}.pocket{font-size:14px;margin-top:4px}
  #v4-ui .caption{width:min(640px,calc(100vw - 364px))}
  .study-panel{display:flex;padding-top:15px;gap:18px}.study-panel h2{font-size:26px}.study-panel p{font-size:17px;max-width:440px}.study-panel .button-row{flex-shrink:0;max-width:260px;gap:8px}.study-panel .btn{padding:10px 15px}.study-top{top:16px}
  .desktop-controls{bottom:12px}.hud.desktop .prompt{left:auto;right:max(16px,env(safe-area-inset-right));bottom:108px;transform:none;max-width:min(280px,36vw)}.hud.desktop .status{left:50%;right:auto;bottom:74px;transform:translateX(-50%);text-align:center;max-width:none;white-space:nowrap}.key-strip{bottom:78px;max-width:min(250px,32vw)}.desktop-hint{display:none}.map-card{top:64px;max-height:calc(100dvh - 76px);padding:12px 14px;overflow:hidden}.map-direction{margin:8px 0}.map-card .map-live{margin:4px 0 6px}
  .panel.is-pause{padding:12px 4vw;align-items:center;overflow:hidden}.panel.is-pause .panel-content{max-width:none;width:100%;margin-block:0}.panel.is-pause .pause-layout{display:flex;gap:16px;align-items:flex-start;justify-content:space-between}.panel.is-pause .pause-copy{flex:1 1 auto;min-width:0}.panel.is-pause .button-row{flex-direction:column;flex:0 0 auto;width:min(230px,34vw);margin-top:0;gap:6px}.panel.is-pause h2{margin:0 0 6px}.panel.is-pause .eyebrow{margin-bottom:4px}.panel.is-pause .pause-objective,.panel.is-pause .pause-destination{margin:2px 0}.panel.is-pause .recent{margin:4px 0 0}
}
@media(max-height:520px) and (max-width:649px){.touch-help{display:none}}
@media(max-width:639px){
  .panel.is-pause{padding:12px 16px;overflow:hidden}.panel.is-pause .pause-layout{display:flex;flex-direction:column}.panel.is-pause .button-row{order:-1;flex-direction:row;width:auto;margin:0 0 8px}.panel.is-pause h2{margin:2px 0 6px}.panel.is-pause .eyebrow{margin-bottom:4px}.panel.is-pause .pause-objective,.panel.is-pause .pause-destination{margin:2px 0}.panel.is-pause .recent{margin:4px 0 6px}
}
@media(max-height:520px) and (max-width:639px){
  .panel.is-pause .button-row{flex-direction:column;width:min(230px,70vw)}
}
@media(orientation:portrait) and (max-height:760px){.map-card{top:74px;max-height:calc(100dvh - 270px);padding:12px 14px}.map-direction{margin:8px 0}.map-card .map-live{margin:4px 0 6px}}
`;

export function createPreviewUI(callbacks) {
  const events=new AbortController();
  const listen=(target,type,handler,capture=false)=>target.addEventListener(type,handler,{signal:events.signal,capture});
  listen(window,'contextmenu',e=>e.preventDefault());
  const style=document.createElement('style');style.textContent=CSS;document.head.append(style);
  const root=document.createElement('div');root.id='v4-ui';document.body.append(root);
  let inputPref=callbacks.inputMode||'auto',hintsOn=callbacks.hints!==false,compassOn=callbacks.compass!==false,playerHidden=false,lightIsOn=false,lastPause={},controlsFrom='pause',confirming=null;
  const usingTouch=()=>resolveInputMode(inputPref)==='touch';
  root.innerHTML=`<section class="panel" id="panel"><div class="panel-content" id="panel-content"></div></section>
  <section class="hud" hidden><div class="topline"><div><div class="objective-label">ACT II · STILLWATER ANNEX</div><div class="objective">Find a way out.</div><div class="stamina" aria-label="Stamina"><i></i></div><div class="stamina-label">STAMINA</div><div class="pocket"></div></div><div class="top-buttons"><button class="icon-btn" data-cmd="map">BEARINGS</button><button class="icon-btn" data-cmd="pause" aria-label="Pause">Ⅱ</button></div></div><button type="button" class="prompt" data-input="action" hidden><span></span><i></i></button><div class="status"></div><div class="desktop-controls" hidden><button type="button" class="desktop-btn" data-input="run" aria-pressed="false" title="Click or press R to toggle run; hold Shift to run">RUN <kbd>R / SHIFT</kbd></button><button type="button" class="desktop-btn" data-input="light" aria-pressed="false">FLASHLIGHT: OFF <kbd>F</kbd></button><button type="button" class="desktop-btn" data-input="defend" disabled>NO CROWBAR</button></div><div class="key-strip" hidden></div><div class="desktop-hint" hidden>WASD MOVE · DRAG TO LOOK · CLICK PROMPTS OR PRESS E</div></section>
  <div class="caption" hidden></div><div class="film-title" hidden><div class="eyebrow">THE LONG WAY OUT</div><h2>THE ROAD ENDS HERE.</h2></div><button class="btn film-skip" data-cmd="skip" hidden>SKIP SCENE</button><button class="btn film-pause" data-cmd="pause" hidden>PAUSE</button>
  <div class="touch-controls" hidden><div class="stick-zone"><div class="stick-ring"><div class="stick-knob"></div></div><div class="stick-label">MOVE</div></div><div class="touch-help">DRAG RIGHT SIDE TO LOOK</div><div class="touch-actions"><button class="touch-btn flashlight" data-touch="light" data-input="light" aria-pressed="false" aria-label="FLASHLIGHT: OFF"><span class="light-name">FLASH<wbr>LIGHT</span><span class="light-state">OFF</span></button><button class="touch-btn big" data-touch="action" data-input="action">USE</button><button class="touch-btn" data-touch="run" data-input="run">RUN</button><button class="touch-btn" data-touch="defend" data-input="defend" aria-label="Swing crowbar">SWING</button></div></div>
  <aside class="map-card" hidden><div class="map-heading">BEARINGS · LIVE</div><div class="map-direction"><span class="map-arrow">↑</span><div><div class="map-distance"></div><div class="small map-destination">toward the camp</div></div></div><p class="map-live">The night keeps moving while this is open.</p><div class="map-body"><p>The arrow follows your view toward the next landmark. Signs and camp notices help you find a way through. Take another path when he sees you.</p></div><p class="map-more" hidden>More ↓</p><button class="icon-btn" data-cmd="map">CLOSE</button></aside>
  <div class="study-top" hidden><div class="eyebrow">V4 · ENGINE VISUAL STUDIES</div><button class="icon-btn" data-cmd="home">BACK</button></div><section class="study-panel" hidden><div><div class="study-count"></div><h2></h2><p></p></div><div class="button-row"><button class="btn" data-cmd="prev">←</button><button class="btn" data-cmd="next">NEXT STUDY →</button><button class="btn primary" data-cmd="start">PLAY</button></div></section>`;
  // The heading tape sits under the stamina line; its marker is the same landmark BEARINGS points at.
  const compass=createCompass(root.querySelector('.stamina-label'));root.querySelector('.stamina-label').after(compass.el);
  const q=s=>root.querySelector(s), keys=new Set(), actionPointers=new Set(), actionKeys=new Set(), captures=new Map();
  const input={strafe:0,forward:0,lookX:0,lookY:0,run:false,action:false,actionHeld:false,defend:false,light:false,quickTurn:false};
  let mode='title',stick=null,drag=null,stickX=0,stickY=0,runLatch=false,mapOpen=false;
  q('.hud').classList.toggle('desktop',!usingTouch());
  function syncRun(){
    const on=runLatch||keys.has('ShiftLeft')||keys.has('ShiftRight');
    for(const b of root.querySelectorAll('[data-input="run"]')){b.classList.toggle('active',on);b.setAttribute('aria-pressed',String(on));}
  }
  function updateActionHold(){input.actionHeld=actionPointers.size>0||actionKeys.size>0;}
  function capture(target,id){captures.set(id,target);try{target.setPointerCapture(id);}catch{}}
  function releaseCapture(id){const target=captures.get(id);captures.delete(id);try{target?.releasePointerCapture(id);}catch{}}
  const reset=()=>{
    keys.clear();actionPointers.clear();actionKeys.clear();stick=drag=null;stickX=stickY=0;runLatch=false;
    for(const k in input)input[k]=typeof input[k]==='number'?0:false;
    for(const id of [...captures.keys()])releaseCapture(id);
    q('.stick-knob').style.transform='';q('.stick-ring').classList.remove('is-active');syncRun();
  };
  function syncMapScroll(){const body=q('.map-body');if(!body)return;const more=body.scrollHeight>body.clientHeight+8;body.classList.toggle('can-scroll',more);const hint=q('.map-more');if(hint)hint.hidden=!more||q('.map-card').hidden;}
  const toggleMap=()=>{if(mode!=='play')return;mapOpen=!mapOpen;q('.map-card').hidden=!mapOpen;syncMapScroll();};
  const trigger=(kind)=>{
    if(mode!=='play')return;
    if(kind==='run'){runLatch=!runLatch;syncRun();}
    else if(kind==='action')input.action=true;
    else input[kind]=true;
  };
  const pointerCommands=new WeakSet();
  // Pause and Bearings act on finger-down, which changes what is under the finger. The click the
  // browser sends when that finger lifts belongs to the same press and must not reach the new
  // screen: on short landscape phones RESUME sits where the pause button was.
  let pressEcho=null;
  listen(root,'pointerdown',e=>{
    const b=e.target.closest('button');if(!b||b.disabled||mode!=='play'||e.button!==0)return;
    const cmd=b.dataset.cmd;if(cmd!=='map'&&cmd!=='pause')return;
    // A second touch may not synthesize a click while the movement finger is held.
    e.preventDefault();pointerCommands.add(b);pressEcho={id:e.pointerId,b,until:Infinity};
    if(cmd==='map')toggleMap();else callbacks.command(cmd);
  });
  // Only the first lift of that press opens the window, and any later press closes it: a mouse
  // keeps one pointer id, so a later click must never be taken for the echo.
  listen(window,'pointerdown',()=>{if(pressEcho&&pressEcho.until!==Infinity)pressEcho=null;},true);
  listen(window,'pointerup',e=>{if(pressEcho&&pressEcho.id===e.pointerId&&pressEcho.until===Infinity)pressEcho.until=performance.now()+600;},true);
  listen(window,'pointercancel',e=>{if(pressEcho&&pressEcho.id===e.pointerId)pressEcho=null;},true);
  // On window, not root: when the pressed button disappears, the browser sends the click to the page body.
  listen(window,'click',e=>{
    if(!pressEcho||e.detail===0)return;
    const echo=pressEcho;pressEcho=null;
    if(performance.now()>echo.until)return;
    pointerCommands.delete(echo.b);echo.b.blur?.();e.preventDefault();e.stopImmediatePropagation();
  },true);
  listen(root,'click',e=>{
    const b=e.target.closest('button');if(!b||b.disabled)return;
    if(b.dataset.input){
      // All game buttons act on press; keyboard/AT clicks without a pointer
      // gesture supply an additional activation path.
      if(e.detail===0)trigger(b.dataset.input);
    }else if(b.dataset.cmd){
      const pointerEcho=e.detail>0&&pointerCommands.delete(b);
      if(!pointerEcho){
        const cmd=b.dataset.cmd;
        if(cmd==='map')toggleMap();
        else if(cmd==='controls')showControls();
        else if(cmd==='controls-back')menu(controlsFrom==='title'?'title':'pause',lastPause);
        else if((cmd==='retry'||cmd==='home')&&mode==='pause')askConfirm(cmd);
        else if(cmd==='confirm-yes'){const next=confirming;confirming=null;if(next)callbacks.command(next);}
        else if(cmd==='confirm-no'){confirming=null;menu('pause',lastPause);}
        else callbacks.command(cmd);
      }
    }
    // A mouse click shouldn't leave an invisible focused control stealing Space
    // from the crowbar. Tab-focused controls retain ordinary keyboard behavior.
    if(e.detail>0)b.blur();
  });
  const canvas=document.querySelector('#game canvas');
  listen(canvas,'pointerdown',e=>{if(mode!=='play'||drag||e.button!==0)return;drag={id:e.pointerId,x:e.clientX,y:e.clientY};capture(canvas,e.pointerId);});
  const zone=q('.stick-zone'),ring=q('.stick-ring');
  let lastLayout=stickLayout(ring);
  function moveStick(e){const v=stickVector(e.clientX,e.clientY,stick,42);stickX=v.x;stickY=v.y;q('.stick-knob').style.transform=`translate(${v.knobX}px,${v.knobY}px)`;}
  listen(zone,'pointerdown',e=>{
    if(mode!=='play'||e.button!==0)return;e.preventDefault();
    if(stick)return;
    stick={id:e.pointerId,...stickCenter(ring)};lastLayout=stickLayout(ring);ring.classList.add('is-active');capture(zone,e.pointerId);moveStick(e);
  });
  listen(window,'pointermove',e=>{
    if(stick?.id===e.pointerId)moveStick(e);
    else if(drag?.id===e.pointerId){input.lookX+=e.clientX-drag.x;input.lookY+=e.clientY-drag.y;drag.x=e.clientX;drag.y=e.clientY;}
  });
  const release=e=>{
    actionPointers.delete(e.pointerId);updateActionHold();
    if(stick?.id===e.pointerId){stick=null;stickX=stickY=0;runLatch=false;q('.stick-knob').style.transform='';ring.classList.remove('is-active');syncRun();}
    if(drag?.id===e.pointerId)drag=null;
    releaseCapture(e.pointerId);
  };
  listen(window,'pointerup',release);listen(window,'pointercancel',release);listen(window,'lostpointercapture',release);
  for(const b of root.querySelectorAll('[data-input]')){
    listen(b,'pointerdown',e=>{
      if(mode!=='play'||b.disabled||e.button!==0)return;e.preventDefault();
      if(b.dataset.input==='action'){actionPointers.add(e.pointerId);updateActionHold();input.action=true;}
      else trigger(b.dataset.input);
      capture(b,e.pointerId);
    });
    if(b.dataset.input!=='action')continue;
    listen(b,'lostpointercapture',e=>{actionPointers.delete(e.pointerId);updateActionHold();});
    listen(b,'keydown',e=>{
      if(mode!=='play'||!['Space','Enter'].includes(e.code))return;
      e.preventDefault();if(!e.repeat)input.action=true;actionKeys.add(e.code);updateActionHold();
    });
    listen(b,'blur',()=>{actionKeys.clear();updateActionHold();});
  }
  listen(window,'keydown',e=>{
    if(e.code==='Escape'&&!e.repeat){onEscape();return;}
    if(e.target.matches('input,textarea,[contenteditable="true"]'))return;
    if(mode!=='play')return;
    // Let a keyboard-focused button use its normal Space/Enter activation. The
    // action prompt handles these as a hold; movement/Shift still work on focus.
    if(e.target.closest('button')&&['Space','Enter'].includes(e.code))return;
    if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();
    keys.add(e.code);syncRun();
    if(!e.repeat){if(e.code==='KeyE')input.action=true;if(e.code==='Space')input.defend=true;if(e.code==='KeyF')input.light=true;if(e.code==='KeyQ')input.quickTurn=true;if(e.code==='KeyR')trigger('run');if(e.code==='KeyM')toggleMap();}
  });
  listen(window,'keyup',e=>{keys.delete(e.code);actionKeys.delete(e.code);updateActionHold();syncRun();});
  listen(window,'blur',reset);
  function onLayoutChange(){const layout=stickLayout(ring);if(layout!==lastLayout)reset();lastLayout=layout;syncMapScroll();fitPause();syncControlsScroll();syncSettingsScroll();}
  listen(window,'resize',onLayoutChange);if(window.visualViewport)listen(window.visualViewport,'resize',onLayoutChange);
  listen(q('#panel'),'scroll',()=>{if(mode==='controls')syncControlsScroll();if(mode==='settings')syncSettingsScroll();});
  function onEscape(){
    const action=escapeAction({mode,mapOpen,confirming:!!confirming});
    if(action==='ignore')return;
    if(action!=='close-bearings')reset();
    if(action==='cancel-confirm'){confirming=null;menu('pause',lastPause);return;}
    if(action==='back'){if(mode==='controls')menu(controlsFrom==='title'?'title':'pause',lastPause);else callbacks.command('back');return;}
    if(action==='close-bearings'){mapOpen=false;q('.map-card').hidden=true;return;}
    if(action==='pause')callbacks.command('pause');
    if(action==='resume')callbacks.command('resume');
  }
  function askConfirm(cmd){
    confirming=cmd;
    setMode('confirm');
    const yes=cmd==='retry'?'RESTART AT CRASH':'TITLE';
    q('#panel-content').innerHTML=`<div class="eyebrow">STILLWATER ANNEX</div><h2>Are you sure?</h2><p>${esc(confirmCopy(cmd))}</p><div class="button-row"><button class="btn primary" data-cmd="confirm-yes">${yes}</button><button class="btn" data-cmd="confirm-no">BACK</button></div>`;
  }
  function syncHints(){
    const show=mode==='play'&&!usingTouch()&&hintsOn&&!playerHidden;
    q('.key-strip').hidden=!show;
    // The key strip replaced the older one-line legend; one set of key reminders, as in Act I.
    const hint=q('.desktop-hint');if(hint)hint.hidden=true;
  }
  function fitPause(){
    if(mode!=='pause')return;
    const panel=q('#panel');if(!panel||panel.clientHeight<40)return;
    const items=[...panel.querySelectorAll('.recent li')];
    for(const li of items)li.hidden=false;
    const fits=()=>{
      if(panel.scrollHeight>panel.clientHeight+2)return false;
      return [...panel.querySelectorAll('.button-row .btn')].every((b)=>{
        const r=b.getBoundingClientRect();
        return r.height>8&&r.top>=-1&&r.bottom<=innerHeight+1&&r.left>=-1&&r.right<=innerWidth+1;
      });
    };
    for(let i=items.length-1;i>=0&&!fits();i--)items[i].hidden=true;
  }
  function syncScrollCue(which){
    const more=q(which==='settings'?'.settings-more':'.controls-more');
    if(!more||mode!==which)return;
    const scroller=q(which==='settings'?'.settings-scroll':'.controls-scroll')||q('#panel');
    const scrolls=scroller.scrollHeight>scroller.clientHeight+8;
    const atEnd=scroller.scrollTop+scroller.clientHeight>=scroller.scrollHeight-12;
    more.hidden=!scrolls||atEnd;
    scroller.classList.toggle('can-scroll',scrolls&&!atEnd);
  }
  function syncControlsScroll(){syncScrollCue('controls');}
  function syncSettingsScroll(){syncScrollCue('settings');}
  function setMode(next){
    if(next!=='confirm')confirming=null;
    mode=next;reset();q('#panel').scrollTop=0;mapOpen=false;q('.map-card').hidden=true;
    q('#panel').classList.toggle('is-pause',mode==='pause');
    q('#panel').classList.toggle('is-controls',mode==='controls');
    q('#panel').classList.toggle('is-settings',mode==='settings');
    q('#panel').hidden=!['title','pause','dead','won','settings','controls','confirm'].includes(mode);
    q('.hud').hidden=mode!=='play';q('.touch-controls').hidden=mode!=='play'||!usingTouch();
    q('.desktop-controls').hidden=mode!=='play'||usingTouch();
    syncHints();
    q('.study-top').hidden=q('.study-panel').hidden=mode!=='study';
    q('.film-skip').hidden=q('.film-pause').hidden=!['intro','death','escape'].includes(mode);q('.film-title').hidden=true;q('.caption').hidden=true;
  }
  function controlBlock(rows){return `<ul class="controls-list">${rows.map((r)=>`<li><span>${esc(r.does)}</span><span class="how">${esc(r.how)}</span></li>`).join('')}</ul>`;}
  function showControls(){
    controlsFrom=mode==='title'?'title':'pause';
    const active=usingTouch()?'touch':'keyboard',other=active==='touch'?'keyboard':'touch';
    const head=(m)=>m==='touch'?'TOUCH':'KEYBOARD & MOUSE';
    setMode('controls');
    q('#panel-content').innerHTML=`<div class="controls-scroll"><div class="eyebrow">STILLWATER ANNEX</div><h2>CONTROLS</h2><h3 class="controls-subhead">${head(active)}</h3>${controlBlock(controlRows(2,active))}<h3 class="controls-subhead">${head(other)}</h3>${controlBlock(controlRows(2,other))}</div><p class="controls-more" hidden>More ↓</p><div class="button-row controls-back"><button class="btn primary" data-cmd="controls-back">BACK</button></div>`;
    q('.controls-scroll').addEventListener('scroll',()=>syncControlsScroll(),{signal:events.signal});
    syncControlsScroll();
  }
  function menu(kind,detail=''){
    setMode(kind);let html='';
    if(kind==='pause'&&detail&&typeof detail==='object')lastPause=detail;
    const pauseInfo=lastPause||{};
    if(kind==='title')html=`<div class="eyebrow">SURVIVAL HORROR</div><h1>GET OUT OF<br>MY WOODS</h1><div class="chapter">ACT II · THE ROAD ENDS HERE</div><p>You made it through the gate.<br>Someone knew which road you would take.</p><div class="button-row"><button class="btn primary" data-cmd="start">ENTER THE WOODS →</button>${callbacks.campaign?'':'<button class="btn" data-cmd="studies">VISUAL STUDIES</button>'}<button class="btn" data-cmd="settings">SETTINGS</button><button class="btn" data-cmd="controls">CONTROLS</button></div><p class="controls-copy">${usingTouch()?'Use the left circle to move. Drag the picture to look. RUN, USE, FLASHLIGHT and SWING are on the right.':keyStrip(2)}</p><p class="small">The second chapter of the complete journey. Headphones recommended.<br>Contains pursuit, violence, and sudden loud sounds.</p><p class="title-mark">A GAME BY GRANT WILLIAMS</p>`;
    if(kind==='pause'){const recent=(pauseInfo.recent||[]).slice(0,4).map((t)=>`<li>${esc(t)}</li>`).join('');const where=pauseInfo.destination?`<p class="pause-destination">${esc(pauseInfo.destination)}${pauseInfo.distance==null?'':` · ${pauseInfo.distance} m`}</p>`:'';html=`<div class="pause-layout"><div class="pause-copy"><div class="eyebrow">STILLWATER ANNEX</div><h2>Take a breath.</h2><p class="pause-objective">${esc(pauseInfo.objective||'Find a way out.')}</p>${where}${recent?`<ul class="recent">${recent}</ul>`:''}</div><div class="button-row"><button class="btn primary" data-cmd="resume">RESUME</button><button class="btn" data-cmd="controls">CONTROLS</button><button class="btn" data-cmd="settings">SETTINGS</button><button class="btn" data-cmd="retry">RESTART AT CRASH</button><button class="btn" data-cmd="home">TITLE</button></div></div>`;}
    if(kind==='dead')html=`<div class="eyebrow red">YOU WERE FOUND</div><h2>The woods kept you.</h2><p>${detail || 'Break his line of sight before you hide. The cabin has two exits.'}</p><div class="button-row"><button class="btn primary" data-cmd="retry">TRY AGAIN · AT THE CRASH</button><button class="btn" data-cmd="home">TITLE</button></div><p class="small">Your next attempt begins here. No need to replay Act I.</p>`;
    if(kind==='won')html=`<div class="eyebrow">YOU SURVIVED</div><h2>You made it out.</h2><p>First light. The road carries you away.<br>You are alive.</p><p class="small">${detail}</p><div class="button-row">${callbacks.campaign?'<button class="btn primary" data-cmd="newgame">PLAY FROM BEGINNING</button><button class="btn" data-cmd="retry">REPLAY FROM CRASH</button>':'<button class="btn primary" data-cmd="retry">PLAY AGAIN</button>'}<button class="btn" data-cmd="home">TITLE</button></div><p class="title-mark">A GAME BY GRANT WILLIAMS</p>`;
    q('#panel-content').innerHTML=html;
    if(kind==='pause')fitPause();
  }
  function settings(values){
    setMode('settings');
    const choice=(id,label,options)=>`<label>${label}<select id="${id}" aria-label="${label}">${options.map(([value,text])=>`<option value="${value}"${String(values[id])===String(value)?' selected':''}>${text}</option>`).join('')}</select></label>`;
    q('#panel-content').innerHTML=`<div class="settings-scroll"><div class="eyebrow">PICTURE & SOUND</div><h2>SETTINGS</h2><div class="settings-grid">
      <label>Brightness<input id="brightness" aria-label="Brightness" type="range" min="${BRIGHTNESS_RANGE.min}" max="${BRIGHTNESS_RANGE.max}" step="${BRIGHTNESS_RANGE.step}" value="${values.brightness}"></label>
      <label>Sound<input id="volume" aria-label="Sound" type="range" min="0" max="1" step="0.05" value="${values.volume}"></label>
      <label>Your footsteps<input id="steps" aria-label="Your footsteps" type="range" min="0" max="1" step="0.05" value="${values.steps??.45}"></label>
      <label>Rain and wind<input id="weather" aria-label="Rain and wind" type="range" min="0" max="1" step="0.05" value="${values.weather??.7}"></label>
      <p class="small settings-note">Changes what you hear, not what he hears. His footsteps stay audible.</p>
      ${choice('picture','Picture',[['sharp','Clean'],['retro','Retro']])}
      ${choice('tape','Tape effect',[[false,'Off'],[true,'On']])}
      ${choice('flashes','Flashes',[['full','Full'],['reduced','Reduced']])}
      ${choice('inputMode','Controls shown',[['auto','Automatic'],['keyboard','Keyboard & mouse'],['touch','Touch']])}
      ${choice('hints','Control hints',[[true,'On'],[false,'Off']])}
      ${choice('compass','Compass',[[true,'On'],[false,'Off']])}
      </div>
      <p class="small">TEST SOUND plays three notes at your selected volume.</p>
      <p class="small">Settings apply to both chapters. Private browsing may forget them after you close the session.</p>
      <h3>FULL SCREEN</h3><div class="display-help">${displayHelp()}</div></div>
      <p class="settings-more" hidden>More ↓</p>
      <div class="settings-back"><p class="small settings-status" id="settings-status" role="status" hidden></p><div class="button-row"><button class="btn" data-cmd="soundcheck">TEST SOUND</button>${displayMode()==='native'?'<button class="btn" data-cmd="fullscreen">FULLSCREEN</button>':''}<button class="btn primary" data-cmd="back">BACK</button></div></div>`;
    q('.settings-scroll').addEventListener('scroll',()=>syncSettingsScroll(),{signal:events.signal});
    syncSettingsScroll();
    for(const id of ['brightness','volume','steps','weather'])q('#'+id).addEventListener('input',e=>callbacks.setting(id,Number(e.target.value)));
    for(const id of ['picture','tape','flashes','inputMode','hints','compass'])q('#'+id).addEventListener('change',e=>callbacks.setting(id,id==='tape'||id==='hints'||id==='compass'?e.target.value==='true':e.target.value));
  }
  function paintLight(on){
    lightIsOn=!!on;const state=flashlightState(lightIsOn);
    const touchBtn=q('[data-touch="light"]');
    if(touchBtn){touchBtn.setAttribute('aria-pressed',String(lightIsOn));touchBtn.setAttribute('aria-label',state.text);const name=touchBtn.querySelector('.light-name'),line=touchBtn.querySelector('.light-state');if(name&&name.textContent!==state.label)name.textContent=state.label;if(line)line.textContent=state.state;}
    const desk=q('.desktop-controls [data-input="light"]');
    if(desk){const html=`${state.text} <kbd>F</kbd>`;if(desk.innerHTML!==html)desk.innerHTML=html;desk.setAttribute('aria-pressed',String(lightIsOn));}
    const strip=q('.key-strip');if(strip&&!strip.hidden){const text=`${keyStrip(2)} · ${state.text}`;if(strip.textContent!==text)strip.textContent=text;}
  }
  function applyInput(values={}){
    inputPref=values.inputMode||'auto';hintsOn=values.hints!==false;compassOn=values.compass!==false;if(!compassOn)compass.set(null);
    q('.hud').classList.toggle('desktop',!usingTouch());
    if(mode==='play'){q('.touch-controls').hidden=!usingTouch();q('.desktop-controls').hidden=usingTouch();syncHints();paintLight(lightIsOn);}
  }
  return {root,reset,setMode,menu,settings,applyInput,showControls,displayStatus(text){const el=q('#settings-status');if(el){el.textContent=text;el.hidden=!text;}},dispose(){reset();events.abort();root.remove();style.remove();},get mode(){return mode;},get mapOpen(){return mapOpen;},get touch(){return usingTouch();},
    read(){const v={...input,strafe:stickX+(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0),forward:stickY+(keys.has('KeyW')||keys.has('ArrowUp')?1:0)-(keys.has('KeyS')||keys.has('ArrowDown')?1:0),run:runLatch||keys.has('ShiftLeft')||keys.has('ShiftRight'),sneak:keys.has('KeyC'),actionHeld:input.actionHeld||keys.has('KeyE')};input.lookX=input.lookY=0;input.action=input.defend=input.light=input.quickTurn=false;return v;},
    soundCheck(text){const el=q('#settings-status');if(el){el.textContent=text;el.hidden=!text;}},
    caption(text){q('.caption').textContent=text;q('.caption').hidden=!text;},filmTitle(text){q('.film-title h2').textContent=text;q('.film-title').hidden=!text;},
    hud(sim,yaw,lightOn=lightIsOn){
      const p=sim.player,stamina=Math.round(Math.max(0,Math.min(1,p.stamina))*100);
      playerHidden=!!p.hidden;
      q('.objective').textContent=sim.objective || (sim.keys?'Get to the van.':'Find a way through the camp.');
      q('.stamina i').style.width=stamina+'%';
      const recovering=!!p.winded||p.gait==='jog';
      q('.stamina-label').textContent=recovering?(p.runRequested?'CATCHING BREATH · RUN RESUMES':'CATCHING BREATH'):p.gait==='sprint'||p.run?`RUNNING · STAMINA ${stamina}%`:`STAMINA ${stamina}%${usingTouch()?'':' · SHIFT / R TO RUN'}`;
      q('.stamina-label').classList.toggle('recovering',recovering);
      q('.pocket').textContent=[sim.keys?'VAN KEYS':'',sim.weapon==='ready'?'CROWBAR · HIT STUNS 4s':sim.weapon==='spent'?'CROWBAR USED UP':''].filter(Boolean).join('  /  ');
      const prompt=q('.prompt');prompt.hidden=!sim.prompt;
      const text=act2PromptText(sim.prompt,p.hidden?.kind,usingTouch()?'touch':'keyboard');
      q('.prompt span').textContent=text;q('.prompt i').style.width=((sim.prompt?.progress||0)*100)+'%';
      prompt.setAttribute('aria-label',text);
      const danger=['chase','attack','check-hide','stagger'].includes(sim.killer.state);
      q('.status').textContent=p.hidden?(sim.killer.state==='check-hide'?'HE SAW YOU':'HIDDEN'):sim.killer.state==='stagger'?'HE IS DOWN. RUN.':danger?'HE IS CLOSE. KEEP MOVING.':sim.killer.state==='search'?'STAY QUIET.':'STILLWATER PRIVATE CAMPGROUND';
      q('.status').classList.toggle('danger',danger);
      const nav=sim.navigation || {x:0,z:0,label:'the camp'};
      compass.set(compassOn&&mode==='play'&&!p.hidden?{yaw,x:p.x,z:p.z,target:sim.navigation}:null);
      q('.map-destination').textContent=nav.label;const dx=nav.x-p.x,dz=nav.z-p.z;q('.map-arrow').style.transform=`rotate(${(yaw-Math.atan2(dx,dz))*180/Math.PI}deg)`;q('.map-distance').textContent=Math.round(Math.hypot(dx,dz))+' m';
      const ready=sim.weapon==='ready',defend=q('.desktop-controls [data-input="defend"]');
      defend.disabled=!ready;const weaponLabel=ready?'SWING CROWBAR <kbd>SPACE</kbd>':sim.weapon==='spent'?'CROWBAR USED UP':'NO CROWBAR';if(defend.innerHTML!==weaponLabel)defend.innerHTML=weaponLabel;
      defend.title=ready?'Face him, then swing when he is close. A hit stuns him for four seconds and uses the crowbar up. A miss does not.':'Find the crowbar inside the cabin.';
      q('[data-touch="defend"]').hidden=!ready;syncRun();syncHints();paintLight(lightOn);syncMapScroll();
    },
    study(shot,index,total){setMode('study');q('.study-count').textContent=String(index+1).padStart(2,'0')+' / '+String(total).padStart(2,'0');q('.study-panel h2').textContent=shot.title;q('.study-panel p').textContent=shot.caption;},
  };
}
