import { MAP, LOCATIONS, OBSTACLES, HIDE_SPOTS, PATROL_CIRCUITS, INSPECT_SPOTS, ROUTE_LANDMARKS } from './layout.js';

const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const distance = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const facing = (yaw) => ({ x: Math.sin(yaw), z: Math.cos(yaw) });
const copy = (p) => ({ x: p.x, z: p.z });
const PLAYER_RADIUS = .32;
const KILLER_RADIUS = .42;
const GRID = .8;
const BODY_SEPARATION = .8;
export const ATTACK_TIMING = Object.freeze({windup:.62,strike:.20,recover:.42,contact:.60,reach:1.8});
export const DEFENSE_TIMING = Object.freeze({duration:.5,cooldown:.55,stagger:4,reach:3,assistCone:Math.PI/3,maxAssist:25*Math.PI/180});
export const ACT2_DIFFICULTY = Object.freeze({
  relaxed: Object.freeze({sense:.75,memory:2,searchTime:7,chase:2.45}),
  standard: Object.freeze({sense:1,memory:3.2,searchTime:10,chase:3.15}),
  hard: Object.freeze({sense:1.15,memory:4,searchTime:12,chase:3.55}),
});

// Segment / expanded AABB intersection. Expansion also lets navigation ask whether
// a whole body fits along a segment, rather than casting only a centre ray.
function hitsBox(a, b, o, radius = 0) {
  if (Number.isFinite(o.yaw)) {
    a=obstacleLocalPoint(o,a.x,a.z); b=obstacleLocalPoint(o,b.x,b.z);
    o={minX:-o.halfX,maxX:o.halfX,minZ:-o.halfZ,maxZ:o.halfZ};
  }
  let lo = 0, hi = 1;
  for (const axis of ['x', 'z']) {
    const min = o[axis === 'x' ? 'minX' : 'minZ'] - radius;
    const max = o[axis === 'x' ? 'maxX' : 'maxZ'] + radius;
    const delta = b[axis] - a[axis];
    if (Math.abs(delta) < 1e-9) {
      if (a[axis] < min || a[axis] > max) return false;
    } else {
      const t1 = (min - a[axis]) / delta, t2 = (max - a[axis]) / delta;
      lo = Math.max(lo, Math.min(t1, t2));
      hi = Math.min(hi, Math.max(t1, t2));
      if (lo > hi) return false;
    }
  }
  return hi >= 0 && lo <= 1;
}

function obstacleLocalPoint(o,x,z) {
  const c=Math.cos(o.yaw),s=Math.sin(o.yaw),dx=x-o.x,dz=z-o.z;
  return {x:c*dx-s*dz,z:s*dx+c*dz};
}

export function obstacleContainsPoint(o,x,z,radius=0) {
  if (Number.isFinite(o.yaw)) {
    const p=obstacleLocalPoint(o,x,z);
    return Math.abs(p.x)<=o.halfX+radius && Math.abs(p.z)<=o.halfZ+radius;
  }
  return x>=o.minX-radius && x<=o.maxX+radius && z>=o.minZ-radius && z<=o.maxZ+radius;
}

export function clearSegment(a, b, radius = 0, obstacles = OBSTACLES) {
  return !obstacles.some((o) => hitsBox(a, b, o, radius));
}

export function walkable(x, z, radius = PLAYER_RADIUS, obstacles = OBSTACLES) {
  if (x < MAP.minX + radius || x > MAP.maxX - radius || z < MAP.minZ + radius || z > MAP.maxZ - radius) return false;
  return !obstacles.some((o) => obstacleContainsPoint(o,x,z,radius));
}

function moveBody(body, dx, dz, radius, obstacles, other = null) {
  // Small physical capsules keep both actors from walking through one another.
  // If a test/setup begins overlapped, allow only motion that increases separation.
  const clearActor=(x,z)=>!other || Math.hypot(x-other.x,z-other.z)>=BODY_SEPARATION || Math.hypot(x-other.x,z-other.z)>distance(body,other)+1e-7;
  // Small sweeps stop bodies tunnelling across thin cabin walls on a slow frame.
  const count = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dz)) / .16));
  const sx = dx / count, sz = dz / count;
  for (let i = 0; i < count; i++) {
    if (walkable(body.x + sx, body.z, radius, obstacles) && clearActor(body.x+sx,body.z)) body.x += sx;
    if (walkable(body.x, body.z + sz, radius, obstacles) && clearActor(body.x,body.z+sz)) body.z += sz;
  }
}

class Heap {
  constructor() { this.a = []; }
  push(v) {
    const a = this.a; a.push(v); let i = a.length - 1;
    while (i) { const p = (i - 1) >> 1; if (a[p].f <= v.f) break; a[i] = a[p]; i = p; }
    a[i] = v;
  }
  pop() {
    const a = this.a, result = a[0], tail = a.pop();
    if (a.length) {
      let i = 0;
      while (i * 2 + 1 < a.length) {
        let c = i * 2 + 1;
        if (c + 1 < a.length && a[c + 1].f < a[c].f) c++;
        if (a[c].f >= tail.f) break;
        a[i] = a[c]; i = c;
      }
      a[i] = tail;
    }
    return result;
  }
}

// A* uses the chapter's own obstacles. Routes stay physical at both doors and
// across replans; no rescue teleport is used when a route cannot be found.
export function findPath(start, goal, radius = KILLER_RADIUS, obstacles = OBSTACLES) {
  if (walkable(goal.x, goal.z, radius, obstacles)) {
    const direct = findPathTo(start, goal, radius, obstacles);
    if (direct.length) return direct;
    // The goal is a legal spot no grid route reaches (a gap she fits through and he does not).
    // Fall through and walk to the nearest point he can stand on within sight of it.
  }
  // The player is narrower than the killer. A player pressed against a wall or
  // van can therefore occupy a legal position the killer cannot stand on. Route
  // to a nearby approach point on the same visible side, within striking reach;
  // never change either actor's position to repair the path.
  const approaches = [];
  for (const r of [.12, .24, .48, .8, 1.2]) {
    for (let i = 0; i < 24; i++) {
      const angle = i * Math.PI / 12;
      const p = { x: goal.x + Math.sin(angle) * r, z: goal.z + Math.cos(angle) * r };
      if (walkable(p.x, p.z, radius, obstacles) && clearSegment(goal, p, 0, obstacles)) approaches.push(p);
    }
  }
  approaches.sort((a, b) => distance(a, goal) + distance(a, start) * .04 - distance(b, goal) - distance(b, start) * .04);
  for (const p of approaches) if (clearSegment(start, p, radius, obstacles)) return [p];
  // A nearby point may need a route through a door. Trying alternatives also
  // handles a grid node being unavailable right beside a thin wall.
  for (const p of approaches.slice(0, 12)) {
    const route = findPathTo(start, p, radius, obstacles);
    if (route.length) return route;
  }
  return [];
}

function findPathTo(start, goal, radius, obstacles) {
  if (!walkable(goal.x, goal.z, radius, obstacles)) return [];
  if (clearSegment(start, goal, radius, obstacles)) return [copy(goal)];
  const width = Math.floor((MAP.maxX - MAP.minX) / GRID) + 1;
  const height = Math.floor((MAP.maxZ - MAP.minZ) / GRID) + 1;
  const point = (id) => ({ x: MAP.minX + (id % width) * GRID, z: MAP.minZ + Math.floor(id / width) * GRID });
  const snap = (p) => {
    const cx = Math.round((p.x - MAP.minX) / GRID), cz = Math.round((p.z - MAP.minZ) / GRID);
    for (let r = 0; r <= 3; r++) {
      let best = null, bestD = Infinity;
      for (let z = cz - r; z <= cz + r; z++) for (let x = cx - r; x <= cx + r; x++) {
        if (x < 0 || x >= width || z < 0 || z >= height) continue;
        const id = z * width + x, q = point(id), d = distance(p, q);
        if (d < bestD && walkable(q.x, q.z, radius, obstacles) && clearSegment(p, q, radius, obstacles)) { best = id; bestD = d; }
      }
      if (best !== null) return best;
    }
    return null;
  };
  const first = snap(start), last = snap(goal);
  if (first === null || last === null) return [];
  const open = new Heap(), costs = new Map([[first, 0]]), previous = new Map(), closed = new Set();
  const target = point(last);
  open.push({ id: first, f: distance(point(first), target) });
  let found = false;
  while (open.a.length && closed.size < width * height) {
    const { id } = open.pop();
    if (closed.has(id)) continue;
    if (id === last) { found = true; break; }
    closed.add(id);
    const p = point(id), ix = id % width, iz = Math.floor(id / width);
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      if ((!dx && !dz) || ix + dx < 0 || ix + dx >= width || iz + dz < 0 || iz + dz >= height) continue;
      const next = (iz + dz) * width + ix + dx;
      if (closed.has(next)) continue;
      const q = point(next);
      if (!walkable(q.x, q.z, radius, obstacles) || !clearSegment(p, q, radius, obstacles)) continue;
      const g = costs.get(id) + GRID * Math.hypot(dx, dz);
      if (g >= (costs.get(next) ?? Infinity)) continue;
      costs.set(next, g); previous.set(next, id);
      open.push({ id: next, f: g + distance(q, target) });
    }
  }
  if (!found) return [];
  const path = [copy(goal)]; let id = last;
  while (id !== first) { path.push(point(id)); id = previous.get(id); }
  path.push(point(first)); path.reverse();
  // String-pulling still checks the full body width, retaining doorway clearance.
  const result = []; let anchor = copy(start), at = 0;
  while (at < path.length) {
    let far = at;
    while (far + 1 < path.length && clearSegment(anchor, path[far + 1], radius, obstacles)) far++;
    result.push(path[far]); anchor = path[far]; at = far + 1;
  }
  return result;
}

export class Act2Sim {
  constructor({ seed = 7319, difficulty = 'standard', arrivalTime = 18, extraObstacles = [] } = {}) {
    // Scene-generated solids belong to this run, never to a mutable module-global map.
    this.obstacles = [...new Map([...OBSTACLES, ...extraObstacles].map(o=>[o.id,o])).values()];
    this.seed = seed >>> 0;
    this.difficulty = difficulty;
    this.profile = ACT2_DIFFICULTY[difficulty] || ACT2_DIFFICULTY.standard;
    this.arrivalTime = arrivalTime;
    this.time = 0;
    this.phase = 'play';
    this.player = this.p = { ...LOCATIONS.start, y: 0, yaw: Math.PI, stamina: 1, hidden: null, run: false, runRequested: false, gait:'idle', moving: false, speed: 0, flashlight: true, winded: false, defending:false, defendYaw:null, defendProgress:0, defendHit:false };
    this.killer = { ...LOCATIONS.killer, y: 0, yaw: Math.PI / 2, state: 'dormant', active: false, speed: 0, notice: 0, attack: 0, attackPhase:null, attackProgress:0, attackCycle:0, attackTarget:null, attackHit:false, stagger: 0, lastSeen: null, target: null, path: [], patrolIndex: 0, visibleToPlayer: false };
    this.keys = false;
    this.weapon = 'none';
    this.prompt = null;
    this.events = [];
    this.stats = { seen: 0, closeCalls: 0, defenses: 0, distance: 0, hides: 0, clues:0 };
    this.routeStage=0;this.discovered=new Set(['arrival']);this.inspected=new Set();this._bridgeNoises=new Set();this._routeSide=-1;this._patrolCircuit=-1;
    this.checkpoint = 'post-crash';
    this.deathKind = null;
    this.keyProgress = 0;
    this._heardAt = -100;
    this._seenAt = -100;
    this._searchUntil = 0;
    this._inspectAt = null;
    this._knownHide = null;
    this._pathAt = -100;
    this._pathGoal = null;
    this._searchIndex = 0;
    this._strikeAt = null;
    this._attackContact = false;
    this._defendCooldown = 0;
    this._defendAt = null;
    this.updateRoute(false);
    this.updatePrompt();
  }

  emit(type, extra = {}) { this.events.push({ type, time: this.time, ...extra }); }

  // True only for an unobstructed cone. Nearby peripheral vision is slightly
  // wider, but walls, tents, vans and rocks still stop sight at touching range.
  canSeePlayer() {
    const k = this.killer, p = this.p;
    if (!k.active || p.hidden) return false;
    const d = distance(k, p), range = (p.flashlight ? 29 : p.run ? 24 : 20) * this.profile.sense;
    if (d > range || !this.clearSight(k,p)) return false;
    const f = facing(k.yaw), dot = ((p.x - k.x) * f.x + (p.z - k.z) * f.z) / Math.max(d, .001);
    return d < 2.8 || dot > (p.flashlight ? -.05 : .26);
  }

  step(dt, input = {}) {
    if (this.phase !== 'play') return;
    // Keep slow-frame results stable without simulating an entire suspended tab.
    dt = clamp(Number.isFinite(dt) ? dt : 0, 0, .1);
    this.time += dt;
    this.p.flashlight = input.flashlight ?? this.p.flashlight;
    this._defendCooldown = Math.max(0, this._defendCooldown - dt);
    this.updateDefense();
    // The attack edge keeps the counselor's existing intent, never a camera yaw
    // supplied only for that frame. Movement still works while facing is locked.
    const startingDefense=input.defend&&this.weapon==='ready'&&!this.p.hidden&&this._defendCooldown<=0;
    const holdFacing=this.p.defending||startingDefense;
    if (!holdFacing&&Number.isFinite(input.yaw)) this.p.yaw = input.yaw;
    // Honor a valid hide press before movement can carry the counselor beyond
    // the displayed prompt. Reuse the normal selection and obstruction checks.
    let enteredHide=false;
    if(input.action&&!this.p.hidden){
      this.updatePrompt();
      if(this.prompt?.kind==='hide')enteredHide=this.interact();
    }
    this.movePlayer(dt,holdFacing?{...input,yaw:this.p.yaw}:input);
    this.updateRoute();
    this.checkBridgeNoise();
    if (input.action&&!enteredHide) this.interact();
    if (this.phase !== 'play') { this.updatePrompt(); return; }
    if (input.defend) this.defend();
    if (input.actionHeld && !this.keys && !this.p.hidden && distance(this.p, LOCATIONS.keys) < 2.2) {
      this.keyProgress = Math.min(1, this.keyProgress + dt / 1.4);
      if (this.keyProgress >= 1) {
        this.keys = true; this.emit('keys', { text: 'Van keys. Get to the driver’s door.' });this.updateRoute(false);
      }
    } else if (!this.keys) this.keyProgress = 0;
    this.updateKiller(dt);
    this.updatePrompt();
  }

  clearSight(a,b) {
    // Walking characters can see across low desks, stakes and the fallen log.
    return clearSegment(a,b,0,this.obstacles.filter(o=>(o.height??Infinity)>=1.55));
  }

  nearbyHide() {
    return HIDE_SPOTS.find(h=>distance(this.p,h)<h.radius && clearSegment(this.p,h,PLAYER_RADIUS,this.obstacles));
  }

  movePlayer(dt, input) {
    const p = this.p;
    p.runRequested=!!input.run && !input.sneak;
    p.run=false;p.gait='idle';p.moving=false;p.speed=0;
    if(p.stamina<=0)p.winded=true;
    if(p.winded&&p.stamina>=.42)p.winded=false;
    if(p.hidden){p.stamina=Math.min(1,p.stamina+dt*.18);return;}
    const mx=Number.isFinite(input.moveX)?input.moveX:0,mz=Number.isFinite(input.moveZ)?input.moveZ:0;
    const magnitude=Math.min(1,Math.hypot(mx,mz));
    if(magnitude<.05){p.stamina=Math.min(1,p.stamina+dt*.18);return;}
    const gait=input.sneak?'sneak':p.runRequested&&magnitude>.12?(p.winded||p.stamina<=0?'jog':'sprint'):'walk';
    const speed=gait==='sprint'?4.7:gait==='jog'?3:gait==='sneak'?1.35:2.6;
    const norm=Math.hypot(mx,mz),before=copy(p);
    moveBody(p,mx/norm*magnitude*speed*dt,mz/norm*magnitude*speed*dt,PLAYER_RADIUS,this.obstacles,this.killer.active?this.killer:null);
    const moved=distance(before,p);
    p.speed=dt>0?moved/dt:0;p.moving=moved>.0005;
    p.gait=p.moving?gait:'idle';p.run=p.gait==='sprint';
    if(p.run){
      const effort=clamp(moved/Math.max(.0001,speed*magnitude*dt),0,1);
      p.stamina=Math.max(0,p.stamina-dt*.055*effort);
      if(p.stamina<=0)p.winded=true;
    }else p.stamina=Math.min(1,p.stamina+dt*(p.moving?.10:.18));
    if(!p.defending&&!Number.isFinite(input.yaw)&&p.moving)p.yaw=Math.atan2(mx,mz);
    this.stats.distance+=moved;
  }

  interact() {
    if (this.phase !== 'play') return false;
    const p = this.p;
    if (p.hidden) {
      const hide = p.hidden; p.hidden = null;
      this.emit('leaveHide', { hide: hide.id });
      if (this._knownHide?.id === hide.id) {
        this._leftHide = { id: hide.id, inspectAt: this._inspectAt, at: this.time };
        this._knownHide = null; this._inspectAt = null;
        this.beginSearch(copy(hide), 'leave-hide');
      }
      this.updatePrompt(); return true;
    }
    if (this.weapon === 'none' && distance(p, LOCATIONS.weapon) < 1.9 && clearSegment(p,LOCATIONS.weapon,0,this.obstacles)) {
      this.weapon = 'ready'; this.emit('weapon', { text: 'Crowbar ready. Face him, then swing when he is close. A hit stuns him for four seconds and uses it up. A miss does not.' }); this.updatePrompt(); return true;
    }
    if (distance(p, LOCATIONS.vanDoor) < 2) {
      if (this.keys) {
        this.cancelDefense();this.phase = 'escape'; this.emit('escape'); this.prompt = null; return true;
      }
      this.emit('locked', { text: 'Locked. The keys are in his hand, beside the van.' }); return false;
    }
    if (!this.keys && distance(p, LOCATIONS.keys) < 2.2) return true; // hold handled by step
    const hide = this.nearbyHide();
    if (hide) {
      // A successful defense grants the full escape window, including hiding.
      // Stunned Sackhead cannot observe entry or replace stagger with inspection.
      const seen = this.killer.state !== 'stagger' && this.canSeePlayer();
      this.cancelAttack();
      this.cancelDefense();
      p.hidden = hide; p.run = false;p.gait='idle';p.runRequested=false; p.speed = 0; p.moving = false;
      this.stats.hides++;
      this.emit('hide', { hide: hide.id, kind: hide.kind });
      if (seen) {
        const back = this._leftHide?.id === hide.id && this.time - this._leftHide.at < 6 ? this._leftHide.inspectAt : null;
        this._knownHide = hide; this._inspectAt = back; this._leftHide = null;
        this.killer.state = 'check-hide'; this.killer.target = copy(hide);
        this.cancelAttack();
        this.emit('hideSeen', { text: 'He saw you. Leave before he reaches the hiding place.' });
      }
      this.updatePrompt(); return true;
    }
    const clue=this.nearbyInspect();
    if(clue){
      if(!this.inspected.has(clue.id)){this.inspected.add(clue.id);this.stats.clues++;}
      this.emit('inspect',{clue:true,id:clue.id,text:clue.text});this.updatePrompt();return true;
    }
    return false;
  }

  // Discovery changes guidance, never locks progress behind an invisible trigger.
  // Every notice is optional; the van only requires the keys beside it.
  updateRoute(announce=true) {
    const previous=this.routeStage;
    while(this.routeStage<ROUTE_LANDMARKS.length-1 && this.p.z<ROUTE_LANDMARKS[this.routeStage].threshold)this.routeStage++;
    if(previous<2&&this.routeStage>=2)this._routeSide=this.p.x>5?1:-1;
    if(previous!==this.routeStage){
      for(let i=previous+1;i<=this.routeStage;i++)this.discovered.add(ROUTE_LANDMARKS[i].id);
      if(announce)this.emit('route',{stage:this.routeStage,id:ROUTE_LANDMARKS[this.routeStage].id,text:ROUTE_LANDMARKS[this.routeStage].text});
    }
    const landmark=ROUTE_LANDMARKS[this.routeStage];
    this.objective=this.keys?'Get to the van.':landmark.objective;
    this.navigation=this.keys?{...LOCATIONS.vanDoor,label:'DRIVER’S DOOR'}:{x:landmark.x,z:landmark.z,label:landmark.label};
    if(!this.keys&&this.routeStage===2)this.navigation={x:this._routeSide*20,z:-58,label:this._routeSide<0?'WEST FOOTBRIDGE':'EAST SERVICE CROSSING'};
    if(!this.keys&&this.routeStage===3)this.navigation={x:this._routeSide*14,z:-82,label:'SERVICE YARD'};
  }

  nearbyInspect() {
    return INSPECT_SPOTS.find(clue=>distance(this.p,clue)<clue.radius&&clearSegment(this.p,clue,0,this.obstacles));
  }

  checkBridgeNoise() {
    const p=this.p;
    if(p.hidden||!p.moving||p.z> -56||p.z< -60||Math.abs(Math.abs(p.x)-20)>2.5)return;
    const id=p.x<0?'west':'east';if(this._bridgeNoises.has(id))return;
    this._bridgeNoises.add(id);
    const at={x:p.x<0?-20:20,z:-58};this.emit('bridgeNoise',{...at,text:'The boards creak under you.'});
    const k=this.killer;
    if(k.active&&['patrol','search'].includes(k.state)&&distance(k,at)<=55){
      this.beginSearch(at,'bridge');
      // A creek bank can make the walking route much longer than the sound's
      // straight-line distance. Give him time to reach that remembered point.
      const path=findPath(k,at,KILLER_RADIUS,this.obstacles);let from=k,pathLength=0;
      for(const point of path){pathLength+=distance(from,point);from=point;}
      k.path=path;this._pathGoal=copy(at);this._pathAt=this.time;
      this._searchUntil=this.time+Math.max(10,pathLength/2.05+8);
      this._heardAt=this.time;
    }
  }

  patrolRoute() {return PATROL_CIRCUITS[Math.max(0,this._patrolCircuit)];}

  updatePatrolCircuit() {
    const circuit=this.routeStage>=4?2:this.routeStage>=2?1:0;
    if(circuit===this._patrolCircuit)return;
    this._patrolCircuit=circuit;
    const route=this.patrolRoute(),k=this.killer;
    // Broad route pacing selects a fixed, nearby circuit entrance. He must walk
    // there, and receives no live player position or chase/search override.
    k.patrolIndex=route.reduce((best,p,i)=>distance(k,p)<distance(k,route[best])?i:best,0);
    k.target=copy(route[k.patrolIndex]);k.path=[];this._pathAt=-100;
  }

  defend() {
    if(this.phase!=='play'||this._defendCooldown>0)return false;
    this._defendCooldown=DEFENSE_TIMING.cooldown;
    const p=this.p,k=this.killer,d=distance(p,k);
    const unobstructed=clearSegment(p,k,0,this.obstacles);
    const targetYaw=Math.atan2(k.x-p.x,k.z-p.z);
    const difference=Math.atan2(Math.sin(targetYaw-p.yaw),Math.cos(targetYaw-p.yaw));
    const swing=this.weapon==='ready'&&!p.hidden;
    if(swing){
      // A little help toward an already frontal, reachable threat. Never turn
      // toward an unseen/blocked threat, or sweep the aim around behind her.
      if(k.active&&d<=DEFENSE_TIMING.reach&&unobstructed&&Math.abs(difference)<=DEFENSE_TIMING.assistCone){
        p.yaw+=clamp(difference,-DEFENSE_TIMING.maxAssist,DEFENSE_TIMING.maxAssist);
      }
      this._defendAt=this.time;p.defending=true;p.defendYaw=p.yaw;p.defendProgress=0;p.defendHit=false;
    }
    const f=facing(p.yaw),dot=((k.x-p.x)*f.x+(k.z-p.z)*f.z)/Math.max(d,.001);
    let reason=null,text='';
    if(p.hidden){reason='hidden';text='Leave your hiding place before swinging.';}
    else if(this.weapon!=='ready'){reason='unarmed';text=this.weapon==='spent'?'The crowbar is gone. Keep moving.':'Pick up a crowbar before swinging.';}
    else if(!k.active||d>DEFENSE_TIMING.reach){reason='range';text='Miss. The crowbar is not used up. Wait until he is close enough to reach.';}
    else if(dot<.15){reason='facing';text='Miss. The crowbar is not used up. Face him before you strike.';}
    else if(!unobstructed){reason='blocked';text='Miss. The crowbar is not used up. Something is between you.';}
    if(reason){this.emit('defendMiss',{reason,text,swing,yaw:p.yaw,duration:DEFENSE_TIMING.duration});return false;}
    this.weapon='spent';this.stats.defenses++;p.defendHit=true;
    this.cancelAttack();k.state='stagger';k.stagger=DEFENSE_TIMING.stagger;k.speed=0;
    this._knownHide=null;this._inspectAt=null;k.lastSeen=copy(p);this._seenAt=this.time;
    this.emit('defend',{text:"Hit. He's stunned for four seconds. The crowbar is used up. RUN!",yaw:p.yaw,duration:DEFENSE_TIMING.duration});return true;
  }

  updateDefense() {
    const p=this.p;
    if(this._defendAt===null)return;
    p.defendProgress=clamp((this.time-this._defendAt)/DEFENSE_TIMING.duration,0,1);
    if(p.defendProgress>=1){p.defending=false;p.defendYaw=null;this._defendAt=null;return;}
    p.yaw=p.defendYaw;
  }

  cancelDefense() {
    this._defendAt=null;
    this.p.defending=false;this.p.defendYaw=null;this.p.defendProgress=0;this.p.defendHit=false;
  }

  cancelAttack() {
    const k=this.killer;
    this._strikeAt=null;this._attackContact=false;
    k.attackPhase=null;k.attackProgress=k.attackCycle=k.attack=0;k.attackTarget=null;k.attackHit=false;
  }

  beginAttack() {
    const k=this.killer;
    this._strikeAt=this.time;this._attackContact=false;
    k.attackPhase='windup';k.attackProgress=k.attackCycle=k.attack=0;k.attackTarget=copy(this.p);k.attackHit=false;
    k.yaw=Math.atan2(this.p.x-k.x,this.p.z-k.z);k.speed=0;
    this.emit('attackWindup',{text:'Move!'});
  }

  updateAttack() {
    const k=this.killer,p=this.p,t=this.time-this._strikeAt;
    const {windup,strike,recover,contact,reach}=ATTACK_TIMING,total=windup+strike+recover;
    k.speed=0;
    if(t>=total){this.cancelAttack();return;}
    const previous=k.attackPhase;
    if(t<windup){k.attackPhase='windup';k.attackProgress=t/windup;}
    else if(t<windup+strike){k.attackPhase='strike';k.attackProgress=(t-windup)/strike;}
    else{k.attackPhase='recover';k.attackProgress=(t-windup-strike)/recover;}
    k.attackCycle=k.attack=clamp(t/total,0,1);
    if(k.attackPhase==='strike'&&previous!=='strike')this.emit('attack',{text:'Move!'});
    if(!this._attackContact&&t>=windup+strike*contact){
      this._attackContact=true;
      const dx=p.x-k.x,dz=p.z-k.z,f=facing(k.yaw),forward=dx*f.x+dz*f.z,lateral=Math.abs(dx*f.z-dz*f.x);
      if(!p.hidden&&Math.hypot(dx,dz)<=reach&&forward>.2&&lateral<=.46&&clearSegment(k,p,0,this.obstacles)){
        // Death freezes the exact contact pose, even when a slow frame crossed
        // that instant; the visible fork must not already be withdrawing.
        k.attackPhase='strike';k.attackProgress=contact;
        k.attackCycle=k.attack=(windup+strike*contact)/total;
        k.attackHit=true;this.kill('outdoors');
      }else{this.stats.closeCalls++;this.emit('attackMiss',{text:'He missed. Keep moving.'});}
    }
  }

  beginSearch(where, reason = 'lost') {
    const k = this.killer;
    k.state = 'search'; k.lastSeen = copy(where); k.target = copy(where);
    this._searchUntil = this.time + this.profile.searchTime;
    this._searchIndex = 0; this._pathAt = -100;
    if (reason === 'lost') this.emit('lost', { text: 'He lost sight of you. Keep quiet.' });
    else if (reason === 'heard') this.emit('investigate', { text: 'He heard something. Keep quiet.' });
  }

  follow(target, speed, dt) {
    const k = this.killer;
    if (!target) return;
    const stale = this.time - this._pathAt > .85;
    if (!this._pathGoal || distance(target, this._pathGoal) > 1.3 || (stale && (k.state === 'chase' || k.state === 'check-hide' || !k.path.length))) {
      k.path = findPath(k, target, KILLER_RADIUS, this.obstacles);
      this._pathGoal = copy(target); this._pathAt = this.time;
    }
    while (k.path.length && distance(k, k.path[0]) < .22) k.path.shift();
    const next = k.path[0];
    if (!next) { k.speed = 0; return; }
    const dx = next.x - k.x, dz = next.z - k.z, d = Math.hypot(dx, dz), amount = Math.min(d, speed * dt);
    k.yaw = Math.atan2(dx, dz);
    const before = copy(k);
    if (d > 1e-6) moveBody(k, dx / d * amount, dz / d * amount, KILLER_RADIUS, this.obstacles, this.p.hidden?null:this.p);
    k.speed = dt > 0 ? distance(before, k) / dt : 0;
  }

  updateKiller(dt) {
    const k = this.killer, p = this.p;
    if (!k.active) {
      if (this.time < this.arrivalTime) return;
      k.active = true; k.state = 'patrol'; this.updatePatrolCircuit();
      this.emit('killerArrival', { text: 'A heavy footfall. Somewhere beyond the trees.' });
    }
    // Stagger is an exclusive state: sight, attacks, path following and hearing
    // cannot interrupt it. Recovery searches the struck location, not the player.
    if (k.state === 'stagger') {
      k.speed = 0; k.stagger = Math.max(0, k.stagger - dt);
      if (k.stagger <= 0) this.beginSearch(k.lastSeen ?? copy(k), 'recover');
      return;
    }
    if(k.attackPhase){this.updateAttack();return;}
    if(k.state==='patrol')this.updatePatrolCircuit();
    k.visibleToPlayer = distance(k, p) < 34 && this.clearSight(k,p);
    const sees = this.canSeePlayer();
    if (sees) {
      k.notice = Math.min(1, k.notice + dt * (distance(k, p) < 8 ? 3 : 1.5) * this.profile.sense);
      if (k.notice >= 1 || k.state === 'chase') {
        if (k.state !== 'chase') { this.stats.seen++; this.emit('spotted', { text: 'He sees you.' }); }
        k.state = 'chase'; k.lastSeen = copy(p); this._seenAt = this.time;
        k.target = copy(p); this._knownHide = null; this._inspectAt = null;
      }
    } else k.notice = Math.max(0, k.notice - dt * .6);

    if (k.state === 'check-hide' && this._knownHide) {
      const hide = this._knownHide;
      k.target = copy(hide);
      if (distance(k, hide) > 1.65) this.follow(hide, this.profile.chase, dt);
      else {
        k.speed = 0;
        if (this._inspectAt === null) { this._inspectAt = this.time; this.emit('inspect', { text: 'He is opening it. Get out now.' }); }
        if (this.time - this._inspectAt >= 2.3 && p.hidden?.id === hide.id) this.kill(hide.kind);
      }
      return;
    }

    if (k.state === 'chase') {
      if (!sees && this.time - this._seenAt > this.profile.memory) this.beginSearch(k.lastSeen ?? copy(k));
      else {
        k.target = copy(k.lastSeen ?? p);
        const reach = distance(k, p);
        if(!p.hidden&&reach<=ATTACK_TIMING.reach&&clearSegment(k,p,0,this.obstacles)){
          this.beginAttack();return;
        }
        this.follow(k.target, this.profile.chase, dt);
        return;
      }
    }

    if (k.state === 'search') {
      if (this.time >= this._searchUntil) {
        k.state = 'patrol';this.updatePatrolCircuit();k.target = copy(this.patrolRoute()[k.patrolIndex % this.patrolRoute().length]); k.notice = 0;
      } else if (!k.target || distance(k, k.target) < .65) {
        const offsets = [{x:4,z:0},{x:0,z:-4},{x:-4,z:0},{x:0,z:4}];
        const o = offsets[this._searchIndex++ % offsets.length];
        const at = k.lastSeen ?? copy(k), target = {x:at.x+o.x,z:at.z+o.z};
        if (walkable(target.x, target.z, KILLER_RADIUS, this.obstacles)) k.target = target;
      }
    }
    // Hearing supplies a location when the sound occurs, never a live player
    // pointer. Quiet walking is not audible beyond the immediate area.
    const hearing = (p.run ? 17 : p.speed > 1.7 ? 4 : 0) * this.profile.sense;
    if (!p.hidden && p.moving && distance(k, p) < hearing && this.time - this._heardAt > 3.5 && k.state !== 'chase') {
      this._heardAt = this.time; this.beginSearch(copy(p), 'heard');
    }
    if (k.state === 'patrol' && (!k.target || distance(k, k.target) < .8)) {
      k.patrolIndex = (k.patrolIndex + 1) % this.patrolRoute().length;
      k.target = copy(this.patrolRoute()[k.patrolIndex]);
    }
    this.follow(k.target, k.state === 'search' ? 2.05 : 1.7, dt);
  }

  kill(kind = 'outdoors') {
    if (this.phase !== 'play') return;
    this.phase = 'dead'; this.deathKind = kind;
    this.cancelDefense();
    this.killer.speed = 0; this.p.speed = 0; this.p.moving = false;this.p.gait='idle';this.p.run=false;
    this.emit('death', { kind }); this.prompt = null;
  }

  updatePrompt() {
    const p = this.p;
    if (this.phase !== 'play') { this.prompt = null; return; }
    if (p.hidden) this.prompt = { kind:'leave', text:`Leave ${p.hidden.kind==='tent'?'tent':'wardrobe'}`, warning:!!this._knownHide };
    else if (this.weapon === 'none' && distance(p, LOCATIONS.weapon) < 1.9 && clearSegment(p,LOCATIONS.weapon,0,this.obstacles)) this.prompt = { kind:'weapon', text:'Take crowbar' };
    else if (!this.keys && distance(p, LOCATIONS.keys) < 2.2) this.prompt = { kind:'keys', text:'Hold to take van keys', progress:this.keyProgress };
    else if (distance(p, LOCATIONS.vanDoor) < 2) this.prompt = { kind:'van', text:this.keys ? 'Get in the van' : 'Try driver’s door' };
    else {
      const hide = this.nearbyHide();
      const clue=this.nearbyInspect();
      this.prompt = hide ? { kind:'hide', text:`Hide in ${hide.kind === 'tent' ? 'tent' : 'wardrobe'}` } : clue?{kind:'inspect',text:clue.name}:null;
    }
  }
}
