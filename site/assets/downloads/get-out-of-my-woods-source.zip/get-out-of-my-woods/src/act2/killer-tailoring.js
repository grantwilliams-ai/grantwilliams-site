// Preview-only clothing geometry. The skeleton, hands and pitchfork stay at
// their authored dimensions; loose garments should not resemble padded armour.
import * as THREE from 'three';
import { MeshBuilder, toGeometry, surfaceAt, rgb } from '../characters/mesh.js';

const rings = [
  // The waist ends inside the trousers instead of descending as a pointed apron.
  // Broad shoulders come from the rig; the shirt itself need not be inflated.
  { y: .93, rx: .245, rz: .145 }, { y: 1.0, rx: .267, rz: .17 },
  { y: 1.09, rx: .276, rz: .176 }, { y: 1.2, rx: .275, rz: .178 },
  { y: 1.31, rx: .286, rz: .18 }, { y: 1.43, rx: .307, rz: .178 },
  { y: 1.55, rx: .329, rz: .176 }, { y: 1.65, rx: .342, rz: .158 },
  { y: 1.71, rx: .316, rz: .148 }, { y: 1.77, rx: .254, rz: .13 },
  { y: 1.83, rx: .144, rz: .1 }, { y: 1.86, rx: .095, rz: .075 },
];
const clamp = (n) => Math.max(0, Math.min(1, n));

function clothTorso(rig) {
  const mb = new MeshBuilder();
  mb.part(rig.idx.chest, [0, 0, 0]);
  mb.uvScale = 3.2;
  const surface = mb.loft(rings.map((r) => ({ ...r, lump: .012,
    c: r.y < 1.18 ? 0x293b31 : r.y < 1.45 ? 0x55584a : 0x626358,
  })), { sides: 20, sq: .86, capBot: false, capTop: false });
  // The bib is part of the same cloth surface. A second large curved patch
  // intersected the bending shirt and shimmered in the moving flashlight.
  const bib = rgb(0x293b31);
  for (let i = 0; i < mb.pos.length / 3; i++) {
    const x = mb.pos[i * 3], y = mb.pos[i * 3 + 1], z = mb.pos[i * 3 + 2];
    if (y >= 1.04 && y <= 1.65 && Math.abs(Math.atan2(x, z)) < .7) {
      for (let j = 0; j < 3; j++) mb.col[i * 3 + j] = bib[j];
    }
  }
  const point = (a, y, off = .003) => surfaceAt(surface, a, y, off).p;
  const patch = (a0, a1, y0, y1, color, off = .003, cols = 4, rows = 3) => {
    for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
      const a = a0 + (a1 - a0) * x / cols, b = a0 + (a1 - a0) * (x + 1) / cols;
      const lo = y0 + (y1 - y0) * y / rows, hi = y0 + (y1 - y0) * (y + 1) / rows;
      mb.fan([point(a, lo, off), point(b, lo, off), point(b, hi, off), point(a, hi, off)], rgb(color));
    }
  };
  // A worn canvas bib, its upper pocket and two load-bearing shoulder straps.
  for (const side of [-1, 1]) {
    patch(side * .37 - .085, side * .37 + .085, 1.56, 1.83, 0x2b3c31, .014, 2, 5);
    patch(side * .37 - .07, side * .37 - .056, 1.57, 1.8, 0x68725c, .016, 1, 4);
    patch(side * .67 - .012, side * .67 + .012, 1.12, 1.58, 0x53604c, .007, 1, 6);
    // Side seam and knee-to-waist grime are darker than the central handling wear.
    patch(side * 1.22 - .012, side * 1.22 + .012, .95, 1.55, 0x30362c, .003, 1, 6);
    for (let i = 0; i < 13; i++) {
      const y = 1.13 + i * .033;
      patch(side * .64 - .007, side * .64 + .007, y, y + .006, 0x6c715d, .008, 1, 1);
    }
  }
  patch(-.29, .3, 1.29, 1.46, 0x223328, .008, 4, 3);
  patch(-.3, .31, 1.455, 1.47, 0x5a654f, .011, 5, 1);
  patch(-.3, .31, 1.29, 1.3, 0x4c5a45, .011, 5, 1);
  for (const a of [-.3, .3]) patch(a - .01, a + .01, 1.3, 1.46, 0x56624c, .01, 1, 3);
  // Uneven creases below the pocket. Surface patches follow the cloth, never float.
  for (const [a, y, w] of [[-.29, 1.18, .25], [.18, 1.23, .2], [.05, 1.52, .19]]) {
    mb.fan([point(a - w, y, .006), point(a + w, y + .014, .006), point(a + w, y + .019, .006), point(a - w, y + .004, .006)], rgb(0x32382b));
  }
  const torsoVertices = mb.pos.length / 3;
  // The shoulder slopes continuously from the collar into an unpadded sleeve.
  // Its upper section follows the chest, then gradually transfers to the arm.
  for (const side of [-1, 1]) {
    mb.part(rig.idx[side < 0 ? 'uarmR' : 'uarmL'], [0, 0, 0]);
    mb.loft([
      { y: 1.8, ox: side * .155, rx: .05, rz: .05, c: 0x626358 },
      { y: 1.73, ox: side * .295, rx: .092, rz: .102, c: 0x626358 },
      { y: 1.65, ox: side * .375, rx: .103, rz: .106, c: 0x5d6051 },
      { y: 1.51, ox: side * .385, rx: .096, rz: .102, c: 0x5a5e50 },
      { y: 1.31, ox: side * .382, rx: .088, rz: .089, c: 0x55594b },
      { y: 1.24, ox: side * .38, rx: .084, rz: .085, c: 0x525749 },
      { y: 1.2, ox: side * .38, rx: .084, rz: .083, c: 0x55594b },
    ], { sides: 12, sq: .9, capBot: false, capTop: false });
  }
  const g = toGeometry(mb, null, true), p = g.attributes.position;
  const skin = g.attributes.skinIndex, weights = g.attributes.skinWeight;
  // A single continuous garment bends across the torso instead of three rigid
  // overlapping shells. All attached fabric details use the same skin weights.
  for (let i = 0; i < p.count; i++) {
    const y = p.getY(i), lower = y < 1.32;
    if (i >= torsoVertices) {
      const arm = skin.getX(i), blend = clamp((1.79 - y) / .23);
      skin.setXYZW(i, rig.idx.chest, arm, 0, 0);
      weights.setXYZW(i, 1 - blend, blend, 0, 0);
      continue;
    }
    // Let the collar follow the sack's turn, with its upper rim tucked inside
    // the tied neck. Chest-only weights left a dark open notch when he looked up.
    if (y > 1.77) {
      const blend = clamp((y - 1.77) / .09);
      skin.setXYZW(i, rig.idx.chest, rig.idx.head, 0, 0);
      weights.setXYZW(i, 1 - blend, blend, 0, 0);
      continue;
    }
    const blend = lower ? clamp((y - 1.04) / .28) : clamp((y - 1.32) / .2);
    skin.setXYZW(i, lower ? rig.idx.pelvis : rig.idx.spine, lower ? rig.idx.spine : rig.idx.chest, 0, 0);
    weights.setXYZW(i, 1 - blend, blend, 0, 0);
  }
  return g;
}

function profile(y) {
  let i = 0;
  while (i < rings.length - 2 && y > rings[i + 1].y) i++;
  const a = rings[i], b = rings[i + 1], t = clamp((y - a.y) / (b.y - a.y));
  return { rx: a.rx + (b.rx - a.rx) * t, rz: a.rz + (b.rz - a.rz) * t };
}

// Existing sleeve/trouser rings used rigid, capped segments. Let their cloth
// share the two neighboring bones around elbows and knees, with no new surface
// or expanded silhouette. Hands, boots, skeleton and weapon remain untouched.
function softenClothJoints(geometry,rig) {
  const position=geometry.attributes.position,skin=geometry.attributes.skinIndex,weights=geometry.attributes.skinWeight;
  for(let i=0;i<position.count;i++) {
    const name=rig.names[skin.getX(i)],y=position.getY(i);
    // The upper trouser ring stays under the waist during a long stride;
    // the leg takes over below the hip rather than peeling a rigid cap away.
    if(name.startsWith('thigh')&&y>.86){
      const thigh=skin.getX(i),t=clamp((1.08-y)/.22),blend=t*t*(3-2*t);
      skin.setXYZW(i,rig.idx.pelvis,thigh,0,0);weights.setXYZW(i,1-blend,blend,0,0);
      continue;
    }
    let upper,lower,center;
    if(name.startsWith('farm')) {
      lower=skin.getX(i);upper=rig.idx['uarm'+name.slice(-1)];center=rig.at[lower][1];
    } else if(name==='chest' && weights.getX(i)<.001 && rig.names[skin.getY(i)].startsWith('uarm')) {
      upper=skin.getY(i);lower=rig.idx['farm'+rig.names[upper].slice(-1)];center=rig.at[lower][1];
    } else if(name.startsWith('thigh')||name.startsWith('shin')) {
      upper=rig.idx['thigh'+name.slice(-1)];lower=rig.idx['shin'+name.slice(-1)];center=rig.at[lower][1];
    } else continue;
    if(Math.abs(y-center)>.12)continue;
    const t=clamp((center+.1-y)/.2),blend=t*t*(3-2*t);
    skin.setXYZW(i,upper,lower,0,0);weights.setXYZW(i,1-blend,blend,0,0);
  }
  skin.needsUpdate=weights.needsUpdate=true;
}

export function tailorKillerClothes(figure) {
  const rig = figure.rig, cloth = figure.meshes.find(m => m.name === 'killer-cloth');
  const old = cloth.geometry, p = old.attributes.position, si = old.attributes.skinIndex;
  const torso = new Set(['pelvis', 'spine', 'chest'].map(n => rig.idx[n]));
  const keep = [];
  for (let i = 0; i < p.count; i++) {
    const bone = rig.names[si.getX(i)];
    if (torso.has(si.getX(i)) || bone.startsWith('uarm')) continue;
    keep.push(i);
    const at = rig.at[si.getX(i)], x = p.getX(i) - at[0], z = p.getZ(i) - at[2];
    const factor = bone.startsWith('farm') ? .75 : bone.startsWith('thigh') ? .77 : .81;
    const y = p.getY(i), crease = .992 + .025 * Math.sin(y * 42 + Math.atan2(x, z) * 3);
    p.setXYZ(i, at[0] + x * factor * crease, y, at[2] + z * factor * crease);
  }
  const fitted = clothTorso(rig), merged = new THREE.BufferGeometry();
  for (const name of Object.keys(old.attributes)) {
    const a = old.attributes[name], b = fitted.attributes[name], values = [];
    for (const i of keep) for (let j = 0; j < a.itemSize; j++) values.push(a.array[i * a.itemSize + j]);
    values.push(...b.array);
    merged.setAttribute(name, name === 'skinIndex' ? new THREE.Uint16BufferAttribute(values, a.itemSize) : new THREE.Float32BufferAttribute(values, a.itemSize));
  }
  softenClothJoints(merged,rig);
  merged.computeVertexNormals(); merged.computeBoundingSphere();
  cloth.geometry = merged; old.dispose(); fitted.dispose();
  const hard = figure.meshes.find(m => m.name === 'killer-hard').geometry;
  const hp = hard.attributes.position, hs = hard.attributes.skinIndex;
  for (let i = 0; i < hp.count; i++) {
    const name = rig.names[hs.getX(i)], at = rig.at[hs.getX(i)];
    if (name === 'chest') {
      const shape = profile(hp.getY(i)), x = hp.getX(i) * .9;
      hp.setXYZ(i, x, hp.getY(i), shape.rz * Math.sqrt(Math.max(0, 1 - (x / shape.rx) ** 2)) + .01 + (hp.getZ(i) - .342));
    } else if (/^(hand|shin|foot)/.test(name)) {
      const factor = name.startsWith('hand') ? .84 : .86;
      hp.setX(i, at[0] + (hp.getX(i) - at[0]) * factor);
      hp.setZ(i, at[2] + (hp.getZ(i) - at[2]) * factor);
    }
  }
  hp.needsUpdate = true; hard.computeVertexNormals(); hard.computeBoundingSphere();
}
