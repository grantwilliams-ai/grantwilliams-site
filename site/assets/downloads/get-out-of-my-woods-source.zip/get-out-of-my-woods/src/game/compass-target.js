// Small rules shared by the app and its tests, kept free of three.js so Node can load them.
import { CAR } from '../sim/layout.js';

// The place the compass marks: the car, whenever the objective is the car. While things are still
// missing there is no one place to point at, and the tape alone gives the signposts their meaning.
export const COMPASS_TARGET = (s) => {
  if (s.phase === 'intro') return CAR;
  if (s.phase !== 'play' || !s.has.keys || (!s.has.battery && !s.batteryIn)) return null;
  return s.batteryIn ? CAR.door : CAR.hood;
};

// How near he is, for the sound mix: 0 beyond 32 m, 1 inside 8 m.
export const THREAT_NEAR = (distance) => Math.max(0, Math.min(1, 1 - (distance - 8) / 24));

// The two lines that close the opening. A container can be searched before the hunt starts, so by
// then she may already hold the keys or the battery: each line names only what is still missing.
const STILL_MISSING = (s) => ({ keys: !s?.has?.keys, battery: !s?.has?.battery && !s?.batteryIn });
export const CAR_REVEAL_LINE = (s) => {
  const m = STILL_MISSING(s);
  if (m.keys && m.battery) return 'Somebody took your battery and your keys. Find them. Get out.';
  if (m.battery) return 'Somebody took your battery. Find it. Get out.';
  if (m.keys) return 'Somebody took your keys. Find them. Get out.';
  return 'Somebody has been at your car. Put the battery in. Get out.';
};
export const HUNT_LINE = (s) => {
  const m = STILL_MISSING(s);
  if (m.keys && m.battery) return 'You are not alone. Find your keys and a battery. Get out.';
  if (m.battery) return 'You are not alone. Find a battery. Get out.';
  if (m.keys) return 'You are not alone. Find your keys. Get out.';
  return 'You are not alone. Get to your car. Get out.';
};
