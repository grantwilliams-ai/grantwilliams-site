// Small rules shared by the app and its tests, kept free of three.js so Node can load them.
import { CAR } from '../sim/layout.js';

// The place the compass marks: the car, whenever the objective is the car. While things are still
// missing there is no one place to point at, and the tape alone gives the signposts their meaning.
export const COMPASS_TARGET = (s) => {
  if (s.phase === 'intro') return CAR;
  if (s.phase !== 'play' || !s.has.keys || (!s.has.battery && !s.batteryIn)) return null;
  return s.batteryIn ? CAR.door : CAR.hood;
};

// How near he is, for the sound mix: 0 beyond 32 m, 1 inside 8 m.
export const THREAT_NEAR = (distance) => Math.max(0, Math.min(1, 1 - (distance - 8) / 24));
