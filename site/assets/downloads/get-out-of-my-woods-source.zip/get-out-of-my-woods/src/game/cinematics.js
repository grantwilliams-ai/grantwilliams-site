// The moments that are a film rather than a game: the title shot, the opening walk with its credits,
// the windshield, the engine that will not catch, the drive out, the dawn.
import * as THREE from 'three';
import { canvasTexture } from '../render/textures.js';
import { CAR, LAYOUT, localToWorld } from '../sim/layout.js';
import { heightAt, surfaceY } from '../sim/terrain.js';
import { audio } from '../audio/index.js';
import { Timeline } from './timeline.js';

const OPENING_CREDITS = [
  { at: 2.5, text: 'CAMP STILLWATER, 1984', hold: 4 },
  { at: 8, text: 'Last night of the season.', hold: 4 },
  { at: 14, text: 'The last bus left at sundown.', hold: 4 },
  { at: 20, text: 'You stayed behind to lock up.', hold: 4 },
];

const lerp = (a, b, t) => a + (b - a) * t;
const ease = (t) => t * t * (3 - 2 * t);

const HOOD_OPEN = -1.05;

function setHood(app, open) {
  const pivot = app.world.car?.userData.hoodPivot;
  if (pivot) pivot.rotation.x = open ? HOOD_OPEN : 0;
}

export class Cinematics {
  constructor(app) {
    this.app = app;
    this.tl = null;
    this.blocking = false;
    this.showKiller = false;
    this.watch = null;
  }

  // The drive and the dawn move the wagon; put it back where it belongs for the next night.
  restoreCar() {
    const app = this.app;
    const car = app.world.car;
    if (car && car.parent !== app.world.root) app.world.root.add(car);
    if (car) {
      car.position.set(CAR.x, surfaceY(CAR.x, CAR.z), CAR.z);
      car.rotation.y = CAR.rot;
      car.userData?.setHeadlights?.(false);
      setHood(app, !!app.sim && app.sim.phase !== 'intro');
    }
    if (app.camera.parent !== app.mainScene) app.mainScene.add(app.camera);
    // The dawn scene is built fresh each escape. Nothing of it may outlive the morning.
    this.dawnScene?.traverse((o) => {
      o.geometry?.dispose();
      o.material?.map?.dispose();
      o.material?.dispose();
      o.dispose?.();
    });
    this.dawnScene = null;
    this.engineLoop?.stop?.();
    this.engineLoop = null;
  }

  // A pause hides the title card. Resuming inside its three seconds shows it again for the time left.
  resumeCard() {
    const c = this.card;
    if (!c || !this.tl || c.tl !== this.tl || this.tl.done) return;
    const left = c.until - this.tl.t;
    if (left > 0.2) this.app.ui.showTitleCard(c.text, { seconds: left, animate: false });
  }

  openHood() {
    setHood(this.app, true);
  }

  clear() {
    this.tl = null;
    this.blocking = false;
    this.showKiller = false;
    this.hidePlayer = false;
    this.watch = null;
    this.title = false;
    this.app.post.uLetterbox.value = 0;
  }

  update(dt) {
    if (this.title) this.updateTitle(dt);
    if (this.watch) this.updateWatcher(dt);
    if (this.tl) {
      const active = this.tl;
      active.update(dt);
      if (this.tl === active && active.done) this.tl = null;
    }
  }

  // Behind the title screen: the road through the fog, and someone standing on it.
  titleShot() {
    const app = this.app;
    this.title = true;
    this.titleT = 0;
    app.killer.root.visible = true;
    app.playerFig.root.visible = false;
    app.flash.setOn(false);
    app.flash.update(0.016, new THREE.Vector3(0, -50, 0), new THREE.Vector3(0, 0, 1), 0);
    app.killer.root.position.set(38, surfaceY(38, 7.5), 7.5);
    app.killer.root.rotation.y = -Math.PI / 2;
    app.killer.setAnim?.('idle');
    app.stormNow = 0;
    app.post.uDanger.value = 0;
    app.post.uTear.value = 0;
    app.post.uFlash.value = 0;
    app.post.uRed.value = 0;
    app.post.uDesat.value = 0;
  }

  updateTitle(dt) {
    const app = this.app;
    this.titleT += dt;
    const t = this.titleT;
    const x = 23 + Math.min(t, 120) * 0.06;
    const cam = app.camera;
    app.post.uFade.value = 1;
    cam.fov = 40;
    cam.updateProjectionMatrix();
    cam.position.set(x, surfaceY(x, 8) + 1.5, 8.2 + Math.sin(t * 0.15) * 0.25);
    // On a wide screen he stands to the right of the words; on a tall one, under them. A sideways
    // phone has its buttons down the right, so there he stands in the gap between words and buttons.
    const sidewaysPhone = cam.aspect > 1.1 && (globalThis.innerHeight || 720) <= 460;
    cam.lookAt(38, surfaceY(38, 7.5) + 1.4, sidewaysPhone ? 6 : cam.aspect > 1.1 ? 1.4 : 7.6);
    app.killer.update?.(dt, { speed: 0, anim: 'idle' });
  }

  // First night only: credits over the walk. The physical roadside lurker owns his position.
  opening() {
    const app = this.app;
    // Credits, not lines to recall: they stay out of the pause screen's recent lines.
    this.tl = new Timeline(OPENING_CREDITS.map((c) => ({ at: c.at, fn: () => app.ui.caption(c.text, c.hold, { keep: false }) })));
  }

  // He is simply there, far off in the trees, watching. Nothing can hurt the player yet.
  placeWatcher() {
    const app = this.app;
    const sim = app.sim;
    if (!sim || sim.phase !== 'intro') return;
    const p = sim.player;
    // Ahead and to one side of the walk toward the car, at the edge of what the fog allows.
    const f = Math.atan2(CAR.x - p.x, CAR.z - p.z);
    const a = f + (Math.random() < 0.5 ? -1 : 1) * (0.42 + Math.random() * 0.2);
    const r = 30;
    const x = p.x + Math.sin(a) * r, z = p.z + Math.cos(a) * r;
    sim.killer.x = x;
    sim.killer.z = z;
    sim.killer.yaw = a + Math.PI;
    app.killer.root.position.set(x, surfaceY(x, z), z);
    app.killer.root.rotation.y = a + Math.PI;
    app.killer.root.visible = true;
    app.killer.setAnim?.('standStill');
    this.showKiller = true;
    this.watch = { t: 0, x, z };
  }

  updateWatcher(dt) {
    const app = this.app;
    const sim = app.sim;
    const w = this.watch;
    if (!sim || sim.phase !== 'intro') {
      this.watch = null;
      return;
    }
    w.t += dt;
    app.killer.update?.(dt, { speed: 0, anim: 'standStill' });
    const p = sim.player;
    const d = Math.hypot(w.x - p.x, w.z - p.z);
    // Is the camera turned away? Then he can be gone when the player looks back.
    const cam = app.camera;
    const dirx = w.x - cam.position.x, dirz = w.z - cam.position.z;
    const l = Math.hypot(dirx, dirz) || 1;
    const facing = (Math.sin(app.rig.yaw) * dirx + Math.cos(app.rig.yaw) * dirz) / l;
    if ((w.t > 7 && facing < 0.35) || d < 19 || w.t > 22) {
      if (d < 19 || facing >= 0.35) {
        // Looked straight at: the fog takes him, a step at a time, the only way he can leave in view.
        w.leaving = true;
      }
      if (facing < 0.35 || w.leaving) {
        if (facing < 0.35 || w.fadeT > 1.2) {
          app.killer.root.visible = false;
          this.showKiller = false;
          this.watch = null;
          sim.killer.x = -92;
          sim.killer.z = -66;
          return;
        }
        w.fadeT = (w.fadeT || 0) + dt;
      }
    }
  }

  // Keep the hood closed for the windshield message, then open it on the return to gameplay.
  carReveal() {
    const app = this.app;
    const sim = app.sim;
    const post = app.post;
    const cam = app.camera;
    this.blocking = true;
    this.watch = null;
    this.showKiller = false;
    app.killer.root.visible = false;
    app.ui.setPrompt(null);
    app.ui.setTouchVisible(false);
    app.flash.showBeam = true;
    setHood(app, false);
    audio.ambience('none');
    const car = CAR;
    // In world terms the car faces +x. Stand off its front left corner, low.
    const y = heightAt(car.x, car.z);
    const fromA = new THREE.Vector3(car.x + 8.5, y + 0.9, car.z + 3.5);
    const toA = new THREE.Vector3(car.x + 4.1, y + 1.25, car.z + 0.7);
    const lookAt = new THREE.Vector3(car.x + 1.1, y + 1.28, car.z);
    this.tl = new Timeline(
      [
        { at: 0, fn: () => { post.uTear.value = 0.5; app.ui.setObjective?.(''); audio.sfx('wood_crack', { volume: 0.2 }); } },
        {
          at: 4.2,
          fn: () => {
            audio.sfx('stinger_title', {});
            post.uTear.value = 1;
            this.card = { tl: this.tl, text: 'GET OUT OF MY WOODS', until: 7.2 };
            app.ui.showTitleCard(this.card.text);
          },
        },
        {
          at: 8.2,
          fn: () => {
            app.seenHunt = true;
            sim.beginHunt();
            setHood(app, true);
            this.blocking = false;
            app.ui.setTouchVisible(app.touchControls);
            app.rig.first = true;
            post.uLetterbox.value = 0;
            post.uTear.value = 0.4;
            audio.ambience('forest');
            audio.sfx('fork_ting', { volume: 0.5 });
            app.ui.caption('Somebody took your battery and your keys. Find them. Get out.', 6);
          },
        },
      ],
      (t) => {
        post.uLetterbox.value = t >= 8.2 ? 0 : Math.min(1, t * 2);
        const k = ease(Math.min(1, t / 4.2));
        cam.position.lerpVectors(fromA, toA, k);
        cam.fov = 44;
        cam.lookAt(lookAt);
        cam.updateProjectionMatrix();
      },
    );
  }

  // A hard cut, the way a film would do it: his face, upside down, an arm's length away.
  bodyCut(x, floor, z, yaw) {
    const app = this.app;
    const cam = app.camera;
    this.blocking = true;
    app.ui.setPrompt(null);
    app.ui.setTouchVisible(false);
    app.flash.showBeam = false;
    this.hidePlayer = true; // the lens is about where she is standing
    const fx = Math.sin(yaw), fz = Math.cos(yaw);
    const from = new THREE.Vector3(x + fx * 1.25, floor + 0.8, z + fz * 1.25);
    const lamp = new THREE.Vector3(x + fx * 1.7 - fz * 0.5, floor + 1.25, z + fz * 1.7 + fx * 0.5);
    const face = new THREE.Vector3(x, floor + 0.8, z);
    const head = new THREE.Vector3();
    const dir = new THREE.Vector3();
    this.tl = new Timeline(
      [{
        at: 1.9,
        fn: () => {
          this.blocking = false;
          app.flash.showBeam = true;
          this.hidePlayer = false;
          app.rig.first = true;
          app.ui.setTouchVisible(app.touchControls);
        },
      }],
      (t, dt) => {
        // The camera lets him swing a little before it follows, then creeps in.
        app.hanging.headAt(head);
        face.lerp(head, 1 - Math.exp(-dt * 9));
        cam.position.lerpVectors(from, face, Math.min(0.3, t * 0.14));
        cam.fov = 44;
        cam.lookAt(face.x, face.y - 0.08, face.z);
        cam.updateProjectionMatrix();
        dir.copy(face).sub(lamp).normalize();
        app.flash.setOn(true);
        app.flash.update(dt, lamp, dir, 0);
      },
    );
  }

  // Driver's seat, looking out through his own message. Turn the key.
  carScene() {
    const app = this.app;
    const sim = app.sim;
    const cam = app.camera;
    this.blocking = true;
    app.flash.showBeam = true;
    app.ui.setHide?.(null);
    app.ui.setTouchVisible(app.touchControls);
    app.playerFig.root.visible = false;
    app.ui.setCarMode(true);
    audio.setRoom('car');
    audio.sfx('car_door', {});
    app.world.setIndoor?.(null);
    app.post.uLetterbox.value = 0;
    const [sx, sz] = [CAR.x, CAR.z - 0.43]; // left seat; the car faces +x so left is -z
    const y = heightAt(CAR.x, CAR.z) + 1.2;
    this.carCam = { x: sx - 0.1, y, z: sz };
    // He comes out of the storm, straight down the road at the windshield.
    const k = sim.killer;
    k.state = 'wait';
    this.carKiller = { x: CAR.x + 30, z: CAR.z - 2, target: { x: CAR.x - 0.1, z: CAR.z - 2.2 } };
    app.killer.root.visible = true;
    app.killer.root.rotation.y = -Math.PI / 2;
    app.killer.setAnim?.('walk');
    this.shake = 0;
    this.tl = new Timeline([{ at: 999, fn: null }], (t, dt) => {
      const ck = this.carKiller;
      const c = this.carCam;
      // He covers the ground by the time the clock runs out.
      const left = 13 - sim.car.threat;
      const dx = ck.target.x - ck.x, dz = ck.target.z - ck.z, d = Math.hypot(dx, dz);
      const speed = d > 0.3 ? Math.max(1.8, d / Math.max(1, left - 1)) : 0;
      ck.x += (dx / (d || 1)) * speed * dt;
      ck.z += (dz / (d || 1)) * speed * dt;
      app.killer.root.position.set(ck.x, surfaceY(ck.x, ck.z), ck.z);
      app.killer.root.rotation.y = Math.atan2(dx, dz);
      app.killer.update?.(dt, { speed, anim: 'walk' });
      this.shake = Math.max(0, this.shake - dt * 2);
      const s = this.shake * 0.012;
      cam.position.set(c.x + (Math.random() - 0.5) * s, c.y + (Math.random() - 0.5) * s, c.z + (Math.random() - 0.5) * s);
      cam.fov = 66;
      cam.updateProjectionMatrix();
      cam.lookAt(c.x + 8, c.y - 0.1, c.z + 0.2);
    });
    this.tl.beats[0].fn = null;
    app.ui.caption('Come on. Come on.', 2.5);
  }

  crank(e) {
    audio.sfx('crank_fail', {});
    this.shake = 1;
    if (e.tries === e.need) this.app.post.uTear.value = 0.5;
  }

  crankFail(e) {
    const lines = ['It coughs and dies.', 'Almost. Again.', 'Please.'];
    this.app.ui.caption(lines[Math.min(e.tries - 1, lines.length - 1)], 1.6, { kind: 'urgent' });
  }

  // It catches. Everything happens at once.
  engineStart() {
    const app = this.app;
    const post = app.post;
    const cam = app.camera;
    const car = app.world.car;
    const y = heightAt(CAR.x, CAR.z);
    const ud = car?.userData ?? {};
    ud.setHeadlights?.(true);
    audio.sfx('engine_start', {});
    audio.music('finale');
    app.ui.setPrompt(null);
    app.ui.setInventory({});
    app.ui.setObjective?.('');
    app.ui.setTouchVisible(false);
    const engine = audio.loop('engine_rev', { volume: 0.9 });
    this.engineLoop = engine;
    post.uTear.value = 0.9;
    post.uFlash.value = 0.15;

    const startX = CAR.x;
    const gateX = 122;
    const carZ = CAR.z;
    const killerRoot = app.killer.root;
    let carX = startX, v = 0;
    const road = (x) => (x > 106 ? 0 : carZ + ((x - startX) / 10) * (0 - carZ));
    let shot = 0;
    const closeCall = this.carKiller && Math.hypot(this.carKiller.x - CAR.x, this.carKiller.z - CAR.z) < 5;
    const stare = new THREE.Vector3();
    const lampFrom = new THREE.Vector3(), lampDir = new THREE.Vector3(1, 0, 0);
    let staring = false;

    // The camp is short. 26 m to the gate at this pull: he is in the road at 2.5 s, hit at 3.4, the gate
    // goes at 4.4.
    const tl = new Timeline(
      [
        {
          at: 0.2,
          fn: () => {
            if (!closeCall) return;
            // The side window goes in as you pull out. Tines, glass, gone.
            audio.sfx('window_smash', {});
            audio.sfx('stinger_near', {});
            post.uTear.value = 1;
            this.shake = 1;
            app.killer.setAnim?.('strike');
          },
        },
        { at: 1.1, fn: () => { audio.sfx('tires_gravel', {}); shot = 1; killerRoot.visible = false; } },
        {
          at: 2.5,
          fn: () => {
            // He cannot be here. He is here.
            shot = 2;
            post.uTear.value = 0.5;
            killerRoot.visible = true;
            killerRoot.position.set(gateX - 9, surfaceY(gateX - 9, 0), 0);
            killerRoot.rotation.y = -Math.PI / 2;
            app.killer.setAnim?.('standStill');
          },
        },
        { at: 2.9, fn: () => app.killer.setAnim?.('raise') },
        {
          at: 3.4,
          fn: () => {
            audio.sfx('body_hit', {});
            audio.sfx('glass_smash', {});
            audio.sfx('stinger_jump', {});
            post.uFlash.value = 0.75;
            post.uTear.value = 1;
            this.shake = 1;
            killerRoot.visible = false;
          },
        },
        // Outside the gate, on the road, looking back: the lights come straight at us.
        { at: 3.75, fn: () => { shot = 3; } },
        {
          at: 4.42,
          fn: () => {
            audio.sfx('metal_crash', {});
            app.world.burstGate?.();
            post.uFlash.value = 0.4;
            post.uTear.value = 0.5;
          },
        },
        {
          at: 5.6,
          fn: () => {
            // Up the road behind them. The sound of the engine goes, and he gets up.
            shot = 4;
            engine?.setVolume?.(0.25);
            killerRoot.visible = true;
            killerRoot.position.set(gateX - 5, surfaceY(gateX - 5, 0), 0.6);
            killerRoot.rotation.y = Math.PI / 2;
            app.killer.setAnim?.('rise');
          },
        },
        { at: 8.6, fn: () => { app.killer.setAnim?.('listen'); audio.sfx('fork_ting', { volume: 0.7 }); } },
        { at: 9.3, fn: () => { staring = true; } },
        { at: 10.4, fn: () => { engine?.stop?.(); } },
        { at: 11.3, fn: () => this.finishDrive() },
      ],
      (t, dt) => {
        v = Math.min(21, v + dt * 2.4);
        carX += v * dt;
        const cz = road(carX);
        if (car) {
          car.position.x = carX;
          car.position.z = cz;
          car.position.y = heightAt(carX, cz) + (shot >= 1 ? Math.sin(t * 34) * 0.012 : 0);
        }
        (ud.wheels || []).forEach((w) => (w.rotation.x += v * dt * 2.6));
        // The flashlight's lamp does the headlights' work: same light, no new shader.
        app.flash.setOn(carX < gateX + 12);
        lampFrom.set(carX + 2.5, heightAt(carX, cz) + 0.85, cz);
        lampDir.set(1, shot === 2 ? 0.07 : 0.0, cz < -0.2 ? 0.08 : 0);
        app.flash.update(dt, lampFrom, lampDir, 0);
        // At the very end he turns his head and looks at us.
        stare.copy(cam.position);
        app.killer.update?.(dt, staring ? { speed: 0, lookAt: stare } : { speed: 0 });
        post.uFade.value = t > 10.3 ? Math.max(0, 1 - (t - 10.3) / 0.9) : 1;
        this.shake = Math.max(0, this.shake - dt * 2);
        const s = this.shake * 0.02;

        if (shot === 0) {
          const c = this.carCam;
          cam.position.set(c.x + (carX - startX), c.y, c.z + (cz - carZ));
          cam.fov = 66;
          cam.lookAt(cam.position.x + 8, c.y - 0.1, c.z + 0.2);
        } else if (shot === 1) {
          // Trailing behind and low, tail lights and rain.
          cam.fov = 58;
          cam.position.set(carX - 6.5, heightAt(carX - 6, cz) + 1.5, cz + 1.1);
          cam.lookAt(carX + 5, heightAt(carX, cz) + 1.1, cz);
        } else if (shot === 2) {
          // Off the hood, low: the words on the glass would hide him. This is the one time he stands
          // in full light, so make the most of it.
          cam.fov = 46;
          cam.position.set(carX + 2.7, heightAt(carX, cz) + 1.02 + (Math.random() - 0.5) * s, cz + 0.3 + (Math.random() - 0.5) * s);
          cam.lookAt(gateX - 9, surfaceY(gateX - 9, 0) + 1.55, 0);
        } else if (shot === 3) {
          cam.fov = 50;
          cam.position.set(gateX + 7.2, surfaceY(gateX + 7, 2) + 0.9, 2.3);
          cam.lookAt(gateX - 3, surfaceY(gateX - 3, 0) + 1.1, -0.2);
        } else if (shot === 4) {
          cam.fov = 40;
          cam.position.set(gateX - 15, surfaceY(gateX - 15, 0) + 0.45, 0.9);
          cam.lookAt(gateX - 5, surfaceY(gateX - 5, 0) + 1.05, 0.6);
        }
        cam.updateProjectionMatrix();
        audio.setListener(cam.position.x, cam.position.y, cam.position.z, 1.57);
      },
    );
    this.tl = tl;
  }

  finishDrive() {
    if (!this.app.completeActOne?.()) this.dawn();
  }

  dawn() {
    const app = this.app;
    const post = app.post;
    const cam = app.camera;
    audio.ambience('none');
    audio.music('dawn');
    audio.setRoom('outside');
    // A small separate picture: the wagon on an empty highway, sunrise behind the pines.
    const scene = new THREE.Scene();
    const sky = new THREE.Color(0xe08a5c);
    scene.background = sky;
    scene.fog = new THREE.FogExp2(0xe9a47b, 0.012);
    scene.add(new THREE.HemisphereLight(0xffd2b0, 0x402a28, 2.4));
    const sun = new THREE.DirectionalLight(0xffc088, 2.4);
    sun.position.set(40, 16, -30);
    scene.add(sun);
    const road = new THREE.Mesh(new THREE.PlaneGeometry(9, 900), new THREE.MeshLambertMaterial({ color: 0x3a3535 }));
    road.rotation.x = -Math.PI / 2;
    const dirt = new THREE.Mesh(new THREE.PlaneGeometry(900, 900), new THREE.MeshLambertMaterial({ color: 0x52402f }));
    dirt.rotation.x = -Math.PI / 2;
    dirt.position.y = -0.05;
    scene.add(road, dirt);
    for (let i = -40; i < 40; i++) {
      const line = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 3), new THREE.MeshBasicMaterial({ color: 0xcdbb77 }));
      line.rotation.x = -Math.PI / 2;
      line.position.set(0, 0.02, i * 8);
      scene.add(line);
    }
    const tree = new THREE.ConeGeometry(2.2, 12, 6).translate(0, 6, 0);
    const treeMat = new THREE.MeshLambertMaterial({ color: 0x241a1e, flatShading: true });
    const trees = new THREE.InstancedMesh(tree, treeMat, 260);
    const m = new THREE.Matrix4();
    for (let i = 0; i < 260; i++) {
      const side = i % 2 ? 1 : -1;
      const s = 0.8 + Math.random() * 0.9;
      m.makeScale(s, s, s);
      m.setPosition(side * (9 + Math.random() * 46), 0, (i / 260) * 620 - 400 + Math.random() * 8);
      trees.setMatrixAt(i, m);
    }
    scene.add(trees);
    // The sun, low, at the end of the road.
    const sunTex = canvasTexture(128, (c, n) => {
      const g = c.createRadialGradient(n / 2, n / 2, 0, n / 2, n / 2, n / 2);
      g.addColorStop(0, 'rgba(255,240,205,1)');
      g.addColorStop(0.16, 'rgba(255,226,170,1)');
      g.addColorStop(0.2, 'rgba(255,190,120,0.55)');
      g.addColorStop(1, 'rgba(255,150,90,0)');
      c.clearRect(0, 0, n, n);
      c.fillStyle = g;
      c.fillRect(0, 0, n, n);
    });
    const sunDisc = new THREE.Mesh(
      new THREE.PlaneGeometry(190, 190),
      new THREE.MeshBasicMaterial({ map: sunTex, transparent: true, fog: false, depthWrite: false }),
    );
    sunDisc.position.set(-4, 16, -395);
    scene.add(sunDisc);
    const wagon = app.world.car;
    if (wagon) {
      wagon.position.set(1.6, 0, -6);
      wagon.rotation.y = Math.PI;
      scene.add(wagon);
    }
    scene.add(cam); // three only refreshes a parented camera through the scene it is in
    app.scene = scene;
    this.dawnScene = scene;
    let z = 0;
    this.tl = new Timeline(
      [
        { at: 1.2, fn: () => { app.ui.caption('Morning.', 3); } },
        { at: 6.2, fn: () => app.win() },
      ],
      (t, dt) => {
        post.uFade.value = Math.min(1, t / 2);
        post.uLetterbox.value = 1;
        post.uTear.value = 0;
        z += dt * 4.6;
        // Set all of it: the drive-out's last frame ran after this scene was built and moved the wagon.
        if (wagon) wagon.position.set(1.6, 0, -6 - z);
        cam.fov = 42;
        cam.position.set(3.4, 1.15, 6);
        cam.lookAt(1.2, 1.2, -8 - z * 0.6);
        cam.updateProjectionMatrix();
      },
    );
  }
}
