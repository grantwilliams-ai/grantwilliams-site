// The one body in the camp. It comes down on a rope when you have stopped expecting anything.
import * as THREE from 'three';
import { lit } from '../render/materials.js';

const TOP = 2.35; // rope knot above the floor, under the lowest ceiling in camp

export class HangingBody {
  constructor(scene, figure, blood) {
    this.fig = figure;
    this.blood = blood;
    this.pivot = new THREE.Group();
    this.pivot.visible = false;
    const rope = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 3, 4), lit({ color: 0x8a7650 }));
    rope.position.y = 1.5;
    this.pivot.add(rope);
    figure.root.rotation.x = Math.PI;
    this.pivot.add(figure.root);
    scene.add(this.pivot);
    this.on = false;
  }

  start(x, floor, z, yaw) {
    this.on = true;
    this.x = x;
    this.z = z;
    this.floor = floor;
    this.yaw = yaw;
    this.t = 0;
    this.bounce = 0;
    this.bounceV = 0;
    this.swing = 0.2;
    this.swingV = 0;
    this.snapped = false;
    this.dripT = 0.3;
    this.pivot.position.set(x, floor + TOP, z);
    this.pivot.visible = true;
    this.fig.setAnim('hang', { fade: 0 });
    this.blood.decal({ x, y: floor, z }, 0.3);
  }

  headAt(v) {
    return this.fig.rig.b('head').getWorldPosition(v);
  }

  reset() {
    this.on = false;
    this.pivot.visible = false;
  }

  update(dt, player) {
    if (!this.on) return;
    this.t += dt;
    const fall = Math.max(0, 1 - this.t / 0.3);
    if (fall === 0 && !this.snapped) {
      this.snapped = true;
      this.bounceV = -2.6;
    }
    this.bounceV += (-this.bounce * 110 - this.bounceV * 6) * dt;
    this.bounce += this.bounceV * dt;
    this.swingV += (-this.swing * 7 - this.swingV * 0.25) * dt;
    this.swing += this.swingV * dt;
    // Walk into him and he swings away from you.
    const d = Math.hypot(player.x - this.x, player.z - this.z);
    if (d < 0.5 && player.speed > 0.5) this.swingV += (0.5 - d) * dt * 14;
    this.fig.root.position.y = this.bounce + fall * fall * 2.1;
    this.pivot.rotation.z = this.swing;
    // The rope turns him slowly, so his back comes round: STAFF, upside down.
    this.pivot.rotation.y = this.yaw + Math.PI + Math.sin(this.t * 0.17) * 2.2;
    this.fig.update(dt, { speed: 0 });
    this.dripT -= dt;
    if (this.dripT <= 0 && this.snapped) {
      this.dripT = 0.5 + Math.random() * 1.1;
      this.blood.drip({ x: this.x, y: this.floor + 0.55, z: this.z });
    }
  }
}
