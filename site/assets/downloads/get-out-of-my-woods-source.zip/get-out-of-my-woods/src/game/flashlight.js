// The flashlight: one real shadow-casting spot, a visible beam in the mist, and a nervous flicker
// when he is close. It is the player's only friend and it gives them away.
import * as THREE from 'three';
import { PALETTE } from '../render/palette.js';

const BEAM_VERT = /* glsl */ `
varying float vAlong; varying vec3 vN; varying vec3 vV;
void main() {
  vAlong = uv.y;
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  vN = normalize(normalMatrix * normal);
  vV = normalize(-mv.xyz);
  gl_Position = projectionMatrix * mv;
}`;
const BEAM_FRAG = /* glsl */ `
uniform vec3 uColor; uniform float uPower;
varying float vAlong; varying vec3 vN; varying vec3 vV;
void main() {
  float rim = pow(abs(dot(normalize(vN), normalize(vV))), 2.4);
  float fade = pow(vAlong, 1.8);
  gl_FragColor = vec4(uColor * rim * fade * uPower, 1.0);
}`;

export class Flashlight {
  constructor(scene, quality) {
    this.light = new THREE.SpotLight(PALETTE.flashlight, 90, 38, 0.46, 0.62, 1.55);
    this.light.castShadow = quality.shadowSize > 0;
    if (this.light.castShadow) {
      this.light.shadow.mapSize.set(quality.shadowSize, quality.shadowSize);
      this.light.shadow.camera.near = 0.3;
      this.light.shadow.camera.far = 34;
      this.light.shadow.bias = -0.0015;
    }
    scene.add(this.light, this.light.target);
    // A soft cone of lit mist. Length 9, pointing along -y in its own space before we aim it.
    const geo = new THREE.ConeGeometry(2.6, 9, 14, 1, true);
    geo.translate(0, -4.5, 0);
    this.beamMat = new THREE.ShaderMaterial({
      vertexShader: BEAM_VERT,
      fragmentShader: BEAM_FRAG,
      uniforms: { uColor: { value: new THREE.Color(PALETTE.flashlight) }, uPower: { value: 0.1 } },
      blending: THREE.AdditiveBlending,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    this.beam = new THREE.Mesh(geo, this.beamMat);
    this.beam.frustumCulled = false;
    this.beam.renderOrder = 5;
    scene.add(this.beam);
    this.on = true;
    this.flick = 1;
    this.flickT = 0;
    this.aim = new THREE.Vector3(0, -0.1, 1);
    this.tmp = new THREE.Vector3();
    this.up = new THREE.Vector3(0, -1, 0);
    this.power = 1; // lying in the dirt it is a dying glow, not a beam
    this.showBeam = true;
  }

  setOn(on) {
    this.on = on;
  }

  // danger 0..1: how close he is. The light starts to stutter, the player learns what that means.
  update(dt, from, dir, danger) {
    this.aim.lerp(dir, 1 - Math.exp(-dt * 16)).normalize();
    this.flickT -= dt;
    if (this.flickT <= 0) {
      this.flickT = 0.03 + Math.random() * 0.1;
      const stutter = danger > 0.45 && Math.random() < danger * 0.5;
      this.flick = stutter ? 0.1 + Math.random() * 0.5 : 0.97 + Math.random() * 0.03;
    }
    const lvl = this.on ? this.flick * this.power : 0;
    this.light.intensity = 90 * lvl;
    this.light.visible = true;
    this.light.position.copy(from);
    this.light.target.position.copy(from).add(this.tmp.copy(this.aim).multiplyScalar(10));
    this.beamMat.uniforms.uPower.value = 0.085 * lvl;
    this.beam.visible = this.showBeam && lvl > 0.01;
    this.beam.position.copy(from);
    this.beam.quaternion.setFromUnitVectors(this.up, this.aim);
  }
}
