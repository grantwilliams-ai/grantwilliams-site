// The running game: owns the renderer, world, figures, sound and interface, and keeps them in step
// with the simulation.
import * as THREE from 'three';
import { GameRenderer } from '../render/renderer.js';
import { PALETTE, MOON_DIR } from '../render/palette.js';
import { GLOBALS } from '../render/materials.js';
import { detectQuality } from '../core/quality.js';
import { buildWorld } from '../world/index.js';
import { createKiller, createPlayer, createVictim, createBlood, playDeath } from '../characters/index.js';
import { HangingBody } from './hanging.js';
import { Glints } from '../world/glints.js';
import { audio, WEATHER_DEFAULT } from '../audio/index.js';
import { createFootfallSync, readFootSoles } from '../audio/footfall-sync.js';
import { createUI } from '../ui/index.js';
import { resolveInputMode } from '../ui/input-mode.js';
import { GameSim, sharedWorld } from '../sim/game.js';
import { surfaceY, lakeField } from '../sim/terrain.js';
import { CAR, LAYOUT } from '../sim/layout.js';
import { CameraRig } from './camera.js';
import { Flashlight } from './flashlight.js';
import { Cinematics } from './cinematics.js';
import { polishKillerAppearance } from '../act2/killer.js';
import { createWallClearance } from '../characters/wall-clearance.js';
import { aimBeam } from '../core/beam.js';
import { COMPASS_TARGET, THREAT_NEAR } from './compass-target.js';

export const OBJECTIVE = (s) => {
  if (s.phase === 'intro') return 'Follow the road east to your car.';
  const need = [];
  if (!s.has.keys) need.push('your CAR KEYS');
  if (!s.has.battery && !s.batteryIn) need.push('a CAR BATTERY');
  if (need.length) return 'Find ' + need.join(' and ') + '.';
  if (!s.batteryIn) return 'Get to the car. Put the battery in.';
  return s.phase === 'car' ? '' : 'Get in the car.';
};

export class App {
  constructor({ campaign = null } = {}) {
    this.campaign = campaign;
    this.initializing = true;
    this.disposed = false;
    this.chapterComplete = false;
    this.playerFootfalls = createFootfallSync();
    this.thunderTimers = new Set(); // Remaining game-time delays, never wall-clock timers.
    this.quality = detectQuality();
    this.canvas = document.querySelector('#game canvas');
    this.renderer = new GameRenderer(this.canvas, this.quality);
    this.renderer.adaptiveSharp = !!campaign;
    this.post = this.renderer.post.uniforms;
    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2(PALETTE.fog, 0.024);
    this.scene.background = new THREE.Color(PALETTE.fog);
    this.camera = new THREE.PerspectiveCamera(60, 16 / 9, 0.08, 420);
    this.scene.add(this.camera);
    this.mainScene = this.scene;

    const { collision } = sharedWorld();
    this.world = buildWorld(this.scene, this.quality);
    this.killer = campaign ? polishKillerAppearance(createKiller()) : createKiller();
    this.killerClearance = campaign ? createWallClearance(this.killer) : null;
    this.playerFig = createPlayer();
    this.scene.add(this.killer.root, this.playerFig.root);
    this.blood = createBlood(this.scene);
    this.hanging = new HangingBody(this.scene, createVictim(), this.blood);
    this.glints = new Glints(this.scene);
    this.flash = new Flashlight(this.scene, this.quality);
    this.rig = new CameraRig(this.camera, collision);
    this.rig.touch = this.quality.isTouch;
    this.cine = new Cinematics(this);

    this.settings = { brightness: 1, sound: 0.9, steps: 0.45, weather: WEATHER_DEFAULT, picture: 'retro', tape: true, flashes: 'full', inputMode: 'auto', hints: true, compass: true };
    this.difficulty = 'normal';
    this.ui = createUI(document.getElementById('ui'), {
      campaign,
      onStart: (d) => this.startNight(d),
      onResume: () => this.resume(),
      onQuit: () => this.quitToTitle(),
      onRetry: () => this.startNight(this.difficulty, true),
      onSetting: (k, v) => this.setting(k, v),
    });
    // Shared campaign preferences win over this chapter's historical defaults.
    // UI receives the same object so its sliders and the running picture agree.
    for (const [key, value] of Object.entries(campaign?.preferences || {})) {
      const chapterKey = key === 'volume' ? 'sound' : key;
      if (['brightness', 'sound', 'steps', 'weather', 'picture', 'tape', 'flashes', 'inputMode', 'hints', 'compass'].includes(chapterKey)) this.setting(chapterKey, value);
    }
    this.initializing = false;

    this.audio = audio;
    this.state = 'title';
    this.sim = null;
    this.aim = new THREE.Vector3();
    this.from = new THREE.Vector3();
    this.seenHunt = false;
    this.deathSeq = null;
    this.frozen = false;
    this.last = performance.now();
    this.running = true;
    this.musicNow = '';
    this.musicHold = 0;
    this.objective = '';
    this.stormNow = 0;
    this.eyes = 1;
    this.tmpV = new THREE.Vector3();
    this.headTarget = new THREE.Vector3();

    this.onVisibilityChange = () => {
      if (document.hidden && (this.state === 'play' || this.state === 'dead')) this.pause();
    };
    document.addEventListener('visibilitychange', this.onVisibilityChange);
    this.onWindowBlur = () => {
      if (this.state === 'play' || this.state === 'dead') this.pause();
    };
    window.addEventListener('blur', this.onWindowBlur);
    this.renderer.onStruggling = () => {
      this.flash.light.castShadow = false;
      this.renderer.gl.shadowMap.enabled = false;
    };

    this.cine.titleShot();
    this.ui.showTitle();
    audio.music?.('title');
    this.onFrame = (t) => this.frame(t);
    this.raf = requestAnimationFrame(this.onFrame);
  }

  // Which controls the player is shown (touch buttons or keyboard help): the one input policy plus
  // the player's Settings choice. Render quality and the device's own camera feel stay with quality.isTouch.
  get touchControls() {
    return resolveInputMode(this.settings.inputMode) === 'touch';
  }

  setting(k, v) {
    if (this.disposed) return;
    this.settings[k] = v;
    switch (k) {
      case 'brightness': this.post.uBrightness.value = v; break;
      case 'sound': audio.setVolume(v); break;
      case 'weather': audio.setWeather?.(v); break;
      case 'picture': this.renderer.setSharp(v === 'sharp'); break;
      case 'tape': this.post.uVhs.value = v ? 0.08 : 0; break;
      case 'flashes': this.post.uFlashScale.value = v === 'full' ? 1 : 0.2; break;
      case 'difficulty': this.difficulty = v; break;
      case 'inputMode': this.refreshControls(); break;
      default: break;
    }
    if (!this.initializing) this.campaign?.onSetting?.(k === 'sound' ? 'volume' : k, v);
  }

  // A change of Settings -> Controls shown reaches the HUD at once. Only the touch layer is the app's
  // to decide; the key strip and the words follow the same setting inside the interface.
  refreshControls() {
    if (!this.ui || this.initializing || this.disposed) return;
    this.ui.setTouchVisible(this.state === 'play' && this.touchControls && (!this.cine.blocking || this.sim?.phase === 'car'));
  }

  // What the player is carrying: the battery leaves the pack once it is installed.
  inventoryView() {
    const has = this.sim?.has || {};
    return { keys: !!has.keys, battery: !!has.battery && !this.sim?.batteryIn };
  }

  startNight(difficulty, retry = false) {
    if (this.disposed) return;
    this.clearThunder();
    this.chapterComplete = false;
    if (this.campaign && !retry) this.seenHunt = false;
    audio.unlock();
    audio.resumeAll();
    this.difficulty = difficulty || this.difficulty;
    this.campaign?.onStart?.({ difficulty: this.difficulty, retry });
    this.sim = new GameSim({ difficulty: this.difficulty, skipIntro: this.seenHunt });
    this.resetVisuals();
    this.ui.hideAll();
    this.ui.setTouchVisible(this.touchControls);
    this.cine.clear();
    this.state = 'play';
    audio.ambience('forest');
    audio.music('none');
    audio.setRoom('outside');
    audio.setThreat?.(0);
    this.world.setIndoor(null);
    this.objective = '';
    if (this.sim.phase === 'intro') {
      this.cine.opening();
      this.ui.showControlsHint();
    }
    this.rig.snapBehind(this.sim.player.yaw);
    this.fireLoop?.stop?.();
    this.fireLoop = audio.loop('fire', { x: 0, y: 1, z: 8, volume: 0.8 });
    this.genLoop?.stop?.();
    this.genLoop = audio.loop('generator', { x: 72, y: 1, z: -42, volume: 0.7 });
    this.lapLoop?.stop?.();
    this.lapLoop = audio.loop('water_lap', { x: -30, y: 0, z: 42, volume: 0.8 });
  }

  resetVisuals() {
    const s = this.sim;
    this.pausedFrom = this.deathHide = null;
    this.killerClearance?.reset();
    this.deathSeq?.restore?.();
    this.deathSeq = null;
    this.cine.restoreCar();
    this.scene = this.mainScene;
    this.killer.setBloody?.(0);
    this.killer.setEyeGlint?.(0);
    this.killer.setAnim?.('idle');
    this.playerFig.setAnim?.('idle');
    this.playerFig.setWounded?.(false);
    this.ui.setPursuit?.('');
    this.ui.toast('');
    this.ui.clearCaptions?.({ keepRecent: false });
    this.ui.setKeyStrip?.(false);
    this.ui.setCompass?.(null);
    this.playerStepSide = 0;
    this.playerFootfalls?.reset();
    this.playerFig?.resetStance?.();
    this.killer?.resetStance?.();
    this.lastKillerAnim = this.lastPlayerAnim = 'idle';
    this.blood.clear();
    for (const d of LAYOUT.doors) this.world.setDoor(d.id, 0);
    this.flash.setOn(true);
    this.flash.power = 1;
    this.flash.showBeam = true;
    this.eyes = 1;
    this.stormOn = false;
    this.lastPrompt = undefined;
    this.playerFig.root.visible = true;
    this.killer.root.visible = s.phase === 'play';
    this.playerFig.setFlashlight?.(true);
    this.world.car?.userData.setBatteryVisible?.(false);
    this.world.car?.userData.setHeadlights?.(false);
    this.world.resetGate?.();
    this.world.clearStage();
    this.hanging.reset();
    this.glints.hide();
    this.ui.setFlashlight(true);
    this.ui.setCarMode(false);
    this.ui.setHide?.(null);
    const p = this.post;
    p.uRed.value = 0; p.uFlash.value = 0; p.uDesat.value = 0; p.uDanger.value = 0; p.uTear.value = 0; p.uLetterbox.value = 0; p.uFade.value = 1;
    this.frozen = false;
    this.stormNow = 0;
    this.ui.setInventory({ keys: false, battery: false });
  }

  pause() {
    if (this.state !== 'play' && this.state !== 'dead') return;
    this.pausedFrom = this.state;
    this.state = 'paused';
    this.playerFootfalls?.reset();
    audio.pauseAll();
    this.ui.showPause();
  }

  resume() {
    if (this.state !== 'paused') return;
    this.state = this.pausedFrom === 'dead' ? 'dead' : 'play';
    this.pausedFrom = null;
    this.ui.hideAll();
    this.ui.setTouchVisible(this.state === 'play' && this.touchControls && (!this.cine.blocking || this.sim?.phase === 'car'));
    const hideType = this.state === 'dead' ? this.deathHide : this.sim?.player.hidden?.type;
    if (hideType) this.ui.setHide(hideType);
    if (this.state === 'dead') this.ui.setPrompt(null);
    if (this.state === 'play') this.cine?.resumeCard?.();
    audio.resumeAll();
    this.last = performance.now();
  }

  quitToTitle() {
    if (this.disposed) return;
    this.pausedFrom = this.deathHide = null;
    this.killerClearance?.reset();
    this.playerFig?.resetStance?.();
    this.killer?.resetStance?.();
    this.clearThunder();
    this.state = 'title';
    this.cine.clear();
    this.deathSeq?.restore?.();
    this.deathSeq = null;
    this.cine.restoreCar();
    this.scene = this.mainScene;
    this.killer.setBloody?.(0);
    this.world.clearStage();
    this.world.resetGate();
    this.ui.setHide?.(null);
    this.sim = null;
    this.eyes = 1;
    this.post.uBrightness.value = this.settings.brightness;
    audio.setRoom?.('outside');
    for (const name of ['fireLoop', 'genLoop', 'lapLoop']) {
      this[name]?.stop?.();
      this[name] = null;
    }
    this.post.uRed.value = 0;
    this.post.uDesat.value = 0;
    this.post.uFade.value = 1;
    this.post.uLetterbox.value = 0;
    audio.ambience('forest');
    audio.setIntensity(0);
    audio.setThreat?.(0);
    audio.resumeAll();
    audio.music('title');
    this.world.setIndoor(null);
    this.cine.titleShot();
    this.ui.hideAll();
    this.ui.setTouchVisible(false);
    this.ui.showTitle();
  }

  frame(t) {
    if (!this.running || this.disposed) return;
    this.raf = requestAnimationFrame(this.onFrame);
    // Never negative: a resume can stamp `last` a little after the next frame's timestamp.
    const dt = Math.max(0, Math.min(0.05, (t - this.last) / 1000));
    this.last = t;
    if (this.fixedDt) this.tick(this.fixedDt);
    else this.tick(dt);
  }

  tick(dt) {
    if (this.disposed) return;
    // Esc pauses gameplay or a fatality, and resumes the same state.
    const raw = this.ui.input;
    if (raw.pausePressed) {
      raw.pausePressed = false;
      if (this.state === 'play' || this.state === 'dead') this.pause();
      else if (this.state === 'paused') this.resume();
    }
    if (raw.lockLost) {
      raw.lockLost = false;
      if (this.state === 'play') this.pause();
    }
    switch (this.state) {
      case 'play': this.tickPlay(dt); break;
      case 'dead': this.tickDead(dt); break;
      case 'paused': break;
      default: break;
    }
    this.tickThunder(dt);
    if (this.state !== 'paused') this.cine.update(dt);
    if (this.disposed) return;
    this.tickFx(dt);
    const subject = this.sim?.player;
    if (subject) {
      const enabled = (this.state === 'play' || this.state === 'paused') && !subject.hidden && !subject.inCar && !this.cine.hidePlayer;
      GLOBALS.uSubject.value.set(subject.x, subject.y + 1.42, subject.z, enabled ? 1 : 0);
    } else {
      GLOBALS.uSubject.value.w = 0;
    }
    this.world.update(dt, { time: this.renderer.time, camera: this.camera, playerPos: this.sim?.player ?? { x: 0, y: 0, z: 0 }, storm: this.stormNow });
    this.blood.update(this.state === 'paused' ? 0 : dt);
    if (this.state === 'play') this.hanging.update(dt, this.sim.player);
    this.renderer.render(this.scene, this.camera, this.state === 'paused' ? 0 : dt);
  }

  tickFx(dt) {
    const p = this.post;
    p.uTear.value = Math.max(0, p.uTear.value - dt * 1.6);
    p.uFlash.value = Math.max(0, p.uFlash.value - dt * 3.5);
    // Render the same physical leaf used by bodies, navigation and fork clearance.
    for (const d of this.sim?.collision.doors || []) this.world.setDoor(d.id, this.sim.collision.doorAmount(d));
  }

  tickPlay(dt) {
    const sim = this.sim;
    const ui = this.ui;
    const raw = ui.input;
    if (raw.quickTurnPressed) {
      raw.quickTurnPressed = false;
      if (!this.cine.blocking && !ui.mapOpen() && !sim.player.hidden && sim.phase !== 'car' && !this.rig.zone) {
        sim.player.yaw += Math.PI;
        this.rig.yaw += Math.PI;
        this.rig.moveYaw = this.rig.yaw;
        this.rig.first = true;
        audio.sfx('ui_click', { volume: 0.2, rate: 0.8 });
      }
    }
    if (raw.mapPressed) {
      raw.mapPressed = false;
      if (!this.cine.blocking && sim.phase !== 'car') {
        ui.showMap?.({ player: { x: sim.player.x, z: sim.player.z, yaw: sim.player.yaw }, searched: [...sim.searched] });
      }
    }
    const mapPaused = ui.mapOpen();
    // Caption time is game time: it runs only while the night runs (not paused, in settings, or on the map).
    if (!mapPaused) ui.tickMessages?.(dt);
    const paused = this.cine.blocking || mapPaused; // a cutscene owns the moment; he waits while you read the map
    const input = {
      moveX: paused ? 0 : raw.moveX,
      moveY: paused ? 0 : raw.moveY,
      lookX: paused ? 0 : raw.lookX,
      lookY: paused ? 0 : raw.lookY,
      camYaw: this.rig.moveYaw,
      run: raw.run,
      sneak: raw.sneak,
      action: raw.action,
      actionHeld: raw.actionHeld,
      flashlight: raw.flashlightPressed,
      // Hidden in brush: the way she is looking, which is the way she steps out.
      leaveYaw: sim.player.hidden?.type === 'bush' ? this.rig.hideYaw : undefined,
    };
    raw.lookX = 0;
    raw.lookY = 0;
    raw.action = false;
    raw.flashlightPressed = false;

    // Measure this simulation tick, not the AI's commanded speed: blocked
    // path/waypoint frames can retain that value for gameplay sound timing.
    const killerStartX = sim.killer.x, killerStartZ = sim.killer.z;
    if (!paused) sim.step(dt, input);
    else if (sim.phase === 'car') sim.step(dt, input);

    for (const e of sim.drainEvents()) this.onEvent(e);
    if (this.state !== 'play') return;

    const pl = sim.player;
    if (!paused && sim.phase !== 'car') {
      // F10: while the battery goes in, the camera turns to the hood instead of being pushed onto the player's back.
      this.rig.focus = sim.prompt?.kind === 'battery' && sim.holdT > 0 ? CAR.hood : null;
      this.rig.update(dt, pl, input);
      if (this.rig.justCut) this.onCut();
    }

    // The player figure.
    const fig = this.playerFig;
    fig.root.visible = !pl.hidden && !pl.inCar && (!!this.rig.zone || this.rig.dist > 0.9) && !this.cine.hidePlayer;
    fig.root.position.set(pl.x, pl.y, pl.z);
    fig.root.rotation.y = pl.yaw;
    const anim = pl.vaultT > 0 ? 'vault'
      : sim.holdT > 0 ? 'search'
      : pl.winded && pl.speed < 0.2 ? 'winded'
      : { idle: 'idle', sneak: 'sneak', walk: 'walk', run: 'run' }[pl.moveMode];
    const travelDriven = !this.cine.blocking;
    if (anim !== this.lastPlayerAnim || fig.animator?.cur?.opts?.travelDriven !== travelDriven) {
      fig.setAnim(anim, { travelDriven });
      this.lastPlayerAnim = anim;
    }
    fig.setWounded?.(!!pl.wounded);
    // The map already freezes the simulation. Keep the actors at that same
    // instant; cutscenes still advance their authored performances normally.
    const actorDt = mapPaused ? 0 : dt;
    fig.update(actorDt, { speed: pl.speed });
    fig.stabilizeStance?.(actorDt, { enabled: travelDriven &&
      (sim.phase === 'play' || sim.phase === 'intro') && !pl.hidden && !pl.inCar });
    this.playPlayerFootfall(actorDt, !paused && (sim.phase === 'play' || sim.phase === 'intro') &&
      !pl.hidden && !pl.inCar && !(pl.vaultT > 0));

    // The killer's figure.
    const k = sim.killer, kf = this.killer;
    if (k.state !== 'wait' || this.cine.showKiller) {
      if (k.state !== 'wait') kf.root.visible = true;
      kf.root.position.set(k.x, surfaceY(k.x, k.z), k.z);
      kf.root.rotation.y = k.yaw;
      if (k.anim !== this.lastKillerAnim) {
        kf.setAnim(k.anim);
        this.lastKillerAnim = k.anim;
      }
      // The head leads. When he has noticed you it is turned on you, and that is the warning.
      if (k.sees && k.awareness > 0.2) this.headTarget.set(pl.x, pl.y + 1.5, pl.z);
      else {
        const hy = k.yaw + k.headYaw;
        this.headTarget.set(k.x + Math.sin(hy) * 6, surfaceY(k.x, k.z) + 1.7, k.z + Math.cos(hy) * 6);
      }
      let renderSpeed = k.speed;
      if (!paused && (sim.phase === 'play' || sim.phase === 'intro')) {
        const travelled = Math.hypot(k.x - killerStartX, k.z - killerStartZ);
        renderSpeed = dt > 0 ? travelled / dt : 0;
        // Opening placement/scene seeks are not walking. Keep ordinary chase
        // and catch-up travel, including collision slides, at their real rate.
        if (!Number.isFinite(renderSpeed) || renderSpeed > 12) renderSpeed = 0;
      }
      kf.update(actorDt, { speed: renderSpeed, lookAt: this.headTarget });
      let contact = null;
      if (sim.phase === 'play' && !this.cine.blocking) {
        contact = this.killerContact = this.killerClearance?.apply(sim.collision, paused ? 0 : dt);
      }
      // Wall restraint owns the final validated pose near panels. Free-space
      // stance correction is allowed only after clearance reports no nearby wall.
      const openSpace = Math.max(0, Math.min(1, ((contact?.nearestWallDistance ?? Infinity) - 2.7) / 1.8));
      kf.stabilizeStance?.(actorDt, { strength: openSpace * openSpace * (3 - 2 * openSpace),
        enabled: !this.cine.blocking &&
        (sim.phase === 'play' || sim.phase === 'intro') &&
        !contact?.nearWalls && !contact?.weight && !contact?.shift });
    } else kf.resetStance?.();

    // The flashlight goes where the player is looking, and stutters when he is near.
    const danger = sim.intensity();
    const anchor = fig.flashlightAnchor;
    if (anchor) anchor.getWorldPosition(this.from);
    else this.from.set(pl.x, pl.y + 1.2, pl.z);
    if (!this.cine.blocking) this.flash.showBeam = !!pl.hidden;
    if (pl.hidden || pl.inCar) this.flash.setOn(false);
    else this.flash.setOn(pl.flashlight);
    fig.setFlashlight?.(pl.flashlight);
    this.world.setFlashlight?.(pl.flashlight && !pl.hidden && !pl.inCar);
    if (this.rig.zone || this.quality.isTouch) {
      this.aim.set(Math.sin(pl.yaw), -0.14, Math.cos(pl.yaw));
    } else {
      const c = Math.cos(this.rig.pitch), yaw = this.beam = aimBeam(this.beam, pl.yaw, this.rig.yaw, pl.speed > 0.3, dt);
      this.aim.set(Math.sin(yaw) * c, Math.sin(this.rig.pitch) - 0.02, Math.cos(yaw) * c);
    }
    // Right up against a trunk the beam would burn to white. Ease it down.
    let throwTo = 1;
    for (let t = 0.7; t < 4.5; t += 0.9) {
      if (sim.collision.blocked(this.from.x + this.aim.x * t, this.from.z + this.aim.z * t, 0.12, true)) {
        throwTo = 0.1 + t * t * 0.05;
        break;
      }
    }
    this.flash.power += (throwTo - this.flash.power) * (1 - Math.exp(-dt * 9));
    this.flash.update(dt, this.from, this.aim, this.settings.flashes === 'full' ? danger : 0);
    fig.setAim?.(this.rig.zone ? 0 : this.rig.pitch);
    this.glints.update(this.renderer.time, this.from, this.aim, pl.flashlight && !pl.hidden && !pl.inCar && sim.phase === 'play', sim.searched,
      this.renderer.target.height / this.renderer.gl.domElement.height);

    // Two pinpricks in the eye holes when the beam finds him.
    if (kf.setEyeGlint) {
      const toK = this.tmpV.set(k.x - pl.x, 0, k.z - pl.z);
      const d = toK.length();
      toK.normalize();
      const lit = pl.flashlight && d < 26 ? Math.max(0, toK.x * this.aim.x + toK.z * this.aim.z - 0.86) * 8 : 0;
      kf.setEyeGlint(Math.min(1, lit));
    }

    // Eyes adjust in the dark of a hiding place. You need to see him through the slats.
    this.eyes += ((pl.hidden ? 2.1 : 1) - this.eyes) * (1 - Math.exp(-dt * 2.5));
    this.post.uBrightness.value = this.settings.brightness * this.eyes;

    // Sound and the mood of the night.
    this.stormNow = sim.storm;
    audio.setListener(this.camera.position.x, this.camera.position.y, this.camera.position.z, this.rig.yaw);
    audio.setIntensity(danger);
    // Rain and wind sink a little as he closes in, so his steps always carry through the storm.
    audio.setThreat?.(['wait', 'lurk', 'kill'].includes(k.state) ? 0 : THREAT_NEAR(Math.hypot(k.x - pl.x, k.z - pl.z)));
    this.post.uDanger.value += (Math.max(0, danger - 0.45) * 1.1 - this.post.uDanger.value) * (1 - Math.exp(-dt * 4));
    this.updateMusic(dt, sim);
    if (sim.storm > 0.5 && !this.stormOn) {
      this.stormOn = true;
      audio.ambience('storm');
    }

    // Text on the screen.
    const obj = sim.phase === 'escaped' || (this.cine.blocking && sim.phase !== 'car') ? '' : OBJECTIVE(sim);
    if (obj !== this.objective) {
      this.objective = obj;
      ui.setObjective(obj);
    }
    ui.setPursuit?.(!paused && sim.phase === 'play' ? (pl.hidden && pl.seenEntering ? 'hideSeen' : sim.pursuitStatus?.()) : '');
    const live = sim.phase === 'play' || sim.phase === 'intro';
    const pr = sim.phase === 'car' ? (sim.car.crank > 0 ? null : 'TURN KEY') : live && !paused ? sim.prompt?.label ?? null : null;
    if (pr !== this.lastPrompt) {
      ui.setPrompt(pr, !!sim.prompt?.hold);
      this.lastPrompt = pr;
    }
    ui.setHold(sim.prompt?.hold ? sim.holdT / sim.prompt.hold : 0);
    ui.setStamina(pl.stamina, pl.moveMode === 'run' || pl.winded || pl.stamina < 0.98);
    ui.setRun?.(!!input.run && !pl.hidden && !pl.inCar, pl.winded);
    // The key reminder stays up in ordinary play; films, the car and hiding views take it away.
    const ordinary = !this.cine.blocking && sim.phase !== 'car' && !pl.hidden && !pl.inCar && sim.phase !== 'escaped';
    ui.setKeyStrip?.(ordinary);
    // The compass reads the way the picture faces. Indoors the fixed cameras make that meaningless, so it rests.
    // Hidden in brush it stays up, on the way she is looking: that is the way she will leave.
    const inBrush = pl.hidden?.type === 'bush' && !this.cine.blocking && (sim.phase === 'play' || sim.phase === 'intro');
    ui.setCompass?.((ordinary || inBrush) && !this.rig.zone && this.settings.compass !== false
      ? { yaw: inBrush ? this.rig.hideYaw : this.rig.yaw, x: pl.x, z: pl.z, target: COMPASS_TARGET(sim) } : null);
    if (sim.signText !== this.lastSign) {
      this.lastSign = sim.signText;
      if (sim.signText) ui.toast(sim.signText, 5, { kind: 'essential' });
    }
  }

  updateMusic(dt, sim) {
    if (sim.phase === 'escaped') return; // the drive out keeps the music it started with
    const k = sim.killer;
    let want = 'none';
    if (sim.phase === 'play') {
      const d = Math.hypot(k.x - sim.player.x, k.z - sim.player.z);
      if (k.state === 'chase' || k.state === 'strike') want = sim.act >= 2 ? 'finale' : 'chase';
      else if ((k.state === 'investigate' || k.state === 'search' || k.state === 'notice' || k.state === 'checkhide') && d < 34) want = 'stalk';
      else if (d < 30) want = 'stalk';
      // After a close call the score goes too. The quiet is what makes him audible again.
      else if (sim.time > 45 && sim.director.relax <= 0) want = 'dread';
    }
    this.musicHold -= dt;
    if (want !== this.musicNow) {
      // A chase theme does not stop the moment he loses you.
      const leavingChase = (this.musicNow === 'chase' || this.musicNow === 'finale') && want !== 'chase' && want !== 'finale';
      if (leavingChase && this.musicHold > 0) return;
      this.musicNow = want;
      audio.music(want);
      if (want === 'chase' || want === 'finale') this.musicHold = 5;
    } else if (want === 'chase' || want === 'finale') this.musicHold = 5;
  }

  onCut() {
    const b = this.rig.zone?.building ?? null;
    this.world.setIndoor(b, this.rig.zone?.id ?? null);
    audio.setRoom(b ? 'room' : 'outside');
    this.post.uTear.value = Math.max(this.post.uTear.value, 0.12);
  }

  playPlayerFootfall(dt, active) {
    const p = this.sim.player, cur = this.playerFig.animator?.cur;
    const contact = this.playerFootfalls?.sample({ phase: cur?.phase, gait: cur?.name,
      x: p.x, z: p.z, dt, soles: this.playerFootfalls ? readFootSoles(this.playerFig) : null, active: active && this.state === 'play' && !this.disposed });
    if (!contact || !(this.settings.steps > 0)) return;
    const vol = (p.moveMode === 'run' ? .48 : p.moveMode === 'sneak' ? .12 : .28) * this.settings.steps;
    this.playerStepSide = contact.side === 'R' ? 1 : 0;
    audio.sfx('step_' + this.sim.surfaceKind(p.x, p.z), {
      volume: vol * (this.playerStepSide ? .96 : 1.04), rate: .96 + Math.random() * .08,
    });
  }

  onEvent(e) {
    const ui = this.ui;
    const at = (x, z, volume = 1, rate) => ({ x, y: surfaceY(x, z) + 1, z, volume, rate });
    switch (e.t) {
      // Simulation step events still drive hearing/follower/RNG; rendered
      // counselor contacts own only their audible presentation.
      case 'step': break;
      case 'killerStep':
        if (e.hurry) break; // his far-off catch-up pace is never heard (see ai/killer.js sounds)
        // The same step all night. In the storm it carries a little farther, so the rain does not hide him.
      audio.sfx(e.indoors ? 'killer_step_wood' : 'killer_step', { ...at(e.x, e.z, 1, 0.94 + Math.random() * 0.12), ref: this.stormOn && !e.indoors ? 7 : undefined }); break;
      case 'killerBreath': audio.sfx('killer_breath', at(e.x, e.z)); break;
      case 'ting': audio.sfx('fork_ting', at(e.x, e.z, 0.9, 0.9 + Math.random() * 0.25)); break;
      case 'doorOpen': audio.sfx('door_open', at(e.x, e.z)); break;
      case 'doorClose': audio.sfx('door_close', at(e.x, e.z)); break;
      case 'doorSlam': audio.sfx('door_slam', at(e.x, e.z)); break;
      case 'doorBash': audio.sfx('door_bash', at(e.x, e.z)); this.post.uTear.value = 0.5; this.rig.shake = 0.5; break;
      case 'distantDoor': audio.sfx('door_slam', at(e.x, e.z, 0.8)); break;
      case 'body':
        this.hanging.start(e.x, surfaceY(e.x, e.z), e.z, e.yaw);
        audio.sfx('wood_crack', at(e.x, e.z));
        if (e.near) {
          audio.sfx('stinger_jump', {});
          this.post.uTear.value = 1;
          this.cine.bodyCut(e.x, surfaceY(e.x, e.z), e.z, e.yaw);
          ui.caption('Mike said he was getting on the last bus.', 5, { kind: 'essential' });
        }
        break;
      case 'scream': audio.sfx('scream_distant', at(e.x, e.z, 0.8)); break;
      case 'hush': audio.ambience('none'); break;
      case 'lurkGone':
        this.killer.root.visible = false;
        audio.ambience('forest');
        break;
      case 'followStep': audio.sfx('step_leaf', at(e.x, e.z, 0.9, 0.62 + Math.random() * 0.08)); break;
      case 'branch': audio.sfx('branch_snap', { volume: 0.9 }); break;
      case 'branchNear': audio.sfx('branch_snap', at(e.x, e.z, 0.7)); break;
      case 'spotted':
        audio.sfx('stinger_spot', {});
        this.post.uTear.value = 0.8;
        break;
      case 'noticed': audio.sfx('gasp', { volume: 0.25 }); break;
      case 'ambush':
        audio.sfx('stinger_jump', {});
        this.post.uTear.value = 1;
        this.rig.shake = 0.8;
        break;
      case 'windup': audio.sfx('fork_swing', at(e.x, e.z)); break;
      case 'miss':
        audio.sfx('fork_thunk', at(e.x, e.z));
        audio.sfx('stinger_near', {});
        this.rig.shake = 1;
        this.post.uTear.value = 0.7;
        break;
      case 'graze':
        this.playerFig.setWounded?.(true);
        ui.bloodSplat(0.15);
        ui.caption('Just your shoulder. Keep moving.', 3, { kind: 'urgent', key: 'graze' });
        break;
      case 'hideSeen':
        ui.caption('He saw you hide. Move!', 3, { kind: 'urgent', key: 'hideSeen' });
        break;
      case 'hideDanger':
        ui.caption('He is checking here. Get ready to move.', 2.5, { kind: 'urgent', key: 'hideDanger' });
        break;
      case 'lost':
        ui.caption('He lost sight. Quiet feet. Light off.', 3, { kind: 'urgent', key: 'lost' });
        break;
      case 'found':
        audio.sfx(e.what === 'keys' ? 'item_keys' : 'item_battery', {});
        audio.sfx('stinger_found', {});
        ui.caption(e.text, 4.5, { kind: 'essential', key: 'found:' + e.what });
        ui.setInventory(this.inventoryView());
        this.world.lightning?.(this.settings.flashes === 'full' ? 0.5 : 0.15);
        break;
      case 'nothing':
        audio.sfx('found_nothing', {});
        ui.caption(e.text, 4.5, { kind: 'flavor' });
        break;
      case 'searchStart': audio.sfx('rummage', {}); break;
      case 'batteryStart': audio.sfx('hood_open', {}); break;
      case 'batteryIn':
        audio.sfx('battery_install', {});
        ui.caption('It clicks home.', 3, { kind: 'essential', key: 'clicks-home' });
        ui.setInventory(this.inventoryView()); // the battery is in the car now, not in the pack (F12)
        this.world.car?.userData.setBatteryVisible?.(true);
        break;
      case 'line': ui.caption(e.text, 3, { kind: 'urgent', key: 'line:' + e.text }); break;
      case 'hide':
        audio.sfx('closet_open', { volume: 0.5 });
        audio.setRoom(e.spot.type === 'bush' ? 'outside' : 'closet');
        ui.setHide(e.spot.type);
        this.rig.hidePan = 0;
        this.rig.hideYaw = this.sim.player.yaw;
        if (e.spot.type === 'bush' && !this.bushHint) {
          this.bushHint = true;
          ui.caption('Look around. You leave the way you are facing.', 4, { kind: 'essential', key: 'bush-turn' });
        }
        this.rig.update(0, this.sim.player, { moveX: 0, moveY: 0 });
        break;
      case 'unhide':
        audio.sfx('closet_close', { volume: 0.5 });
        audio.setRoom(this.rig.zone ? 'room' : 'outside');
        ui.setHide(null);
        if (e.spot?.type === 'bush' && Number.isFinite(this.rig.hideYaw)) this.rig.snapBehind(this.rig.hideYaw);
        this.rig.first = true;
        break;
      case 'vault': audio.sfx('vault_window', {}); break;
      case 'flashlight': audio.sfx('ui_click', { volume: 0.4 }); ui.setFlashlight(e.on); break;
      case 'winded': audio.sfx('player_breath_fast', {}); break;
      case 'lightning': {
        const reduced = this.settings.flashes !== 'full';
        this.world.lightning(reduced ? e.strength * 0.25 : e.strength);
        if (!reduced) this.post.uFlash.value = Math.max(this.post.uFlash.value, e.strength * 0.35);
        if (e.reveal) {
          audio.sfx('stinger_near', { volume: 0.8 });
          this.post.uTear.value = 0.6;
        }
        this.thunderTimers.add({ night: this.sim, strength: e.strength, remaining: .4 + (1 - e.strength) * 1.8 });
        break;
      }
      case 'huntStarted':
        this.seenHunt = true;
        this.cine.clear();
        this.cine.openHood();
        audio.ambience('forest');
        ui.caption('You are not alone. Find your keys and a battery. Get out.', 6);
        break;
      case 'carFound': this.cine.carReveal(); break;
      case 'carEnter': this.cine.carScene(); break;
      case 'crank': this.cine.crank(e); break;
      case 'crankFail': this.cine.crankFail(e); break;
      case 'engineStart': this.cine.engineStart(); break;
      case 'death': this.onDeath(e); break;
      default: break;
    }
  }

  onDeath(e) {
    this.playerFig?.resetStance?.();
    this.killer?.resetStance?.();
    this.state = 'dead';
    const sim = this.sim;
    const pl = sim.player;
    this.cine.clear();
    const hiddenDeath = ['closet', 'bed', 'canoe', 'outhouse'].includes(e.kind);
    const fixedHideView = ['bed', 'canoe', 'outhouse'].includes(e.kind);
    this.deathHide = hiddenDeath ? e.kind : null;
    this.ui.showControlsHint?.(0);
    this.ui.setHide?.(this.deathHide);
    this.ui.setPrompt(null);
    this.ui.setPursuit?.('');
    this.ui.setObjective('');
    this.ui.caption('');
    this.ui.toast('');
    this.ui.setKeyStrip?.(false);
    this.ui.setCompass?.(null);
    audio.setThreat?.(0);
    this.ui.setStamina?.(1, false);
    this.objective = '';
    this.ui.setTouchVisible(false);
    audio.music('none');
    this.flash.setOn(pl.flashlight);
    this.playerFig.root.visible = e.kind === 'impale' || e.kind === 'pinned';
    this.killer.root.visible = true;
    const k = sim.killer;
    this.killer.root.position.set(k.x, surfaceY(k.x, k.z), k.z);
    this.killer.root.rotation.y = k.yaw;
    this.playerFig.root.position.set(pl.x, pl.y, pl.z);
    // Each death needs its own stage directions.
    const h = pl.hidden;
    let at = { x: pl.x, y: pl.y, z: pl.z, yaw: Math.atan2(k.x - pl.x, k.z - pl.z) };
    if (e.kind === 'pinned' && sim.pinAt) {
      const w = sim.pinAt;
      at = { x: w.x, y: surfaceY(w.x, w.z), z: w.z, yaw: Math.atan2(k.x - w.x, k.z - w.z) };
    } else if (hiddenDeath && h) {
      const [px, py, pz] = h.view.pos, [lx, , lz] = h.view.look;
      at = { x: px, y: surfaceY(px, pz) + py, z: pz, yaw: Math.atan2(lx - px, lz - pz) };
    } else if (e.kind === 'car') {
      at = { x: CAR.x - 0.1, y: surfaceY(CAR.x, CAR.z) + 1.2, z: CAR.z - 0.43, yaw: CAR.rot };
    }
    let clear = { x: at.x, z: at.z, r: 7.5 };
    if (e.kind === 'impale' && !this.rig.zone) {
      // A hard cut, so the stage can turn: he stands between the camera and the moon, and the pines on
      // that side are gone so nothing covers it. Every time.
      const yaw = Math.atan2(MOON_DIR[0], MOON_DIR[2]) - 0.38;
      const fx = Math.sin(yaw), fz = Math.cos(yaw);
      if (!sim.collision.wallBetween(pl.x, pl.z, pl.x + fx * 14, pl.z + fz * 14)) {
        at.yaw = yaw;
        clear = { x: at.x + fx * 9, z: at.z + fz * 9, r: 17 };
      }
    }
    if (e.kind === 'impale' || e.kind === 'pinned') this.world.clearStage(clear.x, clear.z, clear.r, e.kind === 'pinned' ? sim.pinTrunk : null);
    this.deathSeq = playDeath(e.kind, {
      scene: this.scene,
      camera: this.camera,
      killer: this.killer,
      player: this.playerFig,
      blood: this.blood,
      post: this.post,
      audioCue: (name, opts) => audio.sfx(name, opts || {}),
      ground: (x, z) => surfaceY(x, z),
      at,
      hiding: fixedHideView && h ? { x: h.x, z: h.z } : null,
      entryView: fixedHideView ? { position: this.camera.position.clone(), direction: this.camera.getWorldDirection(new THREE.Vector3()), fov: this.camera.fov } : null,
      onReveal: () => { this.deathHide = null; this.ui.setHide?.(null); },
      location: sim.buildingAt(pl.x, pl.z) ? 'cabin' : lakeField(pl.x, pl.z) < 1.25 ? 'lake' : 'woods',
      // How far along the line from the subject the camera can stand before a wall (1 = all the way).
      clearLine: (tx, tz, px, pz) => {
        const c = sim.collision;
        for (let k = 1; k > 0.3; k -= 0.1) {
          if (!c.wallBetween(tx, tz, tx + (px - tx) * k, tz + (pz - tz) * k)) return k;
        }
        return 0.3;
      },
      lamp: (from, to, dt, dying) => {
        this.flash.power = dying ? 0.05 : 0.14;
        this.flash.showBeam = false;
        this.flash.setOn(true);
        this.from.set(from.x, from.y, from.z);
        this.aim.subVectors(to, this.from).normalize();
        this.flash.aim.copy(this.aim);
        this.flash.update(dt, this.from, this.aim, this.settings?.flashes === 'reduced' ? 0 : 0.6);
      },
      onDone: () => this.gameOver(),
    });
  }

  tickDead(dt) {
    this.deathSeq?.update?.(dt);
  }

  gameOver() {
    if (this.state !== 'dead') return;
    this.state = 'gameover';
    this.ui.setHide?.(null);
    const s = this.sim;
    this.post.uRed.value = 0.82;
    this.post.uDesat.value = 0.2;
    audio.ambience('none');
    audio.setIntensity(0);
    this.ui.showGameOver({ time: s.time, searched: s.searched.size, seen: s.stats.seen });
  }

  // The gate escape is only the midpoint of a connected campaign. Return true
  // even on repeated calls so an exhausted timeline cannot fall back to dawn.
  completeActOne() {
    if (!this.campaign?.onEscape) return false;
    if (this.chapterComplete || this.disposed) return true;
    this.chapterComplete = true;
    this.state = 'transition';
    this.clearThunder();
    this.ui.setPrompt(null);
    this.ui.setObjective('');
    this.ui.caption('');
    this.ui.setTouchVisible(false);
    this.campaign.onEscape({ time: this.sim?.time || 0, difficulty: this.difficulty, settings: { ...this.settings } });
    return true;
  }

  tickThunder(dt) {
    if (this.state === 'paused') return;
    if (this.disposed || (this.state !== 'play' && this.state !== 'dead')) { this.clearThunder(); return; }
    let due = null;
    for (const pending of this.thunderTimers) {
      if (pending.night !== this.sim) { this.thunderTimers.delete(pending); continue; }
      pending.remaining -= Math.max(0, Number.isFinite(dt) ? dt : 0);
      if (pending.remaining > 0) continue;
      this.thunderTimers.delete(pending);
      // A long frame may cross several deadlines. Keep one strongest roll,
      // rather than emitting a pile-up when rendering catches up.
      if (!due || pending.strength > due.strength) due = pending;
    }
    if (due) audio.sfx(due.strength > .8 ? 'thunder_near' : 'thunder', { volume: due.strength * (due.strength > .8 ? .55 : .75) });
  }

  clearThunder() {
    this.thunderTimers.clear();
  }

  // The campaign owner disposes renderer/scene resources after this stops all
  // activity belonging to the chapter. It then installs the next chapter's DOM.
  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.playerFootfalls?.reset();
    this.playerFig?.resetStance?.();
    this.killer?.resetStance?.();
    this.running = false;
    cancelAnimationFrame(this.raf);
    document.removeEventListener('visibilitychange', this.onVisibilityChange);
    window.removeEventListener('blur', this.onWindowBlur);
    this.clearThunder();
    this.deathSeq?.restore?.();
    this.deathSeq = null;
    this.cine.clear();
    this.cine.restoreCar();
    for (const name of ['fireLoop', 'genLoop', 'lapLoop']) {
      this[name]?.stop?.();
      this[name] = null;
    }
    this.ui.dispose?.();
    this.state = 'disposed';
    this.sim = null;
    GLOBALS.uSubject.value.w = 0;
  }

  win() {
    this.state = 'ending';
    const s = this.sim;
    this.ui.showEnding({ time: s.time, searched: s.searched.size, seen: s.stats.seen, closeCalls: s.closeCalls });
  }
}
