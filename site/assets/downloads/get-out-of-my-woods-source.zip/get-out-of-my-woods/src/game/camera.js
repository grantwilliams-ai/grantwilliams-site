// Outdoors: a third-person camera over the shoulder. Indoors: fixed corner cameras, like the
// survival horror games of the 1990s, which also frees rooms from all camera-collision trouble.
import * as THREE from 'three';
import { BUILDINGS, LAYOUT, localToWorld, worldToLocal } from '../sim/layout.js';
import { surfaceY } from '../sim/terrain.js';

const wrap = (a) => {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
};

const BACK = 3.5, RIGHT = 0.55, HEAD = 1.42;
const SENS = 0.0028;

export class CameraRig {
  constructor(camera, collision) {
    this.camera = camera;
    this.collision = collision;
    this.yaw = 0; // the way the camera faces: forward is (sin yaw, cos yaw)
    this.pitch = -0.1;
    this.dist = BACK;
    this.pos = new THREE.Vector3();
    this.look = new THREE.Vector3();
    this.frameLocal = new THREE.Vector3();
    this.frameRotation = new THREE.Quaternion();
    this.zone = null;
    this.focus = null; // {x, z}: something the player is working on, which the camera turns to show
    this.moveYaw = 0; // the camera yaw used to turn the stick into movement
    this.holdMove = false;
    this.lastLook = 0;
    this.shake = 0;
    this.touch = false;
    this.buildings = new Map(BUILDINGS.map((b) => [b.id, b]));
    this.doorwayShots = new Map(BUILDINGS.filter(b => b.template === 'boathouse').map(b => {
      const point = (x, y, z) => { const [wx, wz] = localToWorld(b, x, z); return [wx, y, wz]; };
      // The room's lake-facing camera sits beside the landward door: that exit
      // and its approaching counselor otherwise leave the frame before the cut.
      return [b.id, { id: `${b.id}.doorway`, building: b.id,
        pos: point(1.9, 2.3, 1), look: point(0, 1, 5.1), fov: 74 }];
    }));
    this.rearShots = new Map(BUILDINGS.filter(b => b.template === 'cabin' || b.template === 'messhall').map(b => {
      const point = (x, y, z) => { const [wx, wz] = localToWorld(b, x, z); return [wx, y, wz]; };
      // The original rear-corner views cannot frame the interactions immediately
      // below them. A reverse angle keeps the closet/window/desk and kitchen exit
      // readable without moving those interactions or altering their reach.
      const cabin = b.template === 'cabin';
      return [b.id, { id: `${b.id}.rear`, building: b.id,
        pos: cabin ? point(0, 1.65, 2.9) : point(4.2, 1.85, 1.9),
        look: cabin ? point(0, 1, -2.8) : point(6, 1, -4.6),
        fov: cabin ? 74 : 76 }];
    }));
    this.hallRearShots = new Map(BUILDINGS.filter(b => b.template === 'messhall').map(b => {
      const point = (x, y, z) => { const [wx, wz] = localToWorld(b, x, z); return [wx, y, wz]; };
      // The back aisle passes directly under the original dining-room tripod.
      // Film that corner along the aisle so tables cannot swallow the walker.
      return [b.id, { id: `${b.id}.hall-rear`, building: b.id,
        pos: point(-1.1, 3, -4.7), look: point(-7.5, .8, -3.6), fov: 76 }];
    }));
    this.justCut = false;
    this.first = true;
  }

  snapBehind(yaw) {
    this.yaw = yaw;
    this.moveYaw = yaw;
    this.dist = BACK;
    this.first = true;
  }

  zoneAt(x, z) {
    for (const zn of LAYOUT.zones) {
      const b = this.buildings.get(zn.building);
      const [lx, lz] = worldToLocal(b, x, z);
      if (lx >= zn.rect[0] && lz >= zn.rect[1] && lx <= zn.rect[2] && lz <= zn.rect[3]) {
        const doorway = this.doorwayShots.get(zn.building);
        // Keep a small hysteresis band so a stopped/sliding step near the cut
        // cannot alternate cameras. Movement uses the existing cut-direction hold.
        if (doorway && lz >= (this.zone === doorway ? 2.8 : 3.4) - 1e-6) return doorway;
        const hallRear = this.hallRearShots.get(zn.building);
        const inHallRear = this.zone === hallRear;
        if (hallRear && lx <= (inHallRear ? -5.3 : -5.8) &&
            lz <= (inHallRear ? -2.2 : -2.7)) return hallRear;
        const rear = this.rearShots.get(zn.building);
        // Each reverse angle owns a stable rear band. The Mess Hall angle is
        // confined to its kitchen; the dining-room partition remains opaque.
        if (rear && (b.template === 'cabin' || lx > 3) &&
            lz <= (this.zone === rear ? -1.2 : -1.8) + 1e-6) return rear;
        return zn;
      }
    }
    return null;
  }

  // lookX/lookY: pixels of mouse or finger travel since last frame. moving: is the stick pushed.
  update(dt, player, input) {
    this.justCut = false;
    const cam = this.camera;
    const moving = Math.hypot(input.moveX, input.moveY) > 0.08;

    if (player.hidden) {
      const v = player.hidden.view;
      cam.position.set(v.pos[0], v.pos[1] + surfaceY(v.pos[0], v.pos[2]) + Math.sin(performance.now() * 0.0012) * 0.006, v.pos[2]);
      cam.fov = 62;
      if (player.hidden.type === 'bush') {
        // In brush she can turn all the way round, by dragging the view or with the stick, and she
        // leaves the way she is looking (hideYaw goes back to the sim as the yaw she steps out on).
        if (!Number.isFinite(this.hideYaw)) this.hideYaw = player.yaw;
        this.hideYaw = wrap(this.hideYaw - (input.lookX || 0) * SENS - (Math.abs(input.moveX || 0) > 0.25 ? input.moveX : 0) * dt * 2.2);
        cam.lookAt(v.pos[0] + Math.sin(this.hideYaw) * 3, v.look[1] + surfaceY(v.pos[0], v.pos[2]), v.pos[2] + Math.cos(this.hideYaw) * 3);
      } else cam.lookAt(v.look[0] + this.hideLook(input), v.look[1] + surfaceY(v.look[0], v.look[2]), v.look[2]);
      cam.updateProjectionMatrix();
      return;
    }

    const zone = this.zoneAt(player.x, player.z);
    if (zone !== this.zone) {
      // A cut. Keep the old stick direction until the player lets go, so walking through a door
      // into a room shot from the far corner does not flip the controls and walk them back out.
      this.zone = zone;
      this.justCut = true;
      this.holdMove = moving;
      if (!zone) {
        // Coming back outside: put the camera behind them.
        this.yaw = player.yaw;
        this.pitch = -0.1;
        this.first = true;
      }
    }

    if (zone) {
      cam.position.set(zone.pos[0], zone.pos[1] + surfaceY(zone.pos[0], zone.pos[2]), zone.pos[2]);
      const fy = surfaceY(zone.look[0], zone.look[2]);
      // A corner camera that very slightly turns to keep its subject, as a person would.
      this.look.set(zone.look[0], zone.look[1] + fy, zone.look[2]);
      const px = player.x - this.look.x, pz = player.z - this.look.z;
      cam.lookAt(this.look.x + px * .18, this.look.y, this.look.z + pz * .18);
      // Keep the authored tripod composition until a narrow panel would crop
      // the subject. Then pan only enough to restore a small edge margin; no
      // zoom, camera translation or continuously centered follow camera.
      if (cam.aspect < 1.4) {
        this.frameLocal.set(player.x - cam.position.x, player.y + 1 - cam.position.y, player.z - cam.position.z)
          .applyQuaternion(this.frameRotation.copy(cam.quaternion).invert());
        const angle = Math.atan2(this.frameLocal.x, -this.frameLocal.z);
        const edge = Math.atan(Math.tan(zone.fov * Math.PI / 360) * cam.aspect * .6);
        const correction = angle - Math.max(-edge, Math.min(edge, angle));
        cam.rotateY(-Math.max(-.45, Math.min(.45, correction)));
      }
      if (cam.fov !== zone.fov) {
        cam.fov = zone.fov;
        cam.updateProjectionMatrix();
      }
      const cy = Math.atan2(this.look.x - cam.position.x, this.look.z - cam.position.z);
      if (!this.holdMove) this.moveYaw = cy;
      this.yaw = cy;
    } else {
      if (cam.fov !== 60) {
        cam.fov = 60;
        cam.updateProjectionMatrix();
      }
      const lx = input.lookX || 0, ly = input.lookY || 0;
      if (lx !== 0 || ly !== 0) this.lastLook = performance.now();
      this.yaw -= lx * SENS;
      this.pitch = Math.max(-0.75, Math.min(0.35, this.pitch - ly * SENS));

      // With no one steering the camera on a phone, it swings gently round behind the walker.
      const idleMs = performance.now() - this.lastLook;
      // Not while she is coming back toward the camera: following her facing then would chase its
      // own tail and walk her in a tight circle.
      if (this.touch && moving && idleMs > 700 && Math.abs(wrap(player.yaw - this.yaw)) < 2) {
        const want = player.yaw;
        const side = Math.abs(input.moveY) < 0.4 ? 0.4 : 1; // strafing should not spin the view
        this.yaw = wrap(this.yaw + wrap(want - this.yaw) * (1 - Math.exp(-dt * 1.5 * side)));
        this.pitch += (-0.1 - this.pitch) * (1 - Math.exp(-dt * 1.2));
      }
      // While the player works on something (the battery under the hood), turn to look at it from
      // behind them, so a car or wall at their back cannot push the camera onto their shoulder (F10).
      if (this.focus) {
        const ease = 1 - Math.exp(-dt * 5);
        this.yaw = wrap(this.yaw + wrap(Math.atan2(this.focus.x - player.x, this.focus.z - player.z) - this.yaw) * ease);
        this.pitch += (-0.22 - this.pitch) * ease;
      }
      if (!this.holdMove) this.moveYaw = this.yaw;

      const fx = Math.sin(this.yaw), fz = Math.cos(this.yaw);
      const rx = -fz, rz = fx;
      const head = player.y + HEAD;
      // Sit behind and a little to the right. Pull in when a trunk or wall is in the way.
      const cp = Math.cos(this.pitch), sp = Math.sin(this.pitch);
      const wantD = player.moveMode === 'run' ? BACK + 0.5 : BACK;
      let d = wantD;
      for (let t = 0.6; t <= wantD; t += 0.3) {
        const px = player.x + rx * RIGHT * (t / wantD) - fx * t * cp, pz = player.z + rz * RIGHT * (t / wantD) - fz * t * cp;
        if (this.collision.blocked(px, pz, 0.22, false)) {
          d = Math.max(0.7, t - 0.35);
          break;
        }
      }
      this.dist += (d - this.dist) * (1 - Math.exp(-dt * (d < this.dist ? 18 : 3)));
      const k = this.dist / wantD;
      let cx = player.x + rx * RIGHT * k - fx * this.dist * cp;
      let cz = player.z + rz * RIGHT * k - fz * this.dist * cp;
      let cy = head - this.dist * sp * 1.0 + 0.3;
      cy = Math.max(cy, surfaceY(cx, cz) + 0.45);
      const smooth = this.first ? 1 : 1 - Math.exp(-dt * 16);
      this.first = false;
      this.pos.x += (cx - this.pos.x) * smooth;
      this.pos.y += (cy - this.pos.y) * smooth;
      this.pos.z += (cz - this.pos.z) * smooth;
      cam.position.copy(this.pos);
      const ax = player.x + rx * RIGHT * 0.9 * k + fx * 2.5;
      const az = player.z + rz * RIGHT * 0.9 * k + fz * 2.5;
      cam.lookAt(ax, head + sp * 2.5 - 0.05, az);
    }

    if (!moving) this.holdMove = false;

    if (this.shake > 0) {
      this.shake = Math.max(0, this.shake - dt * 1.6);
      const s = this.shake * this.shake * 0.05;
      cam.position.x += (Math.random() - 0.5) * s;
      cam.position.y += (Math.random() - 0.5) * s;
      cam.rotation.z += (Math.random() - 0.5) * s * 0.5;
    }
  }

  hideLook(input) {
    this.hidePan = Math.max(-2.5, Math.min(2.5, (this.hidePan || 0) + (input.lookX || 0) * 0.004));
    return this.hidePan;
  }
}
