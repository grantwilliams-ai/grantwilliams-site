// A cutscene is a list of beats at set times. update(dt) runs whichever beats have come due;
// `during` runs every frame with the elapsed time.
export class Timeline {
  constructor(beats, during) {
    this.beats = beats.slice().sort((a, b) => a.at - b.at);
    this.during = during;
    this.t = 0;
    this.i = 0;
    this.done = false;
    this.duration = this.beats.length ? this.beats[this.beats.length - 1].at : 0;
  }

  update(dt) {
    if (this.done) return;
    this.t += dt;
    while (this.i < this.beats.length && this.beats[this.i].at <= this.t) this.beats[this.i++].fn?.();
    this.during?.(this.t, dt);
    if (this.i >= this.beats.length) this.done = true;
  }
}
