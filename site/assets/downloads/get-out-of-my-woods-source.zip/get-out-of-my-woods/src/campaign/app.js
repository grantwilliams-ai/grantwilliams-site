import { App } from '../game/app.js';
import { PreviewApp } from '../act2/app.js';
import { audio } from '../audio/index.js';
import { createCampaignState,act2Difficulty } from './state.js';
import { disposeSceneResources } from './resources.js';

export class CampaignApp {
  constructor(){
    let storage;try{storage=localStorage;}catch{}
    this.save=createCampaignState(storage);this.app=null;this.chapter=null;this.switching=false;this.transitions=0;this.disposals=[];
    this.mountAct1();
  }
  get preferences(){return this.save.state.preferences;}
  settings(key,value){this.save.setting(key,value);}
  mountAct1({start=false}={}){
    this.chapter='act1';
    const campaign={preferences:this.preferences,canContinue:()=>this.save.canContinue(),
      // False when Continue works now but would not survive a reload (the browser refused the save).
      checkpointSaved:()=>this.save.checkpointSaved,
      onResumeCheckpoint:()=>this.transition('act2',{intro:false}),
      onStart:data=>this.save.start(data),onSetting:(key,value)=>this.settings(key,value),
      onEscape:data=>{if(this.switching||this.chapter!=='act1')return;this.save.reachCrash(data);this.transition('act2',{intro:true});}};
    this.app=new App({campaign});
    if(start)this.app.startNight(this.save.state.difficulty);
    this.expose();
  }
  mountAct2({intro=false}={}){
    this.chapter='act2';this.save.replayCrash();
    this.app=new PreviewApp({campaign:{preferences:this.preferences,difficulty:act2Difficulty(this.save.state.difficulty),
      act1Time:this.save.state.act1Time,checkpointSaved:()=>this.save.checkpointSaved,onSetting:(key,value)=>this.settings(key,value),
      onHome:()=>this.transition('act1'),onNewGame:()=>this.transition('act1',{start:true}),
      onRetry:()=>this.save.replayCrash(),onComplete:()=>this.save.complete()}});
    this.app.start(intro);this.expose();
  }
  expose(){window.__goomw=this.app;window.__woodsPreview=this.chapter==='act2'?this.app:null;}
  transition(chapter,options={}){
    if(this.switching)return;
    this.switching=true;
    const cover=document.createElement('div');cover.id='chapter-transition';cover.setAttribute('role','status');
    cover.style.cssText='position:fixed;inset:0;z-index:1000;background:#000;color:#faf6e9;display:grid;place-items:center;font:22px Oswald,Arial,sans-serif;text-align:center;padding:24px';
    cover.textContent=chapter==='act2'?'BEYOND THE GATE':'RETURNING TO STILLWATER';document.body.append(cover);
    // Let the outgoing cinematic finish its tick and paint the black cut.
    requestAnimationFrame(()=>setTimeout(()=>{
      try{
        const old=this.app;old.dispose();
        this.disposals.push({chapter:this.chapter,...disposeSceneResources(old.mainScene||old.scene)});
        old.renderer.dispose();audio.resetChapter();
        document.getElementById('game').replaceChildren(document.createElement('canvas'));
        const ui=document.getElementById('ui');ui.replaceChildren();ui.className='';
        document.getElementById('goomw-ui-css')?.remove();
        if(chapter==='act2')this.mountAct2(options);else this.mountAct1(options);
        this.transitions++;this.switching=false;cover.remove();
      }catch(error){
        console.error(error);this.switching=false;cover.textContent='The next chapter could not load. Reload to use your saved crash checkpoint.';
      }
    },30));
  }
}
