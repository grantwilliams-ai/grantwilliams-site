// One V4 save: preferences and the crash checkpoint. V3's saves stay untouched.
export const CAMPAIGN_SAVE_KEY = 'goomw.v4.campaign';
// The union of the chapter ranges preserves every previously offered choice.
export const BRIGHTNESS_RANGE = Object.freeze({min:.4,max:1.7,step:.05});
// inputMode: which controls are shown (auto follows the device; see ui/input-mode.js).
// hints: the always-visible keyboard reminder strip during play.
// weather: rain, wind and thunder (0.7 plays the storm as mixed). compass: the heading tape on the HUD.
export const DEFAULT_PREFERENCES = Object.freeze({brightness:1.12,volume:.65,steps:.45,weather:.7,picture:'sharp',tape:false,flashes:'full',inputMode:'auto',hints:true,compass:true});
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export function cleanPreferences(value={}) {
  if(!value||typeof value!=='object')value={};
  const prefs={...DEFAULT_PREFERENCES};
  for(const [key,range] of Object.entries({brightness:[BRIGHTNESS_RANGE.min,BRIGHTNESS_RANGE.max],volume:[0,1],steps:[0,1],weather:[0,1]}))if(Number.isFinite(value[key]))prefs[key]=clamp(value[key],...range);
  if(['sharp','retro'].includes(value.picture))prefs.picture=value.picture;
  if(typeof value.tape==='boolean')prefs.tape=value.tape;
  if(['full','reduced'].includes(value.flashes))prefs.flashes=value.flashes;
  if(['auto','keyboard','touch'].includes(value.inputMode))prefs.inputMode=value.inputMode;
  if(typeof value.hints==='boolean')prefs.hints=value.hints;
  if(typeof value.compass==='boolean')prefs.compass=value.compass;
  return prefs;
}
const difficulty=v=>['easy','normal','hard'].includes(v)?v:'normal';
export function createCampaignState(storage) {
  let saved;try{saved=JSON.parse(storage?.getItem(CAMPAIGN_SAVE_KEY)||'null');}catch{}
  const valid=saved?.version===1;
  const state={preferences:cleanPreferences(valid?saved.preferences:{}),difficulty:difficulty(valid?saved.difficulty:null),checkpoint:valid&&saved.checkpoint==='crash'?'crash':null,act1Time:valid&&Number.isFinite(saved.act1Time)?clamp(saved.act1Time,0,86400):0,completed:valid&&saved.completed===true};
  let storageAvailable=!!storage;
  // Whether the crash checkpoint is really in browser storage, or lives only in this session.
  let checkpointStored=state.checkpoint==='crash';
  const save=()=>{
    if(!storage)return false;
    try{storage.setItem(CAMPAIGN_SAVE_KEY,JSON.stringify({version:1,...state}));}catch{storageAvailable=false;return false;}
    storageAvailable=true;if(state.checkpoint==='crash')checkpointStored=true;return true;
  };
  return {state,get storageAvailable(){return storageAvailable;},canContinue:()=>state.checkpoint==='crash'&&!state.completed,
    // False when Continue would work now but not after a reload: the browser refused the write.
    get checkpointSaved(){return state.checkpoint==='crash'&&checkpointStored;},
    setting(key,value){if(key==='sound')key='volume';state.preferences=cleanPreferences({...state.preferences,[key]:value});save();},
    start({difficulty:level=state.difficulty,retry=false}={}){state.difficulty=difficulty(level);if(!retry){state.checkpoint=null;state.act1Time=0;state.completed=false;checkpointStored=false;}
      // NEW GAME replaces the checkpoint. If the browser refuses the write, remove the old save so it cannot come back.
      if(!save()&&!retry&&storage){try{storage.removeItem?.(CAMPAIGN_SAVE_KEY);}catch{}save();}},
    reachCrash({time=0,difficulty:level=state.difficulty}={}){state.checkpoint='crash';state.act1Time=Number.isFinite(time)?Math.max(0,time):0;state.difficulty=difficulty(level);state.completed=false;checkpointStored=false;return save();},
    replayCrash(){state.completed=false;save();},complete(){state.completed=true;save();},save};
}
export const act2Difficulty = level => level==='easy'?'relaxed':level==='hard'?'hard':'standard';
