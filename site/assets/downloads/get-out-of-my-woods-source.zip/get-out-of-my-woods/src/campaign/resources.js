// Release per-chapter GPU allocations. CPU asset caches may re-upload shared
// textures in the next renderer; their source canvases are deliberately retained.
export function disposeSceneResources(scene) {
  const geometries=new Set(),materials=new Set(),textures=new Set(),skeletons=new Set();
  scene?.traverse(o=>{
    if(o.geometry)geometries.add(o.geometry);
    for(const material of (Array.isArray(o.material)?o.material:[o.material]))if(material)materials.add(material);
    if(o.skeleton)skeletons.add(o.skeleton);
    o.shadow?.map?.dispose();o.shadow?.mapPass?.dispose();
    if(o.isInstancedMesh)o.dispose();
  });
  for(const material of materials){
    for(const value of Object.values(material))if(value?.isTexture)textures.add(value);
    for(const uniform of Object.values(material.uniforms||{}))if(uniform?.value?.isTexture)textures.add(uniform.value);
    material.dispose();
  }
  for(const geometry of geometries)geometry.dispose();
  for(const texture of textures)texture.dispose();
  for(const skeleton of skeletons)skeleton.dispose();
  scene?.clear();
  return {geometries:geometries.size,materials:materials.size,textures:textures.size,skeletons:skeletons.size};
}
