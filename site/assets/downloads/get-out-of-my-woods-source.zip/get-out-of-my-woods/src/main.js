// Entry point. Waits for the embedded fonts (the car's painted message is drawn with one), checks
// for WebGL 2, then starts the game.
import { CampaignApp } from './campaign/app.js';

async function boot() {
  const bootEl = document.getElementById('boot');
  const fail = (msg) => {
    if (bootEl) {
      bootEl.textContent = msg;
      bootEl.style.display = 'flex';
    }
  };
  const probe = document.createElement('canvas');
  if (!probe.getContext('webgl2')) {
    fail('This browser cannot show the game’s 3D graphics (WebGL 2 is unavailable). If you opened this link inside another app, open it in your regular browser. Otherwise, try another browser or device.');
    return;
  }
  try {
    if (document.fonts?.load) {
      await Promise.race([
        Promise.all(["40px 'Rock Salt'", "40px 'Anton'", "700 20px 'Oswald'", "20px 'Special Elite'", "20px 'VT323'"].map((f) => document.fonts.load(f))),
        new Promise((r) => setTimeout(r, 2500)),
      ]);
    }
    // Let the browser paint the loading card before the heavy generation starts.
    await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 30)));
    const app = new CampaignApp();
    window.__woodsCampaign = app;
    window.__goomw = app.app; // used by the automated browser tests
    if (bootEl) bootEl.remove();
  } catch (e) {
    console.error(e);
    fail('Something went wrong loading the game: ' + (e.message || e));
  }
}

boot();
