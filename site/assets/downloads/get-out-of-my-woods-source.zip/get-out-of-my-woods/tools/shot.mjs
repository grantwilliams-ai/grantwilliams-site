#!/usr/bin/env node
// Open a page in headless Chromium (software rendering), let it run, take a screenshot.
//   node tools/shot.mjs <page.html> <out.png> [--size 1280x720] [--wait 1500] [--eval "js"] [--mobile] [--dpr 1]
// --eval may be given several times; each runs in the page in order, with --wait after each,
// and if --each is set a screenshot <out>-N.png is taken after each one.
// Prints console errors and page errors. Exit code 2 if any occurred.
import { pinToECores, launch, fileUrl, openPage, reportLogs } from './browser.mjs';
import { mkdirSync, readFileSync, existsSync } from 'node:fs';
import { dirname } from 'node:path';

pinToECores();

const argv = process.argv.slice(2);
const positional = [];
const evals = [];
let size = '1280x720', wait = 1500, mobile = false, dpr = 1, each = false;
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === '--size') size = argv[++i];
  else if (a === '--wait') wait = Number(argv[++i]);
  else if (a === '--eval') evals.push(argv[++i]);
  else if (a === '--evalfile') evals.push(readFileSync(argv[++i], 'utf8'));
  else if (a === '--mobile') mobile = true;
  else if (a === '--dpr') dpr = Number(argv[++i]);
  else if (a === '--each') each = true;
  else positional.push(a);
}
const [pagePath, outPath] = positional;
if (!pagePath || !outPath) {
  console.error('usage: shot.mjs <page.html> <out.png> [--size WxH] [--wait ms] [--eval js] [--each] [--mobile]');
  process.exit(64);
}
if (!pagePath.startsWith('http') && !existsSync(pagePath)) {
  console.error('no such page: ' + pagePath);
  process.exit(64);
}
mkdirSync(dirname(outPath), { recursive: true });

const [width, height] = size.split('x').map(Number);
const browser = await launch();
const { page, logs } = await openPage(browser, pagePath.startsWith('http') ? pagePath : fileUrl(pagePath), { width, height, mobile, dpr });
await page.waitForTimeout(wait);
let n = 0;
for (const js of evals) {
  const r = await page.evaluate(js);
  if (r !== undefined) console.log('[eval]', typeof r === 'string' ? r : JSON.stringify(r));
  await page.waitForTimeout(wait);
  if (each) await page.screenshot({ path: outPath.replace(/\.png$/, `-${n}.png`) });
  n++;
}
await page.screenshot({ path: outPath });
const bad = reportLogs(logs);
await browser.close();
console.log('wrote', outPath);
process.exit(bad ? 2 : 0);
