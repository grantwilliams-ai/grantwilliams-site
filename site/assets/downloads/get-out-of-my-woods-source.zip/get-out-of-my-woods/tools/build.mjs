#!/usr/bin/env node
// Build tool. Two jobs:
//   node tools/build.mjs                    -> dist/get-out-of-my-woods.html (the whole game in ONE file)
//   node tools/build.mjs --entry debug/x.js --out .out/x [--title T]  -> .out/x/index.html for a debug scene
// No server is ever needed: every page works from file://.
import { build } from 'esbuild';
import { readFileSync, readdirSync, writeFileSync, mkdirSync, existsSync, copyFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const opt = (name, dflt) => {
  const i = args.indexOf('--' + name);
  return i >= 0 ? args[i + 1] : dflt;
};
const flag = (name) => args.includes('--' + name);

// A </script inside inlined JS would end the tag early.
const safeInline = (s) => s.replace(/<\/script/gi, '<\\/script');

// GOOMW_STUBS=world,kit,... swaps those modules for src/stubs/<name>.js, so one area's half-finished
// work never stops anyone else from building.
const STUBS = (process.env.GOOMW_STUBS || '').split(',').filter(Boolean);
const stubPlugin = {
  name: 'stubs',
  setup(b) {
    b.onResolve({ filter: /(^|\/)(world|kit|characters|audio|ui)\/index\.js$/ }, (a) => {
      const m = a.path.match(/(world|kit|characters|audio|ui)\/index\.js$/);
      if (m && STUBS.includes(m[1])) return { path: join(ROOT, 'src/stubs', m[1] + '.js') };
      return undefined;
    });
  },
};

// Licensed web fonts, base64 inline, so the page needs nothing from the network.
const FONTS = [
  ['VT323', 'vt323', 400], ['Oswald', 'oswald', 500], ['Oswald', 'oswald', 700],
  ['Special Elite', 'special-elite', 400], ['Rock Salt', 'rock-salt', 400], ['Anton', 'anton', 400],
];
function fontCss() {
  return FONTS.map(([family, pkg, weight]) => {
    const f = join(ROOT, `node_modules/@fontsource/${pkg}/files/${pkg}-latin-${weight}-normal.woff2`);
    const b64 = readFileSync(f).toString('base64');
    return `@font-face{font-family:'${family}';font-weight:${weight};font-style:normal;font-display:block;src:url(data:font/woff2;base64,${b64}) format('woff2')}`;
  }).join('\n');
}

// The fonts and three.js travel inside the one file, so their licences travel with them.
function licenseNotice() {
  const dir = join(ROOT, 'LICENSES');
  const text = readdirSync(dir).sort().map((f) => `==== ${f} ====\n${readFileSync(join(dir, f), 'utf8')}`).join('\n');
  // The game's own licence comes first: the file is the whole game, so it is the copy people pass on.
  const own = readFileSync(join(ROOT, 'LICENSE'), 'utf8');
  return `\n<!--\nGET OUT OF MY WOODS\n\n${own}\nLicences for what is embedded in this file.\n\n${text.replaceAll('--', '- -')}\n-->\n`;
}

async function bundle(entry, minify) {
  const res = await build({
    plugins: [stubPlugin],
    entryPoints: [join(ROOT, entry)],
    bundle: true,
    format: 'iife',
    target: ['es2020', 'safari15'],
    minify,
    legalComments: 'none',
    write: false,
    define: { 'import.meta.env.DEV': minify ? 'false' : 'true' },
    loader: { '.glsl': 'text', '.txt': 'text' },
    logLevel: 'warning',
  });
  return res.outputFiles[0].text;
}

const DEBUG_HTML = (title, js) => `<!doctype html>
<html><head><meta charset="utf-8"><title>${title}</title>
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<style>${fontCss()}
html,body{margin:0;height:100%;background:#000;overflow:hidden;color:#eee;font:16px sans-serif}
canvas{display:block;width:100vw;height:100vh}</style></head>
<body><script>${safeInline(js)}</script></body></html>`;

// src/ui/css.js is the same text as style.css, for debug pages that have no inlined CSS. Never edit it.
function syncUiCss() {
  const css = readFileSync(join(ROOT, 'src/ui/style.css'), 'utf8');
  writeFileSync(join(ROOT, 'src/ui/css.js'), `export const UI_CSS = ${JSON.stringify(css)};\n`);
}

// The copy for a private claude.ai link. That host wraps a page in its own document, so this one
// starts at its title and carries no document tags.
function hostedPage(html) {
  return html
    .replace(/^<!doctype html>\s*<html[^>]*>\s*<head>\s*<meta charset="utf-8">\s*/i, '')
    .replace(/<meta name="(apple-mobile-web-app-capable|mobile-web-app-capable|theme-color)"[^>]*>\s*/g, '')
    .replace('<style>', '<style>\n:root{color-scheme:dark}')
    .replace(/<\/head>\s*<body>\s*/, '')
    .replace(/\s*<\/body>\s*<\/html>\s*$/, '\n');
}

async function main() {
  syncUiCss();
  const entry = opt('entry');
  if (entry) {
    const out = join(ROOT, opt('out', '.out/' + entry.replace(/\W+/g, '_')));
    mkdirSync(out, { recursive: true });
    const js = await bundle(entry, false);
    writeFileSync(join(out, 'index.html'), DEBUG_HTML(opt('title', entry), js));
    console.log('built', join(out, 'index.html'), (js.length / 1024).toFixed(0) + ' KB');
    return;
  }
  const template = readFileSync(join(ROOT, 'src/index.template.html'), 'utf8');
  const js = await bundle(flag('study')?'src/study-main.js':'src/main.js', !flag('no-minify'));
  const cssPath = join(ROOT, 'src/ui/style.css');
  const css = ''; // Preview UI owns its styles; V3 selectors must not leak into it.
  const html = template
    .replace('/*__CSS__*/', () => fontCss() + '\n' + css)
    .replace('/*__JS__*/', () => safeInline(js));
  mkdirSync(join(ROOT, 'dist'), { recursive: true });
  const out = join(ROOT, flag('study')?'dist/act2-study.html':'dist/get-out-of-my-woods.html');
  writeFileSync(out, html + licenseNotice());
  if(flag('study')){console.log('built isolated QA study',out);return;}
  copyFileSync(out, join(ROOT, 'dist/index.html')); // same file, ready for any static host
  mkdirSync(join(ROOT, 'hosted'), { recursive: true });
  writeFileSync(join(ROOT, 'hosted/get-out-of-my-woods.html'), hostedPage(html) + licenseNotice());
  console.log('built', out, (html.length / 1024).toFixed(0) + ' KB');
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
