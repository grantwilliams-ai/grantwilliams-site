// Shared headless browser launcher for every test and screenshot.
// Software rendering only (SwiftShader), pinned to E-cores, so nothing here touches the RTX card
// or the P-cores while a GPU hold is standing.
import { chromium } from 'playwright-core';
import { execFileSync, spawnSync } from 'node:child_process';
import { existsSync, readdirSync } from 'node:fs';
import { homedir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const E_CORES = '16-23';

// Re-exec this node process under taskset once, so Chromium and SwiftShader inherit the mask.
export function pinToECores() {
  if (process.env.GOOMW_PINNED) return;
  const r = spawnSync('taskset', ['-c', E_CORES, process.execPath, ...process.argv.slice(1)], {
    stdio: 'inherit',
    env: { ...process.env, GOOMW_PINNED: '1' },
  });
  process.exit(r.status ?? 1);
}

function chromePath() {
  const base = join(homedir(), '.cache/ms-playwright');
  const dirs = readdirSync(base).filter((d) => /^chromium-\d+$/.test(d)).sort((a, b) => Number(b.split('-')[1]) - Number(a.split('-')[1]));
  for (const d of dirs) {
    const p = join(base, d, 'chrome-linux64/chrome');
    if (existsSync(p)) return p;
    const q = join(base, d, 'chrome-linux/chrome');
    if (existsSync(q)) return q;
  }
  throw new Error('No Playwright Chromium found under ~/.cache/ms-playwright');
}

export async function launch({allowAutoplay=true}={}) {
  return chromium.launch({
    executablePath: chromePath(),
    headless: true,
    args: [
      '--use-gl=angle',
      '--use-angle=swiftshader',
      '--enable-unsafe-swiftshader',
      '--ignore-gpu-blocklist',
      '--enable-webgl',
      ...(allowAutoplay ? ['--autoplay-policy=no-user-gesture-required'] : []),
      '--no-sandbox',
      '--disable-dev-shm-usage',
    ],
  });
}

export const fileUrl = (p) => pathToFileURL(resolve(p)).href;

// Opens a page with console/error capture. opts: {width,height,mobile}
export async function openPage(browser, url, opts = {}) {
  const width = opts.width ?? 1280;
  const height = opts.height ?? 720;
  const context = await browser.newContext({
    viewport: { width, height },
    deviceScaleFactor: opts.dpr ?? 1,
    hasTouch: !!opts.mobile,
    isMobile: !!opts.mobile,
    userAgent: opts.mobile
      ? 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1'
      : undefined,
  });
  const page = await context.newPage();
  const logs = [];
  page.on('console', (m) => logs.push({ type: m.type(), text: m.text() }));
  page.on('pageerror', (e) => logs.push({ type: 'pageerror', text: String(e.stack || e) }));
  await page.goto(url);
  return { page, context, logs };
}

export function reportLogs(logs) {
  let bad = 0;
  for (const l of logs) {
    if (l.type === 'error' || l.type === 'pageerror') {
      bad++;
      console.log(`[${l.type}] ${l.text}`);
    } else if (l.type === 'warning' && /THREE|shader|WebGL/i.test(l.text) && !/GPU stall|swiftshader|software WebGL/i.test(l.text)) {
      console.log(`[warn] ${l.text}`);
    } else if (l.type === 'log' || l.type === 'info') {
      console.log(`[log] ${l.text}`);
    }
  }
  return bad;
}
