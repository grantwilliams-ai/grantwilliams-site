# Get Out of My Woods

A free survival-horror game: Camp Stillwater, 1984, the last night of the season.
A tribute to the summer-camp slashers of the 1980s, by Grant Williams.

Play it: https://grantwilliams.ai/games/get-out-of-my-woods/

The whole game builds into one self-contained HTML file that runs in a browser on a
phone, tablet or computer, online or offline.

## Build it

You need Node.js 20 or newer.

    npm install
    npm run build

The game is written to `dist/get-out-of-my-woods.html`. Open that file in a browser.

## Test it

    npm test
    npm run test:v3

## Where things are

- `src/game`, `src/sim`, `src/ai`, `src/ui`, `src/characters`: Act I (the camp)
- `src/act2`: Act II
- `src/campaign`: what joins the two acts
- `src/audio`: every sound and all the music, made in code
- `src/sim/layout.js`: the map of the camp, and where the keys and the battery can be
- `src/ai/tuning.js`: how fast and how sharp he is on Easy, Normal and Hard
- `tools/build.mjs`: the build
- `tools/shot.mjs`, `tools/browser.mjs`: screenshots with Playwright's Chromium (optional)

## License

MIT License, Copyright (c) 2026 Grant Williams. See `LICENSE`.
You are free to play it, share it, change it and build your own game from it.

The game embeds three.js (MIT) and five fonts (SIL Open Font License 1.1 and Apache
License 2.0). Their licenses are in `LICENSES/`.

A non-profit fan homage, not connected with any film or studio.

## Bugs and ideas

hello@grantwilliams.ai
