import test from 'node:test';
import assert from 'node:assert/strict';
import {stickCenter,stickVector,inStickPad,stickLayout,THUMB_KNOB_TRAVEL} from '../src/ui/thumbstick.js';

test('fixed neutral uses the displayed base including safe-area/panel offset',()=>{
 const base={getBoundingClientRect:()=>({left:61,top:525,width:128,height:128})};
 assert.deepEqual(stickCenter(base),{x:125,y:589});
 const neutral=stickVector(125,589,stickCenter(base),56);
 assert.equal(Math.hypot(neutral.x,neutral.y),0);
 const edge=stickVector(181,589,stickCenter(base),56);
 assert.equal(edge.x,1);assert.equal(edge.knobX,THUMB_KNOB_TRAVEL);
 assert.deepEqual(stickCenter(base),{x:125,y:589},'finger movement never moves the displayed neutral');
});

test('chapter input travel remains56/42px; diagonal overdrag keeps heading and maximum speed',()=>{
 for(const radius of [56,42]){
   const center={x:100,y:200};
   assert.equal(stickVector(100+radius/2,200,center,radius).x,.5);
   assert.equal(stickVector(102,200,center,radius).x,2/radius,'no new deadzone or sensitivity curve');
   for(const [dx,dy] of [[500,-250],[-300,-700],[0,200]]){
     const v=stickVector(center.x+dx,center.y+dy,center,radius);
     assert.ok(Math.abs(Math.hypot(v.x,v.y)-1)<1e-12);
     assert.ok(Math.abs(Math.atan2(v.y,v.x)-Math.atan2(-dy,dx))<1e-12);
     assert.ok(Math.hypot(v.knobX,v.knobY)+24<=62,'48px knob remains inside128px base border');
   }
 }
});

test('pad bounds and layout identity reflect real geometry, not synthetic resize events',()=>{
 let r={left:12,top:214,width:176,height:176,right:188,bottom:390};
 const pad={getBoundingClientRect:()=>r},win={innerWidth:844,innerHeight:390};
 assert.ok(inStickPad(pad,100,300));assert.ok(!inStickPad(pad,230,300));
 const previous=stickLayout(pad,win);assert.equal(stickLayout(pad,win),previous);
 r={...r,left:46,right:222};assert.notEqual(stickLayout(pad,win),previous);
});
