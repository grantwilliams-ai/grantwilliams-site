import test from 'node:test';
import assert from 'node:assert/strict';
import {displayMode, displayHelp, enterFullscreen} from '../src/ui/display-mode.js';

const win={matchMedia:()=>({matches:false})};
test('iPhone without element fullscreen gets actionable Home Screen guidance; standalone gets no installation prompt',()=>{
 const doc={documentElement:{}}, nav={userAgent:'Mozilla/5.0 (iPhone; CPU iPhone OS 27_0 like Mac OS X)'};
 assert.equal(displayMode(doc,nav,win),'ios');
 assert.match(displayHelp(displayMode(doc,nav,win)),/Safari.*Add to Home Screen.*Open as Web App/s);
 assert.equal(displayMode(doc,{...nav,standalone:true},win),'standalone');
 assert.doesNotMatch(displayHelp('standalone'),/Add to Home Screen/);
});
test('disallowed fullscreen is not offered, and denial or synchronous throw resolves to visible-failure result',async()=>{
 const denied={fullscreenEnabled:false,documentElement:{requestFullscreen(){throw Error('must not call');}}};
 assert.equal(displayMode(denied,{userAgent:'Desktop'},win),'window');
 assert.equal(await enterFullscreen(denied),false);
 assert.equal(await enterFullscreen({documentElement:{requestFullscreen(){throw Error('denied');}}}),false);
 assert.equal(await enterFullscreen({documentElement:{requestFullscreen:()=>Promise.reject(Error('denied'))}}),false);
});
test('successful fullscreen request uses its receiver and confirms actual fullscreen state',async()=>{
 const doc={fullscreenEnabled:true};doc.documentElement={requestFullscreen(){assert.equal(this,doc.documentElement);doc.fullscreenElement=this;return Promise.resolve();}};
 assert.equal(displayMode(doc,{},win),'native');assert.equal(await enterFullscreen(doc),true);
});
