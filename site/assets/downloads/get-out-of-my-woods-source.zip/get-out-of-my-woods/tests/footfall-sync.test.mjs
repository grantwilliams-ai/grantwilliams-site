import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { createFootfallSync, readFootSoles } from '../src/audio/footfall-sync.js';
import { createPlayer } from '../src/characters/player.js';
import { App } from '../src/game/app.js';
import { PreviewApp } from '../src/act2/app.js';
import { audio } from '../src/audio/index.js';

const context = new Proxy({measureText:()=>({width:20}),createLinearGradient:()=>({addColorStop(){}})}, {get:(o,k)=>o[k]??(()=>{})});
globalThis.document = {createElement:()=>({getContext:()=>context})};
const noop=()=>{}, speeds={walk:1.9,sneak:1,run:4.5};
function sample(sync,phase,x,overrides={}) {return sync.sample({phase,gait:'walk',x,z:0,dt:.05,soles:{L:0,R:0},...overrides});}
function trace(hz,select,seconds=12.2){
 const figure=createPlayer(),sync=createFootfallSync(),contacts=[];let x=0,lastIndex=0,crossings=0;
 for(let frame=0;frame<hz*seconds;frame++){
  const time=frame/hz,gait=select(time),speed=speeds[gait];x+=speed/hz;
  figure.setAnim(gait,{travelDriven:true});figure.root.position.set(x,2.3,0);figure.root.rotation.y=time*.2;
  figure.update(1/hz,{speed});const phase=figure.animator.cur.phase,soles=readFootSoles(figure),index=Math.floor(phase*2+1e-8);
  if(frame&&index>lastIndex)crossings++;lastIndex=index;
  const contact=sync.sample({phase,gait,x,z:0,dt:1/hz,soles});
  if(contact)contacts.push({...contact,time,clearance:soles[contact.side]});
 }
 return {contacts,crossings};
}
function captureAudio(fn){
 const old=Object.fromEntries(['sfx','setListener','setRoom','setIntensity','pauseAll'].map(k=>[k,audio[k]])),calls=[];
 for(const k of Object.keys(old))audio[k]=noop;
 audio.sfx=(name,opts={})=>calls.push({name,...opts});
 try{return fn(calls);}finally{Object.assign(audio,old);}
}
function act1(){
 const a=Object.create(App.prototype),p={x:0,z:0,y:0,moveMode:'walk',speed:1.9};
 Object.assign(a,{state:'play',settings:{steps:.45},sim:{player:p,surfaceKind:()=> 'dirt'},playerFig:createPlayer(),playerFootfalls:createFootfallSync(),ui:{showPause:noop},cine:{blocking:false}});
 return a;
}
function frame1(a,gait,dt=1/60,active=true){
 const p=a.sim.player,speed=speeds[gait]??0;p.moveMode=gait;p.speed=speed;p.z+=speed*dt;
 a.playerFig.root.position.set(p.x,p.y,p.z);a.playerFig.setAnim(gait,{travelDriven:true});a.playerFig.update(dt,{speed});a.playPlayerFootfall(dt,active);
}
function act2(){
 const a=Object.create(PreviewApp.prototype),p={x:0,z:0,yaw:0,speed:1.9,gait:'walk',run:false,hidden:null,defending:false};
 Object.assign(a,{state:'play',settings:{steps:.45},sim:{phase:'play',player:p,killer:{active:false,x:20,z:20,yaw:0,speed:0,state:'patrol'},weapon:'empty'},figure:createPlayer(),playerFootfalls:createFootfallSync(),heldCrowbar:{},killerFigure:{root:new THREE.Group(),update:noop},flash:{position:new THREE.Vector3(),target:{position:new THREE.Vector3()}},viewYaw:0,killerFoot:0,time:0,post:{uDanger:{value:0}},ui:{menu:noop}});
 return a;
}
function frame2(a,gait,dt=1/60){const p=a.sim.player;p.gait=gait;p.run=gait==='run';p.speed=speeds[gait]??0;p.z+=p.speed*dt;a.updateActors(dt);}

for(const hz of [20,60,120])test(`actual rendered soles align with every steady walk/sneak/run contact at ${hz} Hz`,()=>{
 for(const gait of ['walk','sneak','run']){
  const {contacts,crossings}=trace(hz,()=>gait);
  assert.ok(contacts.length>10,`${gait} has real audible contacts`);
  assert.equal(contacts.length,crossings,`${gait} does not lose a steady contact`);
  for(let i=0;i<contacts.length;i++){
   assert.ok(contacts[i].clearance<=.035+1e-10);assert.ok(contacts[i].delay<=.12+1e-10);
   if(i)assert.notEqual(contacts[i].side,contacts[i-1].side);
  }
 }
});

for(const hz of [20,60,120])test(`rapid continuous gait changes remain audible and grounded at ${hz} Hz`,()=>{
 for(const alternate of ['sneak','run'])for(const period of [.1,.2,.24]){
  const {contacts,crossings}=trace(hz,t=>Math.floor((t+1e-8)/period)%2?alternate:'walk',18);
  assert.ok(contacts.length>=crossings*.75,`${alternate}/${period}: ${contacts.length}/${crossings}`);
  assert.ok(contacts.length>15);const keys=new Set();
  for(let i=0;i<contacts.length;i++){
   const c=contacts[i];assert.ok(c.clearance<=.035+1e-10);assert.ok(c.delay<=.12+1e-10);
   assert.ok(!keys.has(c.phase),'same phase never plays twice');keys.add(c.phase);
   if(i)assert.ok(c.time-contacts[i-1].time<1.45,`${alternate}/${period} starved for ${c.time-contacts[i-1].time}s`);
  }
 }
});

test('single contact defers to the rendered sole, expires, and never catches up',()=>{
 const s=createFootfallSync();assert.equal(sample(s,.49,0),null);
 assert.equal(sample(s,.51,.05,{soles:{R:.08,L:0}}),null);
 const landed=sample(s,.53,.1,{soles:{R:.03,L:0}});assert.equal(landed.side,'R');assert.equal(landed.delay,.05);
 assert.equal(sample(s,.55,.15),null,'a delayed step never duplicates');
 sample(s,.99,.2);assert.equal(sample(s,1.01,.25,{soles:{L:.08,R:0}}),null);
 sample(s,1.03,.3,{soles:{L:.08,R:0}});sample(s,1.05,.35,{soles:{L:.08,R:0}});
 assert.equal(sample(s,1.07,.4),null,'an expired pending contact is discarded');
 assert.equal(sample(s,1.49,.45),null);assert.equal(sample(s,1.51,.5).side,'R');
});

test('near-contact gait switches preserve the phase clock instead of reseeding it',()=>{
 for(const change of [.4999,.5001]){
  const s=createFootfallSync();sample(s,.49,0);const a=sample(s,change,.03,{gait:'sneak'}),b=sample(s,.52,.06,{gait:'run'});
  assert.equal([a,b].filter(Boolean).length,1);assert.equal((a||b).side,'R');
 }
});

test('slow positive travel crosses contacts without an arbitrary walking-speed threshold',()=>{
 const s=createFootfallSync();sample(s,.4999999,0);
 assert.equal(sample(s,.5000001,.0000002).side,'R');
 for(const hz of [20,60,120]){const f=createPlayer(),sync=createFootfallSync();let count=0,x=0;
  f.setAnim('sneak',{travelDriven:true,phase:.49});
  for(let i=0;i<hz*3;i++){x+=.02/hz;f.root.position.x=x;f.update(1/hz,{speed:.02});if(sync.sample({phase:f.animator.cur.phase,gait:'sneak',x,z:0,dt:1/hz,soles:readFootSoles(f)}))count++;}
  assert.equal(count,1,`${hz} Hz quiet creep still lands one foot`);
 }
});

test('idle release drift, zero travel, pause, hide, vault and invalid clocks cancel pending contacts',()=>{
 for(const patch of [{gait:'idle'},{gait:'hide'},{gait:'vault'},{gait:'search'},{active:false},{dt:0},{dt:.5},{phase:NaN},{phase:-1},{x:99},{x:.05}]){
  const s=createFootfallSync();sample(s,.49,0);sample(s,.51,.05,{soles:{R:.08,L:0}});
  assert.equal(sample(s,.53,.1,patch),null,JSON.stringify(patch));
  assert.equal(sample(s,.55,.15),null,'old contact must not leak after boundary');
 }
 const s=createFootfallSync();sample(s,.49,0);sample(s,.51,.05,{soles:{R:.08,L:0}});s.reset();assert.equal(sample(s,.53,.1),null);
 assert.equal(sample(s,10,.15),null,'phase seeks never burst');
});

test('Act I actual contact playback preserves five surface banks, gains and pitch range',()=>captureAudio(calls=>{
 const a=act1();
 for(const surface of ['dirt','wood','leaf','gravel','water'])for(const gait of ['walk','sneak','run']){
  calls.length=0;a.playerFootfalls.reset();a.sim.surfaceKind=()=>surface;
  for(let i=0;i<120;i++)frame1(a,gait);
  assert.ok(calls.length>=2,`${surface}/${gait}: explicit nonzero playback`);
  for(const c of calls){assert.equal(c.name,'step_'+surface);const base={walk:.28,sneak:.12,run:.48}[gait]*.45;assert.ok(Math.min(Math.abs(c.volume-base*.96),Math.abs(c.volume-base*1.04))<1e-10);assert.ok(c.rate>=.96&&c.rate<1.04);}
 }
 calls.length=0;a.onEvent({t:'step',surface:'dirt',mode:'walk'});assert.equal(calls.length,0,'simulation event cannot double the audible contact');
 a.onEvent({t:'killerStep',indoors:false,x:10,z:0});a.onEvent({t:'killerStep',indoors:true,x:10,z:0});
 assert.deepEqual(calls.map(c=>[c.name,c.volume]),[['killer_step',1],['killer_step_wood',1]]);
}));

test('Act I zero volume advances contact clock without playback or a later burst',()=>captureAudio(calls=>{
 const a=act1();a.settings.steps=0;for(let i=0;i<180;i++)frame1(a,'walk');assert.equal(calls.length,0);
 a.settings.steps=.45;frame1(a,'walk');assert.ok(calls.length<=1);for(let i=0;i<120;i++)frame1(a,'walk');assert.ok(calls.length>=3);
 calls.length=0;for(let i=0;i<120;i++)frame1(a,'idle');assert.equal(calls.length,0,'release drift/idle never steps');
 for(const state of ['paused','dead','escape','disposed']){a.state=state;for(let i=0;i<90;i++)frame1(a,'run');assert.equal(calls.length,0,state);}
 a.state='play';a.disposed=true;for(let i=0;i<90;i++)frame1(a,'run');assert.equal(calls.length,0);
}));

test('Act I inactive and reset intervals suppress footsteps and resume at fresh contacts',()=>captureAudio(calls=>{
 const a=act1();for(let i=0;i<120;i++)frame1(a,'walk');assert.ok(calls.length>=3);
 for(const kind of ['map','hide','vault','car','blocking film']){
  calls.length=0;for(let i=0;i<120;i++)frame1(a,'walk',1/60,false);assert.equal(calls.length,0,kind);
  frame1(a,'walk');assert.equal(calls.length,0,'resuming seeds, never catches up');for(let i=0;i<120;i++)frame1(a,'walk');assert.ok(calls.length>=3);
 }
 a.playerFootfalls.reset();calls.length=0;frame1(a,'walk');assert.equal(calls.length,0,'retry/reset seeds');
}));

test('Act II actual actor update preserves surface/gain and independent killer footsteps',()=>captureAudio(calls=>{
 const a=act2();for(const indoors of [false,true])for(const gait of ['walk','sneak','run']){
  calls.length=0;a.playerFootfalls.reset();Object.assign(a.sim.player,{x:indoors?-12:0,z:indoors?0:12});
  for(let i=0;i<90;i++)frame2(a,gait);
  const player=calls.filter(c=>c.name.startsWith('step_'));assert.ok(player.length>=2);
  for(const c of player){assert.equal(c.name,indoors&&a.sim.player.z<8?'step_wood':'step_dirt');assert.equal(c.volume,gait==='run'?.32:.18);}
 }
 calls.length=0;Object.assign(a.sim.killer,{active:true,speed:2});a.settings.steps=0;
 for(let i=0;i<120;i++)frame2(a,'walk');assert.ok(calls.length>=2);assert.ok(calls.every(c=>c.name==='killer_step'&&c.volume===.65));
}));

test('Act II fatal/boarding ticks, hidden actor and teardown never emit counselor contacts',()=>captureAudio(calls=>{
 const a=act2();for(let i=0;i<120;i++)frame2(a,'walk');assert.ok(calls.length>=3);
 for(const phase of ['dead','escape','won']){calls.length=0;a.sim.phase=phase;for(let i=0;i<120;i++)frame2(a,'run');assert.equal(calls.length,0,phase);}
 a.sim.phase='play';a.sim.player.hidden={};for(let i=0;i<120;i++)frame2(a,'walk');assert.equal(calls.length,0);
 a.sim.player.hidden=null;frame2(a,'walk');assert.equal(calls.length,0);for(let i=0;i<120;i++)frame2(a,'walk');assert.ok(calls.length>=3);
 calls.length=0;a.disposed=true;for(let i=0;i<120;i++)frame2(a,'walk');assert.equal(calls.length,0);
}));
