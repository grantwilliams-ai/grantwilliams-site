import test from 'node:test';
import assert from 'node:assert/strict';
import{GameSim}from'../src/sim/game.js';
test('stationary strike recovery produces no phantom pursuit footsteps',()=>{
 const s=new GameSim({seed:91,skipIntro:true}),k=s.killer,p=s.player;
 Object.assign(k,{x:p.x,z:p.z-2.7,yaw:0,state:'strike',strikePhase:2,timer:.7,speed:3.85,stepAcc:0});let moved=0,events=[];
 for(let i=0;i<6;i++){const x=k.x,z=k.z;k.update(.1);moved+=Math.hypot(k.x-x,k.z-z);events.push(...s.drainEvents());}
 assert.equal(moved,0);assert.equal(k.speed,0);assert.equal(events.filter(e=>e.t==='killerStep').length,0);assert.equal(k.state,'strike');
});
test('attack movement reports actual traveled speed while preserving lunge distance',()=>{
 const s=new GameSim({seed:91,skipIntro:true}),k=s.killer,p=s.player;
 Object.assign(k,{x:0,z:0,yaw:0,state:'strike',strikePhase:1,timer:.18,speed:0});Object.assign(p,{x:0,z:5});
 s.collision.resolve=(x,z)=>[x,z];k.strike(.1);assert.ok(Math.abs(k.z-.55)<1e-10);assert.ok(Math.abs(k.speed-5.5)<1e-10);
 Object.assign(k,{x:0,z:0,strikePhase:0,timer:1,speed:3.85});s.collision.resolve=()=>[0,0];k.strike(.1);assert.equal(k.speed,0);
});

test('his far-off catch-up pace is flagged so it is never played as footsteps', async () => {
  const { GameSim } = await import('../src/sim/game.js');
  const sim = new GameSim({ seed: 11, difficulty: 'normal', skipIntro: true });
  const k = sim.killer;
  const steps = (speed, state) => {
    Object.assign(k, { speed, state, stepAcc: 0 });
    const before = sim.events.length;
    for (let i = 0; i < 120; i++) k.sounds(1 / 60);
    return sim.events.slice(before).filter((e) => e.t === 'killerStep');
  };
  const hurried = steps(k.tune.catchUp, 'patrol');
  assert.ok(hurried.length >= 6, 'at catch-up pace the step trigger fires several times a second');
  assert.ok(hurried.every((e) => e.hurry === true));
  assert.ok(steps(k.tune.walk, 'patrol').every((e) => e.hurry === false));
  assert.ok(steps(k.tune.chase * 1.2, 'chase').every((e) => e.hurry === false), 'a chase is always heard');
});
