import test from 'node:test';
import assert from 'node:assert/strict';
import { GameSim } from '../src/sim/game.js';

const IDLE_INPUT = { moveX: 0, moveY: 0, camYaw: 0, run: false, sneak: false, action: false, actionHeld: false, flashlight: false };

function detectionTimes({ count, cabin = false }) {
  const times = [];
  for (let seed = 1000; seed < 1000 + count; seed++) {
    const sim = new GameSim({ seed, skipIntro: true, difficulty: 'normal' });
    if (cabin) {
      for (const door of sim.collision.doors) if (door.id.startsWith('cabin1')) door.open = true;
      sim.player.x = -27;
      sim.player.z = -5;
    }
    let detected = null;
    for (let i = 0; i < 120 * 30 && sim.phase === 'play' && detected === null; i++) {
      sim.step(1 / 30, IDLE_INPUT);
      if (sim.stats.seen > 0) detected = sim.time;
      sim.drainEvents();
    }
    assert.ok(detected !== null, `${cabin ? 'cabin' : 'open ground'} seed ${seed} was never detected`);
    times.push(detected);
  }
  return times.sort((a, b) => a - b);
}

function checkTimes(t, times, medianLimit, lastLimit) {
  const median = times[Math.floor(times.length / 2)];
  t.diagnostic(`median ${median.toFixed(1)}s; latest ${times.at(-1).toFixed(1)}s`);
  assert.ok(median <= medianLimit, `median detection ${median.toFixed(1)}s exceeds ${medianLimit}s`);
  assert.ok(times.at(-1) <= lastLimit, `latest detection ${times.at(-1).toFixed(1)}s exceeds ${lastLimit}s`);
}

test('Jason discovers outdoor loitering before the old two-minute lull', (t) => {
  checkTimes(t, detectionTimes({ count: 20 }), 65, 100);
});

test('Jason can discover a stationary player inside a cabin', (t) => {
  checkTimes(t, detectionTimes({ count: 20, cabin: true }), 80, 120);
});
