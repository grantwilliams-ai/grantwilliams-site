import test from 'node:test';
import assert from 'node:assert/strict';
import { GameSim } from '../src/sim/game.js';
import { LAYOUT } from '../src/sim/layout.js';
import { PLAYER } from '../src/ai/tuning.js';
import { Act2Sim, walkable } from '../src/act2/sim.js';
import { HIDE_SPOTS } from '../src/act2/layout.js';

const cabinIds=['cabin1.bed','cabin2.bed','cabin3.bed','cabin1.closet','cabin2.closet','cabin3.closet'];
const noMove={moveX:0,moveY:0,camYaw:0,action:false,actionHeld:false};
function camp(){const sim=new GameSim({skipIntro:true,seed:42});sim.killer.state='wait';sim.killer.timer=1000;return sim;}
function annex(){return new Act2Sim({arrivalTime:10000});}
function campEdge(sim,id,r=1.14){
  const h=LAYOUT.hides.find(h=>h.id===id);
  for(let i=0;i<64;i++){
    const a=i*Math.PI/32,dx=Math.sin(a),dz=Math.cos(a),x=h.x+dx*r,z=h.z+dz*r;
    if(sim.collision.blocked(x,z,PLAYER.radius))continue;
    Object.assign(sim.player,{x,z,vx:0,vz:0,hidden:null});
    const it=sim.findInteraction();
    if(it?.kind==='hide'&&it.spot.id===id)return {h,a,dx,dz};
  }
  assert.fail(`${id} needs a reachable hide edge`);
}
function annexEdge(sim,h,r=h.radius-.01){
  for(let i=0;i<64;i++){
    const a=i*Math.PI/32,dx=Math.sin(a),dz=Math.cos(a),x=h.x+dx*r,z=h.z+dz*r;
    if(!walkable(x,z,.32,sim.obstacles))continue;
    Object.assign(sim.p,{x,z,hidden:null});sim.updatePrompt();
    if(sim.prompt?.kind==='hide'&&sim.nearbyHide()?.id===h.id)return {a,dx,dz};
  }
  assert.fail(`${h.id} needs a reachable hide edge`);
}

test('Act I accepts a visible hide press before outward walking or release inertia crosses its exact edge',()=>{
  for(const id of cabinIds)for(const dt of [1/60,.05])for(const moving of [true,false]){
    const s=camp(),g=campEdge(s,id);s.prompt=s.findInteraction();
    Object.assign(s.player,{vx:g.dx*PLAYER.walk,vz:g.dz*PLAYER.walk});
    s.step(dt,{...noMove,moveY:moving?1:0,camYaw:g.a,action:true});
    assert.equal(s.player.hidden?.id,id,`${id} at ${dt}: honor visible HIDE`);
    assert.equal(s.events.filter(e=>e.t==='hide').length,1);assert.equal(s.events.some(e=>e.t==='unhide'),false);
    assert.equal(s.prompt?.kind,'leave');
    s.step(dt,{...noMove,actionHeld:true});assert.equal(s.player.hidden?.id,id,'held E cannot also leave');
    s.step(dt,{...noMove,action:true});assert.equal(s.player.hidden,null,'a second press still leaves');
  }
});

test('Act II accepts a visible hide press before movement without changing reach or single-press behavior',()=>{
  for(const h of HIDE_SPOTS)for(const dt of [1/60,.05]){
    const s=annex(),g=annexEdge(s,h);s.step(dt,{moveX:g.dx,moveZ:g.dz,action:true});
    assert.equal(s.p.hidden?.id,h.id);assert.equal(s.events.filter(e=>e.type==='hide').length,1);assert.equal(s.events.some(e=>e.type==='leaveHide'),false);
    s.step(dt,{actionHeld:true});assert.equal(s.p.hidden?.id,h.id);
    s.step(dt,{action:true});assert.equal(s.p.hidden,null);
  }
});

test('a fresh press while entering range in the current frame still works in both halves',()=>{
  for(const id of cabinIds){
    const s=camp(),g=campEdge(s,id);Object.assign(s.player,{x:g.h.x+g.dx*1.18,z:g.h.z+g.dz*1.18,vx:-g.dx*PLAYER.walk,vz:-g.dz*PLAYER.walk});
    assert.notEqual(s.findInteraction()?.kind,'hide');s.step(.05,{...noMove,moveY:-1,camYaw:g.a,action:true});assert.equal(s.player.hidden?.id,id);
  }
  for(const h of HIDE_SPOTS){
    const s=annex(),g=annexEdge(s,h);Object.assign(s.p,{x:h.x+g.dx*(h.radius+.04),z:h.z+g.dz*(h.radius+.04)});s.updatePrompt();
    assert.notEqual(s.prompt?.kind,'hide');s.step(.05,{moveX:-g.dx,moveZ:-g.dz,action:true});assert.equal(s.p.hidden?.id,h.id);
  }
});

test('pressing outside range is not buffered and held E does not auto-hide on a later frame',()=>{
  for(const id of cabinIds){
    const s=camp(),g=campEdge(s,id);Object.assign(s.player,{x:g.h.x+g.dx*1.18,z:g.h.z+g.dz*1.18});
    s.step(.05,{...noMove,action:true,actionHeld:true});assert.equal(s.player.hidden,null);
    Object.assign(s.player,{vx:-g.dx*PLAYER.walk,vz:-g.dz*PLAYER.walk});
    s.step(.05,{...noMove,moveY:-1,camYaw:g.a,actionHeld:true});assert.equal(s.player.hidden,null);assert.equal(s.findInteraction()?.kind,'hide');
  }
  for(const h of HIDE_SPOTS){
    const s=annex(),g=annexEdge(s,h);Object.assign(s.p,{x:h.x+g.dx*(h.radius+.04),z:h.z+g.dz*(h.radius+.04)});
    s.step(.05,{action:true,actionHeld:true});assert.equal(s.p.hidden,null);
    s.step(.05,{moveX:-g.dx,moveZ:-g.dz,actionHeld:true});assert.equal(s.p.hidden,null);assert.equal(s.prompt?.kind,'hide');
  }
});

test('searches still win their existing overlap with hiding, and E alone does not complete a held search',()=>{
  const s=camp(),h=LAYOUT.hides.find(h=>h.id==='cabin2.closet');let found=false;
  for(let i=0;i<64;i++){
    const a=i*Math.PI/32;Object.assign(s.player,{x:h.x+Math.sin(a)*1.14,z:h.z+Math.cos(a)*1.14,vx:0,vz:0});
    if(s.collision.blocked(s.player.x,s.player.z,PLAYER.radius)||s.findInteraction()?.kind!=='search')continue;
    const spot=s.findInteraction().spot;s.step(.05,{...noMove,action:true});
    assert.equal(s.player.hidden,null);assert.equal(s.prompt.kind,'search');assert.equal(s.holdT,0);assert.equal(s.searched.has(spot.id),false);found=true;break;
  }
  assert.equal(found,true,'real cabin search/hide overlap exercised');
});

test('the Act II frame-start path retains its solid obstruction check',()=>{
  const s=annex(),h=HIDE_SPOTS.find(h=>h.id==='tent');Object.assign(s.p,{x:h.x,z:h.z+1});
  s.obstacles=[...s.obstacles,{id:'closed-panel',minX:h.x-2,maxX:h.x+2,minZ:h.z+.4,maxZ:h.z+.6,height:2.5}];
  s.updatePrompt();assert.notEqual(s.prompt?.kind,'hide');
  s.step(.05,{action:true});assert.equal(s.p.hidden,null);assert.equal(s.events.some(e=>e.type==='hide'),false);
});

test('visible entry still records a witnessed hide in both halves',()=>{
  const s=camp();campEdge(s,'cabin2.bed');
  for(let i=0;i<32;i++){
    const yaw=i*Math.PI/16,x=s.player.x+Math.sin(yaw)*.85,z=s.player.z+Math.cos(yaw)*.85;
    if(s.collision.blocked(x,z,.36))continue;
    Object.assign(s.killer,{state:'chase',x,z,yaw:yaw+Math.PI,headYaw:0});if(s.killer.observe().visible)break;
  }
  assert.equal(s.killer.observe().visible,true);s.step(.05,{...noMove,action:true});assert.equal(s.player.seenEntering,true);assert.ok(s.events.some(e=>e.t==='hideSeen'));
  const a=annex(),h=HIDE_SPOTS.find(h=>h.id==='tent');annexEdge(a,h);Object.assign(a.killer,{active:true,state:'chase',x:a.p.x,z:a.p.z+1,yaw:Math.PI});
  assert.equal(a.canSeePlayer(),true);a.step(.05,{action:true});assert.equal(a._knownHide?.id,h.id);assert.ok(a.events.some(e=>e.type==='hideSeen'));
});
