import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { App } from '../src/game/app.js';
import { Cinematics } from '../src/game/cinematics.js';
import { GLOBALS } from '../src/render/materials.js';
import { audio } from '../src/audio/index.js';

function appFixture(campaign) {
  const app = Object.create(App.prototype), calls = [];
  Object.assign(app, {campaign, chapterComplete:false, disposed:false, thunderTimers:new Set(),
    state:'play',sim:{time:213},difficulty:'normal',settings:{brightness:1.2,sound:.6,picture:'sharp'},
    post:Object.fromEntries(['uTear','uFlash','uFade','uLetterbox'].map(k=>[k,{value:1}])),
    camera:new THREE.PerspectiveCamera(),world:{car:new THREE.Group()},
    killer:{root:new THREE.Group(),setAnim(){},update(){}},flash:{setOn(){},update(){}},
    ui:{setPrompt:x=>calls.push(['prompt',x]),setObjective:x=>calls.push(['objective',x]),caption:x=>calls.push(['caption',x]),setTouchVisible:x=>calls.push(['touch',x]),setInventory(){}}});
  return {app,calls};
}

test('gate drive transitions at its final fade exactly once without the standalone dawn',()=>{
  const transfers=[];const {app}=appFixture({onEscape:x=>transfers.push(x)});
  const cine=new Cinematics(app);let dawn=0;cine.dawn=()=>dawn++;app.cine=cine;
  const original=Object.fromEntries(['sfx','music','loop','setListener'].map(k=>[k,audio[k]]));
  Object.assign(audio,{sfx(){},music(){},loop(){return {stop(){},setVolume(){}};},setListener(){}});
  try{
    cine.engineStart();cine.update(11.29);assert.equal(transfers.length,0);assert.equal(app.state,'play');
    cine.update(.02);assert.equal(transfers.length,1);assert.equal(dawn,0);assert.equal(app.state,'transition');
    assert.equal(app.post.uFade.value,0);assert.equal(transfers[0].time,213);assert.equal(transfers[0].difficulty,'normal');
    assert.deepEqual(transfers[0].settings,app.settings);assert.notEqual(transfers[0].settings,app.settings);
    cine.update(10);cine.finishDrive();assert.equal(transfers.length,1);assert.equal(dawn,0);
  }finally{Object.assign(audio,original);}
});

test('standalone chapter retains dawn when no campaign callback is present',()=>{
  const {app}=appFixture(null);const cine=new Cinematics(app);let dawn=0;cine.dawn=()=>dawn++;
  cine.finishDrive();assert.equal(dawn,1);assert.equal(app.state,'play');
});

test('shared setting changes map sound to volume and constructor initialization stays quiet',()=>{
  const settings=[];const {app}=appFixture({onSetting:(...v)=>settings.push(v)});
  app.post.uBrightness={value:1};app.initializing=true;app.setting('brightness',1.3);assert.equal(settings.length,0);
  app.initializing=false;app.setting('sound',.42);app.setting('brightness',1.4);
  assert.deepEqual(settings,[['volume',.42],['brightness',1.4]]);assert.equal(app.settings.sound,.42);assert.equal(app.post.uBrightness.value,1.4);
  app.disposed=true;app.setting('brightness',1.5);assert.equal(settings.length,2);
});

test('chapter disposal cancels work and owned loops once, and stale frame callbacks do nothing',()=>{
  const {app}=appFixture({onEscape:()=>assert.fail('disposed chapter must not transfer')});const calls=[];
  app.running=true;app.raf=45;app.onVisibilityChange=()=>{};app.onWindowBlur=()=>{};
  app.cine={clear:()=>calls.push('cine-clear'),restoreCar:()=>calls.push('cine-restore')};
  app.deathSeq={restore:()=>calls.push('death-restore')};app.ui.dispose=()=>calls.push('ui-dispose');
  for(const key of ['fireLoop','genLoop','lapLoop'])app[key]={stop:()=>calls.push(key)};
  app.thunderTimers.add({night:app.sim,remaining:.4,strength:1});
  const oldDocument=globalThis.document,oldCancel=globalThis.cancelAnimationFrame,oldWindow=globalThis.window;
  globalThis.document={removeEventListener:(event,handler)=>{assert.equal(event,'visibilitychange');assert.equal(handler,app.onVisibilityChange);calls.push('listener');}};
  globalThis.window={removeEventListener:(event,handler)=>{assert.equal(event,'blur');assert.equal(handler,app.onWindowBlur);calls.push('blur-listener');}};
  globalThis.cancelAnimationFrame=id=>{assert.equal(id,45);calls.push('raf');};
  try{
    GLOBALS.uSubject.value.w=1;app.dispose();app.dispose();app.frame(100);app.tick(.1);assert.equal(app.completeActOne(),true);
    assert.equal(app.running,false);assert.equal(app.state,'disposed');assert.equal(app.sim,null);assert.equal(app.thunderTimers.size,0);assert.equal(GLOBALS.uSubject.value.w,0);
    assert.deepEqual(calls,['raf','listener','blur-listener','death-restore','cine-clear','cine-restore','fireLoop','genLoop','lapLoop','ui-dispose']);
  }finally{globalThis.document=oldDocument;globalThis.window=oldWindow;globalThis.cancelAnimationFrame=oldCancel;}
});

test('hood stays closed through the reveal, opens at 8.2 seconds, and resets for intro or skip-intro play',()=>{
  const {app}=appFixture(null),car=new THREE.Group(),hoodPivot=new THREE.Group();
  car.userData={hoodPivot,setHeadlights(){}};
  app.world.car=car;app.world.root=new THREE.Group();app.mainScene=new THREE.Scene();app.camera=new THREE.PerspectiveCamera();
  app.quality={isTouch:false};app.playerFig={root:new THREE.Group()};app.rig={};
  app.ui.showTitleCard=()=>{};app.ui.setHide=()=>{};app.ui.setCarMode=()=>{};
  app.sim={time:0,phase:'intro',killer:{state:'wait'},car:{threat:0},beginHunt(){this.phase='play';}};
  const cine=new Cinematics(app);app.cine=cine;app.flash.showBeam=false;
  const original=Object.fromEntries(['ambience','sfx','setRoom'].map(k=>[k,audio[k]]));
  Object.assign(audio,{ambience(){},sfx(){},setRoom(){}});
  try{
    cine.restoreCar();assert.equal(hoodPivot.rotation.x,0);
    hoodPivot.rotation.x=-1;cine.carReveal();assert.equal(hoodPivot.rotation.x,0);assert.equal(app.flash.showBeam,true);
    cine.update(4.2);assert.equal(hoodPivot.rotation.x,0);
    cine.update(3.9);assert.equal(hoodPivot.rotation.x,0);
    cine.update(.1);assert.ok(Math.abs(hoodPivot.rotation.x+1.05)<1e-9);assert.equal(app.sim.phase,'play');assert.equal(app.post.uLetterbox.value,0);
    hoodPivot.rotation.x=0;cine.restoreCar();assert.ok(Math.abs(hoodPivot.rotation.x+1.05)<1e-9);
    app.sim.phase='intro';cine.restoreCar();assert.equal(hoodPivot.rotation.x,0);
    app.flash.showBeam=false;cine.carScene();assert.equal(app.flash.showBeam,true);
  }finally{Object.assign(audio,original);}
});
