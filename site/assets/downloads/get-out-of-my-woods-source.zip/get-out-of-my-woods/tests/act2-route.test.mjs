import test from 'node:test';
import assert from 'node:assert/strict';
import {Act2Sim,findPath,walkable,clearSegment} from '../src/act2/sim.js';
import {LOCATIONS,OBSTACLES,HIDE_SPOTS,INSPECT_SPOTS,PATROL_CIRCUITS,ROUTE_LANDMARKS} from '../src/act2/layout.js';
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
const peaceful=()=>new Act2Sim({arrivalTime:100000});
const advance=(sim,seconds,input={})=>{for(let i=0;i<Math.ceil(seconds*60)&&sim.phase==='play';i++)sim.step(1/60,input);};
function drive(sim,goal,{run=false,reactive=false}={}){
  const route=findPath(sim.p,goal,.32,sim.obstacles);assert.ok(route.length,`route to ${goal.x},${goal.z}`);
  for(const target of route){
    let budget=5000;
    while(distance(sim.p,target)>.12&&sim.phase==='play'&&budget--){
      const d=distance(sim.p,target),near=distance(sim.p,sim.killer)<12;
      const before={x:sim.p.x,z:sim.p.z};
      sim.step(1/60,{moveX:(target.x-sim.p.x)/d,moveZ:(target.z-sim.p.z)/d,run:run||(reactive&&(near||sim.killer.state==='chase')),flashlight:true});
      assert.ok(distance(before,sim.p)<4.7/60+.001,'player speed remains bounded');
      assert.ok(walkable(sim.p.x,sim.p.z,.32,sim.obstacles),'player remains outside solids');
    }
    assert.ok(budget>0,'physical movement reaches path node');
    if(sim.phase!=='play')return false;
  }
  return true;
}

test('both creek crossings connect crash, lower camp, service yard and van for both body widths',()=>{
  for(const radius of [.32,.42])for(const side of [-1,1]){
    let from=LOCATIONS.start;
    for(const to of [{x:0,z:-28},{x:side*20,z:-48},{x:side*20,z:-68},{x:side*14,z:-86},LOCATIONS.keys,LOCATIONS.vanDoor]){
      assert.ok(walkable(to.x,to.z,radius),`destination ${JSON.stringify(to)}`);
      const path=findPath(from,to,radius);assert.ok(path.length);
      for(const p of path){assert.ok(clearSegment(from,p,radius));from=p;}
    }
  }
  assert.equal(clearSegment({x:0,z:-50},{x:0,z:-68},.32),false,'creek cannot be crossed through the bank');
  assert.equal(clearSegment({x:-20,z:-50},{x:-20,z:-68},.42),true);
  assert.equal(clearSegment({x:20,z:-50},{x:20,z:-68},.42),true);
});

test('all patrol circuits and optional search spots are reachable without crossing solids',()=>{
  for(const route of PATROL_CIRCUITS)for(let i=0;i<route.length;i++)assert.ok(findPath(route[i],route[(i+1)%route.length],.42).length);
  for(const clue of INSPECT_SPOTS){
    assert.ok(walkable(clue.x,clue.z,.32));assert.ok(findPath(LOCATIONS.start,clue,.32).length);
    const s=peaceful();Object.assign(s.p,clue);s.updatePrompt();assert.equal(s.prompt.kind,'inspect');
    s.interact();assert.equal(s.events.at(-1).clue,true);assert.equal(s.events.at(-1).text,clue.text);
    assert.equal(s.stats.clues,1);s.interact();assert.equal(s.stats.clues,1,'reading again does not add another discovery');
    assert.equal(s.keys,false);assert.equal(s.weapon,'none');assert.equal(s.phase,'play');
  }
});

test('route guidance progresses through landmarks, survives backtracking, and leaves all clues optional',()=>{
  const s=peaceful();assert.equal(s.routeStage,0);assert.equal(s.navigation.label,'CABIN LIGHT');
  for(const point of [{x:0,z:12},{x:0,z:-28},{x:-20,z:-68},{x:-14,z:-94},{x:0,z:-109},LOCATIONS.keys])assert.ok(drive(s,point));
  assert.equal(s.routeStage,5);assert.equal(s.stats.clues,0);assert.equal(s.inspected.size,0);
  assert.ok(drive(s,{x:0,z:-107}));assert.equal(s.routeStage,5,'backtracking retains discovered guidance');
  assert.ok(drive(s,LOCATIONS.keys));
  assert.ok(s.objective.includes('keys'));advance(s,1.5,{actionHeld:true});assert.equal(s.keys,true);
  assert.deepEqual(s.navigation,{...LOCATIONS.vanDoor,label:'DRIVER’S DOOR'});
  assert.ok(drive(s,LOCATIONS.vanDoor));s.interact();assert.equal(s.phase,'escape');
  assert.equal(s.discovered.size,ROUTE_LANDMARKS.length);
});

test('late tent is reachable, hides and releases cleanly without moving the original tent view',()=>{
  const s=peaceful(),h=HIDE_SPOTS.find(h=>h.id==='lower-tent');
  assert.ok(findPath({x:-14,z:-86},h,.32).length);Object.assign(s.p,{x:h.x,z:h.z});s.updatePrompt();
  assert.equal(s.prompt.kind,'hide');s.interact();assert.equal(s.p.hidden.id,h.id);assert.equal(s.canSeePlayer(),false);
  s.interact();assert.equal(s.p.hidden,null);assert.ok(walkable(s.p.x,s.p.z));
  assert.deepEqual(HIDE_SPOTS.find(h=>h.id==='tent').view,{x:12.35,y:.95,z:10.6});
});

test('bridge creak supplies one remembered sound position, never a moving player target',()=>{
  const s=peaceful();Object.assign(s.p,{x:-20,z:-55.9,flashlight:false});
  Object.assign(s.killer,{x:-30,z:-37,yaw:0,active:true,state:'patrol'});
  s.step(.1,{moveZ:-1,flashlight:false});
  const sounds=s.events.filter(e=>e.type==='bridgeNoise');assert.equal(sounds.length,1);
  assert.equal(s.killer.state,'search');assert.deepEqual(s.killer.lastSeen,{x:-20,z:-58});
  const until=s._searchUntil;assert.ok(until>s.time+10);
  advance(s,1,{moveZ:-1,flashlight:false});assert.equal(s.events.filter(e=>e.type==='bridgeNoise').length,1);
  assert.deepEqual(s.killer.lastSeen,{x:-20,z:-58});assert.equal(s._searchUntil,until);
});

test('regional patrol updates never interrupt search, chase or four-second stagger',()=>{
  for(const state of ['search','chase','stagger']){
    const s=peaceful();Object.assign(s.p,{x:0,z:-110,flashlight:false});
    Object.assign(s.killer,{x:-28,z:-8,yaw:0,active:true,state,stagger:4,lastSeen:{x:-25,z:-4},target:{x:-25,z:-4}});
    s._searchUntil=100;s._seenAt=s.time;s.step(.1,{flashlight:false});
    assert.equal(s.killer.state,state);assert.equal(s._patrolCircuit,-1);
    assert.ok(distance(s.killer,{x:-28,z:-8})<.32,'no relocation');
  }
});

test('physical active route produces pursuit then evasion and can reach the van',()=>{
  const s=new Act2Sim();
  for(const point of [{x:0,z:13},{x:-12,z:10},LOCATIONS.weapon,{x:-12,z:-5},{x:-8,z:-30},{x:-20,z:-48},{x:-20,z:-68},{x:-14,z:-86},{x:-9,z:-105},LOCATIONS.keys]){
    assert.ok(drive(s,point,{reactive:true}),`survived to ${JSON.stringify(point)}`);
    if(point===LOCATIONS.weapon)s.interact();
  }
  assert.ok(s.stats.seen>0,'actual sight generated a chase');
  assert.ok(s.events.some(e=>e.type==='lost'),'cover or distance allowed pursuit to end');
  assert.ok(s.events.some(e=>e.type==='bridgeNoise'));
  advance(s,1.5,{actionHeld:true});assert.equal(s.keys,true);
  assert.ok(drive(s,LOCATIONS.vanDoor,{reactive:true}));s.interact();assert.equal(s.phase,'escape');
  console.log('expanded route diagnostic',JSON.stringify({seconds:+s.time.toFixed(1),distance:+s.stats.distance.toFixed(1),chases:s.stats.seen,losses:s.events.filter(e=>e.type==='lost').length,clues:s.stats.clues}));
});


test('exploration and a seen late-hide attempt permit a second pursuit without any killer relocation',()=>{
  const s=new Act2Sim();
  for(const goal of [{x:0,z:13},{x:-12,z:10},INSPECT_SPOTS[0],LOCATIONS.weapon,{x:-12,z:-5},INSPECT_SPOTS[1],INSPECT_SPOTS[2],{x:-20,z:-68},INSPECT_SPOTS[3],HIDE_SPOTS[2],{x:-9,z:-105},LOCATIONS.keys]){
    assert.ok(drive(s,goal,{reactive:true}));
    if(goal===LOCATIONS.weapon)s.interact();
    if(goal.id&&goal.kind!=='tent'){
      s.interact();
      // A player can keep moving while reading. Stop only while there is room.
      for(let i=0;i<360&&s.phase==='play'&&distance(s.p,s.killer)>13;i++)s.step(1/60,{});
    }
    if(goal.kind==='tent'){
      s.interact();
      for(let i=0;i<60*18&&s.phase==='play'&&s.killer.state!=='check-hide';i++)s.step(1/60,{});
      if(s.p.hidden)s.interact();
    }
  }
  assert.ok(s.stats.seen>=2);assert.equal(s.stats.clues,4);assert.equal(s.stats.hides,1);
  assert.ok(s.events.some(e=>e.type==='hideSeen'),'seen hiding warns rather than making the tent safe');
  advance(s,1.5,{actionHeld:true});assert.equal(s.keys,true);
  assert.ok(drive(s,LOCATIONS.vanDoor,{reactive:true}));s.interact();assert.equal(s.phase,'escape');
  console.log('exploration route diagnostic',JSON.stringify({seconds:+s.time.toFixed(1),distance:+s.stats.distance.toFixed(1),chases:s.stats.seen,hides:s.stats.hides,clues:s.stats.clues}));
});

test('a bridge search budget covers the actual opposite-crossing detour and stops at the remembered sound',()=>{
  const s=peaceful();Object.assign(s.p,{x:-20,z:-55.9,flashlight:false});
  Object.assign(s.killer,{x:20,z:-58,yaw:0,active:true,state:'patrol'});
  const origin={x:s.killer.x,z:s.killer.z};s.step(.1,{moveZ:-1,flashlight:false});
  assert.equal(s.killer.state,'search');assert.deepEqual(s.killer.lastSeen,{x:-20,z:-58});
  assert.ok(s._searchUntil-s.time>distance(origin,s.killer.lastSeen)/2.05+9,'clock includes physical detour, not just audible radius');
  const target={...s.killer.lastSeen};s.p.hidden=HIDE_SPOTS[0];
  let reached=false;
  for(let i=0;i<60*100&&s.time<s._searchUntil;i++){
    const before={x:s.killer.x,z:s.killer.z};s.step(1/60,{flashlight:false});
    assert.ok(distance(before,s.killer)<=2.05/60+.001);assert.ok(walkable(s.killer.x,s.killer.z,.42));
    if(distance(s.killer,target)<.65){reached=true;break;}
  }
  assert.ok(reached,'physically reaches the far crossing before search expires');
  assert.ok(s._searchUntil-s.time>5,'time remains to inspect after arrival');
  assert.deepEqual(s.killer.lastSeen,target);
});


test('a successful crowbar hit followed by late hiding keeps the full four-second stun',()=>{
  const s=peaceful(),h=HIDE_SPOTS.find(h=>h.id==='lower-tent');
  Object.assign(s.p,{x:h.x,z:h.z,yaw:0});s.weapon='ready';
  Object.assign(s.killer,{x:h.x,z:h.z+2,yaw:Math.PI,active:true,state:'chase'});
  assert.equal(s.canSeePlayer(),true);assert.equal(s.defend(),true);
  assert.equal(s.killer.stagger,4);assert.equal(s.interact(),true);assert.equal(s.p.hidden.id,h.id);
  assert.equal(s.killer.state,'stagger');assert.equal(s._knownHide,null);
  assert.equal(s.events.some(e=>e.type==='hideSeen'),false);
  const stopped={x:s.killer.x,z:s.killer.z};advance(s,3.8,{});
  assert.equal(s.killer.state,'stagger');assert.deepEqual({x:s.killer.x,z:s.killer.z},stopped);
  assert.equal(s.phase,'play');advance(s,.3,{});
  assert.equal(s.killer.state,'search');assert.equal(s._knownHide,null);assert.equal(s.p.hidden.id,h.id);
});
