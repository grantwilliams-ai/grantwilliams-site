import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { createDeathScene, DEATH_SCENES, sampleDeathScene, deathApproach } from '../src/act2/death-scene.js';
import { clearSegment } from '../src/act2/sim.js';
import { createPlayer } from '../src/characters/player.js';
import { createAct2Killer } from '../src/act2/killer.js';

// Real skeletons, geometry and camera math; no WebGL, GPU, audio device or models.
globalThis.document = { createElement: () => ({ getContext: () => ({ fillRect() {}, beginPath() {}, ellipse() {}, fill() {} }) }) };
function fixture(kind) {
  const figure = createPlayer(), killerFigure = createAct2Killer();
  const tent = kind === 'tent', wardrobe = kind === 'wardrobe';
  const p = tent ? { x: 12, z: 13.2, yaw: 0, hidden: { kind, x: 12, z: 13.2, view: { x: 12.35, y: .95, z: 10.6 } } }
    : wardrobe ? { x: -8.8, z: 1.5, yaw: -Math.PI / 2, hidden: { kind, x: -8.8, z: 1.5, view: { x: -7.2, y: 1.6, z: 1 } } }
    : { x: 0, z: 0, yaw: Math.PI, hidden: null };
  const k = tent ? { x: 12, z: 14.6, yaw: Math.PI } : wardrobe ? { x: -9.7, z: 1, yaw: Math.PI / 2 } : { x: 0, z: 1.4, yaw: Math.PI };
  Object.assign(k, { active: true, attackHit: !p.hidden, attackPhase: p.hidden ? null : 'strike', attackProgress: .6 });
  const camera = new THREE.PerspectiveCamera(58, 16 / 9, .08, 210), view = p.hidden?.view;
  camera.position.set(view?.x ?? 0, view?.y ?? 2.8, view?.z ?? -5); camera.lookAt(k.x, 1.5, k.z);
  figure.root.position.set(p.x, 0, p.z); figure.root.rotation.y = p.yaw;
  const flap = sign => {
    const g = new THREE.BufferGeometry();g.setAttribute('position', new THREE.Float32BufferAttribute([sign * 2, 0, 2.08, sign * .86, .15, 2.1, 0, 2.3, 2.08], 3));g.computeVertexNormals();
    return new THREE.Mesh(g, new THREE.MeshBasicMaterial());
  };
  const door = new THREE.Mesh(new THREE.BoxGeometry(.12, 2.4, 1.35), new THREE.MeshBasicMaterial());door.position.set(-7.9, 1.2, .55);door.rotation.y = -.5;
  const events = [], sounds = [];
  const audio = { sfx: (name, options) => sounds.push({ name, options }), music() {}, setIntensity() {}, setRoom() {}, setListener() {} };
  const app = { figure, killerFigure, camera, heldCrowbar: { visible: true }, flash: new THREE.SpotLight(),
    sim: { player: p, killer: k, obstacles: [] }, world: { deathProps: { tentFlaps: [flap(-1), flap(1)], wardrobeDoor: door } },
    post: Object.fromEntries(['uRed', 'uDanger', 'uFade', 'uFlash', 'uLetterbox'].map(k => [k, { value: 0 }])), say: (...x) => events.push(x) };
  return { app, scene: createDeathScene(app, { audio }), sounds, events };
}

test('fatal timeline has exact live-attack contact and bounded authored durations', () => {
  for (const kind of ['tent', 'wardrobe']) {
    const plan = DEATH_SCENES[kind], contact = sampleDeathScene(kind, plan.impact);
    assert.equal(contact.attackPhase, 'strike');assert.ok(Math.abs(contact.attackProgress - .6) < 1e-9);
    assert.equal(sampleDeathScene(kind, plan.windup - .001).attackPhase, null);
    assert.equal(sampleDeathScene(kind, plan.duration).fade, 0);
    assert.equal(sampleDeathScene(kind, plan.duration).finished, true);
  }
  assert.equal(sampleDeathScene('outdoors', 0, .73).attackProgress, .73);
  assert.equal(sampleDeathScene('outdoors', .055, .73).attackPhase, 'recover');
  assert.equal(sampleDeathScene('outdoors', 1).attackPhase, null);
});

for (const kind of ['outdoors', 'tent', 'wardrobe']) test(`${kind}: real rigs stay grounded, the approach is continuous, and the camera looks toward the scene`, () => {
  const { app, scene, sounds } = fixture(kind), k = { ...app.sim.killer };
  if (kind === 'tent') app.sim.obstacles.push({ id: 'tent', minX: 10, maxX: 14, minZ: 8, maxZ: 12 });
  const initialView = app.camera.quaternion.clone();
  assert.equal(scene.begin({ kind }), DEATH_SCENES[kind].duration);
  assert.ok(app.camera.quaternion.angleTo(initialView) < 1e-6, 'first frame preserves the incoming view');
  for (let i = 0; i < 300 && scene.time < scene.duration; i++) {
    const before = { x: app.sim.killer.x, z: app.sim.killer.z };
    scene.tick(1 / 60);
    assert.equal(app.killerFigure.root.position.x, app.sim.killer.x);assert.equal(app.killerFigure.root.position.z, app.sim.killer.z);
    if (kind !== 'tent') { assert.equal(app.sim.killer.x, k.x);assert.equal(app.sim.killer.z, k.z); }
    assert.ok(Math.hypot(app.sim.killer.x - before.x, app.sim.killer.z - before.z) < .06, 'no frame teleports');
    assert.ok(clearSegment(before, app.sim.killer, .42, app.sim.obstacles), 'whole actor sweep clears obstacles');
    assert.ok(app.camera.position.toArray().every(Number.isFinite));
    assert.ok(app.killerFigure.figure.animator.P.a.every(Number.isFinite));
    if (kind === 'tent') { assert.ok(app.camera.position.x > 10 && app.camera.position.x < 14);assert.ok(app.camera.position.z > 8 && app.camera.position.z < 12);assert.ok(app.sim.killer.z >= 12.42); }
    if (kind === 'wardrobe') { assert.ok(app.camera.position.x > -7.9 && app.camera.position.x < -6.6);assert.ok(app.camera.position.z > .2 && app.camera.position.z < 1.8); }
  }
  assert.equal(app.post.uFade.value, 0);assert.equal(sounds.filter(s => s.name === 'body_hit').length, 1);
  assert.equal(sounds.filter(s => s.name === 'scream_death').length, 1);
  assert.equal(sounds.filter(s => s.name === 'body_fall').length, 1);
  const direction = app.camera.getWorldDirection(new THREE.Vector3()), toward = new THREE.Vector3(app.sim.killer.x, .8, app.sim.killer.z).sub(app.camera.position).normalize();
  assert.ok(direction.dot(toward) > .65, 'camera faces threat, not backwards');
  if (kind === 'outdoors') {
    app.figure.root.updateMatrixWorld(true);
    assert.ok(app.figure.rig.b('head').getWorldPosition(new THREE.Vector3()).y < .6, 'counselor ends on ground');
  }
  scene.dispose();
});

test('pause, skip and retry do not advance time, repeat cues or retain distorted props', () => {
  const { app, scene, sounds } = fixture('tent'), flaps = app.world.deathProps.tentFlaps;
  const original = flaps.map(f => Array.from(f.geometry.attributes.position.array)), fov = app.camera.fov;
  scene.begin({ kind: 'tent' });scene.tick(1.1);
  const before = sounds.length, clock = scene.time, picture = app.camera.position.clone();
  scene.tick(0);assert.equal(scene.time, clock);assert.equal(sounds.length, before);assert.ok(picture.distanceTo(app.camera.position) < 1e-9);
  assert.notDeepEqual(Array.from(flaps[0].geometry.attributes.position.array), original[0]);
  scene.skip();assert.equal(sounds.length, before);assert.equal(app.post.uFade.value, 0);
  scene.reset();assert.equal(app.camera.fov, fov);assert.equal(scene.time, 0);
  flaps.forEach((f, i) => { assert.deepEqual(Array.from(f.geometry.attributes.position.array), original[i]);assert.equal(f.children.length, 0); });
  const previousSteps = sounds.filter(s => s.name === 'killer_step').length;
  scene.begin({ kind: 'tent' });scene.tick(.2);assert.equal(sounds.filter(s => s.name === 'killer_step').length, previousSteps + 1);
  scene.dispose();
});

test('tent approach stops before an intervening thin obstacle and remains bounded', () => {
  const hide = { x: 12, z: 13.2, view: { x: 12.35, y: .95, z: 10.6 } }, start = { x: 12, z: 14.8 };
  const tent = { id: 'tent', minX: 10, maxX: 14, minZ: 8, maxZ: 12 };
  const barrier = { id: 'new-post', minX: 11.4, maxX: 13, minZ: 13.3, maxZ: 13.31 };
  const goal = deathApproach('tent', start, hide, [tent]);
  assert.ok(goal.z >= 12.42 && goal.z < 12.7);assert.ok(Math.hypot(goal.x - start.x, goal.z - start.z) <= 2.2 + 1e-9);
  const blocked = deathApproach('tent', start, hide, [tent, barrier]);
  assert.ok(blocked.z >= 13.73);assert.ok(clearSegment(start, blocked, .42, [tent, barrier]));
  const touching = { id: 'at-feet', minX: 11.5, maxX: 12.5, minZ: 14.36, maxZ: 14.38 };
  assert.deepEqual(deathApproach('tent', start, hide, [tent, touching]), start, 'blocked first step safely remains in place');
});

test('tent advance is frame-rate independent and a newly blocked sweep stops safely', () => {
  const a = fixture('tent'), b = fixture('tent');
  a.scene.begin({ kind: 'tent' });b.scene.begin({ kind: 'tent' });
  for (let i = 0; i < 60; i++) a.scene.tick(.02);
  for (let i = 0; i < 12; i++) b.scene.tick(.1);
  assert.ok(Math.hypot(a.app.sim.killer.x - b.app.sim.killer.x, a.app.sim.killer.z - b.app.sim.killer.z) < 1e-9);
  a.scene.dispose();b.scene.dispose();
  const c = fixture('tent');c.scene.begin({ kind: 'tent' });c.scene.tick(.3);
  const before = { x: c.app.sim.killer.x, z: c.app.sim.killer.z };
  c.app.sim.obstacles.push({ id: 'appeared', minX: 11, maxX: 14, minZ: before.z - .55, maxZ: before.z - .44 });
  c.scene.tick(1);assert.deepEqual({ x: c.app.sim.killer.x, z: c.app.sim.killer.z }, before);
  c.scene.dispose();
});

test('wardrobe door opens around a fixed hinge and resets exactly', () => {
  const { app, scene } = fixture('wardrobe'), door = app.world.deathProps.wardrobeDoor;
  const q = door.quaternion.clone(), position = door.position.clone(), hinge = new THREE.Vector3(0, 0, -.675).applyQuaternion(q).add(position);
  scene.begin({ kind: 'wardrobe' });scene.tick(1.4);
  const movedHinge = new THREE.Vector3(0, 0, -.675).applyQuaternion(door.quaternion).add(door.position);
  assert.ok(movedHinge.distanceTo(hinge) < 1e-9);assert.ok(q.angleTo(door.quaternion) > .8);
  scene.reset();assert.deepEqual(q.toArray(), door.quaternion.toArray());assert.deepEqual(position.toArray(), door.position.toArray());
  scene.dispose();
});


test('late-route tent uses its own entrance and cloth, then restores both tents', () => {
  const {app,scene}=fixture('tent'), original=app.world.deathProps.tentFlaps;
  const late=original.map(f=>new THREE.Mesh(f.geometry.clone(),f.material));
  const originals=original.map(f=>Array.from(f.geometry.attributes.position.array));
  app.world.deathProps.tents={tent:{tentFlaps:original},'lower-tent':{tentFlaps:late}};
  const p=app.sim.player,k=app.sim.killer;
  Object.assign(p,{x:-23,z:-87.8,hidden:{id:'lower-tent',colliderId:'lower-tent',kind:'tent',x:-23,z:-87.8,view:{x:-22.65,y:.95,z:-90.4}}});
  Object.assign(k,{x:-23,z:-86.4});
  app.sim.obstacles=[{id:'tent',minX:10,maxX:14,minZ:8,maxZ:12},{id:'lower-tent',minX:-25,maxX:-21,minZ:-93,maxZ:-89}];
  app.camera.position.set(-22.65,.95,-90.4);app.camera.lookAt(-23,1,-86.4);
  scene.begin({kind:'tent'});scene.tick(1.2);
  assert.ok(app.sim.killer.z>=-88.58&&app.sim.killer.z<-87.8,'approach stops outside the correct tent');
  assert.ok(app.camera.position.x>-25&&app.camera.position.x<-21&&app.camera.position.z>-93&&app.camera.position.z<-89);
  assert.notDeepEqual(Array.from(late[0].geometry.attributes.position.array),originals[0]);
  original.forEach((f,i)=>assert.deepEqual(Array.from(f.geometry.attributes.position.array),originals[i]));
  scene.reset();late.forEach((f,i)=>assert.deepEqual(Array.from(f.geometry.attributes.position.array),originals[i]));
  scene.dispose();
});
