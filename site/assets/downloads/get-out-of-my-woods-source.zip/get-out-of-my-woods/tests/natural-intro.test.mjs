import test from 'node:test';
import assert from 'node:assert/strict';
import {GameSim} from '../src/sim/game.js';
import {Killer} from '../src/ai/killer.js';
const dt=1/30,idle={moveX:0,moveY:0,camYaw:0,run:false,action:false,actionHeld:false};
test('fresh first visits start a physical hunt without requiring the car',()=>{
 for(const difficulty of ['easy','normal','hard'])for(const seed of [1000,1001,1002,1003,1004,1005]){
  const s=new GameSim({difficulty,seed});let starts=0,first=null,maxStep=0;
  for(let i=0;i<150/dt&&first===null;i++){
   const x=s.killer.x,z=s.killer.z;s.step(dt,idle);maxStep=Math.max(maxStep,Math.hypot(s.killer.x-x,s.killer.z-z));
   for(const e of s.drainEvents()){if(e.t==='huntStarted')starts++;if(e.t==='spotted')first=s.time;}
  }
  assert.equal(starts,1,`${difficulty}/${seed}: hunt starts exactly once`);
  assert.ok(first!==null&&first<=150,`${difficulty}/${seed}: natural detection`);
  assert.ok(maxStep<=s.tune.catchUp*dt+.001,`${difficulty}/${seed}: no teleport`);
  assert.equal(s.reached.car,false,'no false car discovery');
 }
});
test('first-visit grace is difficulty-specific and cannot fire while the car reveal owns the simulation',()=>{
 for(const difficulty of ['easy','normal','hard']){
  const s=new GameSim({difficulty,seed:91});
  for(let i=0;i<Math.floor((s.tune.introGrace-1)/dt);i++)s.step(dt,idle);
  assert.equal(s.phase,'intro');assert.equal(s.stats.seen,0);
  s.phase='cutscene';for(let i=0;i<60/dt;i++)s.step(dt,idle);
  assert.equal(s.phase,'cutscene');assert.equal(s.drainEvents().filter(e=>e.t==='huntStarted').length,0);
 }
});

test('prolonged patrol catch-up stops at twenty metres and requires occlusion',()=>{
 let opacity=1;const actor={x:25,z:0,tune:{pressure:24},sim:{player:{x:0,z:0},director:{pressured:true,sinceContact:60},collision:{sightOpacity:()=>opacity}}};
 assert.equal(Killer.prototype.farAndUnseen.call(actor),true);
 opacity=0;assert.equal(Killer.prototype.farAndUnseen.call(actor),false,'clear sight keeps ordinary speed');
 opacity=1;actor.x=20;assert.equal(Killer.prototype.farAndUnseen.call(actor),false,'close approach stays ordinary speed');
 actor.x=25;actor.sim.director.pressured=false;assert.equal(Killer.prototype.farAndUnseen.call(actor),false,'hidden/recovery suppression keeps ordinary speed');
 actor.sim.director.pressured=true;actor.sim.director.sinceContact=40;assert.equal(Killer.prototype.farAndUnseen.call(actor),false,'no extra early pressure');
});
