import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { createKiller } from '../src/characters/killer.js';
import { createAct2Killer, polishKillerAppearance } from '../src/act2/killer.js';

globalThis.document = { createElement: () => ({ getContext: () => ({
  fillRect() {}, beginPath() {}, ellipse() {}, fill() {},
}) }) };

function gripState(figure, side) {
  figure.root.updateMatrixWorld(true);
  const pose = figure.animator.appliedPose.a, rig = figure.rig;
  const [weightIndex, uIndex] = side === 'L' ? [10, 12] : [9, 11];
  const hand = rig.b(`hand${side}`).getWorldPosition(new THREE.Vector3());
  const other = rig.b(`hand${side === 'L' ? 'R' : 'L'}`).getWorldPosition(new THREE.Vector3());
  const fork = rig.b('fork'), target = fork.localToWorld(new THREE.Vector3(0, pose[uIndex], 0));
  const local = fork.worldToLocal(hand.clone());
  return { weight: pose[weightIndex], u: pose[uIndex], targetError: hand.distanceTo(target),
    shaftError: Math.hypot(local.x, local.z), separation: hand.distanceTo(other), hand };
}

test('shared Sackhead appearance preserves the Act I animation and combat interface', () => {
  const figure=createKiller(),reference=createKiller();
  const before={root:figure.root,rig:figure.rig,animator:figure.animator,anims:figure.animator.anims,
    update:figure.update,setAnim:figure.setAnim,setBloody:figure.setBloody,forkTip:figure.forkTip};
  assert.equal(polishKillerAppearance(figure),figure);
  for(const name of ['root','rig','animator','update','setAnim','setBloody','forkTip'])assert.equal(figure[name],before[name]);
  assert.equal(figure.animator.anims,before.anims);assert.equal(figure.animator.anims.previewAttack,undefined);
  assert.equal(figure.root.parent,null,'appearance does not install the Act II outer root');
  for(const name of ['walk','chase','raise','jab']){
    for(const f of [figure,reference]){f.setAnim(name,{restart:true,fade:.001});f.update(.2,{speed:2.8});}
    for(const bone of figure.rig.names){assert.ok(figure.rig.b(bone).quaternion.angleTo(reference.rig.b(bone).quaternion)<1e-6,`${name} keeps ${bone} animation`);}
  }
});

test('both chapter adapters produce the same Sackhead geometry and materials without repeated deformation',()=>{
  const figure=polishKillerAppearance(createKiller()),second=createAct2Killer().figure;
  assert.equal(figure.meshes.reduce((n,m)=>n+m.geometry.attributes.position.count,0),9522);
  for(const mesh of figure.meshes){
    const other=second.meshes.find(m=>m.name===mesh.name);
    for(const name of Object.keys(mesh.geometry.attributes))assert.deepEqual(mesh.geometry.attributes[name].array,other.geometry.attributes[name].array,`${mesh.name}: ${name}`);
    for(const name of ['roughness','metalness','bumpScale'])assert.equal(mesh.material[name],other.material[name]);
    assert.equal(mesh.material.emissive.getHex(),other.material.emissive.getHex());
    assert.equal(mesh.material.roughnessMap,other.material.roughnessMap,'both chapters share the same surface wear');
  }
  const geometry=figure.meshes.map(m=>m.geometry),materials=figure.meshes.map(m=>m.material),headChildren=figure.rig.b('head').children.map(c=>c.position.toArray());
  polishKillerAppearance(figure);
  assert.deepEqual(figure.meshes.map(m=>m.geometry),geometry);assert.deepEqual(figure.meshes.map(m=>m.material),materials);
  assert.deepEqual(figure.rig.b('head').children.map(c=>c.position.toArray()),headChildren);
});

test('chase keeps the left hand attached with separated wrists throughout the gait',()=>{
  const figure=createKiller();figure.setAnim('chase',{restart:true,fade:.001});
  let maxTarget=0,maxShaft=0,minSeparation=Infinity,maxSeparation=0;
  for(let i=0;i<240;i++){
    figure.update(1/120,{speed:3.85});
    const grip=gripState(figure,'L');
    assert.equal(grip.weight,1);assert.ok(Math.abs(grip.u-.85)<1e-6);
    maxTarget=Math.max(maxTarget,grip.targetError);maxShaft=Math.max(maxShaft,grip.shaftError);
    minSeparation=Math.min(minSeparation,grip.separation);maxSeparation=Math.max(maxSeparation,grip.separation);
  }
  assert.ok(maxTarget<.002,`maximum target error ${maxTarget}`);assert.ok(maxShaft<.002,`maximum shaft error ${maxShaft}`);
  assert.ok(minSeparation>.599&&maxSeparation<.601,`wrist separation ${minSeparation}..${maxSeparation}`);
});

test('strike releases the left grip smoothly and lift retains it without a boundary snap',()=>{
  const figure=createKiller();figure.setAnim('raise',{restart:true,fade:.001});figure.update(.35,{});
  assert.equal(gripState(figure,'L').weight,1);
  const raisedHand=gripState(figure,'L').hand.clone();figure.setAnim('strike');figure.update(0,{});
  assert.equal(gripState(figure,'L').weight,1);assert.ok(raisedHand.distanceTo(gripState(figure,'L').hand)<1e-6);
  let previous=1,maxWeightDrop=0;
  for(let i=0;i<260;i++){
    figure.update(.001,{});
    const weight=gripState(figure,'L').weight;
    assert.ok(weight<=previous+1e-6,'left grip release is monotonic');maxWeightDrop=Math.max(maxWeightDrop,previous-weight);previous=weight;
  }
  assert.equal(previous,0);assert.ok(maxWeightDrop<.03,`maximum 1 ms weight drop ${maxWeightDrop}`);
  assert.ok(gripState(figure,'R').targetError<.002,'right grip remains attached at strike completion');
  const strikeHand=gripState(figure,'L').hand.clone();figure.setAnim('lift',{restart:true});figure.update(0,{});
  assert.equal(gripState(figure,'L').weight,0);assert.ok(strikeHand.distanceTo(gripState(figure,'L').hand)<1e-6,'no hand snap at strike to lift');
  for(let i=0;i<100;i++)figure.update(.009,{});
  assert.equal(gripState(figure,'L').weight,0);assert.ok(gripState(figure,'R').targetError<.002,'right grip remains attached at lift completion');
});

test('the hanging fork swings outside his right leg through a whole walk and stalk', () => {
  const figure = polishKillerAppearance(createKiller()), rig = figure.rig, point = new THREE.Vector3();
  for (const [anim, speed] of [['walk', 1.5], ['stalk', 2.3]]) {
    figure.setAnim(anim, { restart: true, fade: .001 });
    for (let frame = 0; frame < 300; frame++) {
      figure.update(1 / 60, { speed }); figure.root.updateWorldMatrix(true, true);
      // Right knee to the handle (the fork's own y axis). It was 7-8 cm: the handle crossed his shin each stride.
      rig.b('fork').worldToLocal(rig.b('shinR').getWorldPosition(point));
      const gap = Math.hypot(point.x, point.z, point.y - Math.max(-.15, Math.min(1.57, point.y)));
      assert.ok(gap > .13, `${anim}: handle ${gap.toFixed(3)} m from the right knee at frame ${frame}`);
    }
  }
});
