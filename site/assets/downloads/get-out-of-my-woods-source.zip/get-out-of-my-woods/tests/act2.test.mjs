import test from 'node:test';
import assert from 'node:assert/strict';
import { Act2Sim, ACT2_DIFFICULTY, ATTACK_TIMING, DEFENSE_TIMING, clearSegment, walkable, findPath, obstacleContainsPoint } from '../src/act2/sim.js';
import { LOCATIONS, HIDE_SPOTS, OBSTACLES } from '../src/act2/layout.js';

const tick = (sim, seconds, input = {}) => {
  for (let i = 0; i < Math.ceil(seconds * 60); i++) sim.step(1/60, typeof input === 'function' ? input(i) : input);
};
const peaceful = (difficulty = 'standard') => new Act2Sim({ difficulty, arrivalTime: 10000 });
const placeKiller = (s, x, z, yaw) => Object.assign(s.killer, {x,z,yaw,active:true,state:'patrol',target:{x,z},path:[]});
const distance = (a,b) => Math.hypot(a.x-b.x,a.z-b.z);
const closeTo = (actual,expected,message,epsilon=1e-9) => assert.ok(Math.abs(actual-expected)<=epsilon,`${message}: ${actual} !== ${expected}`);

test('angled road log blocks both directions without filling its rotated bounding corners', () => {
  const log=OBSTACLES.find(o=>o.id==='road-log');
  assert.equal(obstacleContainsPoint(log,0,45),true);
  assert.equal(obstacleContainsPoint(log,log.minX+.01,log.minZ+.01),false);
  assert.equal(clearSegment({x:2.3,z:42},{x:2.3,z:47}),false);
  for(const [z,direction] of [[42.5,1],[47,-1]]) {
    const s=peaceful();Object.assign(s.p,{x:2.3,z});
    tick(s,3,{moveZ:direction,run:true});
    assert.ok(walkable(s.p.x,s.p.z));
    assert.ok(direction>0?s.p.z<44:s.p.z>45.5,'player stops on correct side of log');
  }
});

test('player can escape around the log ends and killer physically routes around it', () => {
  const s=peaceful();Object.assign(s.p,{x:5.5,z:42.5});
  tick(s,1.6,{moveZ:1});assert.ok(s.p.z>46.5,'walk around east log end');
  Object.assign(s.p,{x:-5.5,z:47});tick(s,1.6,{moveZ:-1});assert.ok(s.p.z<43,'walk around west log end');
  Object.assign(s.p,{x:25,z:35,flashlight:false});
  placeKiller(s,2.3,42.5,0);
  Object.assign(s.killer,{state:'search',target:{x:2.3,z:47},lastSeen:{x:2.3,z:47}});s._searchUntil=100;
  let reached=false,aroundEnd=false;
  for(let i=0;i<1200;i++) {
    const before={x:s.killer.x,z:s.killer.z};s.step(1/60,{flashlight:false});
    assert.ok(walkable(s.killer.x,s.killer.z,.42));
    assert.ok(clearSegment(before,s.killer,.42),'every movement segment avoids log');
    assert.ok(Math.hypot(s.killer.x-before.x,s.killer.z-before.z)<=2.05/60+.001);
    if(Math.abs(s.killer.x)>4.7)aroundEnd=true;
    if(Math.hypot(s.killer.x-2.3,s.killer.z-47)<.8){reached=true;break;}
  }
  assert.ok(reached&&aroundEnd,'killer reaches far side using an end of the log');
});

test('substantial furniture and ajar doors are physical while cabin route stays open', () => {
  for(const [x,z] of [[-8.3,5.8],[15,15.8],[-6.65,1],[-7.3,.2],[-7.9,.55],[-13.35,8.9],[-13.35,-2.9]])assert.equal(walkable(x,z),false);
  const s=peaceful();Object.assign(s.p,{x:-8.3,z:4.5});tick(s,1,{moveZ:1});assert.ok(s.p.z<5,'desk blocks player');
  Object.assign(s.p,{x:15,z:14.5});tick(s,1,{moveZ:1});assert.ok(s.p.z<15.2,'camp table blocks player');
  assert.equal(clearSegment({x:-12,z:12},{x:-12,z:-5},.42),true,'both doorway centers remain open');
});

test('wardrobe remains reachable, enterable and escapable with a physical shell', () => {
  const s=peaceful(),h=HIDE_SPOTS.find(h=>h.id==='wardrobe');
  const route=findPath({x:-12,z:3},h);assert.ok(route.length>0);assert.ok(walkable(h.x,h.z,.42));
  Object.assign(s.p,{x:h.x,z:h.z});placeKiller(s,-11.5,1.5,Math.PI/2);
  assert.equal(s.canSeePlayer(),true);s.interact();assert.equal(s.p.hidden?.id,'wardrobe');
  for(let i=0;i<300&&s._inspectAt===null;i++)s.step(1/60,{});
  assert.notEqual(s._inspectAt,null,'killer can reach inspection position');
  assert.equal(s.phase,'play');s.interact();assert.equal(s.p.hidden,null);
  tick(s,.5,{moveX:-1,moveZ:1,run:true});assert.ok(s.p.x<h.x-1,'player can escape around the inspecting killer');
  assert.ok(Math.hypot(s.p.x-s.killer.x,s.p.z-s.killer.z)>=.8,'escape never passes through his body');
});

test('rendered trunk footprints affect movement, sight and navigation only in their own run', () => {
  const trunk={id:'tree-test',minX:1.6,maxX:2.4,minZ:-.4,maxZ:.4,height:3};
  const extra=[trunk],s=new Act2Sim({arrivalTime:10000,extraObstacles:extra});
  extra.length=0; // Constructor keeps its own list; caller lifecycle cannot erase this run's solids.
  Object.assign(s.p,{x:0,z:0});tick(s,2,{moveX:1});assert.ok(s.p.x<1.3);
  assert.equal(clearSegment({x:0,z:0},{x:4,z:0},0,s.obstacles),false);
  const route=findPath({x:0,z:0},{x:4,z:0},.42,s.obstacles);assert.ok(route.length>1);
  let previous={x:0,z:0};for(const p of route){assert.ok(clearSegment(previous,p,.42,s.obstacles));previous=p;}
  Object.assign(s.p,{x:4,z:0});placeKiller(s,0,0,Math.PI/2);assert.equal(s.canSeePlayer(),false);
  const clean=peaceful();Object.assign(clean.p,{x:0,z:0});tick(clean,1.6,{moveX:1});assert.ok(clean.p.x>4);
  assert.equal(walkable(2,0),true,'default chapter obstacle list remains unmodified');
});

test('same-id scene colliders replace approximate layout footprints without duplicate solids', () => {
  const original=OBSTACLES.find(o=>o.id==='car');
  assert.ok(original);
  const revised={...original,minX:28,maxX:30,minZ:20,maxZ:22};
  const s=new Act2Sim({extraObstacles:[revised]});
  assert.equal(s.obstacles.filter(o=>o.id==='car').length,1);
  assert.equal(s.obstacles.find(o=>o.id==='car'),revised);
  assert.equal(walkable(29,21,.32,s.obstacles),false);
  assert.equal(OBSTACLES.find(o=>o.id==='car'),original,'base layout stays unchanged');
});

test('low solid props stop walking without hiding a standing counselor', () => {
  const prop={id:'sight-test-desk',minX:-1,maxX:1,minZ:19.8,maxZ:20.2,height:.9};
  const s=new Act2Sim({extraObstacles:[prop]});
  Object.assign(s.p,{x:0,z:21});placeKiller(s,0,19,0);
  assert.equal(clearSegment(s.p,s.killer,0,s.obstacles),false,'low prop remains a physical solid');
  assert.equal(s.canSeePlayer(),true,'standing eye line passes above the desk');
  const tall=new Act2Sim({extraObstacles:[{...prop,height:2}]});
  Object.assign(tall.p,{x:0,z:21});placeKiller(tall,0,19,0);
  assert.equal(tall.canSeePlayer(),false,'a tall prop blocks the same eye line');
});

test('Act II selects frozen difficulty profiles and falls back to Standard constants', () => {
  assert.deepEqual(ACT2_DIFFICULTY,{
    relaxed:{sense:.75,memory:2,searchTime:7,chase:2.45},
    standard:{sense:1,memory:3.2,searchTime:10,chase:3.15},
    hard:{sense:1.15,memory:4,searchTime:12,chase:3.55},
  });
  assert.equal(Object.isFrozen(ACT2_DIFFICULTY),true);
  for(const [difficulty,profile] of Object.entries(ACT2_DIFFICULTY)) {
    assert.equal(Object.isFrozen(profile),true);
    const s=peaceful(difficulty);
    assert.equal(s.difficulty,difficulty);
    assert.equal(s.profile,profile);
  }
  const fallback=new Act2Sim({difficulty:'unknown'});
  assert.equal(fallback.difficulty,'unknown');
  assert.equal(fallback.profile,ACT2_DIFFICULTY.standard);
  assert.equal(new Act2Sim().profile,ACT2_DIFFICULTY.standard);
});

test('difficulty sense scales every sight boundary and notice fill, but not decay', () => {
  for(const [difficulty,profile] of Object.entries(ACT2_DIFFICULTY)) {
    for(const [base,flashlight,run] of [[29,true,false],[24,false,true],[20,false,false]]) {
      const s=peaceful(difficulty);placeKiller(s,0,0,0);
      const range=base*profile.sense;
      Object.assign(s.p,{x:0,z:range,flashlight,run,hidden:null});
      assert.equal(s.canSeePlayer(),true,`${difficulty}/${base}: boundary is visible`);
      s.p.z=range+.001;
      assert.equal(s.canSeePlayer(),false,`${difficulty}/${base}: beyond boundary is hidden`);
    }
    for(const [d,rate] of [[6,3],[10,1.5]]) {
      const s=peaceful(difficulty);placeKiller(s,0,0,0);
      Object.assign(s.killer,{state:'dormant',target:null});
      Object.assign(s.p,{x:0,z:d,flashlight:true,run:false,hidden:null});
      s.step(.1,{});
      closeTo(s.killer.notice,.1*rate*profile.sense,`${difficulty}/${d}: first notice fill`);
      let frames=1;
      while(!s.events.some(e=>e.type==='spotted')&&frames<20){s.step(.1,{});frames++;}
      const expectedFrames=Math.ceil((1-1e-12)/(.1*rate*profile.sense));
      assert.equal(frames,expectedFrames,`${difficulty}/${d}: notice timing`);
      closeTo(s.time,expectedFrames*.1,`${difficulty}/${d}: spotted time`);
      s.p.hidden=HIDE_SPOTS[0];s.step(.1,{});
      closeTo(s.killer.notice,.94,`${difficulty}/${d}: decay remains .6 per second`);
    }
  }
});

test('difficulty sense scales running and walking hearing while sneaking stays silent', () => {
  for(const [difficulty,profile] of Object.entries(ACT2_DIFFICULTY)) {
    for(const [base,run] of [[17,true],[4,false]])for(const [offset,heard] of [[-.2,true],[.05,false]]) {
      const s=peaceful(difficulty);placeKiller(s,0,0,Math.PI);
      Object.assign(s.killer,{state:'dormant',target:null});
      Object.assign(s.p,{x:0,z:base*profile.sense+offset,flashlight:false,run:false,stamina:1,winded:false,hidden:null});
      s.step(1/60,{moveX:1,run,flashlight:false});
      assert.equal(s.events.some(e=>e.type==='investigate'),heard,`${difficulty}/${run?'run':'walk'}/${offset}: hearing boundary`);
    }
    const s=peaceful(difficulty);placeKiller(s,0,0,Math.PI);
    Object.assign(s.killer,{state:'dormant',target:null});
    Object.assign(s.p,{x:0,z:3,flashlight:false,run:false,hidden:null});
    s.step(1/60,{moveX:1,run:true,sneak:true,flashlight:false});
    assert.equal(s.p.gait,'sneak');
    assert.equal(s.events.some(e=>e.type==='investigate'),false,`${difficulty}: sneaking is silent`);
  }
});

test('lost sight uses difficulty memory and each base search budget expires on schedule', () => {
  for(const [difficulty,profile] of Object.entries(ACT2_DIFFICULTY)) {
    const s=peaceful(difficulty);placeKiller(s,0,0,0);
    Object.assign(s.p,{x:0,z:20,flashlight:false,hidden:HIDE_SPOTS[0]});
    Object.assign(s.killer,{state:'chase',lastSeen:{x:0,z:0},target:null});
    s._seenAt=0;s.time=profile.memory-.02;
    s.step(.01,{});
    assert.equal(s.killer.state,'chase',`${difficulty}: memory has not elapsed`);
    s.step(.02,{});
    assert.equal(s.killer.state,'search',`${difficulty}: lost sight starts search`);
    const searchStarted=s.time,until=s._searchUntil;
    closeTo(until-searchStarted,profile.searchTime,`${difficulty}: base search budget`);
    s.time=until-.01;s.step(.005,{});
    assert.equal(s.killer.state,'search',`${difficulty}: search remains active before budget`);
    s.step(.02,{});
    assert.equal(s.killer.state,'patrol',`${difficulty}: search expires at budget`);
  }
});

test('measured open-chase speed matches every difficulty profile', () => {
  for(const [difficulty,profile] of Object.entries(ACT2_DIFFICULTY)) {
    const s=peaceful(difficulty);Object.assign(s.p,{x:0,z:0,flashlight:true,hidden:null});
    placeKiller(s,0,10,Math.PI);
    Object.assign(s.killer,{state:'chase',lastSeen:{x:0,z:0}});s._seenAt=s.time;
    const before={x:s.killer.x,z:s.killer.z};tick(s,.5,{});
    closeTo(distance(before,s.killer)/.5,profile.chase,`${difficulty}: measured open chase`,1e-6);
    assert.equal(s.killer.state,'chase');
  }
});

test('witnessed-hide approach matches chase speed and preserves the 2.3 second warning', () => {
  for(const [difficulty,profile] of Object.entries(ACT2_DIFFICULTY)) {
    const s=peaceful(difficulty),h=HIDE_SPOTS[0];
    Object.assign(s.p,{x:h.x,z:h.z,flashlight:true,hidden:null});placeKiller(s,12,20,Math.PI);
    assert.equal(s.canSeePlayer(),true);s.interact();
    assert.equal(s.killer.state,'check-hide');assert.equal(s.p.hidden?.id,h.id);
    const before={x:s.killer.x,z:s.killer.z};tick(s,.5,{});
    closeTo(distance(before,s.killer)/.5,profile.chase,`${difficulty}: measured hide approach`,1e-6);
    for(let i=0;i<600&&s._inspectAt===null;i++)s.step(1/60,{});
    assert.notEqual(s._inspectAt,null,`${difficulty}: killer reaches hiding place`);
    const inspectedAt=s._inspectAt;
    tick(s,2.2,{});
    assert.equal(s.phase,'play',`${difficulty}: full warning remains available`);
    tick(s,.2,{});
    assert.equal(s.phase,'dead');assert.equal(s.deathKind,h.kind);
    const death=s.events.find(e=>e.type==='death');
    closeTo(death.time-inspectedAt,2.3,`${difficulty}: witnessed-hide warning`,1/60+.001);
  }
});

test('attack contact and one-use four-second crowbar stagger are invariant across difficulties', () => {
  for(const difficulty of Object.keys(ACT2_DIFFICULTY)) {
    const attack=peaceful(difficulty);Object.assign(attack.p,{x:0,z:20});placeKiller(attack,0,18.35,0);
    attack.beginAttack();const started=attack.time;
    tick(attack,.6,{});assert.equal(attack.phase,'play');assert.equal(attack.killer.attackPhase,'windup');
    tick(attack,.1,{});assert.equal(attack.phase,'play');assert.equal(attack.killer.attackPhase,'strike');
    tick(attack,.05,{});assert.equal(attack.phase,'dead');assert.equal(attack.killer.attackHit,true);
    assert.equal(attack.killer.attackProgress,ATTACK_TIMING.contact);
    const contact=ATTACK_TIMING.windup+ATTACK_TIMING.strike*ATTACK_TIMING.contact;
    assert.ok(attack.time-started>=contact-1e-9&&attack.time-started<contact+1/60+.001,`${difficulty}: attack contact timing`);

    const defense=peaceful(difficulty);Object.assign(defense.p,{x:0,z:0,yaw:0});defense.weapon='ready';
    placeKiller(defense,0,2,Math.PI);
    assert.equal(defense.defend(),true);assert.equal(defense.weapon,'spent');
    assert.equal(DEFENSE_TIMING.stagger,4);assert.equal(defense.killer.stagger,4);
    const stopped={x:defense.killer.x,z:defense.killer.z};tick(defense,3.8,{flashlight:true});
    assert.equal(defense.killer.state,'stagger',`${difficulty}: stagger lasts four seconds`);
    assert.deepEqual({x:defense.killer.x,z:defense.killer.z},stopped);
    assert.equal(defense.phase,'play');assert.equal(defense.defend(),false,`${difficulty}: crowbar remains one-use`);
    tick(defense,.3,{});assert.notEqual(defense.killer.state,'stagger');
  }
});

test('cabin walls stop sight, while the paired doors provide a clear route', () => {
  assert.equal(clearSegment({x:-20,z:3},{x:-12,z:3}), false);
  assert.equal(clearSegment({x:-12,z:12},{x:-12,z:-5}, .42), true);
  assert.equal(walkable(-18,3), false);
  const path = findPath({x:-20,z:3},{x:-12,z:3});
  assert.ok(path.length > 1, 'route must go around a wall through a door');
  let last = {x:-20,z:3};
  for (const p of path) { assert.ok(clearSegment(last,p,.42)); assert.ok(walkable(p.x,p.z,.42)); last=p; }
  assert.deepEqual(last,{x:-12,z:3});
});

test('movement cannot tunnel through thin walls and passes both cabin doors', () => {
  const s=peaceful(); Object.assign(s.p,{x:-20,z:3});
  tick(s,3,{moveX:1,moveZ:0,run:true});
  assert.ok(s.p.x < -18.5);
  Object.assign(s.p,{x:-12,z:12,stamina:1,winded:false});
  tick(s,4,{moveX:0,moveZ:-1,run:true});
  assert.ok(s.p.z < -4);
});

test('killer follows the physical route into a cabin without wall crossings or jumps', () => {
  const s=peaceful(); Object.assign(s.p,{x:30,z:40});
  placeKiller(s,-20,3,Math.PI/2);
  Object.assign(s.killer,{state:'search',target:{x:-12,z:3},lastSeen:{x:-12,z:3}});
  s._searchUntil=100;
  let reached=false;
  for(let i=0;i<1200;i++) {
    const before={x:s.killer.x,z:s.killer.z}; s.step(1/60,{});
    assert.ok(walkable(s.killer.x,s.killer.z,.42));
    assert.ok(Math.hypot(s.killer.x-before.x,s.killer.z-before.z) <= 2.05/60+.001);
    if(Math.hypot(s.killer.x+12,s.killer.z-3)<.8) {reached=true;break;}
  }
  assert.ok(reached);
});

test('a player pressed against the van remains reachable despite narrower body radius', () => {
  const s=peaceful();Object.assign(s.p,{x:0,z:LOCATIONS.van.z+7});placeKiller(s,0,LOCATIONS.van.z+12,Math.PI);
  for(let i=0;i<60*12 && s.phase==='play';i++) {
    const before={x:s.killer.x,z:s.killer.z};
    s.step(1/60,{moveZ:-1,flashlight:true});
    assert.ok(Math.hypot(s.killer.x-before.x,s.killer.z-before.z)<=3.15/60+.001);
    assert.ok(walkable(s.killer.x,s.killer.z,.42));
  }
  assert.equal(s.phase,'dead');
  assert.ok(s.stats.seen>0);
  assert.ok(s.p.z > LOCATIONS.van.z+3 && s.p.z < LOCATIONS.van.z+3.5);
  assert.ok(Math.hypot(s.killer.x-s.p.x,s.killer.z-s.p.z)<1.9);
});

test('killer approaches and strikes a player hugging an interior cabin wall', () => {
  const s=peaceful(); Object.assign(s.p,{x:-6.53,z:3});
  assert.equal(walkable(s.p.x,s.p.z,.32),true);
  assert.equal(walkable(s.p.x,s.p.z,.42),false);
  placeKiller(s,-12,3,Math.PI/2);
  Object.assign(s.killer,{state:'chase',lastSeen:{x:s.p.x,z:s.p.z}});s._seenAt=s.time;
  const path=findPath(s.killer,s.p);
  assert.ok(path.length>0);
  const approach=path.at(-1);
  assert.ok(walkable(approach.x,approach.z,.42));
  assert.ok(clearSegment(approach,s.p));
  assert.ok(Math.hypot(approach.x-s.p.x,approach.z-s.p.z)<1.6);
  tick(s,7,{flashlight:true});
  assert.equal(s.phase,'dead');
  assert.ok(walkable(s.killer.x,s.killer.z,.42));
});

test('held sprint lasts eighteen seconds, recovers at a jog and resumes without releasing run', () => {
  const s=peaceful();Object.assign(s.p,{x:-3,z:20});
  const corners=[{x:3,z:20},{x:3,z:26},{x:-3,z:26},{x:-3,z:20}];
  let corner=0,exhaustedAt=null,resumedAt=null,jogFrames=0;
  for(let i=0;i<27*60;i++) {
    if(Math.hypot(s.p.x-corners[corner].x,s.p.z-corners[corner].z)<.12)corner=(corner+1)%corners.length;
    const target=corners[corner];
    s.step(1/60,{moveX:target.x-s.p.x,moveZ:target.z-s.p.z,run:true});
    assert.equal(s.p.runRequested,true);
    if(s.time<12)assert.equal(s.p.gait,'sprint','continuous run remains a sprint beyond eight seconds');
    if(s.p.winded&&exhaustedAt===null)exhaustedAt=s.time;
    if(s.p.gait==='jog') {
      jogFrames++;
      assert.equal(s.p.run,false);
      assert.ok(s.p.speed<=3.001);
      assert.ok(s.p.stamina<.422,'reserve refills during the held-run jog');
    }
    if(exhaustedAt!==null&&s.p.run&&s.time>exhaustedAt+1){resumedAt=s.time;break;}
  }
  assert.ok(exhaustedAt>18&&exhaustedAt<18.5,`full sprint duration was ${exhaustedAt}`);
  assert.ok(jogFrames>4*60,'recovery is a sustained jog, not repeated short sprint bursts');
  assert.ok(resumedAt>exhaustedAt+4&&resumedAt<exhaustedAt+4.5);
  assert.ok(s.p.stamina>.41&&s.p.stamina<.43,'sprint resumes with a substantial reserve');
});

test('holding run into a wall neither drains stamina nor claims the player is sprinting', () => {
  const s=peaceful();Object.assign(s.p,{x:-18.53,z:3,stamina:.5});
  tick(s,3,{moveX:1,run:true});
  assert.ok(s.p.x<-18.52);
  assert.ok(s.p.stamina>=.99,'blocked player recovers');
  assert.equal(s.p.runRequested,true);assert.equal(s.p.run,false);assert.equal(s.p.gait,'idle');
});

test('the counselor cannot run through a stationary killer, including on slow frames', () => {
  const s=peaceful();Object.assign(s.p,{x:0,z:20});placeKiller(s,0,17,0);
  Object.assign(s.killer,{state:'stagger',stagger:100});
  for(let i=0;i<30;i++){
    s.step(.1,{moveZ:-1,run:true});
    assert.ok(Math.hypot(s.p.x-s.killer.x,s.p.z-s.killer.z)>=.8);
  }
  assert.ok(s.p.z>17.79&&s.p.z<18,'capsule stops at the killer');
});

test('killer movement cannot pass through the counselor while following a route', () => {
  const s=peaceful();Object.assign(s.p,{x:0,z:20});placeKiller(s,0,17,0);
  for(let i=0;i<80;i++) {
    s.time+=1/60;s.follow({x:0,z:24},3.15,1/60);
    assert.ok(Math.hypot(s.p.x-s.killer.x,s.p.z-s.killer.z)>=.8);
  }
  assert.ok(s.killer.z<19.21&&s.killer.z>19,'killer stops at the counselor');
});

test('pitchfork has a readable windup and one precisely timed contact', () => {
  const s=peaceful();Object.assign(s.p,{x:0,z:20});placeKiller(s,0,18.35,0);s.killer.state='chase';
  s.step(1/60,{});const started=s.time;
  assert.equal(s.killer.attackPhase,'windup');assert.equal(s.killer.attackProgress,0);
  tick(s,.6,{});assert.equal(s.phase,'play');assert.equal(s.killer.attackPhase,'windup');
  tick(s,.1,{});assert.equal(s.phase,'play');assert.equal(s.killer.attackPhase,'strike');
  tick(s,.05,{});assert.equal(s.phase,'dead');assert.equal(s.killer.attackHit,true);
  assert.equal(s.killer.attackProgress,ATTACK_TIMING.contact,'death preserves the visible contact pose');
  const contact=ATTACK_TIMING.windup+ATTACK_TIMING.strike*ATTACK_TIMING.contact;
  assert.ok(s.time-started>=contact&&s.time-started<contact+1/60+.001);
  assert.equal(s.events.filter(e=>e.type==='attack').length,1);
});

test('a sidestep evades the committed thrust and recovery cannot restart each frame', () => {
  const s=peaceful();Object.assign(s.p,{x:0,z:20});placeKiller(s,0,18.35,0);s.killer.state='chase';
  s.step(1/60,{});const yaw=s.killer.yaw;
  tick(s,.3,{});tick(s,.25,{moveX:1});tick(s,.3,{});
  assert.equal(s.phase,'play');assert.equal(s.killer.attackPhase,'recover');
  assert.ok(Math.hypot(s.p.x-s.killer.x,s.p.z-s.killer.z)<ATTACK_TIMING.reach,'sidestep misses despite remaining within maximum reach');
  assert.equal(s.killer.yaw,yaw,'swing does not rotate after the counselor');
  assert.equal(s.events.filter(e=>e.type==='attackMiss').length,1);
  assert.equal(s.stats.closeCalls,1);
  tick(s,.2,{});assert.equal(s.killer.attackPhase,'recover');
  assert.equal(s.events.filter(e=>e.type==='attackWindup').length,1);
  tick(s,.2,{});assert.equal(s.killer.attackPhase,null);
});

test('a pitchfork strike cannot land through a solid or beyond its reach', () => {
  for(const obstructed of [false,true]) {
    const wall={id:'attack-test-wall',minX:-.1,maxX:.1,minZ:18,maxZ:22,height:3};
    const s=new Act2Sim({arrivalTime:10000,extraObstacles:obstructed?[wall]:[]});
    Object.assign(s.p,{x:.7,z:20});placeKiller(s,-.7,20,Math.PI/2);
    s.beginAttack();
    if(!obstructed)s.p.x=1.5; // Move beyond the committed weapon reach.
    tick(s,.8,{});
    assert.equal(s.phase,'play');assert.equal(s.killer.attackHit,false);
    assert.equal(s.events.filter(e=>e.type==='attackMiss').length,1);
  }
});

test('unseen hiding does not reveal a location to the patrol', () => {
  const s=peaceful(), hide=HIDE_SPOTS[0];
  Object.assign(s.p,{x:hide.x,z:hide.z});
  placeKiller(s,-20,35,Math.PI);
  s.interact(); assert.equal(s.p.hidden.id,'tent');
  tick(s,18,{});
  assert.equal(s.phase,'play');
  assert.equal(s._knownHide,null);
  assert.ok(!s.events.some(e=>e.type==='hideSeen'));
  s.interact(); assert.equal(s.p.hidden,null);
});

test('hide prompt and interaction require an unobstructed entrance', () => {
  const h=HIDE_SPOTS.find(h=>h.id==='tent');
  const barrier={id:'hide-test-barrier',minX:11,maxX:13,minZ:13.95,maxZ:14.05,height:2};
  const s=new Act2Sim({arrivalTime:10000,extraObstacles:[barrier]});
  Object.assign(s.p,{x:h.x,z:14.5});s.updatePrompt();
  assert.ok(Math.hypot(s.p.x-h.x,s.p.z-h.z)<h.radius);
  assert.equal(walkable(s.p.x,s.p.z,.32,s.obstacles),true);
  assert.equal(s.prompt,null,'prompt is not offered through an obstacle');
  assert.equal(s.interact(),false);assert.equal(s.p.hidden,null);
  Object.assign(s.p,{x:h.x,z:h.z});s.updatePrompt();
  assert.equal(s.prompt.kind,'hide');assert.equal(s.interact(),true);assert.equal(s.p.hidden.id,'tent');
});

test('seen hiding is reached physically, then grants a warning and time to leave', () => {
  const s=peaceful(), h=HIDE_SPOTS[0]; Object.assign(s.p,{x:h.x,z:h.z});
  placeKiller(s,12,17,Math.PI);
  assert.equal(s.canSeePlayer(),true);
  s.interact(); assert.equal(s.killer.state,'check-hide');
  assert.ok(s.events.some(e=>e.type==='hideSeen'));
  let previous={x:s.killer.x,z:s.killer.z};
  for(let i=0;i<600 && s._inspectAt===null;i++) {
    s.step(1/60,{});
    assert.ok(Math.hypot(s.killer.x-previous.x,s.killer.z-previous.z)<=3.15/60+.001);
    previous={x:s.killer.x,z:s.killer.z};
  }
  assert.notEqual(s._inspectAt,null);
  tick(s,2,{}); assert.equal(s.phase,'play');
  s.interact(); assert.equal(s.p.hidden,null);
  assert.equal(s._knownHide,null);
});

test('remaining in a known hiding spot causes the matching death', () => {
  const s=peaceful(), h=HIDE_SPOTS[0]; Object.assign(s.p,{x:h.x,z:h.z});
  placeKiller(s,12,15,Math.PI);
  s.interact(); tick(s,4,{});
  assert.equal(s.phase,'dead'); assert.equal(s.deathKind,'tent');
});

test('one-use defense gives an uninterrupted four second stagger', () => {
  const s=peaceful(); Object.assign(s.p,{x:0,z:0,yaw:0}); s.weapon='ready';
  placeKiller(s,0,2,Math.PI);
  assert.equal(s.defend(),true); assert.equal(s.weapon,'spent');
  const before={x:s.killer.x,z:s.killer.z};
  assert.equal(s.killer.stagger,4);
  tick(s,3.8,{flashlight:true});
  assert.equal(s.killer.state,'stagger');
  assert.deepEqual({x:s.killer.x,z:s.killer.z},before);
  assert.equal(s.phase,'play'); assert.equal(s.defend(),false);
  tick(s,.3,{}); assert.notEqual(s.killer.state,'stagger');
});

test('defense cannot strike through cabin walls or behind the player', () => {
  const s=peaceful(); s.weapon='ready'; Object.assign(s.p,{x:-17,z:3,yaw:-Math.PI/2});
  placeKiller(s,-19,3,Math.PI/2);
  assert.equal(s.defend(),false); assert.equal(s.weapon,'ready');
  assert.equal(s.events.at(-1).reason,'blocked');assert.equal(s.events.at(-1).swing,true);
  Object.assign(s.p,{x:0,z:0,yaw:0}); Object.assign(s.killer,{x:0,z:-2}); s._defendCooldown=0;
  assert.equal(s.defend(),false); assert.equal(s.weapon,'ready');
  assert.equal(s.events.at(-1).reason,'facing');assert.equal(s.events.at(-1).swing,true);
});

test('crowbar misses explain range, preserve the weapon and can be retried successfully', () => {
  const s=peaceful();s.weapon='ready';Object.assign(s.p,{x:0,z:20,yaw:0});placeKiller(s,0,24,Math.PI);
  assert.equal(s.defend(),false);assert.equal(s.events.at(-1).type,'defendMiss');
  assert.equal(s.events.at(-1).reason,'range');assert.equal(s.events.at(-1).swing,true);
  assert.equal(s.weapon,'ready');
  tick(s,.6,{});Object.assign(s.killer,{x:0,z:22});s.beginAttack();
  assert.equal(s.defend(),true);assert.equal(s.weapon,'spent');
  assert.equal(s.killer.attackPhase,null,'defense cancels the windup');
  assert.equal(s.killer.state,'stagger');assert.equal(s.killer.stagger,4);
  const unarmed=peaceful();assert.equal(unarmed.defend(),false);
  assert.equal(unarmed.events.at(-1).reason,'unarmed');assert.equal(unarmed.events.at(-1).swing,false);
});

test('crowbar contact follows the counselor in all four directions, ignoring an opposite camera yaw edge', () => {
  for(const yaw of [0,Math.PI/2,Math.PI,-Math.PI/2]){
    const s=peaceful();s.weapon='ready';Object.assign(s.p,{x:0,z:20,yaw});
    placeKiller(s,Math.sin(yaw)*2.2,20+Math.cos(yaw)*2.2,yaw+Math.PI);
    s.step(1/60,{defend:true,yaw:yaw+Math.PI});
    assert.ok(Math.abs(Math.atan2(Math.sin(s.p.yaw-yaw),Math.cos(s.p.yaw-yaw)))<1e-10);
    assert.equal(s.weapon,'spent');assert.equal(s.killer.state,'stagger');
    assert.equal(s.p.defending,true);assert.equal(s.p.defendYaw,s.p.yaw);
    assert.equal(s.p.defendProgress,0);assert.equal(s.p.defendHit,true);
    const hit=s.events.find(e=>e.type==='defend');assert.equal(hit.yaw,s.p.yaw);assert.equal(hit.duration,.5);
  }
});

test('backpedaling during the swing preserves facing and contact while translation continues', () => {
  const s=peaceful();s.weapon='ready';Object.assign(s.p,{x:0,z:20,yaw:0});placeKiller(s,0,22,Math.PI);
  s.step(1/60,{defend:true,moveZ:-1,yaw:Math.PI});
  tick(s,.4,{moveZ:-1,yaw:Math.PI,run:true});
  assert.equal(s.p.yaw,0);assert.equal(s.p.defendYaw,0);assert.equal(s.p.defending,true);
  assert.ok(s.p.defendProgress>.79&&s.p.defendProgress<.81);
  assert.ok(s.p.z<18.2,'swing does not freeze retreat');
  assert.equal(s.stats.defenses,1);assert.equal(s.killer.state,'stagger');assert.equal(s.killer.z,22);
  tick(s,.15,{moveZ:-1,yaw:Math.PI});
  assert.equal(s.p.defending,false);assert.equal(s.p.defendProgress,1);assert.equal(s.p.defendYaw,null);
  assert.equal(s.p.yaw,Math.PI,'normal movement facing resumes after follow-through');
});

test('aim assistance is limited to twenty-five degrees toward a nearby frontal threat', () => {
  for(const degrees of [20,50]){
    const s=peaceful(),angle=degrees*Math.PI/180;s.weapon='ready';Object.assign(s.p,{x:0,z:20,yaw:0});
    placeKiller(s,Math.sin(angle)*2.2,20+Math.cos(angle)*2.2,angle+Math.PI);
    s.step(1/60,{defend:true,yaw:Math.PI});
    assert.equal(s.weapon,'spent');assert.equal(s.p.defendHit,true);
    assert.ok(Math.abs(s.p.yaw-Math.min(angle,DEFENSE_TIMING.maxAssist))<1e-10);
  }
  const wrapped=peaceful();wrapped.weapon='ready';Object.assign(wrapped.p,{x:0,z:20,yaw:Math.PI-.1});
  placeKiller(wrapped,Math.sin(-Math.PI+.1)*2,20+Math.cos(-Math.PI+.1)*2,.1);
  wrapped.step(1/60,{defend:true});
  assert.equal(wrapped.weapon,'spent');
  assert.ok(Math.abs(wrapped.p.yaw-(Math.PI+.1))<1e-10,'aim crosses the angle seam by a short turn');
});

test('camera yaw cannot make an armed swing auto-hit a threat behind the counselor', () => {
  const s=peaceful();s.weapon='ready';Object.assign(s.p,{x:0,z:20,yaw:0});placeKiller(s,0,18,0);
  s.step(1/60,{defend:true,yaw:Math.PI});
  assert.equal(s.p.yaw,0);assert.equal(s.p.defendYaw,0);assert.equal(s.weapon,'ready');
  assert.equal(s.p.defendHit,false);assert.equal(s.killer.stagger,0);assert.equal(s.stats.defenses,0);
  assert.equal(s.events.find(e=>e.type==='defendMiss').reason,'facing');
});

test('an obstructed threat cannot redirect the swing or be struck through the obstacle', () => {
  const barrier={id:'defense-test-wall',minX:-1,maxX:2,minZ:20.8,maxZ:21.1,height:2};
  const s=new Act2Sim({arrivalTime:10000,extraObstacles:[barrier]});s.weapon='ready';Object.assign(s.p,{x:0,z:20,yaw:0});
  placeKiller(s,1.2,22.08,Math.PI);
  s.step(1/60,{defend:true,yaw:Math.PI});
  assert.equal(s.p.yaw,0);assert.equal(s.p.defendYaw,0);assert.equal(s.weapon,'ready');
  assert.equal(s.p.defendHit,false);assert.equal(s.killer.stagger,0);
  assert.equal(s.events.find(e=>e.type==='defendMiss').reason,'blocked');
});

test('a range miss finishes its facing lock, preserves the crowbar and permits a fresh successful swing', () => {
  const s=peaceful();s.weapon='ready';Object.assign(s.p,{x:0,z:20,yaw:0});placeKiller(s,1,23.2,Math.PI);
  s.step(1/60,{defend:true,yaw:Math.PI});
  assert.equal(s.p.yaw,0,'out-of-range target receives no aim assistance');assert.equal(s.weapon,'ready');
  assert.equal(s.events.find(e=>e.type==='defendMiss').reason,'range');
  tick(s,.6,{});assert.equal(s.p.defending,false);assert.equal(s.p.defendYaw,null);
  Object.assign(s.killer,{x:0,z:22});s.step(1/60,{defend:true,yaw:Math.PI});
  assert.equal(s.weapon,'spent');assert.equal(s.p.defending,true);assert.equal(s.p.defendProgress,0);
  assert.equal(s.p.defendHit,true);assert.equal(s.stats.defenses,1);
});

test('hide, death and a fresh attempt clear the swing-facing lock', () => {
  const s=peaceful();s.weapon='ready';Object.assign(s.p,{x:12,z:13.2,yaw:0});placeKiller(s,0,25,Math.PI);
  s.defend();assert.equal(s.p.defending,true);s.interact();
  assert.equal(s.p.hidden.id,'tent');assert.equal(s.p.defending,false);assert.equal(s.p.defendYaw,null);
  s.interact();s._defendCooldown=0;s.defend();assert.equal(s.p.defending,true);s.kill();
  assert.equal(s.p.defending,false);assert.equal(s.p.defendYaw,null);
  const retry=peaceful();assert.equal(retry.p.defending,false);assert.equal(retry.p.defendProgress,0);
  assert.equal(retry.p.defendHit,false);assert.equal(retry.p.defendYaw,null);
  retry.weapon='ready';Object.assign(retry.p,{x:0,z:20,yaw:0});placeKiller(retry,0,22,Math.PI);
  retry.step(1/60,{defend:true});assert.equal(retry.p.defendHit,true);
});

test('search expires instead of continuously targeting a hidden player', () => {
  const s=peaceful(); placeKiller(s,0,0,Math.PI);
  Object.assign(s.p,{x:12,z:13.2,hidden:HIDE_SPOTS[0]});
  s.beginSearch({x:0,z:2}); tick(s,10.2,{});
  assert.equal(s.killer.state,'patrol'); assert.equal(s.phase,'play');
});

test('hearing investigates a fixed sound location without claiming lost sight', () => {
  const s=peaceful(); Object.assign(s.p,{x:0,z:0});
  placeKiller(s,0,10,0); // Looking away from the approaching sound.
  s.step(1/60,{moveX:1,run:true});
  assert.equal(s.killer.state,'search');
  assert.ok(s.events.some(e=>e.type==='investigate'));
  assert.ok(!s.events.some(e=>e.type==='lost'));
  const heard={...s.killer.lastSeen};
  tick(s,.5,{moveX:1,run:true,flashlight:false});
  assert.deepEqual(s.killer.lastSeen,heard);
});

test('keys require a held action; interrupted hold resets; van requires keys', () => {
  const s=peaceful(); Object.assign(s.p,LOCATIONS.vanDoor);
  s.interact(); assert.equal(s.phase,'play'); assert.ok(s.events.some(e=>e.type==='locked'));
  Object.assign(s.p,LOCATIONS.keys); tick(s,.7,{actionHeld:true});
  assert.ok(s.keyProgress > .4 && !s.keys);
  tick(s,.1,{}); assert.equal(s.keyProgress,0);
  tick(s,1.5,{actionHeld:true}); assert.equal(s.keys,true);
  Object.assign(s.p,LOCATIONS.vanDoor); s.step(1/60,{action:true});
  assert.equal(s.phase,'escape'); assert.equal(s.prompt,null);
  assert.ok(s.events.some(e=>e.type==='escape'));
});

test('a fresh checkpoint attempt clears death, keys and spent weapon', () => {
  const old=peaceful(); old.keys=true; old.weapon='spent'; old.kill('wardrobe');
  const s=peaceful();
  assert.equal(s.phase,'play'); assert.equal(s.deathKind,null);
  assert.equal(s.keys,false); assert.equal(s.weapon,'none'); assert.equal(s.p.hidden,null);
  assert.equal(s.checkpoint,'post-crash'); assert.deepEqual({x:s.p.x,z:s.p.z},LOCATIONS.start);
});
