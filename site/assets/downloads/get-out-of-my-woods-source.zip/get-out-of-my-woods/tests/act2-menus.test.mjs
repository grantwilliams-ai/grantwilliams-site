import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { confirmCopy, escapeAction } from '../src/act2/ui.js';

const TAIL = 'You will lose your progress since the crash. Your crash checkpoint stays.';

test('pause confirmations use the spec wording and nothing else does', () => {
  assert.equal(confirmCopy('retry'), `Restart at the crash? ${TAIL}`);
  assert.equal(confirmCopy('home'), `Return to the title? ${TAIL}`);
  assert.equal(confirmCopy('start'), '');
  assert.equal(confirmCopy('resume'), '');
});

test('Esc cancels a confirmation, backs out of settings, and closes Bearings before pausing', () => {
  assert.equal(escapeAction({ mode: 'pause', confirming: true }), 'cancel-confirm');
  assert.equal(escapeAction({ mode: 'settings' }), 'back');
  assert.equal(escapeAction({ mode: 'controls' }), 'back');
  assert.equal(escapeAction({ mode: 'play', mapOpen: true }), 'close-bearings');
  assert.equal(escapeAction({ mode: 'play' }), 'pause');
  assert.equal(escapeAction({ mode: 'intro' }), 'pause');
  assert.equal(escapeAction({ mode: 'death' }), 'pause');
  assert.equal(escapeAction({ mode: 'escape' }), 'pause');
  assert.equal(escapeAction({ mode: 'pause' }), 'resume');
  assert.equal(escapeAction({ mode: 'title' }), 'ignore');
  assert.equal(escapeAction({ mode: 'dead' }), 'ignore');
  assert.equal(escapeAction({ mode: 'won' }), 'ignore');
});

test('settings, Bearings and the pause screen use the shared words', () => {
  const src = readFileSync(new URL('../src/act2/ui.js', import.meta.url), 'utf8');
  const settings = src.slice(src.indexOf('<h2>SETTINGS</h2>'), src.indexOf('TEST SOUND'));
  const order = [
    'Brightness', 'Sound', 'Your footsteps', 'aria-label="Your footsteps"',
    'Changes what you hear, not what he hears. His footsteps stay audible.',
    'Picture', 'Clean', 'Retro', 'Tape effect', 'Off', 'On', 'Flashes', 'Full', 'Reduced',
    'Controls shown', 'Automatic', 'Keyboard & mouse', 'Touch', 'Control hints',
  ];
  let at = 0;
  for (const bit of order) {
    const i = settings.indexOf(bit, at);
    assert.ok(i >= at, bit);
    at = i + bit.length;
  }
  assert.ok(src.includes('BEARINGS · LIVE'));
  assert.ok(src.includes('The night keeps moving while this is open.'));
  assert.ok(src.includes('pause-destination'));
  assert.equal(src.includes('Counselor steps'), false);
  assert.equal(src.includes('>OPTIONS<'), false);
  assert.ok(src.includes("mode==='pause')askConfirm"));
});
