import test from 'node:test';
import assert from 'node:assert/strict';
import { beamYaw, BEAM_REACH } from '../src/core/beam.js';

const wrap = (a) => Math.atan2(Math.sin(a), Math.cos(a));

test('the flashlight follows the view when she faces it and her body otherwise', () => {
  assert.equal(beamYaw(1, 1), 1);
  assert.ok(Math.abs(beamYaw(0, 0.5) - 0.5) < 1e-9, 'a small look to the side is followed exactly');
  assert.ok(Math.abs(beamYaw(0, 1.1) - BEAM_REACH) < 1e-9, 'a wide look is held at arm reach');
  assert.ok(Math.abs(wrap(beamYaw(0, Math.PI))) < 1e-9, 'running at the camera, the beam points ahead of her');
  assert.ok(Math.abs(wrap(beamYaw(0, -Math.PI + 0.01))) < 0.01, 'and does not flip sides around the back');
});

test('the beam never leaves her side of the body and never jumps', () => {
  let last = beamYaw(0, -Math.PI);
  for (let view = -Math.PI; view <= Math.PI; view += 0.01) {
    const yaw = beamYaw(0, view);
    assert.ok(Math.abs(yaw) <= BEAM_REACH + 1e-9);
    assert.ok(Math.abs(yaw - last) < 0.02, `jump at view ${view}`);
    last = yaw;
  }
});

test('standing still the beam goes to the view; moving it swings to her body without snapping', async () => {
  const { aimBeam } = await import('../src/core/beam.js');
  let beam = aimBeam(undefined, 0, Math.PI, false, 1 / 60);
  assert.equal(beam, Math.PI, 'idle: where the player looks');
  let worst = 0;
  for (let i = 0; i < 90; i++) { const next = aimBeam(beam, 0, Math.PI, true, 1 / 60); worst = Math.max(worst, Math.abs(wrap(next - beam))); beam = next; }
  assert.ok(Math.abs(wrap(beam)) < 0.01, 'moving toward the camera: ahead of her');
  assert.ok(worst < 0.5, 'no snap');
});
