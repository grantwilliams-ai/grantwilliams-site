import test from 'node:test';
import assert from 'node:assert/strict';
import { GameSim } from '../src/sim/game.js';
import { CAR } from '../src/sim/layout.js';
import { PLAYER } from '../src/ai/tuning.js';

const DT = 1 / 60;
const IDLE = { moveX: 0, moveY: 0, camYaw: 0, run: false, sneak: false, action: false, actionHeld: false, flashlight: false };

function openingEvents(sim, event) {
  return sim.drainEvents().filter((e) => e.t === event);
}

function walkToCar(difficulty, moveY = 1) {
  const sim = new GameSim({ difficulty, seed: 91 });
  const player = sim.player;
  const path = sim.nav.findPath(player.x, player.z, CAR.x, CAR.z);
  assert.ok(path, `${difficulty}: nav route to car exists`);
  let waypoint = 0;
  let maxSpeed = 0;
  let carFoundAt = null;
  let huntStartedAt = null;
  for (let frame = 0; frame < sim.introCeiling / DT + 2 && sim.phase === 'intro'; frame++) {
    const target = path[Math.min(waypoint, path.length - 1)];
    const dx = target[0] - player.x;
    const dz = target[1] - player.z;
    if (Math.hypot(dx, dz) < 0.45 && waypoint < path.length - 1) waypoint++;
    sim.step(DT, { ...IDLE, moveY, camYaw: Math.atan2(dx, dz) });
    maxSpeed = Math.max(maxSpeed, player.speed);
    for (const event of sim.drainEvents()) {
      if (event.t === 'carFound') carFoundAt = sim.time;
      if (event.t === 'huntStarted') huntStartedAt = sim.time;
    }
  }
  return { sim, carFoundAt, huntStartedAt, maxSpeed };
}

test('walking the nav route reaches the car reveal before the hunt on every difficulty', () => {
  const results = [];
  for (const difficulty of ['easy', 'normal', 'hard']) {
    const { sim, carFoundAt, huntStartedAt, maxSpeed } = walkToCar(difficulty);
    assert.equal(huntStartedAt, null, `${difficulty}: timer must not skip the reveal`);
    assert.ok(carFoundAt !== null, `${difficulty}: car reveal reached`);
    assert.equal(sim.phase, 'cutscene');
    assert.ok(maxSpeed <= PLAYER.walk + 0.001, `${difficulty}: walking speed only`);
    results.push({ difficulty, carFoundAt: +carFoundAt.toFixed(2), maxSpeed: +maxSpeed.toFixed(2) });
  }
  console.log('intro walk results', JSON.stringify(results));
});

test('standing still and walking away retain the existing bounded grace on every difficulty', () => {
  for (const difficulty of ['easy', 'normal', 'hard']) {
    for (const scenario of ['still', 'away']) {
      const sim = new GameSim({ difficulty, seed: 91 });
      const awayYaw = Math.atan2(sim.player.x - CAR.x, sim.player.z - CAR.z);
      let huntStartedAt = null;
      for (let frame = 0; frame < (sim.tune.introGrace * 2) / DT && sim.phase === 'intro'; frame++) {
        sim.step(DT, scenario === 'away' ? { ...IDLE, moveY: 1, camYaw: awayYaw } : IDLE);
        if (openingEvents(sim, 'huntStarted').length) huntStartedAt = sim.time;
      }
      assert.ok(huntStartedAt !== null, `${difficulty}/${scenario}: hunt starts`);
      assert.ok(huntStartedAt <= sim.tune.introGrace + DT * 2, `${difficulty}/${scenario}: existing grace retained`);
      assert.ok(huntStartedAt <= sim.tune.introGrace * 2, `${difficulty}/${scenario}: hard ceiling`);
      assert.equal(sim.reached.car, false);
    }
  }
});

// Independent check (Grok, 2026-11-08): a touch player with a half-pushed stick, or anyone holding sneak,
// takes about 61 s to reach the car; the first ceiling (twice the grace, 50 s on Hard) still cut them off.
test('sneaking the nav route (a half-pushed stick) also reaches the car reveal on every difficulty', () => {
  for (const difficulty of ['easy', 'normal', 'hard']) {
    const { sim, carFoundAt, huntStartedAt, maxSpeed } = walkToCar(difficulty, 0.4);
    assert.equal(huntStartedAt, null, `${difficulty}: a sneaking approach is not cut off`);
    assert.ok(carFoundAt !== null && sim.phase === 'cutscene', `${difficulty}: car reveal reached at sneak speed`);
    assert.ok(maxSpeed <= PLAYER.sneak + 0.001, `${difficulty}: sneak speed only`);
    assert.ok(carFoundAt < sim.introCeiling - 15, `${difficulty}: with room to spare for a detour`);
  }
});

test('an approach that keeps closing in without arriving is still bounded by the ceiling', () => {
  for (const difficulty of ['easy', 'normal', 'hard']) {
    const sim = new GameSim({ difficulty, seed: 91 });
    let huntStartedAt = null, carFound = false;
    // Spiral in: mostly sideways, a little toward the car, so the distance shrinks on most frames.
    for (let frame = 0; frame < sim.introCeiling / DT + 2 && sim.phase === 'intro'; frame++) {
      const bearing = Math.atan2(CAR.x - sim.player.x, CAR.z - sim.player.z);
      sim.step(DT, { ...IDLE, moveY: 1, camYaw: bearing + 1.45 });
      for (const event of sim.drainEvents()) {
        if (event.t === 'huntStarted') huntStartedAt = sim.time;
        if (event.t === 'carFound') carFound = true;
      }
    }
    assert.ok(huntStartedAt !== null, `${difficulty}: the opening still ends`);
    assert.ok(huntStartedAt <= sim.introCeiling + DT * 2, `${difficulty}: within ${sim.introCeiling} s`);
    assert.equal(carFound, false);
    assert.equal(sim.phase, 'play');
  }
});
