// Lane L4 (Act I screens and layout): captions, controls the player can find, menus, map labels.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as THREE from 'three';
import { App, OBJECTIVE } from '../src/game/app.js';
import { GameSim } from '../src/sim/game.js';
import { CameraRig } from '../src/game/camera.js';
import { createPlayer } from '../src/characters/player.js';
import { createKiller } from '../src/characters/killer.js';
import { audio } from '../src/audio/index.js';
import { createInputState, bindInput } from '../src/ui/input.js';
import { createMessages } from '../src/ui/messages.js';
import { drawCampMap } from '../src/ui/map.js';
import { MAP_LABELS } from '../src/sim/layout.js';

const noop = () => {};
// createPlayer/createKiller want a canvas for their textures.
const ctx2d = new Proxy({ measureText: () => ({ width: 20 }), createLinearGradient: () => ({ addColorStop() {} }) }, { get: (o, k) => o[k] ?? (() => {}) });
globalThis.document ??= { createElement: () => ({ getContext: () => ctx2d }) };
function quiet(fn) {
  const original = Object.fromEntries(['setListener', 'setIntensity', 'setRoom', 'sfx', 'ambience'].map((k) => [k, audio[k]]));
  for (const k of Object.keys(original)) audio[k] = noop;
  try { return fn(); } finally { Object.assign(audio, original); }
}

// A running night with a recording interface.
function fixture() {
  const sim = new GameSim({ skipIntro: true, seed: 42 }), camera = new THREE.PerspectiveCamera(), rig = new CameraRig(camera, sim.collision);
  const calls = [];
  const flags = { map: false };
  const rec = (name) => (...args) => { calls.push([name, ...args]); };
  const ui = {
    input: { moveX: 0, moveY: 0, lookX: 0, lookY: 0 }, mapOpen: () => flags.map,
    setObjective: noop, setPrompt: noop, setHold: noop, setStamina: noop,
    caption: rec('caption'), toast: rec('toast'), setInventory: rec('setInventory'), setKeyStrip: rec('setKeyStrip'),
    tickMessages: rec('tickMessages'), setFlashlight: noop, setHide: noop, bloodSplat: noop,
  };
  const app = Object.create(App.prototype), playerFig = createPlayer(), killer = createKiller();
  Object.assign(app, {
    state: 'play', sim, ui, cine: { blocking: false, clear: noop, openHood: noop }, rig, playerFig, killer, headTarget: new THREE.Vector3(), from: new THREE.Vector3(),
    aim: new THREE.Vector3(), tmpV: new THREE.Vector3(), camera, quality: { isTouch: false }, settings: { flashes: 'reduced', brightness: 1 },
    flash: { power: 1, setOn: noop, update: noop }, world: { setIndoor: noop, lightning: noop, car: null }, glints: { update: noop },
    renderer: { time: 0, target: { height: 720 }, gl: { domElement: { height: 720 } } },
    post: { uBrightness: { value: 1 }, uDanger: { value: 0 }, uTear: { value: 0 } }, eyes: 1, updateMusic: noop,
  });
  return { app, sim, ui, calls, flags };
}

test('K8: the opening objective says to follow the road, not to walk', () => {
  assert.equal(OBJECTIVE({ phase: 'intro', has: {} }), 'Follow the road east to your car.');
});

test('B01/B02: the frame loop feeds caption time only while the night runs', () => quiet(() => {
  const { app, calls, flags } = fixture();
  App.prototype.tickPlay.call(app, 0.05);
  assert.deepEqual(calls.filter((c) => c[0] === 'tickMessages'), [['tickMessages', 0.05]]);
  calls.length = 0;
  flags.map = true; // the map holds the night
  for (let i = 0; i < 20; i++) App.prototype.tickPlay.call(app, 0.05);
  assert.equal(calls.filter((c) => c[0] === 'tickMessages').length, 0, 'map open: no caption time passes');
  // pause is a state in which tickPlay never runs at all
  const tickSrc = readFileSync(new URL('../src/game/app.js', import.meta.url), 'utf8');
  assert.match(tickSrc, /case 'paused': break;/);
}));

test('B01: every Act I caption carries its kind', () => quiet(() => {
  const { app, ui, calls } = fixture();
  const say = (e) => { calls.length = 0; App.prototype.onEvent.call(app, e); return calls.filter((c) => c[0] === 'caption' || c[0] === 'toast'); };
  const one = (e) => say(e)[0];
  assert.equal(one({ t: 'graze' })[3].kind, 'urgent');
  assert.equal(one({ t: 'hideSeen' })[3].kind, 'urgent');
  assert.equal(one({ t: 'hideDanger' })[3].kind, 'urgent');
  const lost = one({ t: 'lost' });
  assert.equal(lost[0], 'caption', 'lost-sight is a caption, not a toast');
  assert.equal(lost[3].kind, 'urgent');
  assert.equal(one({ t: 'found', what: 'keys', text: 'Car keys.' })[3].kind, 'essential');
  assert.equal(one({ t: 'nothing', text: 'Dust.' })[3].kind, 'flavor');
  assert.equal(one({ t: 'batteryIn' })[3].kind, 'essential');
  assert.equal(one({ t: 'line', text: 'It needs the battery.' })[3].kind, 'urgent');
  const hunt = one({ t: 'huntStarted' });
  assert.equal(hunt[1], 'You are not alone. Find your keys and a battery. Get out.', 'untouched by this lane');
  void ui;
}));

test('B01: a warning in the same moment does not erase the hunt instruction', () => {
  const m = createMessages();
  m.say('You are not alone. Find your keys and a battery. Get out.', { seconds: 6 });
  m.say('He saw you hide. Move!', { kind: 'urgent', seconds: 3, key: 'hideSeen' });
  assert.equal(m.text, 'He saw you hide. Move!');
  for (let t = 0; t < 3.05; t += 0.05) m.update(0.05);
  assert.equal(m.text, 'You are not alone. Find your keys and a battery. Get out.');
});

test('F12: the battery leaves the pack once it is installed, and does not come back with later finds', () => quiet(() => {
  const { app, sim, calls } = fixture();
  sim.has.battery = true;
  assert.deepEqual(app.inventoryView(), { keys: false, battery: true });
  sim.batteryIn = true;
  calls.length = 0;
  App.prototype.onEvent.call(app, { t: 'batteryIn' });
  assert.deepEqual(calls.find((c) => c[0] === 'setInventory')[1], { keys: false, battery: false });
  sim.has.keys = true;
  calls.length = 0;
  App.prototype.onEvent.call(app, { t: 'found', what: 'keys', text: 'Car keys.' });
  assert.deepEqual(calls.find((c) => c[0] === 'setInventory')[1], { keys: true, battery: false }, 'finding the keys later must not show BATTERY again');
}));

test('K7/G1: the key strip is told to hide for films, the car and hiding, and to show in ordinary play', () => quiet(() => {
  const { app, sim, calls } = fixture();
  App.prototype.tickPlay.call(app, 0.05);
  assert.deepEqual(calls.filter((c) => c[0] === 'setKeyStrip').pop(), ['setKeyStrip', true]);
  app.cine.blocking = true;
  App.prototype.tickPlay.call(app, 0.05);
  assert.deepEqual(calls.filter((c) => c[0] === 'setKeyStrip').pop(), ['setKeyStrip', false], 'hidden during a film');
  app.cine.blocking = false;
  sim.player.hidden = { type: 'closet', view: { pos: [0, 1, 0], look: [0, 1, 1] } };
  App.prototype.tickPlay.call(app, 0.05);
  assert.deepEqual(calls.filter((c) => c[0] === 'setKeyStrip').pop(), ['setKeyStrip', false], 'hidden in a hiding view');
}));

test('B04: App.setting reaches the touch HUD at once when Controls shown changes', () => {
  const touch = [];
  const app = Object.create(App.prototype);
  Object.assign(app, { disposed: false, initializing: false, settings: { inputMode: 'auto' }, state: 'play', cine: { blocking: false }, sim: { phase: 'play' },
    ui: { setTouchVisible: (on) => touch.push(on) }, campaign: null });
  app.setting('inputMode', 'touch');
  app.setting('inputMode', 'keyboard');
  assert.deepEqual(touch, [true, false]);
});

// ---- Esc goes back one step in a menu before the game sees it
function surface() {
  const l = new Map();
  return { addEventListener(t, f) { (l.get(t) || l.set(t, new Set()).get(t)).add(f); }, removeEventListener(t, f) { l.get(t)?.delete(f); },
    emit(t, p = {}) { const e = { target: this, preventDefault() {}, ...p }; for (const f of [...(l.get(t) || [])]) f(e); return e; },
    closest: () => null, querySelector: () => null, setAttribute() {}, removeAttribute() {}, classList: { add() {}, remove() {}, toggle() {} }, style: {}, dataset: {} };
}
test('B08: an Esc a menu handles is not also a pause press, and one it ignores still pauses', () => {
  const win = surface(), doc = surface(), root = surface(), game = surface();
  win.matchMedia = () => ({ matches: false });
  doc.pointerLockElement = null; doc.getElementById = () => game; doc.exitPointerLock = noop;
  const prevWin = globalThis.window, prevDoc = globalThis.document;
  globalThis.window = win; globalThis.document = doc;
  try {
    const input = createInputState();
    let menu = true;
    const io = bindInput(input, { uiRoot: root, gameEl: game, blocked: () => false, playing: () => true, touchOn: () => false, onEscape: () => menu });
    win.emit('keydown', { code: 'Escape' });
    assert.equal(input.pausePressed, false, 'Esc in a menu goes back; the game must not resume or pause on it');
    menu = false;
    win.emit('keydown', { code: 'Escape' });
    assert.equal(input.pausePressed, true, 'Esc in play is still the pause key');
    io.dispose();
  } finally { globalThis.window = prevWin; globalThis.document = prevDoc; }
});

// ---- F3: map labels stay attached to their buildings
function recordingCanvas(w, h) {
  const calls = [];
  const g = new Proxy({ measureText: (t) => ({ width: String(t).length * 9 }), createLinearGradient: () => ({ addColorStop: noop }), createRadialGradient: () => ({ addColorStop: noop }),
    getImageData: (x, y, ww, hh) => ({ data: new Uint8ClampedArray(ww * hh * 4) }), putImageData: noop }, {
    get(o, k) { if (k in o) return o[k]; return (...a) => { calls.push([k, ...a]); }; },
    set(o, k, v) { o[k] = v; return true; },
  });
  return { canvas: { clientWidth: w, clientHeight: h, width: w, height: h, getContext: () => g }, calls };
}
// The map paper's CSS size at each spec viewport (portrait/desktop 92vw x 62dvh, short landscape 70vw x 88dvh), plus a few odd ones.
const MAP_SIZES = [[296, 352], [320, 400], [350, 540], [640, 400], [820, 620],
  ...[[320, 568], [360, 732], [390, 844], [1280, 720], [1365, 820]].map(([vw, vh]) => [Math.round(Math.min(vw * 0.92, 820)), Math.round(Math.min(vh * 0.62, 620))]),
  ...[[732, 360], [844, 390], [800, 450], [1280, 500]].map(([vw, vh]) => [Math.round(Math.min(vw * 0.7, 720)), Math.round(Math.min(vh * 0.88, 360))])];
test('F3: no map label overlaps another, the YOU marker or the compass rose; all four points are drawn', () => {
  for (const [w, h] of MAP_SIZES) {
    globalThis.devicePixelRatio = 1;
    const { canvas, calls } = recordingCanvas(w, h);
    drawCampMap(canvas, { player: { x: 3.4, z: 11.4 }, searched: [] });
    const labs = MAP_LABELS.map((l) => { const t = calls.find((c) => c[0] === 'fillText' && c[1] === l.text); return { text: l.text, x: t[2], y: t[3], w: l.text.length * 9 }; });
    for (let i = 0; i < labs.length; i++) for (let j = i + 1; j < labs.length; j++) {
      const a = labs[i], b = labs[j];
      const clash = Math.abs(a.x - b.x) < (a.w + b.w) / 2 + 8 && Math.abs(a.y - b.y) < 24;
      assert.ok(!clash, `${a.text} and ${b.text} overlap at ${w}x${h}`);
    }
    // The marker: a ring of radius 17 at her place. No name may sit on it.
    const PAD = 36, B = { minX: -130, maxX: 150, minZ: -122, maxZ: 132 };
    const px = PAD + ((3.4 - B.minX) / (B.maxX - B.minX)) * (w - PAD * 2), py = PAD + ((11.4 - B.minZ) / (B.maxZ - B.minZ)) * (h - PAD * 2);
    for (const l of labs) {
      const cx = Math.max(l.x - l.w / 2, Math.min(px, l.x + l.w / 2)), cy = Math.max(l.y - 12, Math.min(py, l.y + 12));
      assert.ok(Math.hypot(cx - px, cy - py) >= 17, `${l.text} sits on the YOU marker at ${w}x${h}`);
    }
    // She is named once: in the legend where it fits, by a small tag beside the marker where it does not.
    const named = calls.filter((c) => c[0] === 'fillText' && (c[1] === 'YOU ARE HERE' || c[1] === 'YOU'));
    assert.equal(named.length, 1, `the marker is named once at ${w}x${h}`);
    if (named[0][1] === 'YOU') for (const l of labs) {
      const hit = Math.abs(l.x - named[0][2]) < l.w / 2 + 22 && Math.abs(l.y - named[0][3]) < 22;
      assert.ok(!hit, `the YOU tag covers ${l.text} at ${w}x${h}`);
    }
    // The rose: N, E, S and W, and no name across it.
    const points = ['N', 'E', 'S', 'W'].map((p) => calls.find((c) => c[0] === 'fillText' && c[1] === p));
    assert.ok(points.every(Boolean), `all four compass points at ${w}x${h}`);
    assert.ok(points[0][3] < points[2][3] && points[3][2] < points[1][2], 'north above south, west left of east');
    const rx = points[0][2], ry = (points[0][3] + points[2][3]) / 2;
    for (const l of labs) {
      const hit = Math.abs(l.x - rx) < l.w / 2 + 30 && Math.abs(l.y - ry) < 12 + 30;
      assert.ok(!hit, `${l.text} runs across the compass rose at ${w}x${h}`);
    }
  }
});

test('the map draws the dock and a box for each search spot that stands in the open', () => {
  const PAD = 36, B = { minX: -130, maxX: 150, minZ: -122, maxZ: 132 };
  for (const [w, h] of MAP_SIZES) {
    globalThis.devicePixelRatio = 1;
    const { canvas, calls } = recordingCanvas(w, h);
    drawCampMap(canvas, { player: { x: 3.4, z: 11.4 }, searched: [] });
    const at = (x, z) => [PAD + ((x - B.minX) / (B.maxX - B.minX)) * (w - PAD * 2), PAD + ((z - B.minZ) / (B.maxZ - B.minZ)) * (h - PAD * 2)];
    const rects = calls.filter((c) => c[0] === 'fillRect');
    const covers = ([x, y]) => rects.some((r) => r[3] < 60 && r[4] < 120 && x >= r[1] - 0.5 && x <= r[1] + r[3] + 0.5 && y >= r[2] - 0.5 && y <= r[2] + r[4] + 0.5);
    assert.ok(covers(at(22, -91)), `the archery range's equipment box is drawn at ${w}x${h}`);
    assert.ok(covers(at(-34.8, 72.5)), `the cooler at the end of the dock is drawn at ${w}x${h}`);
    assert.ok(covers(at(-34, 60)), `the dock is drawn at ${w}x${h}`);
  }
});

test('F3: at small sizes every map label is on its place or joined to it by a leader tick', () => {
  const PAD = 36, B = { minX: -130, maxX: 150, minZ: -122, maxZ: 132 };
  for (const [w, h] of MAP_SIZES) {
    globalThis.devicePixelRatio = 1;
    const { canvas, calls } = recordingCanvas(w, h);
    drawCampMap(canvas, { player: { x: 3.4, z: 11.4 }, searched: [] });
    for (const lab of MAP_LABELS) {
      const ax = PAD + ((lab.x - B.minX) / (B.maxX - B.minX)) * (w - PAD * 2), ay = PAD + ((lab.z - B.minZ) / (B.maxZ - B.minZ)) * (h - PAD * 2);
      const t = calls.find((c) => c[0] === 'fillText' && c[1] === lab.text);
      assert.ok(t, `${lab.text} is drawn at ${w}x${h}`);
      const tw = lab.text.length * 9, x = t[2], y = t[3];
      const nx = Math.max(x - tw / 2 - 4, Math.min(ax, x + tw / 2 + 4)), ny = Math.max(y - 12, Math.min(ay, y + 12));
      const drift = Math.hypot(nx - ax, ny - ay);
      if (drift >= 8) {
        const leader = calls.some((c, i) => c[0] === 'moveTo' && Math.hypot(c[1] - ax, c[2] - ay) < 0.5 && calls[i + 1]?.[0] === 'lineTo');
        assert.ok(leader, `${lab.text} at ${w}x${h} is ${drift.toFixed(0)}px from its place and needs a leader`);
      }
      assert.ok(x - tw / 2 >= 0 && x + tw / 2 <= w, `${lab.text} stays on the paper at ${w}x${h}`);
    }
  }
});

// ---- Layout rules that only a stylesheet can hold
test('K2/F7/K6: the stylesheet keeps the title in one column in portrait and on one screen in short landscape', () => {
  const css = readFileSync(new URL('../src/ui/style.css', import.meta.url), 'utf8');
  const tail = css.slice(css.indexOf('Title: long labels wrap'));
  assert.match(tail, /@media \(orientation: portrait\) \{[\s\S]*?\.title-right \{ flex-wrap: nowrap;/, 'portrait: the button column does not wrap into a second column');
  assert.match(tail, /\.title-right \.btn-display, \.title-right \.btn-continue \{ flex: 0 0 auto; \}/, 'a 100% flex basis in a column once pushed FULLSCREEN off screen');
  assert.match(css, /@media \(orientation: landscape\) and \(max-height: 460px\) \{\s*\.title-layout \{\s*display: grid;/);
  assert.match(css, /\.more-cue/);
  assert.match(css, /\.menu-card > \.btn\[data-act="back"\],\n\.menu-card > \.btn\[data-act="controls-back"\]/, 'BACK stays reachable in long menus');
});
