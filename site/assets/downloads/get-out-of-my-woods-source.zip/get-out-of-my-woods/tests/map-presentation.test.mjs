import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { App } from '../src/game/app.js';
import { Flashlight } from '../src/game/flashlight.js';
import { GLOBALS } from '../src/render/materials.js';
import { GameSim } from '../src/sim/game.js';
import { CameraRig } from '../src/game/camera.js';
import { createPlayer } from '../src/characters/player.js';
import { createKiller } from '../src/characters/killer.js';
import { createWallClearance } from '../src/characters/wall-clearance.js';
import { audio } from '../src/audio/index.js';
import { createInputState, bindInput } from '../src/ui/input.js';

const context=new Proxy({measureText:()=>({width:20}),createLinearGradient:()=>({addColorStop(){}})}, {get:(o,k)=>o[k]??(()=>{})});
globalThis.document={createElement:()=>({getContext:()=>context})};
const noop=()=>{};
function fixture(){
 const app=Object.create(App.prototype),sim=new GameSim({skipIntro:true,seed:42}),camera=new THREE.PerspectiveCamera(),rig=new CameraRig(camera,sim.collision);
 Object.assign(sim.player,{x:0,z:0,y:0,moveMode:'run',speed:4.7,vx:0,vz:4.7});
 Object.assign(sim.killer,{x:8,z:0,state:'chase',anim:'chase',speed:3.8});
 const flags={map:true},playerFig=createPlayer(),killer=createKiller();
 Object.assign(app,{state:'play',sim,ui:{input:{moveX:0,moveY:0,lookX:0,lookY:0},mapOpen:()=>flags.map,setObjective:noop,setPrompt:noop,setHold:noop,setStamina:noop},
  cine:{blocking:false},rig,playerFig,killer,headTarget:new THREE.Vector3(),from:new THREE.Vector3(),aim:new THREE.Vector3(),tmpV:new THREE.Vector3(),camera,
  quality:{isTouch:false},settings:{flashes:'reduced',brightness:1},flash:{power:1,setOn:noop,update:noop},world:{setIndoor:noop},glints:{update:noop},
  renderer:{time:0,target:{height:720},gl:{domElement:{height:720}}},post:{uBrightness:{value:1},uDanger:{value:0},uTear:{value:0}},eyes:1,updateMusic:noop});
 return {app,sim,flags,playerFig,killer};
}
function quiet(fn){
 const original=Object.fromEntries(['setListener','setIntensity','setRoom','sfx'].map(k=>[k,audio[k]]));
 for(const k of Object.keys(original))audio[k]=noop;
 try{return fn();}finally{Object.assign(audio,original);}
}
function pose(figure){return figure.rig.bones.map(b=>({p:b.position.clone(),q:b.quaternion.clone()}));}
function samePose(figure,before){for(let i=0;i<before.length;i++){
 assert.ok(figure.rig.bones[i].position.distanceTo(before[i].p)<1e-10,`position of ${figure.rig.names[i]} changed`);
 assert.ok(figure.rig.bones[i].quaternion.angleTo(before[i].q)<1e-6,`rotation of ${figure.rig.names[i]} changed`);
}}

test('Act I map freezes both locomotion clocks and poses along with simulation',()=>quiet(()=>{
 const {app,sim,flags,playerFig,killer}=fixture();
 // Establish the live flashlight/aim and animation state before opening the map.
 flags.map=false;app.cine.blocking=true;App.prototype.tickPlay.call(app,1/60);
 flags.map=true;app.cine.blocking=false;App.prototype.tickPlay.call(app,1/60);
 const before=[pose(playerFig),pose(killer)],time=sim.time,phases=[playerFig.animator.cur.phase,killer.animator.cur.phase];
 const clocks=[playerFig.animator.cur.t,killer.animator.cur.t],positions=[sim.player.x,sim.player.z,sim.killer.x,sim.killer.z];
 for(let i=0;i<120;i++)App.prototype.tickPlay.call(app,1/60);
 assert.equal(sim.time,time);assert.deepEqual([sim.player.x,sim.player.z,sim.killer.x,sim.killer.z],positions);
 assert.deepEqual([playerFig.animator.cur.phase,killer.animator.cur.phase],phases);
 assert.deepEqual([playerFig.animator.cur.t,killer.animator.cur.t],clocks);
 samePose(playerFig,before[0]);samePose(killer,before[1]);
}));

test('map freezes an in-progress attack and preserves its existing wall restraint and fork grip',()=>quiet(()=>{
 const {app,sim,killer}=fixture();
 Object.assign(sim.killer,{x:.46,z:0,yaw:-Math.PI/2,state:'strike',anim:'raise',speed:0});
 app.killerClearance=createWallClearance(killer);
 sim.collision={walls:[{x1:0,z1:-10,x2:0,z2:10}],doors:[],blocked:()=>false};
 killer.root.position.set(.46,0,0);killer.root.rotation.y=-Math.PI/2;killer.setAnim('raise',{restart:true,fade:.001});killer.update(.18,{speed:0});
 app.lastKillerAnim='raise';app.killerClearance.apply(sim.collision,1/60);
 App.prototype.tickPlay.call(app,1/60);
 const before=pose(killer),clock=killer.animator.cur.t,root=killer.root.position.clone(),tip=killer.forkTip.getWorldPosition(new THREE.Vector3());
 for(let i=0;i<90;i++)App.prototype.tickPlay.call(app,1/30);
 samePose(killer,before);assert.equal(killer.animator.cur.t,clock);assert.ok(killer.root.position.distanceTo(root)<1e-12);
 assert.ok(killer.forkTip.getWorldPosition(new THREE.Vector3()).distanceTo(tip)<1e-8);
 const hand=killer.rig.b('handR').getWorldPosition(new THREE.Vector3()),fork=killer.rig.b('fork').getWorldPosition(new THREE.Vector3()),axis=new THREE.Vector3(0,1,0).transformDirection(killer.rig.b('fork').matrixWorld);
 hand.sub(fork).addScaledVector(axis,-hand.dot(axis));assert.ok(hand.length()<.04,'right hand remains attached to the shaft');
 assert.ok(app.killerContact.shift<=.320001);assert.equal(app.killerContact.limited,false);
}));

test('an old camera cut is not replayed while the map owns the view',()=>quiet(()=>{
 const {app,flags}=fixture();let cuts=0,updates=0;app.onCut=()=>cuts++;app.rig.justCut=true;
 app.rig.update=()=>{updates++;app.rig.justCut=true;};
 for(let i=0;i<60;i++)App.prototype.tickPlay.call(app,1/60);
 assert.equal(cuts,0);assert.equal(updates,0);
 flags.map=false;App.prototype.tickPlay.call(app,1/60);
 assert.equal(updates,1);assert.equal(cuts,1,'the fresh cut still dispatches exactly once');
}));

test('closing the map resumes simulation and pose time without a catch-up jump',()=>quiet(()=>{
 const {app,sim,flags,playerFig,killer}=fixture();Object.assign(sim.killer,{state:'wait',timer:1000});
 App.prototype.tickPlay.call(app,1/60);
 for(let i=0;i<300;i++)App.prototype.tickPlay.call(app,1/60);
 assert.equal(sim.time,0);assert.equal(playerFig.animator.cur.t,0);
 flags.map=false;Object.assign(app.ui.input,{moveY:1,run:true});App.prototype.tickPlay.call(app,1/60);
 assert.ok(Math.abs(sim.time-1/60)<1e-10);assert.ok(Math.abs(playerFig.animator.cur.t-1/60)<1e-10);
 assert.ok(sim.player.z>0&&sim.player.z<.1,'movement advances only by the resumed frame');
}));

test('a blocking authored film keeps its actor animation time when no map is open',()=>quiet(()=>{
 const {app,sim,flags,playerFig,killer}=fixture();flags.map=false;app.cine.blocking=true;
 App.prototype.tickPlay.call(app,.1);
 assert.equal(sim.time,0);assert.equal(playerFig.animator.cur.t,.1);assert.equal(killer.animator.cur.t,.1);
 assert.ok(playerFig.animator.cur.phase>0);assert.ok(killer.animator.cur.phase>0);
}));


// Minimal event surfaces exercise the production keyboard handler. Rendering and
// map drawing are irrelevant to ownership and key-repeat behavior.
class InputSurface {
 constructor(){this.listeners=new Map();this.style={};this.classList={add(){},remove(){},toggle(){}};}
 addEventListener(type,fn){if(!this.listeners.has(type))this.listeners.set(type,new Set());this.listeners.get(type).add(fn);}
 removeEventListener(type,fn){this.listeners.get(type)?.delete(fn);}
 fire(type,event){for(const fn of this.listeners.get(type)||[])fn(event);}
 closest(){return null;}querySelector(){return null;}
 getBoundingClientRect(){return {left:0,top:0,width:844,height:390};}
}
test('holding M does not dismiss the map, and opening it releases held movement/action',()=>{
 const original={window:globalThis.window,document:globalThis.document},win=new InputSurface(),doc=new InputSurface(),root=new InputSurface(),game=new InputSurface(),touch=new InputSurface();
 win.innerWidth=844;win.matchMedia=()=>({matches:false});win.PointerEvent=class{};doc.pointerLockElement=null;
 globalThis.window=win;globalThis.document=doc;
 let map=false,closes=0;const input=createInputState();
 const io=bindInput(input,{uiRoot:root,touchEl:touch,gameEl:game,playing:()=>!map,blocked:()=>map,touchOn:()=>!map,mapOpen:()=>map,closeMap:()=>{map=false;closes++;}});
 const key=(type,code,repeat=false)=>win.fire(type,{code,repeat,target:game,preventDefault(){}});
 try{
  key('keydown','KeyW');key('keydown','KeyE');assert.equal(input.moveY,1);assert.equal(input.actionHeld,true);
  key('keydown','KeyM');assert.equal(input.mapPressed,true);
  // This is the same release operation called by UI.openMap.
  map=true;io.resetPointers();assert.equal(input.moveY,0);assert.equal(input.actionHeld,false);assert.equal(input.action,false);
  key('keydown','KeyW',true);key('keydown','KeyE',true);assert.equal(input.moveY,0);assert.equal(input.actionHeld,false);
  for(let i=0;i<5;i++)key('keydown','KeyM',true);
  assert.equal(map,true);assert.equal(closes,0);
  key('keyup','KeyM');key('keydown','KeyM');assert.equal(map,false);assert.equal(closes,1);
  key('keyup','KeyW');key('keyup','KeyE');assert.equal(input.moveY,0);assert.equal(input.actionHeld,false);
  key('keydown','KeyW');assert.equal(input.moveY,1,'fresh movement remains available after closing');
 }finally{io.dispose();Object.assign(globalThis,original);}
});

test('ordinary exploration alone suppresses the decorative cone while hiding and films retain beam ownership',()=>quiet(()=>{
 const {app,sim,flags}=fixture();flags.map=false;sim.player.hidden=null;app.cine.blocking=false;app.flash.showBeam=true;
 App.prototype.tickPlay.call(app,1/60);assert.equal(app.flash.showBeam,false);
 app.cine.blocking=true;app.flash.showBeam=true;App.prototype.tickPlay.call(app,1/60);assert.equal(app.flash.showBeam,true);
 app.cine.blocking=false;sim.player.hidden=sim.hides.find(h=>h.type==='closet');app.flash.showBeam=false;
 App.prototype.tickPlay.call(app,1/60);assert.equal(app.flash.showBeam,true);
 sim.player.hidden=null;App.prototype.tickPlay.call(app,1/60);assert.equal(app.flash.showBeam,false);
}));

test('showBeam changes only cone visibility and leaves the real spotlight intact',()=>{
 const flash=new Flashlight(new THREE.Scene(),{shadowSize:0}),from=new THREE.Vector3(),direction=new THREE.Vector3(0,0,1);
 flash.flick=1;flash.flickT=999;flash.showBeam=false;flash.setOn(true);flash.update(1/60,from,direction,0);
 assert.equal(flash.beam.visible,false);assert.equal(flash.light.intensity,90);
 flash.flickT=999;flash.showBeam=true;flash.update(1/60,from,direction,0);
 assert.equal(flash.beam.visible,true);assert.equal(flash.light.intensity,90);
 flash.setOn(false);flash.update(1/60,from,direction,0);
 assert.equal(flash.beam.visible,false);assert.equal(flash.light.intensity,0);
});

test('subject corridor ownership tracks the live center and disables hidden or in-car subjects',()=>quiet(()=>{
 const {app,sim,flags}=fixture();flags.map=false;
 app.world.update=noop;app.blood={update:noop};app.hanging={update:noop};app.renderer.render=noop;
 app.tickFx=noop;app.tickThunder=noop;app.cine.update=noop;app.cine.hidePlayer=false;
 sim.player.hidden=null;sim.player.inCar=false;
 App.prototype.tick.call(app,1/60);
 const p=sim.player;assert.deepEqual(GLOBALS.uSubject.value.toArray(),[p.x,p.y+1.42,p.z,1]);
 sim.player.hidden=sim.hides.find(h=>h.type==='closet');App.prototype.tick.call(app,1/60);
 assert.equal(GLOBALS.uSubject.value.w,0);
 sim.player.hidden=null;sim.player.inCar=true;App.prototype.tick.call(app,1/60);
 assert.equal(GLOBALS.uSubject.value.w,0);
}));
