// Seeded fresh nights: move only through ordinary GameSim input; never place actors or force AI.
import test from 'node:test';import assert from 'node:assert/strict';
import {GameSim} from '../src/sim/game.js';
const DT=1/30,IDLE={moveX:0,moveY:0,camYaw:0,run:false,action:false,actionHeld:false};
function play(seed,difficulty){
 const s=new GameSim({seed,difficulty}),events=[];let maxStep=0;
 const tick=(input={})=>{const k=s.killer,x=k.x,z=k.z,phase=s.phase;s.step(DT,{...IDLE,...input});if(phase==='play')maxStep=Math.max(maxStep,Math.hypot(k.x-x,k.z-z));for(const e of s.drainEvents())if(['spotted','lost','hide','evaded'].includes(e.t))events.push({event:e.t,time:+s.time.toFixed(2),seenEntering:s.player.seenEntering});};
 const until=(fn,seconds)=>{for(let n=0;n<seconds/DT&&!fn()&&s.phase!=='dead';n++)tick();return fn();};
 const route=(x,z,run)=>{const p=s.player,path=s.nav.findPath(p.x,p.z,x,z);assert.ok(path);let n=0;for(const [tx,tz]of path){while(Math.hypot(tx-p.x,tz-p.z)>.5&&s.phase!=='dead'){assert.ok(n++<90/DT,'route stalled');const it=s.findInteraction();tick({moveY:1,camYaw:Math.atan2(tx-p.x,tz-p.z),run,action:it?.kind==='door'&&!it.door.open});}}};
 assert.ok(until(()=>s.stats.seen>0,150),`${difficulty}/${seed}: first natural chase`);
 tick({flashlight:true});route(-27,-5,true);const h=s.hides.find(h=>h.id==='cabin1.closet');route(h.x,h.z,false);tick({action:true});
 assert.ok(s.player.hidden&&!s.player.seenEntering,`${difficulty}/${seed}: unseen hide`);
 assert.ok(until(()=>events.some(e=>e.event==='evaded'),100),`${difficulty}/${seed}: finite search`);
 assert.ok(s.director.relax>=20,`${difficulty}/${seed}: recovery granted`);
 assert.ok(until(()=>s.director.relax===0,65));tick({action:true,flashlight:true});route(-33,33,false);
 assert.ok(until(()=>s.stats.seen>=2,180),`${difficulty}/${seed}: natural boathouse rediscovery`);
 assert.ok(maxStep<.21,`${difficulty}/${seed}: no hunt teleport`);
 return {seed,difficulty,events,maxStep};
}
test('fresh natural encounter -> unseen hide -> recovery -> boathouse recurrence across seeds',t=>{
 const runs=[];for(const difficulty of ['normal','hard'])for(let seed=1000;seed<1006;seed++)runs.push(play(seed,difficulty));t.diagnostic(JSON.stringify(runs));
});
