import test from 'node:test';
import assert from 'node:assert/strict';
import {createInputState,bindInput} from '../src/ui/input.js';
import {createHide} from '../src/ui/hide.js';
import {App} from '../src/game/app.js';
import {audio} from '../src/audio/index.js';

class Surface {
  constructor(){this.listeners=new Map();this.dataset={};this.attrs={};this.classList={add(){},remove(){},toggle(){}};this.style={};this.children=[];}
  addEventListener(type,fn){if(!this.listeners.has(type))this.listeners.set(type,new Set());this.listeners.get(type).add(fn);}
  removeEventListener(type,fn){this.listeners.get(type)?.delete(fn);}
  emit(type,props={}){const e={target:this,button:0,preventDefault(){this.prevented=true;},...props};for(const fn of [...(this.listeners.get(type)||[])])fn(e);return e;}
  closest(selector){return selector==='[data-touch]'&&this.dataset.touch ? this : selector==='button'&&(this.dataset.touch||this.isButton) ? this : null;}
  querySelector(selector){return this.queries?.[selector]||null;}
  setAttribute(name,value){this.attrs[name]=value;}
  removeAttribute(name){delete this.attrs[name];}
  setPointerCapture(){}
  appendChild(child){this.children.push(child);child.parent=this;}
  remove(){if(this.parent)this.parent.children=this.parent.children.filter(x=>x!==this);}
  get count(){return [...this.listeners.values()].reduce((n,s)=>n+s.size,0);}
}
function fixture({dragLook=true}={}){
  const win=new Surface(),doc=new Surface(),root=new Surface(),touch=new Surface(),game=new Surface(),run=new Surface();run.dataset.touch='run';
  touch.queries={'.tbtn-run':run};win.matchMedia=()=>({matches:false});doc.pointerLockElement=null;doc.getElementById=id=>id==='game'?game:root;doc.exitPointerLock=()=>{doc.pointerLockElement=null;};
  doc.createElement=()=>new Surface();let captured=0;game.requestPointerLock=()=>{captured++;};
  globalThis.window=win;globalThis.document=doc;
  const input=createInputState(),ctx={uiRoot:root,touchEl:touch,gameEl:game,blocked:()=>false,playing:()=>true,touchOn:()=>false,dragLook};
  const io=bindInput(input,ctx);return {win,doc,root,touch,game,run,input,ctx,io,captured:()=>captured};
}

test('R latches running, held Shift composes with it; blur releases motion but leaves the RUN switch on',()=>{
  const f=fixture();f.win.emit('keydown',{code:'KeyR'});assert.equal(f.input.run,true);
  f.win.emit('keyup',{code:'KeyR'});assert.equal(f.input.run,true);
  f.win.emit('keydown',{code:'KeyR',repeat:true});assert.equal(f.input.run,true);
  f.win.emit('keydown',{code:'ShiftLeft'});f.win.emit('keydown',{code:'KeyR'});assert.equal(f.input.run,true);
  f.win.emit('keyup',{code:'ShiftLeft'});assert.equal(f.input.run,false);
  f.win.emit('keydown',{code:'KeyR'});f.win.emit('keydown',{code:'KeyW'});assert.equal(f.input.moveY,1);
  f.win.emit('blur');assert.equal(f.input.run,true);assert.equal(f.input.moveY,0);assert.equal(f.run.attrs['aria-pressed'],'true');
  // The map and a pause keep it too; a night ending or starting clears it.
  f.io.resetPointers({keepRun:true});assert.equal(f.input.run,true);
  f.io.resetPointers();assert.equal(f.input.run,false);assert.equal(f.run.attrs['aria-pressed'],'false');f.io.dispose();
});

test('desktop prompt supports one press and held search with pointer cancel and keyboard release',()=>{
  const f=fixture(),button=new Surface();button.dataset.touch='action';
  f.root.emit('pointerdown',{target:button,pointerId:1,clientX:20,clientY:40});assert.equal(f.input.action,true);assert.equal(f.input.actionHeld,true);
  f.input.action=false;f.win.emit('pointermove',{pointerId:1,clientX:21,clientY:40});assert.equal(f.input.action,false);assert.equal(f.input.actionHeld,true);
  f.win.emit('pointercancel',{target:button,pointerId:1});assert.equal(f.input.actionHeld,false);
  f.win.emit('keydown',{target:button,code:'Enter'});assert.equal(f.input.action,true);assert.equal(f.input.actionHeld,true);
  f.input.action=false;f.win.emit('keydown',{target:button,code:'Enter',repeat:true});assert.equal(f.input.action,false);
  f.win.emit('keyup',{target:button,code:'Enter'});assert.equal(f.input.actionHeld,false);f.io.dispose();
});

test('campaign desktop drag looks without pointer capture; legacy capture remains available',()=>{
  const f=fixture();f.game.emit('pointerdown',{pointerId:2,clientX:200,clientY:100});
  f.win.emit('pointermove',{pointerId:2,clientX:225,clientY:90});assert.equal(f.input.lookX,25);assert.equal(f.input.lookY,-10);
  f.win.emit('pointerup',{pointerId:2});f.game.emit('click');f.io.capture();assert.equal(f.captured(),0);f.io.dispose();
  const legacy=fixture({dragLook:false});legacy.io.capture();assert.equal(legacy.captured(),1);legacy.io.dispose();
});

test('disposing chapter input removes listeners and held actions; rebinding processes each event once',()=>{
  const f=fixture();f.win.emit('keydown',{code:'KeyE'});f.win.emit('keydown',{code:'KeyW'});
  assert.ok(f.win.count+f.doc.count+f.root.count+f.game.count>15);f.io.dispose();f.io.dispose();
  assert.equal(f.win.count+f.doc.count+f.root.count+f.game.count,0);assert.equal(f.input.actionHeld,false);assert.equal(f.input.moveY,0);
  f.win.emit('keydown',{code:'KeyW'});assert.equal(f.input.moveY,0);
  const next=createInputState(),io=bindInput(next,f.ctx);f.win.emit('keydown',{code:'KeyR'});assert.equal(next.run,true);assert.equal(f.input.run,false);io.dispose();
});

test('hide overlay disposal cancels queued drawing and removes its resize listener',()=>{
  const f=fixture();f.io.dispose();const queue=new Map();let seq=0;
  globalThis.requestAnimationFrame=fn=>{queue.set(++seq,fn);return seq;};globalThis.cancelAnimationFrame=id=>queue.delete(id);
  const hide=createHide(f.root);hide.set('closet');assert.equal(queue.size,1);assert.equal(f.win.count,1);
  hide.dispose();hide.dispose();assert.equal(queue.size,0);assert.equal(f.win.count,0);assert.equal(f.root.children.length,0);
});


test('touch fallback preserves native menu taps when gameplay is blocked',()=>{
  const f=fixture(),button=new Surface();button.isButton=true;f.ctx.blocked=()=>true;
  const tap=f.root.emit('touchstart',{target:button,changedTouches:[{identifier:1,clientX:30,clientY:50}]});
  assert.equal(tap.prevented,undefined,'native menu click must not be canceled');assert.equal(f.input.action,false);f.io.dispose();
});

test('Escape pulses once per physical press while repeats retain cleanup and default prevention',()=>{
  const f=fixture();f.doc.pointerLockElement=f.game;
  const first=f.win.emit('keydown',{code:'Escape'});
  assert.equal(first.prevented,true);assert.equal(f.input.pausePressed,true);assert.equal(f.doc.pointerLockElement,null);
  f.input.pausePressed=false;f.doc.pointerLockElement=f.game;
  const repeat=f.win.emit('keydown',{code:'Escape',repeat:true});
  assert.equal(repeat.prevented,true);assert.equal(f.input.pausePressed,false);assert.equal(f.doc.pointerLockElement,null);
  f.win.emit('keyup',{code:'Escape'});f.win.emit('keydown',{code:'Escape'});assert.equal(f.input.pausePressed,true);f.io.dispose();
});

test('grouped keyboard aliases release only their own physical code and repeats cannot retrigger actions',()=>{
  const f=fixture();
  for(const [primary,alias,property,value] of [['KeyW','ArrowUp','moveY',1],['KeyS','ArrowDown','moveY',-1],['KeyD','ArrowRight','moveX',1],['KeyA','ArrowLeft','moveX',-1]]){
    f.win.emit('keydown',{code:primary});f.win.emit('keydown',{code:alias});
    f.win.emit('keyup',{code:alias});assert.equal(f.input[property],value,primary+' remains held');
    f.win.emit('keydown',{code:primary,repeat:true});assert.equal(f.input[property],value);
    f.win.emit('keyup',{code:primary});assert.equal(f.input[property],0);
  }
  f.win.emit('keydown',{code:'KeyE'});f.win.emit('keydown',{code:'Space'});f.input.action=false;
  f.win.emit('keyup',{code:'Space'});assert.equal(f.input.actionHeld,true,'E remains held');
  f.win.emit('keydown',{code:'Space',repeat:true});assert.equal(f.input.actionHeld,true);assert.equal(f.input.action,false,'repeat is not another action press');
  f.win.emit('keyup',{code:'KeyE'});assert.equal(f.input.actionHeld,true,'repeated Space remains held');
  f.win.emit('keyup',{code:'Space'});assert.equal(f.input.actionHeld,false);
  f.win.emit('keydown',{code:'KeyE'});f.win.emit('keydown',{code:'Space'});f.win.emit('blur');assert.equal(f.input.actionHeld,false);
  f.win.emit('keyup',{code:'KeyE'});f.win.emit('keyup',{code:'Space'});assert.equal(f.input.actionHeld,false);f.io.dispose();
});

test('flashlight simulation events synchronize the touch label state',()=>{
  const app=Object.create(App.prototype),states=[],original=audio.sfx;
  app.ui={setFlashlight:on=>states.push(on)};audio.sfx=()=>{};
  try{
    app.onEvent({t:'flashlight',on:false});app.onEvent({t:'flashlight',on:true});
    assert.deepEqual(states,[false,true]);
  }finally{audio.sfx=original;}
});
