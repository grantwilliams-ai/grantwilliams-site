import test from 'node:test';
import assert from 'node:assert/strict';
import { BANK_NAMES, SFX_NAMES, synthesize } from '../src/audio/synth.js';

const surfaces = ['dirt', 'leaf', 'wood', 'gravel', 'water'];
const durations = { dirt: 0.19, leaf: 0.23, wood: 0.2, gravel: 0.22, water: 0.24 };

function measure(name) {
  const pcm = synthesize(name);
  let peak = 0, energy = 0;
  for (const sample of pcm.data) {
    assert.ok(Number.isFinite(sample), `${name} contains a non-finite sample`);
    peak = Math.max(peak, Math.abs(sample));
    energy += sample * sample;
  }
  return { ...pcm, peak, rms: Math.sqrt(energy / pcm.data.length) };
}

test('audio bank keeps its public sound names', () => {
  assert.equal(SFX_NAMES.length, 53);
  assert.equal(BANK_NAMES.length, 76);
  for (const surface of surfaces) assert.ok(SFX_NAMES.includes(`step_${surface}`));
  assert.ok(SFX_NAMES.includes('killer_step'));
  assert.ok(SFX_NAMES.includes('killer_step_wood'));
});

test('player footfalls are short, quiet, finite PCM without walk-stride overlap', () => {
  for (const surface of surfaces) {
    const pcm = measure(`step_${surface}`);
    assert.ok(Math.abs(pcm.duration - durations[surface]) <= 1 / pcm.sampleRate);
    assert.ok(Math.abs(pcm.peak - 0.42) < 0.000001, `${surface} peak was ${pcm.peak}`);
    assert.ok(pcm.rms > 0.025 && pcm.rms < 0.1, `${surface} RMS was ${pcm.rms}`);
    assert.ok(pcm.duration / 0.92 <= 0.28, `${surface} overlaps the next walk stride at the slowest rate`);
  }
});

test('nominal player event peaks are 7–10 dB below the initial draft', () => {
  const modes = {
    walk: { before: 0.5, after: 0.28 },
    run: { before: 0.85, after: 0.48 },
    sneak: { before: 0.22, after: 0.12 },
  };
  for (const surface of surfaces) {
    const { peak } = measure(`step_${surface}`);
    for (const [mode, volume] of Object.entries(modes)) {
      const changeDb = 20 * Math.log10(peak * volume.after / (0.58 * volume.before));
      assert.ok(changeDb >= -10 && changeDb <= -7, `${mode} ${surface} changed by ${changeDb} dB`);
    }
  }
});

test('killer footstep duration and levels stay at their initial-draft values', () => {
  const expectedRms = { killer_step: 0.10204050455044006, killer_step_wood: 0.104994361056126 };
  for (const [name, rms] of Object.entries(expectedRms)) {
    const pcm = measure(name);
    assert.ok(Math.abs(pcm.duration - 0.7) <= 1 / pcm.sampleRate);
    assert.ok(Math.abs(pcm.peak - 0.8) < 0.000001);
    assert.ok(Math.abs(pcm.rms - rms) < 0.000001);
  }
});
