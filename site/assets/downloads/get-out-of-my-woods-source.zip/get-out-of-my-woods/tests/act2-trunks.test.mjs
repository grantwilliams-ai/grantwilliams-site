import test from 'node:test';
import assert from 'node:assert/strict';
import {CylinderGeometry,Matrix4,Vector3,Quaternion,Box3,Mesh} from 'three';
import {trunkFootprint} from '../src/act2/trunk-colliders.js';
import {Act2Sim,clearSegment,walkable} from '../src/act2/sim.js';

test('tree blocker follows the rendered trunk base, excluding the leaning crown',()=>{
  const geometry=new CylinderGeometry(.1,.4,18,9,3);
  const matrix=new Matrix4().compose(new Vector3(10,8.8,-12),new Quaternion().setFromAxisAngle(new Vector3(0,0,1),.12),new Vector3(1,1,1));
  const blocker=trunkFootprint(geometry,matrix,'test-tree');
  const full=new Mesh(geometry);full.applyMatrix4(matrix);full.updateMatrixWorld(true);const box=new Box3().setFromObject(full);
  assert.ok(blocker.minX>box.min.x+.7,'crown must not enlarge the ground collision');
  assert.ok(blocker.maxX-blocker.minX<1.1,'base footprint must stay tight');
  assert.ok(blocker.minX>10,'leaned trunk base is displaced from its centre');
  assert.ok(blocker.height>17);
  geometry.dispose();
});

test('rendered tree blockers belong only to their chapter and stop player and killer routes',()=>{
  const geometry=new CylinderGeometry(.12,.45,15,9,3);
  const blocker=trunkFootprint(geometry,new Matrix4().makeTranslation(0,7.5,30),'test-tree');
  const s=new Act2Sim({arrivalTime:999,extraObstacles:[blocker]});
  assert.equal(walkable(0,30,.32,s.obstacles),false);
  assert.equal(clearSegment({x:0,z:28},{x:0,z:32},.42,s.obstacles),false);
  for(let i=0;i<240;i++)s.step(1/60,{moveZ:-1});
  assert.ok(s.p.z>30.7,'player must stop at the trunk');
  assert.equal(walkable(0,30,.32,new Act2Sim().obstacles),true,'no global collision leak');
  geometry.dispose();
});
