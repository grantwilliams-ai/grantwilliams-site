import test from 'node:test';
import assert from 'node:assert/strict';
import { FrameWatch } from '../src/render/frame-watch.js';
import { detectInputMode, resolveInputMode } from '../src/ui/input-mode.js';
import { controlRows, keyStrip, flashlightState, promptText } from '../src/ui/controls.js';
import { createCampaignState, cleanPreferences, CAMPAIGN_SAVE_KEY } from '../src/campaign/state.js';

// Frames at a steady real cadence; dt is what the game would pass (capped like Act I).
function cadence(watch, fps, seconds, { from = 0, cap = 0.05 } = {}) {
  const step = 1000 / fps;
  let now = from, last = null;
  for (let t = 0; t <= seconds * 1000 + 1e-6; t += step) {
    now = from + t;
    last = watch.sample(now, { dt: Math.min(cap, step / 1000) }) ?? last;
  }
  return { now, last };
}

test('B06: the frame watcher measures real time, not the capped simulation step', () => {
  const ten = new FrameWatch();
  assert.ok(Math.abs(cadence(ten, 10, 4).last - 10) < 0.6, '10 fps reads as 10, not 20');
  const five = new FrameWatch();
  const r = cadence(five, 5, 4);
  assert.ok(r.last !== null && Math.abs(r.last - 5) < 0.6, '5 fps completes a measurement within four seconds');
  const thirty = new FrameWatch();
  assert.ok(Math.abs(cadence(thirty, 30, 4).last - 30) < 1.2);
});

test('B06: paused frames and a hidden tab are not counted', () => {
  const w = new FrameWatch();
  let now = 0;
  for (let i = 0; i < 600; i++) { now += 16.7; w.sample(now, { dt: 0 }); } // 600 paused renders
  const r = cadence(w, 10, 4, { from: now + 16.7 });
  assert.ok(Math.abs(r.last - 10) < 0.6, 'after a pause the slow cadence still reads as slow, not 320');
  const h = new FrameWatch();
  assert.equal(h.sample(1000, { dt: 0.016, hidden: true }), null);
  assert.equal(h.start, null);
});

test('B06: a long gap starts a fresh sample instead of averaging it in', () => {
  const w = new FrameWatch();
  cadence(w, 60, 1);
  const before = w.frames;
  w.sample(1000 + 10_000, { dt: 0.05 }); // ten seconds later (tab was in the background)
  assert.ok(w.frames <= before && w.start === 11_000);
});

test('B04: one input policy; the primary pointer decides, and the player can override it', () => {
  const win = (coarse) => ({ matchMedia: (q) => ({ matches: q === '(pointer: coarse)' ? coarse : false }) });
  assert.equal(detectInputMode(win(false)), 'keyboard', 'a touch-screen laptop driven by a trackpad is a keyboard player');
  assert.equal(detectInputMode(win(true)), 'touch');
  assert.equal(detectInputMode({}), 'keyboard');
  assert.equal(detectInputMode({ matchMedia() { throw Error('no'); } }), 'keyboard');
  assert.equal(resolveInputMode('touch', win(false)), 'touch');
  assert.equal(resolveInputMode('keyboard', win(true)), 'keyboard');
  assert.equal(resolveInputMode('auto', win(true)), 'touch');
  assert.equal(resolveInputMode('bogus', win(false)), 'keyboard');
});

test('controls are named once: rows per chapter and mode, the key strip, flashlight state and prompts', () => {
  const k1 = controlRows(1, 'keyboard').map((r) => r.id);
  const k2 = controlRows(2, 'keyboard').map((r) => r.id);
  assert.ok(k1.includes('turn') && k2.includes('turn'), 'quick turn is taught in both chapters');
  assert.ok(!k1.includes('swing') && k2.includes('swing'));
  assert.ok(k1.includes('search') && !k2.includes('search'));
  assert.ok(!controlRows(1, 'touch').some((r) => r.id === 'turn'), 'no touch row for a control that has no button');
  assert.ok(controlRows(2, 'touch').every((r) => r.how && r.does));
  assert.match(keyStrip(1), /F flashlight.*Q turn.*M map.*Esc pause/);
  assert.match(keyStrip(2), /M bearings.*Space swing.*Esc pause/);
  assert.deepEqual(flashlightState(true), { label: 'FLASHLIGHT', state: 'ON', text: 'FLASHLIGHT: ON' });
  assert.equal(flashlightState(false).text, 'FLASHLIGHT: OFF');
  assert.equal(promptText('keyboard', 'SEARCH', { hold: true }), 'HOLD E: SEARCH');
  assert.equal(promptText('keyboard', 'Take crowbar'), 'E: Take crowbar');
  assert.equal(promptText('touch', 'SEARCH', { hold: true }), 'HOLD: SEARCH');
  assert.equal(promptText('touch', ''), '');
});

test('B03: a refused checkpoint write is reported as session-only; a stored one survives reload', () => {
  const saved = new Map();
  const ok = { getItem: (k) => saved.get(k), setItem: (k, v) => saved.set(k, v) };
  const good = createCampaignState(ok);
  assert.equal(good.reachCrash({ time: 50 }), true);
  assert.equal(good.checkpointSaved, true);
  assert.equal(createCampaignState(ok).checkpointSaved, true, 'a checkpoint read back from storage counts as saved');

  let refuse = false;
  const flaky = { getItem: (k) => saved.get(k), setItem: (k, v) => { if (refuse) throw Error('QuotaExceeded'); saved.set(k, v); } };
  saved.clear();
  const s = createCampaignState(flaky);
  s.start({ difficulty: 'hard' });
  refuse = true;
  assert.equal(s.reachCrash({ time: 61 }), false);
  assert.equal(s.canContinue(), true, 'Continue still works in this session');
  assert.equal(s.checkpointSaved, false, 'but it is not claimed as saved');
  assert.equal(s.storageAvailable, false);
  assert.equal(createCampaignState(flaky).canContinue(), false, 'a reload really has no checkpoint');

  const none = createCampaignState(undefined);
  none.reachCrash({ time: 5 });
  assert.equal(none.canContinue(), true);
  assert.equal(none.checkpointSaved, false);
});

test('loaded settings are validated by type and range; old saves gain the new choices with defaults', () => {
  const p = cleanPreferences({ brightness: 0, volume: -3, steps: '0.5', picture: 'clean', tape: 'true', flashes: 'none', inputMode: 'mouse', hints: 'no' });
  assert.equal(p.brightness, 0.4, 'a zero brightness cannot black out the game');
  assert.equal(p.volume, 0);
  assert.equal(p.steps, 0.45, 'a string is not a number');
  assert.equal(p.picture, 'sharp');
  assert.equal(p.tape, false);
  assert.equal(p.flashes, 'full');
  assert.equal(p.inputMode, 'auto');
  assert.equal(p.hints, true);
  const old = { getItem: (k) => (k === CAMPAIGN_SAVE_KEY ? JSON.stringify({ version: 1, preferences: { brightness: 1.3, picture: 'retro' }, checkpoint: 'crash', act1Time: 90 }) : null) };
  const s = createCampaignState(old);
  assert.equal(s.state.preferences.brightness, 1.3);
  assert.equal(s.state.preferences.inputMode, 'auto');
  assert.equal(s.state.preferences.hints, true);
  assert.equal(s.canContinue(), true, 'existing checkpoints still continue');
});
