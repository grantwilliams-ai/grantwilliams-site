import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { GameSim } from '../src/sim/game.js';
import { Collision } from '../src/sim/collision.js';
import { LAYOUT } from '../src/sim/layout.js';
import { KILLER } from '../src/ai/tuning.js';
import { createKiller } from '../src/characters/killer.js';
import { polishKillerAppearance } from '../src/act2/killer.js';
import { createWallClearance } from '../src/characters/wall-clearance.js';

globalThis.document={createElement:()=>({getContext:()=>({fillRect(){},beginPath(){},ellipse(){},fill(){}})})};
const axes=d=>{const ux=(d.ex-d.hx)/d.width,uz=(d.ez-d.hz)/d.width;return {nx:-uz,nz:ux};};

test('misaligned pursuit opens the real Mess Hall panel without entering it first',()=>{
  const sim=new GameSim({skipIntro:true}),door=LAYOUT.doors.find(d=>d.id==='mess.d0'),{nx,nz}=axes(door),k=sim.killer;
  Object.assign(k,{x:door.x+nx*.55,z:door.z+nz*.55,yaw:Math.atan2(nx,nz),state:'chase',path:[[door.x-nx*2,door.z-nz*2]],pathI:0});door.open=false;
  let shutFrames=0;
  for(let i=0;i<70;i++){
    sim.updateDoors(.05);
    k.follow(.05,4);
    if(!door.open){shutFrames++;assert.ok((k.x-door.x)*nx+(k.z-door.z)*nz>=KILLER.radius+.08-1e-8,'root stays outside shut panel');}
  }
  assert.ok(shutFrames>=3);assert.equal(door.open,true);assert.ok((k.x-door.x)*nx+(k.z-door.z)*nz<-.8,'pursuer still passes the opened door');
});

test('swept movement cannot tunnel a thin wall and resolves exact-centre overlap',()=>{
  const c=new Collision({trees:[],rocks:[],bushes:[]},{noCar:true});
  const wall={kind:'s',x1:150,z1:-10,x2:150,z2:10,t:.1};c._add(wall);
  const [x,z]=c.move(149,0,152,0,KILLER.radius);
  assert.ok(x<=150-KILLER.radius-.1+1e-8);assert.equal(z,0);
  const separated=c.resolve(150,0,KILLER.radius);assert.ok(Math.abs(separated[0]-150)>=KILLER.radius+.1-1e-8);
});

test('a strike cannot move or damage the counselor through a real shut panel',()=>{
  const sim=new GameSim({skipIntro:true}),door=LAYOUT.doors.find(d=>d.id==='mess.d0'),{nx,nz}=axes(door),k=sim.killer,p=sim.player;
  door.open=false;
  Object.assign(k,{x:door.x+nx*.46,z:door.z+nz*.46,yaw:Math.atan2(-nx,-nz),state:'strike',strikePhase:1,timer:0,swings:1});
  Object.assign(p,{x:door.x-nx*.9,z:door.z-nz*.9,speed:0,hidden:false,wounded:false});
  k.strike(.08);
  assert.ok((k.x-door.x)*nx+(k.z-door.z)*nz>=KILLER.radius+.08-1e-8);
  assert.equal(sim.phase,'play');assert.equal(p.wounded,false);assert.equal(door.open,false);
});

test('open cardinal and rotated doors remain navigable at the unchanged killer radius',()=>{
  for(const id of ['mess.d0','cabin1.d0','shack.d0'])for(const side of [-1,1]){
    const s=new GameSim({skipIntro:true}),d=LAYOUT.doors.find(d=>d.id===id),{nx,nz}=axes(d),k=s.killer;d.open=true;
    Object.assign(k,{x:d.x+nx*side*1.8,z:d.z+nz*side*1.8,yaw:Math.atan2(-nx*side,-nz*side),state:'chase',doorWait:0});
    assert.ok(k.setPath(d.x-nx*side*1.8,d.z-nz*side*1.8),`${id}: path`);
    for(let i=0;i<240&&k.pathI<k.path.length;i++)k.follow(1/30,3.85);
    assert.ok(((k.x-d.x)*nx+(k.z-d.z)*nz)*side<-.8,`${id} side${side}: crossed`);
  }
  assert.equal(KILLER.radius,.36);
});

const point=new THREE.Vector3();
const hand=new THREE.Vector3(),fork=new THREE.Vector3(),forkAxis=new THREE.Vector3();
function handGap(figure){
  figure.rig.b('handR').getWorldPosition(hand);figure.rig.b('fork').getWorldPosition(fork);
  forkAxis.set(0,1,0).transformDirection(figure.rig.b('fork').matrixWorld);
  hand.sub(fork).addScaledVector(forkAxis,-hand.dot(forkAxis));return hand.length();
}
function minCoordinate(figure,axis){
  let min=Infinity;
  for(const mesh of figure.meshes)for(let i=0;i<mesh.geometry.attributes.position.count;i++){
    mesh.getVertexPosition(i,point).applyMatrix4(mesh.matrixWorld);
    if(point.y>.08&&point.y<2.8)min=Math.min(min,point[axis]);
  }
  return min;
}

test('actual skinned chase and thrust gather outside opaque walls without moving the AI root',()=>{
  const figure=polishKillerAppearance(createKiller()),clearance=createWallClearance(figure);
  const collision={walls:[{x1:0,z1:-10,x2:0,z2:10}],doors:[]};
  assert.ok(clearance.probeCount<500,'bounded envelope probes');
  let worstBefore=0;
  for(const anim of ['idle','walk','chase','raise','strike','searchCloset'])for(const yaw of [0,-Math.PI/2,Math.PI]){
    figure.root.position.set(.46,0,0);figure.root.rotation.y=yaw;figure.setAnim(anim,{restart:true,fade:.001});clearance.reset();
    const root=figure.root.position.clone(),rotation=figure.root.quaternion.clone();
    for(let i=0;i<24;i++){
      figure.update(1/30,{speed:anim==='chase'?4:1.5});figure.root.updateMatrixWorld(true);figure.rig.skeleton.update();
      worstBefore=Math.min(worstBefore,minCoordinate(figure,'x'));
      const result=clearance.apply(collision,1/30);
      assert.ok(minCoordinate(figure,'x')>=.125,`${anim} yaw${yaw} frame${i}: min${minCoordinate(figure,'x')} ${JSON.stringify(result)}`);
      assert.ok(root.distanceTo(figure.root.position)<1e-9);assert.ok(rotation.angleTo(figure.root.quaternion)<1e-7);
      assert.ok(result.shift<=.320001);assert.equal(result.limited,false);
      assert.ok(handGap(figure)<.04,`${anim}: right hand remains on fork during pose blend`);
    }
  }
  assert.ok(worstBefore<-.4,'regression reproduces substantial original render penetration');
});

test('corner poses clear both faces, while impossible spaces report their bounded limit',()=>{
  const figure=polishKillerAppearance(createKiller()),clearance=createWallClearance(figure);
  const corner={walls:[{x1:0,z1:0,x2:0,z2:10},{x1:0,z1:0,x2:10,z2:0}],doors:[]};
  for(const anim of ['walk','chase','strike'])for(const yaw of [0,-Math.PI/4,-Math.PI/2,-3*Math.PI/4,Math.PI]){
    figure.root.position.set(.46,0,.46);figure.root.rotation.y=yaw;figure.setAnim(anim,{restart:true,fade:.001});clearance.reset();
    for(let i=0;i<24;i++){
      figure.update(1/30,{speed:4});const result=clearance.apply(corner,1/30);
      assert.equal(result.limited,false);assert.ok(minCoordinate(figure,'x')>=.125);assert.ok(minCoordinate(figure,'z')>=.125);
    }
  }
  const impossible={walls:[{x1:0,z1:-10,x2:0,z2:10},{x1:.5,z1:-10,x2:.5,z2:10}],doors:[]};
  figure.root.position.set(.25,0,0);figure.root.rotation.y=0;figure.setAnim('idle',{restart:true,fade:.001});figure.update(.1,{});clearance.reset();
  const result=clearance.apply(impossible);assert.equal(result.limited,true);assert.ok(result.shift<=.320001);assert.equal(figure.root.position.x,.25);
});

test('wall restraint releases away from geometry and does not close an open doorway',()=>{
  const figure=polishKillerAppearance(createKiller()),clearance=createWallClearance(figure);
  const walls={walls:[{x1:0,z1:-10,x2:0,z2:10}],doors:[]};
  figure.root.position.set(.46,0,0);figure.root.rotation.y=-Math.PI/2;figure.setAnim('strike',{fade:.001});figure.update(.18,{speed:0});
  assert.ok(clearance.apply(walls).weight>0);
  figure.root.position.set(8,0,0);let result;
  for(let i=0;i<30;i++){figure.update(1/30,{speed:0});result=clearance.apply(walls,1/30);}
  assert.deepEqual(result,{weight:0,shift:0,limited:false,nearWalls:false,nearestWallDistance:8});
  const gap={walls:[{x1:-8,z1:0,x2:-.55,z2:0},{x1:.55,z1:0,x2:8,z2:0}],doors:[]};
  figure.root.position.set(0,0,0);figure.root.rotation.y=0;figure.setAnim('standStill',{restart:true,fade:.001});figure.update(.1,{speed:0});clearance.reset();
  const door=clearance.apply(gap);assert.equal(door.limited,false);assert.ok(door.shift<=.32);
});

test('the fork goes under a door head and stays out of a closet he is checking',()=>{
  const figure=polishKillerAppearance(createKiller()),clearance=createWallClearance(figure),point=new THREE.Vector3();
  const hard=figure.meshes.find(m=>m.name==='killer-hard'),skin=hard.geometry.attributes.skinIndex;
  const fork=Array.from({length:skin.count},(_,i)=>i).filter(i=>skin.getX(i)===figure.rig.idx.fork);
  const each=fn=>{for(const i of fork){hard.getVertexPosition(i,point).applyMatrix4(hard.matrixWorld);fn(point);}};
  const start=(x,z,anim)=>{figure.root.position.set(x,0,z);figure.root.rotation.y=0;figure.setAnim('idle',{restart:true,fade:.001});figure.update(.05,{});clearance.reset();figure.setAnim(anim,{restart:true,fade:.001});};
  // A 1.1 m doorway; its head frame hangs at 2.12 m and the fork is 2.13 m long.
  const doorway={walls:[{x1:-3,z1:0,x2:-.55,z2:0},{x1:.55,z1:0,x2:3,z2:0}],doors:[{id:'test.door',open:true,width:1.1,x:0,z:0,hx:-.55,hz:0,ex:.55,ez:0}],solids:[]};
  for(const [anim,speed] of [['walk',1.5],['stalk',2.3],['chase',3.9]])for(const x of [0,.1,-.1]){
    start(x,-2.5,anim);let top=0;
    for(let i=0;i<Math.round(5/speed*60);i++){
      figure.root.position.z+=speed/60;figure.update(1/60,{speed});clearance.apply(doorway,1/60);
      each(p=>{if(Math.abs(p.z)<.115&&Math.abs(p.x)<.64)top=Math.max(top,p.y);});
    }
    assert.ok(top<2.1,`${anim} at x=${x}: fork reaches ${top.toFixed(3)} m in the doorway`);
  }
  // A closet (1.44 x 1.1 x 2.1 m) against a wall, checked from his AI stand-off.
  const closet={walls:[{x1:-3,z1:1.56,x2:3,z2:1.56}],doors:[],solids:[{x:0,z:.95,hx:.72,hz:.55,h:2.1}]};
  start(0,0,'stalk');let inside=0,result;
  for(const [anim,frames] of [['stalk',36],['searchCloset',150]]){
    figure.setAnim(anim,{});
    for(let i=0;i<frames;i++){
      figure.update(1/60,{speed:anim==='stalk'?2.3:0});result=clearance.apply(closet,1/60);
      each(p=>{if(Math.abs(p.x)<.72&&p.z>.4&&p.z<1.5&&p.y<2.1)inside=Math.max(inside,Math.min(.72-Math.abs(p.x),p.z-.4));});
    }
  }
  assert.ok(inside<.005,`fork stands ${inside.toFixed(3)} m inside the closet`);assert.equal(result.limited,false);assert.ok(result.shift<=.32+1e-9);
});
