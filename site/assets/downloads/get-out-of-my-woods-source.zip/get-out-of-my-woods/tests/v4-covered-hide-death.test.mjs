import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { GameSim } from '../src/sim/game.js';
import { BUILDINGS, TEMPLATES, LAYOUT, worldToLocal } from '../src/sim/layout.js';
import { surfaceY } from '../src/sim/terrain.js';
import { buildBuilding } from '../src/kit/buildings.js';
import { createKiller } from '../src/characters/killer.js';
import { polishKillerAppearance } from '../src/act2/killer.js';
import { createPlayer } from '../src/characters/player.js';
import { playDeath } from '../src/characters/death.js';
import { App } from '../src/game/app.js';
import { audio } from '../src/audio/index.js';
import { SFX_NAMES } from '../src/audio/synth.js';

const canvasContext = new Proxy({measureText:()=>({width:100}),createLinearGradient:()=>({addColorStop(){}}),createRadialGradient:()=>({addColorStop(){}})}, {get:(o,k)=>o[k]||(()=>{})});
globalThis.document = {createElement:()=>({getContext:()=>canvasContext})};
const ids = ['boathouse.canoe', 'outhouse1.stall', 'outhouse2.stall'];

function discovered(id, roll=0, observed=true) {
  const sim=new GameSim({skipIntro:true,seed:42}),h=sim.hides.find(h=>h.id===id),p=sim.player,k=sim.killer;
  assert.ok(h);Object.assign(p,{x:h.x,z:h.z,y:surfaceY(h.x,h.z),hidden:h,seenEntering:observed});
  Object.assign(k,{x:h.x,z:h.z,checking:h,sawHide:observed?h.id:null,state:'checkhide',timer:0,rng:()=>roll});
  k.checkHide(.05);return {sim,h,event:sim.events.find(e=>e.t==='death')};
}

function fixture(id, {aspect=16/9, rotate=0, breath=0}={}) {
  const original=LAYOUT.hides.find(h=>h.id===id),source=BUILDINGS.find(b=>b.id===original.building);
  const b={...source,rot:source.rot+rotate},h=structuredClone(original);
  const turn=(x,z)=>{const dx=x-b.x,dz=z-b.z;return [b.x+dx*Math.cos(rotate)+dz*Math.sin(rotate),b.z-dx*Math.sin(rotate)+dz*Math.cos(rotate)];};
  [h.x,h.z]=turn(h.x,h.z);[h.view.pos[0],h.view.pos[2]]=turn(h.view.pos[0],h.view.pos[2]);[h.view.look[0],h.view.look[2]]=turn(h.view.look[0],h.view.look[2]);
  // Rotation fixtures use the same rigid floor as the real building, without
  // re-running terrain shaping for a synthetic building orientation.
  const floor=surfaceY(source.x,source.z),ground=rotate?()=>floor:surfaceY;
  const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(62,aspect,.05,100),killer=polishKillerAppearance(createKiller()),player=createPlayer();
  scene.add(killer.root,player.root,camera);player.root.position.set(h.x,ground(h.x,h.z),h.z);
  camera.position.set(h.view.pos[0],ground(h.view.pos[0],h.view.pos[2])+h.view.pos[1]+breath,h.view.pos[2]);
  camera.lookAt(h.view.look[0],ground(h.view.look[0],h.view.look[2])+h.view.look[1],h.view.look[2]);
  const building=buildBuilding(b,TEMPLATES[b.template]);building.position.set(b.x,floor,b.z);building.rotation.y=b.rot;scene.add(building);scene.updateMatrixWorld(true);
  const initial={position:camera.position.clone(),direction:camera.getWorldDirection(new THREE.Vector3()),fov:camera.fov},q=camera.quaternion.clone(),events=[];
  const post=Object.fromEntries(['uRed','uTear','uFlash','uDesat','uLetterbox','uDanger','uFade'].map(k=>[k,{value:0}]));
  const ctx={scene,camera,killer,player,post,ground,at:{x:initial.position.x,y:initial.position.y,z:initial.position.z,yaw:Math.atan2(h.view.look[0]-h.view.pos[0],h.view.look[2]-h.view.pos[2])},entryView:initial,hiding:{x:h.x,z:h.z},audioCue:n=>events.push(n),onReveal:()=>events.push('reveal'),onDone:()=>events.push('done'),clearLine:()=>assert.fail('a hidden viewpoint cannot be pushed through its prop by camera clearance')};
  return {h,b,scene,camera,killer,player,building,floor,initial,q,events,ctx};
}

test('canoe and both outhouses route real hide discovery into contextual fatalities with unchanged odds',()=>{
  for(const id of ids) {
    for(const [roll,observed] of [[0,true],[1,true],[0,false],[1,false]]) {
      const {sim,h,event}=discovered(id,roll,observed),found=observed||roll<sim.killer.tune.checkHide;
      assert.equal(sim.phase==='dead',found);assert.equal(sim.player.hidden,h);
      if(found)assert.equal(event.kind,h.type);else assert.ok(sim.events.some(e=>e.t==='hidechecked'));
    }
  }
  assert.equal(discovered('cabin2.bed').event.kind,'bed');assert.equal(discovered('cabin2.closet').event.kind,'closet');
});

test('covered hide films keep the counselor concealed, camera anchored and hands on the fork at 20/60/120Hz',()=>{
  const hand=new THREE.Vector3(),fork=new THREE.Vector3(),axis=new THREE.Vector3(),point=new THREE.Vector3();
  for(const id of ids)for(const fps of [20,60,120]) {
    const f=fixture(id),at=f.player.root.position.clone(),seq=playDeath(f.h.type,f.ctx),killerAt=f.killer.root.position.clone();
    assert.ok(f.camera.position.distanceTo(f.initial.position)<1e-9);assert.ok(f.camera.quaternion.angleTo(f.q)<1e-6);
    let contactDistance=Infinity;
    for(let i=0;i<Math.ceil(seq.duration*fps)+2;i++) {
      seq.update(1/fps);assert.equal(f.player.root.visible,false);assert.ok(f.player.root.position.distanceTo(at)<1e-9);
      assert.ok(f.killer.root.position.distanceTo(killerAt)<1e-9);assert.ok(f.camera.position.distanceTo(f.initial.position)<.07);
      f.killer.rig.b('fork').getWorldPosition(fork);axis.set(0,1,0).transformDirection(f.killer.rig.b('fork').matrixWorld);
      for(const side of seq.time>=1.7?['R','L']:['R']) {
        f.killer.rig.b('hand'+side).getWorldPosition(hand);hand.sub(fork).addScaledVector(axis,-hand.dot(axis));
        assert.ok(hand.length()<.015,`${id} ${fps}Hz ${seq.time.toFixed(2)} ${side} grip ${hand.length()}`);
      }
      if(seq.time>=3.72){point.set(0,1.98,.05);f.killer.rig.b('fork').localToWorld(point);contactDistance=Math.min(contactDistance,point.distanceTo(f.initial.position));}
      if(seq.time<3.72)assert.equal(f.events.includes('reveal'),false,'cover remains until physical contact');
    }
    assert.ok(contactDistance<.065,`${id} tip must contact the hidden viewpoint`);assert.equal(seq.done,true);
    for(const event of ['reveal','fork_swing','fork_stab','done'])assert.equal(f.events.filter(e=>e===event).length,1);
    for(const event of f.events.filter(n=>!['reveal','done'].includes(n)))assert.ok(SFX_NAMES.includes(event),event+' must be a real sound cue');
    const eventCount=f.events.length;seq.update(.1);assert.equal(f.events.length,eventCount);
    seq.restore();seq.restore();assert.equal(f.player.root.visible,true);assert.equal(f.camera.children.length,0);assert.equal(f.camera.fov,62);
  }
});

test('revealed sack and strike remain in the real scenery across rotated canoe/stalls and phone framing',()=>{
  const point=new THREE.Vector3(),eye=new THREE.Vector3(),ray=new THREE.Raycaster();
  for(const id of ids)for(const rotate of [0,.9])for(const aspect of [390/844,844/390]) {
    const f=fixture(id,{aspect,rotate}),seq=playDeath(f.h.type,f.ctx);
    for(let frame=0;frame<230;frame++) {
      seq.update(1/60);
      if(frame%15===0)for(const mesh of f.killer.meshes)for(let i=0;i<mesh.geometry.attributes.position.count;i++) {
        mesh.getVertexPosition(i,point).applyMatrix4(mesh.matrixWorld);
        assert.ok(point.y>=f.ctx.ground(f.killer.root.position.x,f.killer.root.position.z)-.025,`${id} boots/body stay above floor`);
        if(f.h.type==='canoe') {
          const [x,z]=worldToLocal(f.b,point.x,point.z),ellipsoid=((x-1.15)/.5)**2+((point.y-f.floor-.22)/.28)**2+((z+2.2)/2.3)**2;
          assert.ok(ellipsoid>=.98,`${id} frame=${frame} ${mesh.name} bone=${mesh.geometry.attributes.skinIndex.getX(i)} local=${[x,point.y-f.floor,z]} must not sink into the upturned hull (${ellipsoid})`);
        } else if(mesh.geometry.attributes.skinIndex.getX(i)!==f.killer.rig.idx.fork) {
          const [,z]=worldToLocal(f.b,point.x,point.z);assert.ok(z>.85,`${id} body remains outside the stall`);
        }
      }
      if(frame===150) {
        f.camera.updateMatrixWorld(true);f.killer.rig.b('head').getWorldPosition(eye);eye.y+=.18;
        const marks=[];f.killer.rig.b('head').traverse(o=>{if(o.isMesh&&o.geometry.type==='CircleGeometry')marks.push(o);});
        if(marks.length){eye.set(0,0,0);for(const m of marks)eye.add(m.getWorldPosition(point));eye.multiplyScalar(1/marks.length);}
        ray.set(f.camera.position,point.subVectors(eye,f.camera.position).normalize());ray.far=eye.distanceTo(f.camera.position)-.01;
        assert.equal(ray.intersectObject(f.building,true).length,0,`${id} real building cannot hide the reveal`);
        point.copy(eye).project(f.camera);assert.ok(Math.abs(point.x)<.6&&Math.abs(point.y)<.6,`${id} sack remains inside narrow phone view`);
        if(f.h.type==='outhouse') {
          marks[0].getWorldPosition(point).project(f.camera);
          const x=(point.x+1)*aspect/2,y=(1-point.y)/2,r=Math.min(aspect,1)*.17,cx=aspect/2,cy=.36;
          assert.ok(Math.hypot(x-cx,y-cy)<r*.95&&Math.hypot(x-cx-r*.38,y-cy+r*.1)>r*.9,`${id} eye must show through the actual crescent mask (${point.x},${point.y})`);
        }
      }
    }
    seq.restore();
  }
});

test('restore during setup, reveal and contact cancels clocks/effects and permits a clean retry',()=>{
  for(const id of ids)for(const stop of [.1,2.5,3.9,5.5]) {
    const f=fixture(id),before=f.scene.children.length,seq=playDeath(f.h.type,f.ctx);
    for(let time=0;time<stop;time+=.05)seq.update(.05);
    const count=f.events.length;seq.restore();seq.restore();for(let i=0;i<80;i++)seq.update(.1);
    assert.equal(f.events.length,count);assert.equal(f.scene.children.length,before);assert.equal(f.camera.children.length,0);assert.equal(f.player.root.visible,true);
    const retry=playDeath(f.h.type,f.ctx);assert.equal(retry.time,0);assert.equal(retry.done,false);assert.equal(f.player.root.visible,false);retry.restore();assert.equal(f.scene.children.length,before);
  }
});

test('both canoe eyes stay inside the unchanged slit between its rim and ribs across phone sizes and entry breaths',()=>{
  const point=new THREE.Vector3();
  for(const [width,height] of [[844,390],[812,375],[932,430],[390,844],[1365,820]])for(const breath of [-.007,0,.007]) {
    const f=fixture('boathouse.canoe',{aspect:width/height,breath}),seq=playDeath('canoe',f.ctx),eyes=[];
    f.killer.rig.b('head').traverse(o=>{if(o.isMesh&&o.geometry.type==='CircleGeometry')eyes.push(o);});
    for(let frame=0;frame<205;frame++) {
      seq.update(1/60);if(seq.time<2||frame%6!==0)continue;
      f.camera.updateMatrixWorld(true);
      for(const eye of eyes) {
        eye.getWorldPosition(point).project(f.camera);
        const x=(point.x+1)*width/2,y=(1-point.y)*height/2,rx=width*.46,ry=Math.max(7,height*.028);
        // The painted ellipse has a16px rim. A 1px margin protects the glint
        // against rasterization; checking only the ellipse would miss the bug.
        const gap=ry*Math.sqrt(Math.max(0,1-((x-width/2)/rx)**2))-8;
        assert.ok(Math.abs(y-height/2)<gap-1,`${width}x${height} breath=${breath} time=${seq.time.toFixed(2)} eye=${x},${y} slit half-gap=${gap}`);
        for(const rib of [-.55,-.25,.25,.55])assert.ok(Math.abs(x-(width/2+rx*rib*(1-.3*y/height)))>5,'eye remains outside the painted 8px hull ribs');
      }
    }
    seq.restore();
  }
});

test('established bed and closet contact/completion clocks remain unchanged',()=>{
  for(const [id,kind,hit,duration] of [['cabin2.bed','bed',3.72,5.4],['cabin2.closet','closet',4.7,5.6]]) {
    const f=fixture(id),cues=[];let seq;
    f.ctx.clearLine=()=>1;f.ctx.audioCue=name=>cues.push({name,time:seq?.time||0});
    seq=playDeath(kind,f.ctx);assert.equal(seq.duration,duration);
    while(!seq.done)seq.update(.01);
    const stab=cues.filter(c=>c.name==='fork_stab');assert.equal(stab.length,1);assert.ok(Math.abs(stab[0].time-hit)<.011);
    assert.ok(Math.abs(seq.time-duration)<.011);seq.restore();
  }
});

test('App retains each hide overlay until contact and pause/resume never advances or resurrects it',()=>{
  const old=Object.fromEntries(['music','sfx','pauseAll','resumeAll'].map(k=>[k,audio[k]]));Object.assign(audio,{music(){},sfx(){},pauseAll(){},resumeAll(){}});
  try {for(const id of ids) {
    const {sim,h,event}=discovered(id),f=fixture(id),calls=[],app=Object.create(App.prototype);
    const ui=new Proxy({setHide:x=>calls.push(['hide',x]),setPrompt:x=>calls.push(['prompt',x]),setTouchVisible:x=>calls.push(['touch',x])},{get:(o,k)=>o[k]||(()=>{})});
    Object.assign(app,{state:'play',sim,scene:f.scene,mainScene:f.scene,camera:f.camera,killer:f.killer,playerFig:f.player,post:f.ctx.post,ui,cine:{clear(){},blocking:false},rig:{zone:{}},quality:{isTouch:false},world:{clearStage:()=>assert.fail('hidden deaths must not remove surrounding scenery')},flash:{setOn(){},aim:new THREE.Vector3(),update(){}},from:new THREE.Vector3(),aim:new THREE.Vector3(),gameOver:()=>calls.push(['done'])});
    app.onDeath(event);assert.equal(app.deathSeq.kind,h.type);assert.equal(app.playerFig.root.visible,false);assert.deepEqual(calls[0],['hide',h.type]);
    for(let i=0;i<25;i++)app.tickDead(.1);const time=app.deathSeq.time;app.pause();assert.equal(app.state,'paused');assert.equal(app.deathSeq.time,time);app.resume();assert.equal(app.state,'dead');assert.equal(app.deathHide,h.type);assert.equal(app.deathSeq.time,time);
    for(let i=0;i<13;i++)app.tickDead(.1);assert.equal(app.deathHide,null);app.pause();app.resume();assert.equal(app.state,'dead');assert.equal(app.deathHide,null);
    assert.equal(calls.some(c=>c[0]==='touch'&&c[1]),false);app.deathSeq.restore();assert.equal(sim.player.hidden,h);assert.equal(calls.some(c=>c[0]==='done'),false);
  }}finally{Object.assign(audio,old);}
});
