import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { createPlayer, createVictim } from '../src/characters/player.js';
import { finishCounselorAppearance } from '../src/characters/player-appearance.js';

globalThis.document={createElement:()=>({getContext:()=>new Proxy({},{get:(o,k)=>o[k]||(()=>{})})})};

test('counselor finish retains the rig, flashlight, variants and small shared draw budget',()=>{
  const f=createPlayer(),[cloth,hard,staff,wound]=f.meshes;
  assert.deepEqual(f.rig.at[f.rig.idx.head],[0,1.45,0]);
  assert.deepEqual(f.rig.at[f.rig.idx.handR],[-.2,.84,0]);
  assert.deepEqual(f.flashlightAnchor.position.toArray(),[0,-.27,0]);
  assert.equal(f.height,1.72);assert.equal(f.drawCalls,5);assert.ok(f.triangles()<=2550);
  assert.equal(wound.material,cloth.material);assert.equal(wound.visible,false);
  f.setWounded(true);assert.equal(wound.visible,true);f.setWounded(false);
  f.setFlashlight(false);for(let i=0;i<60;i++)f.update(1/60,{});
  assert.ok(f.rig.b('handR').children.filter(c=>c.isMesh).every(c=>!c.visible));
  for(const name of ['idle','walk','run','sneak','winded','hang','impaled'])assert.ok(f.has(name),name);
  assert.ok(staff.material.transparent&&staff.material.map,'original STAFF print retained');
  for(let i=0;i<hard.geometry.attributes.skinWeight.count;i++)assert.equal(hard.geometry.attributes.skinWeight.getX(i),1,'hands, face, shoes and torch keep rigid authored attachments');
  const victim=createVictim();assert.equal(victim.anim,'hang');assert.equal(victim._light,false);assert.equal(victim.hideLens,true);
  assert.ok(victim.meshes[1].geometry.attributes.position.count!==hard.geometry.attributes.position.count,'staff victim keeps its distinct face and hair variant');
});

test('jacket, sleeves and trousers bend across garment joins without invalid skin weights',()=>{
  const f=createPlayer(),g=f.meshes[0].geometry,si=g.attributes.skinIndex,sw=g.attributes.skinWeight;
  for(const [a,b] of [['spine','chest'],['chest','head'],['chest','uarmL'],['chest','uarmR'],['uarmL','farmL'],['uarmR','farmR'],['thighL','shinL'],['thighR','shinR']]){
    let count=0;for(let i=0;i<si.count;i++)if(si.getX(i)===f.rig.idx[a]&&si.getY(i)===f.rig.idx[b]&&sw.getX(i)>.001&&sw.getY(i)>.001)count++;
    assert.ok(count>=12,`${a}/${b} cloth shares the bend`);
  }
  for(const mesh of f.meshes){const g=mesh.geometry,w=g.attributes.skinWeight,n=g.attributes.normal;
    for(let i=0;i<w.count;i++){
      const weights=[w.getX(i),w.getY(i),w.getZ(i),w.getW(i)];
      assert.ok(weights.every(v=>v>=0&&v<=1)&&Math.abs(weights.reduce((a,b)=>a+b,0)-1)<1e-6);
      assert.ok(Math.abs(Math.hypot(n.getX(i),n.getY(i),n.getZ(i))-1)<1e-5,'surface normals stay valid');
    }
  }
  const geo=Object.fromEntries(['cloth','hard','decal','wound'].map((name,i)=>[name,f.meshes[i].geometry]));
  const before=f.meshes.map(m=>Object.fromEntries(Object.entries(m.geometry.attributes).map(([name,a])=>[name,a.array.slice()])));
  finishCounselorAppearance(geo,f.rig);
  for(let i=0;i<f.meshes.length;i++)for(const [name,values] of Object.entries(before[i]))assert.deepEqual(f.meshes[i].geometry.attributes[name].array,values,'shared finish is idempotent');
});

test('STAFF print and shoulder graze remain on the bending jacket',()=>{
  const point=new THREE.Vector3(),nearest=new THREE.Vector3();
  for(const animation of ['idle','run','sneak','winded']){
    const f=createPlayer();f.setAnim(animation,{restart:true,fade:.001});
    for(let frame=0;frame<12;frame++){
      f.update(.06,{speed:animation==='run'?4.5:1});f.root.updateWorldMatrix(true,true);f.rig.skeleton.update();
      const cloth=f.meshes[0],points=Array.from({length:cloth.geometry.attributes.position.count},(_,i)=>cloth.getVertexPosition(i,new THREE.Vector3())),triangles=[];
      for(let i=0;i<points.length;i+=3)triangles.push(new THREE.Triangle(points[i],points[i+1],points[i+2]));
      for(const [mesh,limit] of [[f.meshes[2],.013],[f.meshes[3],.025]])for(let i=0;i<mesh.geometry.attributes.position.count;i++){
        mesh.getVertexPosition(i,point);let distance=Infinity;
        for(const t of triangles)distance=Math.min(distance,t.closestPointToPoint(point,nearest).distanceTo(point));
        assert.ok(distance<limit,`${animation} garment detail stays attached: ${distance}`);
      }
    }
  }
});

test('cosmetic changes stay inside the previous animated counselor envelope',()=>{
  // Preview03B all-mesh measurements, 90 frames per pose. No hitbox, authored
  // pose, driver contact or flashlight position changes are needed for this art.
  const cases=[
    ['idle',0,[-.291655,-.000986,-.166358],[.318933,1.755568,.831276]],
    ['walk',1.9,[-.404211,-.021075,-.630857],[.330943,1.619339,.848877]],
    ['run',4.5,[-.548303,-.024282,-.710999],[.346223,1.589073,.925299]],
    ['sneak',1,[-.344894,-.020642,-.484535],[.308676,1.569301,.866293]],
    ['winded',0,[-.396769,.133793,-.491991],[.353794,1.293195,.615619]],
  ];
  const p=new THREE.Vector3();
  for(const [animation,speed,min,max] of cases){const f=createPlayer();f.setAnim(animation,{restart:true,fade:.001});
    for(let frame=0;frame<90;frame++){
      f.update(1/60,{speed});f.root.updateWorldMatrix(true,true);f.rig.skeleton.update();
      for(const mesh of f.meshes)for(let i=0;i<mesh.geometry.attributes.position.count;i++){
        mesh.getVertexPosition(i,p);for(let axis=0;axis<3;axis++)assert.ok(p.getComponent(axis)>=min[axis]-1e-6&&p.getComponent(axis)<=max[axis]+1e-6,`${animation} stays in the existing render envelope`);
      }
    }
  }
});
