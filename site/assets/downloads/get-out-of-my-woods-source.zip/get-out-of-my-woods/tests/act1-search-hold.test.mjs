import test from 'node:test';
import assert from 'node:assert/strict';
import { GameSim } from '../src/sim/game.js';
import { CAR } from '../src/sim/layout.js';

function place(sim, x, z) {
  Object.assign(sim.player, { x, z, vx: 0, vz: 0, hidden: null, vaultT: 0 });
}

test('sliding between neighbouring containers resets progress and starts a new search and noise', () => {
  const sim = new GameSim({ skipIntro: true, seed: 91 });
  const bench = GameSim.searchSpots().find((spot) => spot.id === 'shed-bench');
  const toolbox = GameSim.searchSpots().find((spot) => spot.id === 'shed-toolbox');
  const noises = [];
  sim.noise = (...args) => noises.push(args);

  place(sim, bench.wx + (toolbox.wx - bench.wx) * 0.4, bench.wz + (toolbox.wz - bench.wz) * 0.4);
  assert.equal(sim.findInteraction()?.spot?.id, bench.id);
  sim.updateInteraction(0.6, { actionHeld: true });
  assert.equal(sim.holdT, 0.6);
  assert.deepEqual(sim.drainEvents().map((event) => event.t), ['searchStart']);

  place(sim, bench.wx + (toolbox.wx - bench.wx) * 0.5, bench.wz + (toolbox.wz - bench.wz) * 0.5);
  assert.equal(sim.findInteraction()?.spot?.id, toolbox.id);
  sim.updateInteraction(0.1, { actionHeld: true });
  assert.ok(Math.abs(sim.holdT - 0.1) < 1e-9, 'new target starts from zero');
  assert.deepEqual(sim.drainEvents().map((event) => event.t), ['searchStart']);
  assert.equal(sim.searched.has(bench.id), false);
  assert.equal(sim.searched.has(toolbox.id), false);

  sim.updateInteraction(0.9, { actionHeld: true });
  assert.equal(sim.searched.has(toolbox.id), true, 'second search takes its full duration');
  assert.equal(sim.searched.has(bench.id), false);
  assert.equal(noises.length, 2, 'each container makes its own rummage noise');
});

test('releasing E resets the same target, and the hood battery has its own hold identity', () => {
  const sim = new GameSim({ skipIntro: true, seed: 91 });
  const spot = GameSim.searchSpots()[0];
  place(sim, spot.wx, spot.wz);
  sim.noise = () => {};

  sim.updateInteraction(0.6, { actionHeld: true });
  sim.updateInteraction(0.2, { actionHeld: false });
  assert.equal(sim.holdT, 0);
  assert.equal(sim.holdTarget, null);
  sim.updateInteraction(0.2, { actionHeld: true });
  assert.equal(sim.holdT, 0.2);
  assert.deepEqual(sim.drainEvents().map((event) => event.t), ['searchStart', 'searchStart']);

  sim.has.battery = true;
  place(sim, CAR.hood.x, CAR.hood.z);
  sim.updateInteraction(0.2, { actionHeld: true });
  assert.equal(sim.holdT, 0.2);
  assert.equal(sim.holdTarget, 'battery:hood');
  assert.deepEqual(sim.drainEvents().map((event) => event.t), ['batteryStart']);
});

test('a container can be searched from the first second of the night, and searching starts the hunt', () => {
  for (const difficulty of ['easy', 'normal', 'hard']) {
    for (const spot of GameSim.searchSpots()) {
      const sim = new GameSim({ difficulty, seed: 91 });
      assert.equal(sim.phase, 'intro');
      place(sim, spot.wx, spot.wz);
      const idle = { moveX: 0, moveY: 0, camYaw: 0, run: false, sneak: false, action: false, actionHeld: false, flashlight: false };
      sim.step(1 / 60, idle);
      assert.equal(sim.phase, 'intro', `${difficulty} ${spot.id}: standing by a container does not end the opening`);
      assert.equal(sim.findInteraction()?.kind, 'search', `${difficulty} ${spot.id}: SEARCH is offered during the opening`);
      assert.equal(sim.findInteraction().spot.id, spot.id);
      sim.drainEvents();
      for (let f = 0; f < 70 && !sim.searched.has(spot.id); f++) sim.step(1 / 60, { ...idle, actionHeld: true });
      assert.equal(sim.searched.has(spot.id), true, `${difficulty} ${spot.id}: the search finishes`);
      assert.equal(sim.phase, 'play', `${difficulty} ${spot.id}: the hunt has started`);
      const events = sim.drainEvents().map((event) => event.t);
      assert.ok(events.indexOf('huntStarted') >= 0 && events.indexOf('huntStarted') < events.indexOf('searchStart'), 'the hunt starts as the search does');
      assert.equal(events.filter((t) => t === 'huntStarted').length, 1);
      assert.notEqual(sim.killer.state, 'lurk');
    }
  }
});
