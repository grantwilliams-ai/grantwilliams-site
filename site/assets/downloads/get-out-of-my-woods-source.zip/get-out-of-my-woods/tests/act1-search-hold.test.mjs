import test from 'node:test';
import assert from 'node:assert/strict';
import { GameSim } from '../src/sim/game.js';
import { CAR } from '../src/sim/layout.js';

function place(sim, x, z) {
  Object.assign(sim.player, { x, z, vx: 0, vz: 0, hidden: null, vaultT: 0 });
}

test('sliding between neighbouring containers resets progress and starts a new search and noise', () => {
  const sim = new GameSim({ skipIntro: true, seed: 91 });
  const bench = GameSim.searchSpots().find((spot) => spot.id === 'shed-bench');
  const toolbox = GameSim.searchSpots().find((spot) => spot.id === 'shed-toolbox');
  const noises = [];
  sim.noise = (...args) => noises.push(args);

  place(sim, bench.wx + (toolbox.wx - bench.wx) * 0.4, bench.wz + (toolbox.wz - bench.wz) * 0.4);
  assert.equal(sim.findInteraction()?.spot?.id, bench.id);
  sim.updateInteraction(0.6, { actionHeld: true });
  assert.equal(sim.holdT, 0.6);
  assert.deepEqual(sim.drainEvents().map((event) => event.t), ['searchStart']);

  place(sim, bench.wx + (toolbox.wx - bench.wx) * 0.5, bench.wz + (toolbox.wz - bench.wz) * 0.5);
  assert.equal(sim.findInteraction()?.spot?.id, toolbox.id);
  sim.updateInteraction(0.1, { actionHeld: true });
  assert.ok(Math.abs(sim.holdT - 0.1) < 1e-9, 'new target starts from zero');
  assert.deepEqual(sim.drainEvents().map((event) => event.t), ['searchStart']);
  assert.equal(sim.searched.has(bench.id), false);
  assert.equal(sim.searched.has(toolbox.id), false);

  sim.updateInteraction(0.9, { actionHeld: true });
  assert.equal(sim.searched.has(toolbox.id), true, 'second search takes its full duration');
  assert.equal(sim.searched.has(bench.id), false);
  assert.equal(noises.length, 2, 'each container makes its own rummage noise');
});

test('releasing E resets the same target, and the hood battery has its own hold identity', () => {
  const sim = new GameSim({ skipIntro: true, seed: 91 });
  const spot = GameSim.searchSpots()[0];
  place(sim, spot.wx, spot.wz);
  sim.noise = () => {};

  sim.updateInteraction(0.6, { actionHeld: true });
  sim.updateInteraction(0.2, { actionHeld: false });
  assert.equal(sim.holdT, 0);
  assert.equal(sim.holdTarget, null);
  sim.updateInteraction(0.2, { actionHeld: true });
  assert.equal(sim.holdT, 0.2);
  assert.deepEqual(sim.drainEvents().map((event) => event.t), ['searchStart', 'searchStart']);

  sim.has.battery = true;
  place(sim, CAR.hood.x, CAR.hood.z);
  sim.updateInteraction(0.2, { actionHeld: true });
  assert.equal(sim.holdT, 0.2);
  assert.equal(sim.holdTarget, 'battery:hood');
  assert.deepEqual(sim.drainEvents().map((event) => event.t), ['batteryStart']);
});
