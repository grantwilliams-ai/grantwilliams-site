import test from 'node:test';
import assert from 'node:assert/strict';
import { GameSim } from '../src/sim/game.js';
import { CAR } from '../src/sim/layout.js';
import { CAR_REVEAL_LINE, HUNT_LINE } from '../src/game/compass-target.js';

function place(sim, x, z) {
  Object.assign(sim.player, { x, z, vx: 0, vz: 0, hidden: null, vaultT: 0 });
}

test('sliding between neighbouring containers resets progress and starts a new search and noise', () => {
  const sim = new GameSim({ skipIntro: true, seed: 91 });
  const bench = GameSim.searchSpots().find((spot) => spot.id === 'shed-bench');
  const toolbox = GameSim.searchSpots().find((spot) => spot.id === 'shed-toolbox');
  const noises = [];
  sim.noise = (...args) => noises.push(args);

  place(sim, bench.wx + (toolbox.wx - bench.wx) * 0.4, bench.wz + (toolbox.wz - bench.wz) * 0.4);
  assert.equal(sim.findInteraction()?.spot?.id, bench.id);
  sim.updateInteraction(0.6, { actionHeld: true });
  assert.equal(sim.holdT, 0.6);
  assert.deepEqual(sim.drainEvents().map((event) => event.t), ['searchStart']);

  place(sim, bench.wx + (toolbox.wx - bench.wx) * 0.5, bench.wz + (toolbox.wz - bench.wz) * 0.5);
  assert.equal(sim.findInteraction()?.spot?.id, toolbox.id);
  sim.updateInteraction(0.1, { actionHeld: true });
  assert.ok(Math.abs(sim.holdT - 0.1) < 1e-9, 'new target starts from zero');
  assert.deepEqual(sim.drainEvents().map((event) => event.t), ['searchStart']);
  assert.equal(sim.searched.has(bench.id), false);
  assert.equal(sim.searched.has(toolbox.id), false);

  sim.updateInteraction(0.9, { actionHeld: true });
  assert.equal(sim.searched.has(toolbox.id), true, 'second search takes its full duration');
  assert.equal(sim.searched.has(bench.id), false);
  assert.equal(noises.length, 2, 'each container makes its own rummage noise');
});

test('releasing E resets the same target, and the hood battery has its own hold identity', () => {
  const sim = new GameSim({ skipIntro: true, seed: 91 });
  const spot = GameSim.searchSpots()[0];
  place(sim, spot.wx, spot.wz);
  sim.noise = () => {};

  sim.updateInteraction(0.6, { actionHeld: true });
  sim.updateInteraction(0.2, { actionHeld: false });
  assert.equal(sim.holdT, 0);
  assert.equal(sim.holdTarget, null);
  sim.updateInteraction(0.2, { actionHeld: true });
  assert.equal(sim.holdT, 0.2);
  assert.deepEqual(sim.drainEvents().map((event) => event.t), ['searchStart', 'searchStart']);

  sim.has.battery = true;
  place(sim, CAR.hood.x, CAR.hood.z);
  sim.updateInteraction(0.2, { actionHeld: true });
  assert.equal(sim.holdT, 0.2);
  assert.equal(sim.holdTarget, 'battery:hood');
  assert.deepEqual(sim.drainEvents().map((event) => event.t), ['batteryStart']);
});

const IDLE = { moveX: 0, moveY: 0, camYaw: 0, run: false, sneak: false, action: false, actionHeld: false, flashlight: false };

test('a container can be searched from the first second of the night, and the opening carries on', () => {
  for (const difficulty of ['easy', 'normal', 'hard']) {
    for (const spot of GameSim.searchSpots()) {
      const sim = new GameSim({ difficulty, seed: 91 });
      assert.equal(sim.phase, 'intro');
      place(sim, spot.wx, spot.wz);
      sim.step(1 / 60, IDLE);
      assert.equal(sim.findInteraction()?.kind, 'search', `${difficulty} ${spot.id}: SEARCH is offered during the opening`);
      assert.equal(sim.findInteraction().spot.id, spot.id);
      sim.drainEvents();
      for (let f = 0; f < 70 && !sim.searched.has(spot.id); f++) sim.step(1 / 60, { ...IDLE, actionHeld: true });
      assert.equal(sim.searched.has(spot.id), true, `${difficulty} ${spot.id}: the search finishes`);
      const events = sim.drainEvents().map((event) => event.t);
      assert.ok(events.includes('searchStart'));
      assert.ok(events.includes('found') || events.includes('nothing'));
      assert.equal(events.includes('huntStarted'), false, `${difficulty} ${spot.id}: a search does not start the hunt`);
      assert.equal(sim.phase, 'intro', `${difficulty} ${spot.id}: the opening carries on`);
      assert.equal(sim.killer.state, 'lurk', `${difficulty} ${spot.id}: he has not started walking`);
    }
  }
});

test('searching during the opening does not bring the hunt forward by a single frame', () => {
  const spot = GameSim.searchSpots().find((s) => s.id === 'c1-locker');
  for (const difficulty of ['easy', 'normal', 'hard']) {
    const run = (search) => {
      const sim = new GameSim({ difficulty, seed: 91 });
      place(sim, spot.wx, spot.wz);
      let frame = 0;
      for (; frame < 200 * 60 && sim.phase === 'intro'; frame++) {
        sim.step(1 / 60, { ...IDLE, actionHeld: search && frame >= 300 && frame < 400 });
      }
      return { frame, time: sim.time, phase: sim.phase, kx: sim.killer.x, kz: sim.killer.z, kstate: sim.killer.state, searched: sim.searched.size };
    };
    const quiet = run(false), searched = run(true);
    assert.equal(searched.searched, 1);
    assert.equal(quiet.searched, 0);
    assert.equal(quiet.phase, 'play');
    assert.equal(Math.round(quiet.time), sim_grace(difficulty), `${difficulty}: the opening lasts its grace period`);
    assert.deepEqual({ ...searched, searched: 0 }, quiet, `${difficulty}: the hunt starts at the same frame, with him in the same place`);
  }
});

function sim_grace(difficulty) {
  return new GameSim({ difficulty, seed: 91 }).tune.introGrace;
}

test('empty searches in the opening do not spend the body scare: it falls at the next empty search of the hunt', () => {
  const sim = new GameSim({ difficulty: 'normal', seed: 91 });
  const empty = GameSim.searchSpots().filter((s) => s.building && s.id !== sim.items.keys && s.id !== sim.items.battery);
  assert.ok(empty.length >= sim.dropAfter + 1);
  for (const spot of empty.slice(0, sim.dropAfter)) {
    place(sim, spot.wx, spot.wz);
    for (let f = 0; f < 70 && !sim.searched.has(spot.id); f++) sim.step(1 / 60, { ...IDLE, actionHeld: true });
    assert.equal(sim.searched.has(spot.id), true);
  }
  assert.equal(sim.phase, 'intro');
  assert.equal(sim.dropped, false, 'not armed during the opening');
  sim.beginHunt({ fromHere: true });
  const next = empty[sim.dropAfter];
  place(sim, next.wx, next.wz);
  sim.drainEvents();
  for (let f = 0; f < 70 && !sim.searched.has(next.id); f++) sim.step(1 / 60, { ...IDLE, actionHeld: true });
  assert.equal(sim.dropped, true, 'armed by the first empty search of the hunt');
  assert.equal(sim.dropSpot.id, next.id, 'and it falls where she is standing');
});

test('the lines that close the opening name only what is still missing', () => {
  const s = (keys, battery) => ({ has: { keys, battery }, batteryIn: false });
  assert.equal(HUNT_LINE(s(false, false)), 'You are not alone. Find your keys and a battery. Get out.');
  assert.equal(CAR_REVEAL_LINE(s(false, false)), 'Somebody took your battery and your keys. Find them. Get out.');
  assert.equal(HUNT_LINE(s(true, false)), 'You are not alone. Find a battery. Get out.');
  assert.equal(CAR_REVEAL_LINE(s(true, false)), 'Somebody took your battery. Find it. Get out.');
  assert.equal(HUNT_LINE(s(false, true)), 'You are not alone. Find your keys. Get out.');
  assert.equal(CAR_REVEAL_LINE(s(false, true)), 'Somebody took your keys. Find them. Get out.');
  assert.equal(HUNT_LINE(s(true, true)), 'You are not alone. Get to your car. Get out.');
  assert.equal(CAR_REVEAL_LINE(s(true, true)), 'Somebody has been at your car. Put the battery in. Get out.');
});
