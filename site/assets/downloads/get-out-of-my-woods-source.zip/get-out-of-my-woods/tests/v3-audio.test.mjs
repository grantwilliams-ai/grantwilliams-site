import test from 'node:test';
import assert from 'node:assert/strict';
import { synthesize } from '../src/audio/synth.js';

test('footstep variants have distinct natural grains and bounded peaks', () => {
  for (const surface of ['dirt', 'leaf', 'wood', 'gravel', 'water']) {
    const waves = Array.from({length: 4}, (_, i) => synthesize('step_' + surface, 22050, i).data);
    for (let i=1; i<4; i++) {
      assert.notDeepEqual(waves[i], waves[i-1]);
      assert.equal(waves[i].length, waves[0].length);
      assert.ok(waves[i].every(v => Number.isFinite(v) && Math.abs(v) <= 0.420001));
    }
  }
});
test('footstep variant selection leaves threatening sounds identical', () => {
  for (const name of ['killer_step', 'killer_step_wood', 'fork_ting'])
    assert.deepEqual(synthesize(name, 22050, 3).data, synthesize(name).data);
});
