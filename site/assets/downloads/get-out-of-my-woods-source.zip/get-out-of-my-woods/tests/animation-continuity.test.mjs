import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {createPlayer} from '../src/characters/player.js';
import {createKiller} from '../src/characters/killer.js';
import {createAct2Killer,polishKillerAppearance} from '../src/act2/killer.js';
import {Pose} from '../src/characters/rig.js';

globalThis.document={createElement:()=>({getContext:()=>new Proxy({},{get:(o,k)=>o[k]||(()=>{})})})};
const factories=[['counselor',createPlayer,['idle','run','walk']],['Act I Sackhead',()=>polishKillerAppearance(createKiller()),['walk','chase','raise']],['Act II Sackhead',()=>createAct2Killer().figure,['idle','walk','chase']]];
function world(f){f.root.updateMatrixWorld(true);return f.rig.bones.map(b=>({p:b.getWorldPosition(new THREE.Vector3()),q:b.getWorldQuaternion(new THREE.Quaternion())}));}
function closeBones(f,before){const after=world(f);after.forEach((b,i)=>{assert.ok(b.p.distanceTo(before[i].p)<1e-8,`${f.rig.names[i]} did not jump`);assert.ok(b.q.angleTo(before[i].q)<1e-7,`${f.rig.names[i]} did not snap`);});}
function prepare(factory,sequence){const f=factory();f.root.position.set(3,0,-2);f.root.rotation.y=.7;f.setAnim(sequence[0],{restart:true,fade:.001});f.update(.4,{speed:2});f.setAnim(sequence[1],{fade:.3});f.update(.04,{speed:2});return f;}

for(const [name,factory,seq] of factories)test(`${name}: interrupted fade begins at the actual base pose, including grips`,()=>{
 const f=prepare(factory,seq),before=world(f),pose=f.animator.appliedPose.a.slice(),phase=f.animator.cur.phase;
 f.setAnim(seq[2],{fade:.25});f.update(0,{speed:2});closeBones(f,before);assert.deepEqual(f.animator.appliedPose.a,pose);assert.equal(f.animator.cur.phase,phase);assert.equal(f.animator.cur.t,0);
 // A pause during the new blend cannot advance clock/phase/pose or rerun the snap.
 f.update(.05,{speed:2});const paused=world(f),time=f.animator.cur.t,ph=f.animator.cur.phase;
 for(let i=0;i<3;i++)f.update(0,{speed:2});closeBones(f,paused);assert.equal(f.animator.cur.t,time);assert.equal(f.animator.cur.phase,ph);
});

test('several state changes between frames retain the last evaluated pose',()=>{
 const f=prepare(createKiller,['walk','chase']),before=world(f),breath=f.animator.extra.breath,morph=f.meshes[2].morphTargetInfluences[0];
 f.setAnim('raise',{fade:.2});f.setAnim('idle',{fade:.3});f.setAnim('listen',{fade:.4});f.update(0,{speed:0});
 closeBones(f,before);assert.equal(f.animator.extra.breath,breath);assert.equal(f.meshes[2].morphTargetInfluences[0],morph);
});

test('external contact presentation cannot contaminate the next base-pose transition',()=>{
 const f=prepare(createKiller,['walk','chase']),before=world(f),base=f.animator.appliedPose.a.slice();
 const contact=new Pose(f.rig.idx,f.rig.bones.length).copy(f.animator.appliedPose);contact.a[0]+=.2;contact.a[1]-=.13;contact.rot('head',.8,.4,.3);
 f.animator.apply(contact,0,{});assert.ok(world(f)[0].p.distanceTo(before[0].p)>.1);
 f.setAnim('raise',{fade:.25});f.update(0,{speed:2});closeBones(f,before);assert.deepEqual(f.animator.appliedPose.a,base);
});

test('sack breathing blends without a zero-time pop while live light/aim inputs remain live',()=>{
 const f=prepare(createKiller,['walk','chase']),breath=f.animator.extra.breath,morph=f.meshes[2].morphTargetInfluences[0];
 assert.ok(breath>.5&&breath<.9,'ordinary fading interpolates its declared breath output');
 f.setAnim('raise',{fade:.25});f.update(0,{speed:2});assert.equal(f.animator.extra.breath,breath);assert.equal(f.meshes[2].morphTargetInfluences[0],morph);
 f.update(.125,{speed:2});assert.ok(f.animator.extra.breath>breath&&f.animator.extra.breath<1);f.update(.125,{speed:2});assert.equal(f.animator.extra.breath,1);
 const p=prepare(createPlayer,['idle','run']);p.setAnim('walk',{fade:.3});p.setFlashlight(false);p.update(.05,{speed:2,aim:.3});assert.ok(p.animator.extra.light<1);assert.equal(p.animator.extra.aim,.3);
});

test('both chapter render adapters converge at 20/60/120 Hz without changing authored clocks',()=>{
 for(const [name,factory,seq] of factories){const sampled=[];
  for(const hz of [20,60,120]){const f=factory();f.setAnim(seq[0],{restart:true,fade:.001});f.update(.3,{speed:2});f.setAnim(seq[1],{fade:.3});for(let i=0;i<hz/10;i++)f.update(1/hz,{speed:2});f.setAnim(seq[2],{fade:.25});for(let i=0;i<hz/5;i++)f.update(1/hz,{speed:2});assert.ok(Math.abs(f.animator.cur.t-.2)<1e-12);sampled.push(f.animator.appliedPose.a.slice());}
  for(let i=1;i<sampled.length;i++)assert.ok(Math.max(...sampled[i].map((v,j)=>Math.abs(v-sampled[0][j])))<1e-6,name);
 }
});

test('explicit phase, restart and completed attack poses keep their original timing contracts',()=>{
 const f=prepare(createKiller,['walk','chase']);f.setAnim('raise',{restart:true,fade:.001,phase:.25});f.update(.35,{speed:0});assert.equal(f.animator.cur.t,.35);assert.equal(f.animator.cur.phase,.25);assert.equal(f.animator.prev,null);
 f.setAnim('strike',{restart:true,fade:.04});f.update(.26,{speed:0});assert.equal(f.animator.cur.t,.26);assert.equal(f.animator.fade,1);assert.equal(f.animator.prev,null);
 const pose=f.animator.appliedPose.a.slice();f.update(0,{speed:0});assert.ok(f.animator.appliedPose.a.every((v,i)=>v===pose[i]));
 const act2=createAct2Killer();act2.update(.1,{state:'chase',speed:3});act2.update(.05,{state:'patrol',speed:1});act2.reset();assert.equal(act2.figure.anim,'idle');assert.equal(act2.figure.animator.prev,null);act2.update(.02,{state:'patrol',speed:0});assert.equal(act2.figure.animator.prev,null);assert.equal(act2.root.userData.attackPhase,null);
});
