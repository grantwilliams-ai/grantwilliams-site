import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { CameraRig } from '../src/game/camera.js';
import { GameSim } from '../src/sim/game.js';
import { BUILDINGS, TEMPLATES, localToWorld, worldToLocal } from '../src/sim/layout.js';
import { surfaceY } from '../src/sim/terrain.js';
import { PLAYER } from '../src/ai/tuning.js';
import { buildBuilding } from '../src/kit/buildings.js';

const context=new Proxy({measureText:()=>({width:20}),createLinearGradient:()=>({addColorStop(){}})}, {get:(o,k)=>o[k]??(()=>{})});
globalThis.document={createElement:()=>({getContext:()=>context})};
const boat=BUILDINGS.find(b=>b.id==='boathouse'),template=TEMPLATES.boathouse;
const idle={moveX:0,moveY:0,lookX:0,lookY:0};
function point(x,y,z){const [wx,wz]=localToWorld(boat,x,z);return new THREE.Vector3(wx,surfaceY(wx,wz)+y,wz);}
function fixture(aspect=852/393){
  const sim=new GameSim({skipIntro:true,seed:42}),camera=new THREE.PerspectiveCamera(60,aspect,.08,420),rig=new CameraRig(camera,sim.collision);
  rig.touch=true;Object.assign(sim.killer,{x:120,z:100,state:'wait'});
  return {sim,camera,rig};
}
function place(f,x,z){
  [f.sim.player.x,f.sim.player.z]=localToWorld(boat,x,z);
  f.sim.player.y=surfaceY(f.sim.player.x,f.sim.player.z);f.sim.player.yaw=boat.rot;
}
function update(f,input=idle,dt=1/60){f.rig.update(dt,f.sim.player,input);f.camera.updateMatrixWorld(true);}
function inFrame(camera,target,margin=.95){
  const projected=target.clone().project(camera);
  assert.ok(Math.abs(projected.x)<margin&&Math.abs(projected.y)<margin&&projected.z>-1&&projected.z<1,`outside frame: ${projected.toArray()}`);
}

test('the original lake-facing room shot reproduces the missing exit and offscreen counselor',()=>{
  const f=fixture();f.rig.doorwayShots.clear();place(f,0,5.65);update(f);
  assert.equal(f.rig.zone.id,'boathouse.room');
  const door=point(0,1,6).project(f.camera),body=point(0,1,5.65).project(f.camera);
  assert.ok(door.x>1&&door.y< -1);
  assert.ok(body.x>1,'the counselor actually leaves the old shot before reaching the exit');
});

for(const [name,aspect] of [['phone landscape',852/393],['desktop',16/9],['phone portrait',393/852]]){
  test(`door frame and counselor remain visible in the doorway shot: ${name}`,()=>{
    const f=fixture(aspect);
    for(const z of [3.4,4.2,5.1,5.65,6.0])for(const x of [-.2,0,.2]){
      place(f,x,z);update(f);assert.equal(f.rig.zone.id,'boathouse.doorway');
      for(const y of [.15,1.1,1.7])inFrame(f.camera,point(x,y,z));
      for(const side of [-.6,.6])for(const y of [.1,1,2.1])inFrame(f.camera,point(side,y,6));
    }
  });
}

test('the real boathouse meshes do not obstruct the exit shot or its counselor',()=>{
  const f=fixture(),building=buildBuilding(boat,template),door=building.userData.doors[0].pivot;
  building.position.set(boat.x,surfaceY(boat.x,boat.z),boat.z);building.rotation.y=boat.rot;
  const ray=new THREE.Raycaster();
  const visibleHits=target=>{
    ray.set(f.camera.position,target.clone().sub(f.camera.position).normalize());ray.far=f.camera.position.distanceTo(target)+.15;
    return ray.intersectObject(building,true).filter(hit=>!hit.object.material.transparent);
  };
  for(const amount of [0,.4,1]){
    door.rotation.y=amount*1.75;building.updateMatrixWorld(true);
    for(const z of [3.4,4.2,5.1,5.65]){
      place(f,0,z);update(f);
      const leaf=door.localToWorld(new THREE.Vector3(template.doors[0].width/2,1,0));
      const hits=visibleHits(leaf);assert.ok(hits.length,'door mesh is hit');
      let first=hits[0].object;while(first&&first!==door)first=first.parent;
      assert.ok(first===door,`door obstructed at opening ${amount}, local z ${z}`);
      // With the door fully open, the actual path to the counselor also stays clear.
      if(amount===1){
        const body=point(0,1.1,z),occluder=visibleHits(body).find(hit=>hit.distance<f.camera.position.distanceTo(body)-.05);
        assert.ok(!occluder,`counselor occluded at local z ${z}`);
      }
    }
  }
  building.traverse(o=>{if(o.isMesh)o.geometry.dispose();});
});

test('the doorway cut has hysteresis and leaves the lake-facing room and hide views intact',()=>{
  const f=fixture();
  for(const [z,id] of [[3.3,'room'],[3.4,'doorway'],[3.39,'doorway'],[3,'doorway'],[2.81,'doorway'],[2.79,'room'],[3.2,'room'],[3.39,'room'],[3.41,'doorway']]){
    place(f,0,z);update(f);assert.equal(f.rig.zone.id,`boathouse.${id}`);
  }
  place(f,0,0);update(f);assert.equal(f.rig.zone.id,'boathouse.room');
  const hidden=f.sim.hides.find(h=>h.id==='boathouse.canoe');f.sim.player.hidden=hidden;update(f);
  assert.equal(f.camera.position.x,hidden.view.pos[0]);assert.equal(f.camera.position.z,hidden.view.pos[2]);assert.equal(f.camera.fov,62);
  assert.ok(Math.abs(f.camera.position.y-(hidden.view.pos[1]+surfaceY(hidden.view.pos[0],hidden.view.pos[2])))<=.0061);
});

for(const fps of [20,60,120]){
  test(`one held stick direction exits the rotated boathouse through its initially shut door at ${fps} Hz`,()=>{
    const f=fixture(),dt=1/fps;place(f,0,3);update(f,idle,dt);
    const firstYaw=f.rig.moveYaw,angle=boat.rot-firstYaw,input={...idle,moveX:-Math.sin(angle),moveY:Math.cos(angle)},cuts=[];
    const door=f.sim.collision.doors.find(d=>d.id==='boathouse.d0');assert.equal(door.open,false);
    for(let i=0;i<fps*2;i++){
      f.sim.step(dt,{...input,camYaw:f.rig.moveYaw});update(f,input,dt);
      assert.ok(Math.abs(f.rig.moveYaw-firstYaw)<1e-9,'camera cuts cannot reverse a held movement direction');
      assert.equal(f.sim.collision.blocked(f.sim.player.x,f.sim.player.z,PLAYER.radius-1e-6),false);
      if(f.rig.justCut)cuts.push(f.rig.zone?.id??'outside');
      if(f.rig.zone?.id==='boathouse.doorway')inFrame(f.camera,point(0,1,6));
    }
    const [x,z]=worldToLocal(boat,f.sim.player.x,f.sim.player.z);
    assert.ok(z>7&&Math.abs(x)<.25,`counselor exited without realignment: ${x},${z}`);
    assert.deepEqual(cuts,['boathouse.doorway','outside']);assert.equal(f.sim.collision.doorAmount(door),1);
    update(f,idle,dt);update(f,idle,dt);assert.equal(f.rig.holdMove,false);
    // She steps back for the door as it swings in, so she leaves a degree or so off the building's axis.
    assert.ok(Math.abs(f.rig.moveYaw-f.sim.player.yaw)<.05,'after release, new input uses the outside view');
  });
}

test('other rotated buildings retain their authored cameras and existing cut behavior',()=>{
  const f=fixture(),b=BUILDINGS.find(b=>b.id==='cabin1');
  [f.sim.player.x,f.sim.player.z]=localToWorld(b,0,3.3);f.sim.player.y=surfaceY(f.sim.player.x,f.sim.player.z);update(f);
  assert.equal(f.rig.zone.id,'cabin1.room');
  const yaw=f.rig.moveYaw;[f.sim.player.x,f.sim.player.z]=localToWorld(b,0,4.2);update(f,{...idle,moveY:1});
  assert.equal(f.rig.zone,null);assert.equal(f.rig.holdMove,true);assert.equal(f.rig.moveYaw,yaw);
});
