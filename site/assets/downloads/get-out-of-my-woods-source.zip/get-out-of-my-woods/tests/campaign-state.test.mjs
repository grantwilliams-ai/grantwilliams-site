import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {createCampaignState,CAMPAIGN_SAVE_KEY,act2Difficulty} from '../src/campaign/state.js';
import {disposeSceneResources} from '../src/campaign/resources.js';
import {audio} from '../src/audio/index.js';

test('checkpoint persists between chapters/reload; retry retains it and new game resets it',()=>{
 const saved=new Map(),storage={getItem:k=>saved.get(k),setItem:(k,v)=>saved.set(k,v)};
 const first=createCampaignState(storage);first.start({difficulty:'hard'});first.setting('volume',.4);first.setting('picture','sharp');
 first.reachCrash({time:234,difficulty:'hard'});assert.equal(first.canContinue(),true);
 const reload=createCampaignState(storage);assert.equal(reload.canContinue(),true);assert.equal(reload.state.act1Time,234);assert.equal(reload.state.difficulty,'hard');assert.equal(reload.state.preferences.volume,.4);
 reload.start({retry:true,difficulty:'hard'});assert.equal(reload.canContinue(),true);reload.complete();assert.equal(reload.canContinue(),false);
 reload.replayCrash();assert.equal(reload.canContinue(),true);reload.start();assert.equal(reload.state.checkpoint,null);assert.equal(reload.state.act1Time,0);assert.equal(reload.state.preferences.volume,.4);
 assert.deepEqual([...saved.keys()],[CAMPAIGN_SAVE_KEY]);assert.equal(act2Difficulty('easy'),'relaxed');assert.equal(act2Difficulty('normal'),'standard');assert.equal(act2Difficulty('hard'),'hard');
});
test('private storage failure keeps a working in-memory checkpoint; invalid values cannot poison settings',()=>{
 const store=createCampaignState({getItem(){throw Error('private');},setItem(){throw Error('private');}});
 store.reachCrash({time:40});assert.equal(store.canContinue(),true);assert.equal(store.storageAvailable,false);store.setting('brightness',99);assert.equal(store.state.preferences.brightness,1.7);
 const corrupt=createCampaignState({getItem:()=>JSON.stringify({version:1,preferences:{brightness:'NaN',volume:Infinity,picture:'bogus'},checkpoint:'admin',difficulty:'bogus',act1Time:-4})});
 assert.equal(corrupt.canContinue(),false);assert.equal(corrupt.state.act1Time,0);assert.equal(corrupt.state.difficulty,'normal');assert.equal(corrupt.state.preferences.brightness,1.12);
 const nullPrefs=createCampaignState({getItem:()=>JSON.stringify({version:1,preferences:null})});assert.equal(nullPrefs.state.preferences.brightness,1.12);
});

test('QA9: a new game removes the old checkpoint even when the browser refuses writes; a retry keeps it',()=>{
 const saved=new Map();let refuse=false;
 const storage={getItem:k=>saved.get(k),setItem:(k,v)=>{if(refuse)throw Error('QuotaExceeded');saved.set(k,v);},removeItem:k=>saved.delete(k)};
 createCampaignState(storage).reachCrash({time:120});assert.equal(createCampaignState(storage).canContinue(),true);
 refuse=true;
 const visit=createCampaignState(storage);visit.start({difficulty:'normal'});assert.equal(visit.canContinue(),false);
 assert.equal(createCampaignState(storage).canContinue(),false,'the old checkpoint does not come back after a reload');
 refuse=false;createCampaignState(storage).reachCrash({time:50});refuse=true;
 createCampaignState(storage).start({retry:true});assert.equal(createCampaignState(storage).canContinue(),true,'a retry removes nothing');
});

test('all offered brightness values and comfort choices survive chapter and reload without resetting progress',()=>{
 const saved=new Map(),storage={getItem:k=>saved.get(k),setItem:(k,v)=>saved.set(k,v)};
 const state=createCampaignState(storage);state.start({difficulty:'hard'});state.reachCrash({time:234});
 for(const brightness of [.4,.65,.8,1.12,1.6,1.7]) {
   state.setting('brightness',brightness);
   const reload=createCampaignState(storage);
   assert.equal(reload.state.preferences.brightness,brightness);
   assert.equal(reload.state.checkpoint,'crash');assert.equal(reload.state.act1Time,234);assert.equal(reload.state.difficulty,'hard');
 }
 for(const [key,value] of Object.entries({flashes:'reduced',tape:true,picture:'retro',steps:.15}))state.setting(key,value);
 const reload=createCampaignState(storage);
 assert.deepEqual({...reload.state.preferences},{brightness:1.7,volume:.65,steps:.15,weather:.7,picture:'retro',tape:true,flashes:'reduced',inputMode:'auto',hints:true,compass:true});
 assert.equal(reload.canContinue(),true);assert.deepEqual([...saved.keys()],[CAMPAIGN_SAVE_KEY]);
 state.setting('brightness',-10);assert.equal(state.state.preferences.brightness,.4);
});
test('chapter cleanup disposes shared GPU resources only once per scene',()=>{
 const scene=new THREE.Scene(),geometry=new THREE.BoxGeometry(),texture=new THREE.Texture(),material=new THREE.MeshBasicMaterial({map:texture});
 let g=0,m=0,t=0;geometry.addEventListener('dispose',()=>g++);material.addEventListener('dispose',()=>m++);texture.addEventListener('dispose',()=>t++);
 scene.add(new THREE.Mesh(geometry,material),new THREE.Mesh(geometry,material));
 const counts=disposeSceneResources(scene);assert.deepEqual(counts,{geometries:1,materials:1,textures:1,skeletons:0});assert.deepEqual([g,m,t],[1,1,1]);assert.equal(scene.children.length,0);
});
test('audio chapter reset retains the unlocked context but retires old notes, loops and ambience',()=>{
 const source={stopped:0,stop(){this.stopped++;}},gain={gain:{cancelScheduledValues(){},setValueAtTime(value){assert.equal(value,0);}}};
 const context={currentTime:10};const fixture={ctx:context,voices:new Set([{source,gain,stopping:true}]),musicTrack:{},pendingLoops:new Set([{}]),setRoom(){},resumeAll(){},unlocked:true};
 audio.resetChapter.call(fixture);assert.equal(fixture.ctx,context);assert.equal(fixture.unlocked,true);assert.equal(source.stopped,1);assert.equal(fixture.voices.size,0,'old voices cannot block new ambience');assert.equal(fixture.pendingLoops.size,0);assert.equal(fixture.musicName,'none');assert.equal(fixture.ambient,null);
});

test('deferred synth cue from outgoing chapter cannot replay after the switch',async()=>{
 let ready;const fixture={paused:false,hidden:false,failed:false,_init(){},buffers:new Map(),ready:new Promise(r=>ready=r),_voice(){assert.fail('stale cue played');},voices:new Set(),pendingLoops:new Set(),setRoom(){},resumeAll(){}};
 audio.sfx.call(fixture,'car_door');audio.resetChapter.call(fixture);ready();await fixture.ready;
});
