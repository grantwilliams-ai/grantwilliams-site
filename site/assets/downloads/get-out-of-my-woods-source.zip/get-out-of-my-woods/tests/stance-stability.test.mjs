import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {createPlayer} from '../src/characters/player.js';
import {createKiller} from '../src/characters/killer.js';
import {createAct2Killer} from '../src/act2/killer.js';

globalThis.document={createElement:()=>({getContext:()=>new Proxy({},{get:(o,k)=>o[k]||(()=>{})})})};
const rates=[20,60,120],sides=['L','R'];
const cases=[[createPlayer,'walk',1.9,.5],[createPlayer,'sneak',1,.62],[createPlayer,'run',4.5,.355],[createKiller,'walk',1.55,.62],[createKiller,'stalk',1.1,.68],[createKiller,'chase',3.85,.46]];
const feet=f=>sides.map(s=>f.rig.b('foot'+s).getWorldPosition(new THREE.Vector3()));
function begin(factory,gait='walk',phase=0){const f=factory();f.setAnim(gait,{restart:true,fade:.001,phase,travelDriven:true});f.update(.001,{speed:0});f.stabilizeStance(.001,{enabled:true});return f;}
function advance(f,dt,speed,yaw,options={enabled:true}){f.root.rotation.y=yaw;f.root.position.x+=Math.sin(yaw)*speed*dt;f.root.position.z+=Math.cos(yaw)*speed*dt;f.update(dt,{speed});f.root.updateMatrixWorld(true);const raw=feet(f);const status={...f.stabilizeStance(dt,options)};return {raw,status,offsets:feet(f).map((v,i)=>v.sub(raw[i]))};}
function snapshot(f){f.root.updateMatrixWorld(true);return f.rig.bones.map(b=>({p:b.getWorldPosition(new THREE.Vector3()),q:b.getWorldQuaternion(new THREE.Quaternion()),local:b.position.clone()}));}
function same(f,a,tolerance=1e-7){snapshot(f).forEach((b,i)=>{assert.ok(b.p.distanceTo(a[i].p)<1e-8,f.rig.names[i]);assert.ok(b.q.angleTo(a[i].q)<tolerance,f.rig.names[i]);});}
function turnResidual(factory,gait,speed,duty,hz,degrees,enabled){
 const f=begin(factory,gait),previous={};let distance=0,time=0;
 for(let i=1;i<=hz*1.5;i++){const t=i/hz,yaw=degrees*Math.PI/180*Math.min(1,Math.max(0,(t-.8)/.25));advance(f,1/hz,speed,yaw,{enabled});
  sides.forEach((s,index)=>{const phase=f.animator.cur.phase+index*.5,part=(phase%1)/duty,cycle=Math.floor(phase),point=f.rig.b('foot'+s).getWorldPosition(new THREE.Vector3()),last=previous[s];
   if(t>.8&&t<1.15&&part>.1&&part<.85&&last?.part>.1&&last.part<.85&&cycle===last.cycle){distance+=Math.hypot(point.x-last.point.x,point.z-last.point.z);time+=1/hz;}previous[s]={point,part,cycle};});
 }return distance/time;
}
for(const hz of rates)test(`bounded stance reduces measured 90/180-degree turn skating at ${hz} Hz`,()=>{
 for(const [factory,gait,speed,duty]of cases)for(const degrees of[90,180]){const before=turnResidual(factory,gait,speed,duty,hz,degrees,false),after=turnResidual(factory,gait,speed,duty,hz,degrees,true);assert.ok(after<before*.96,`${factory.name}/${gait}/${degrees}: ${before} -> ${after}`);}
});

test('straight middle-stance travel is not increased by the turn presentation layer',()=>{
 for(const [factory,gait,speed,duty]of cases){const before=turnResidual(factory,gait,speed,duty,60,0,false),after=turnResidual(factory,gait,speed,duty,60,0,true);assert.ok(after<=before+1e-8,`${factory.name}/${gait}: ${before} -> ${after}`);}
});

for(const [label,factory]of [['counselor',createPlayer],['Sackhead',createKiller],['Act II adapter',()=>createAct2Killer().figure]])test(`${label}: correction preserves upper body, authored pose, segment lengths and sole contact`,()=>{
 const f=begin(factory);let peak=0;
 for(let i=0;i<150;i++){
  const dt=1/60,yaw=Math.PI*Math.min(1,Math.max(0,(i/60-.4)/.25));f.root.rotation.y=yaw;f.root.position.x+=Math.sin(yaw)*1.9*dt;f.root.position.z+=Math.cos(yaw)*1.9*dt;f.update(dt,{speed:1.9});
  const before=snapshot(f),pose=f.animator.appliedPose.a.slice(),root=f.root.matrixWorld.clone(),phase=f.animator.cur.phase,time=f.animator.cur.t;
  const status=f.stabilizeStance(dt,{enabled:true});peak=Math.max(peak,status.maxCorrection);const after=snapshot(f);
  assert.deepEqual(f.animator.appliedPose.a,pose);assert.deepEqual(f.root.matrixWorld.elements,root.elements);assert.equal(f.animator.cur.phase,phase);assert.equal(f.animator.cur.t,time);
  after.forEach((b,j)=>{assert.ok(b.local.distanceTo(before[j].local)<1e-12);assert.ok([...b.p.toArray(),...b.q.toArray()].every(Number.isFinite));if(!/^(thigh|shin|foot)[LR]$/.test(f.rig.names[j])){assert.ok(b.p.distanceTo(before[j].p)<1e-10);assert.ok(b.q.angleTo(before[j].q)<1e-7);}});
  for(const s of sides){const hi=f.rig.idx['thigh'+s],ki=f.rig.idx['shin'+s],fi=f.rig.idx['foot'+s];assert.ok(Math.abs(after[hi].p.distanceTo(after[ki].p)-before[hi].p.distanceTo(before[ki].p))<1e-10);assert.ok(Math.abs(after[ki].p.distanceTo(after[fi].p)-before[ki].p.distanceTo(before[fi].p))<1e-10);assert.ok(Math.abs(after[fi].p.y-before[fi].p.y)<1e-10);assert.ok(after[fi].q.angleTo(before[fi].q)<1e-7);}
 }
 assert.ok(peak>.015);assert.ok(peak<=(label==='counselor'?.12:.16)+1e-9);
});

test('zero-delta redraw replays scaled correction without accumulation; disabled films and placement jumps reset',()=>{
 const f=begin(createKiller,'chase');for(let i=0;i<50;i++)advance(f,1/60,3.85,i/30,{enabled:true,strength:.6});
 const displayed=snapshot(f),phase=f.animator.cur.phase,time=f.animator.cur.t;
 for(let i=0;i<5;i++){f.update(0,{speed:3.85});f.stabilizeStance(0,{enabled:true,strength:.6});same(f,displayed);assert.equal(f.animator.cur.phase,phase);assert.equal(f.animator.cur.t,time);}
 f.resetStance();same(f,displayed);f.update(0,{speed:0});const raw=snapshot(f);f.stabilizeStance(0,{enabled:false});same(f,raw);
 for(let i=0;i<35;i++)advance(f,1/60,3.85,i/20);f.root.position.x+=10;f.update(1/60,{speed:3.85});const jumped=snapshot(f);assert.equal(f.stabilizeStance(1/60,{enabled:true}).active,false);same(f,jumped);
 f.setAnim('strike');f.update(.1,{speed:0});const authored=snapshot(f);f.stabilizeStance(.1,{enabled:false});same(f,authored);
});

for(const hz of rates)test(`live support releases across stop/search/raise and keeps attack contact raw at ${hz} Hz`,()=>{
 for(const action of ['idle','search','raise'])for(const factory of[createPlayer,createKiller]){
  if(!factory().has(action))continue;
  for(let seed=0;seed<4;seed++){
   const f=begin(factory,'walk',seed/4);let last;
   for(let i=0;i<hz;i++)last=advance(f,1/hz,1.9,i/hz*2.2);
   f.setAnim(action);let maxExtra=0,status;
   for(let i=0;i<Math.ceil(hz*.35);i++){
    const next=advance(f,1/hz,0,2.2);for(let j=0;j<2;j++)maxExtra=Math.max(maxExtra,next.offsets[j].distanceTo(last.offsets[j]));last=next;status=next.status;
   }
   assert.ok(maxExtra<.6/hz+1e-7,`${factory.name}/${action} outgoing offset ${maxExtra}`);assert.equal(status.maxCorrection,0);
   if(action==='raise'){f.setAnim('strike');f.update(.18,{speed:0});const raw=snapshot(f);assert.equal(f.stabilizeStance(.18,{enabled:true}).active,false);same(f,raw);assert.equal(f.animator.cur.t,.18);}
  }
 }
});

test('zero-travel yaw pivots settle and unsupported vault presentation remains authored',()=>{
 for(const factory of[createPlayer,createKiller]){const f=begin(factory);for(let i=0;i<35;i++)advance(f,1/60,1.9,i/20);for(let i=0;i<60;i++)advance(f,1/60,0,Math.PI*Math.min(1,i/15));const raw=advance(f,0,0,Math.PI);assert.equal(raw.status.maxCorrection,0);
 if(f.has('vault')){f.setAnim('vault');f.update(.1,{speed:0});const pose=snapshot(f);assert.equal(f.stabilizeStance(.1,{enabled:true}).active,false);same(f,pose);}}
});

// Instant yaw changes are a real Act II input path. Full counter-correction may
// move farther than its normal slew only when it reduces the feasible world step.
function abruptResidual(factory,gait,speed,duty,hz,angle,enabled){
 const f=begin(factory,gait,.13);let old=null,distance=0,time=0;
 for(let i=0;i<hz*3;i++){const t=i/hz;advance(f,1/hz,speed,t>=1&&t<2?angle:0,{enabled});const points=feet(f),phase=f.animator.cur.phase;
  if(old)sides.forEach((s,j)=>{const q=phase+j*.5,prev=old.phase+j*.5,part=(q%1)/duty,lastPart=(prev%1)/duty;
   if(part>.12&&part<.85&&lastPart>.12&&lastPart<.85&&Math.floor(q)===Math.floor(prev)&&((t>=.85&&t<=1.35)||(t>=1.85&&t<=2.35))){distance+=Math.hypot(points[j].x-old.points[j].x,points[j].z-old.points[j].z);time+=1/hz;}});
  old={points,phase};
 }return distance/time;
}
for(const hz of rates)test(`instant Act II style 90/180 yaw changes also reduce stance travel at ${hz} Hz`,()=>{
 const instantCases=[[createPlayer,'walk',2.6,.5],[createPlayer,'sneak',1.35,.62],[createPlayer,'run',4.7,.355],[createKiller,'walk',1.5,.62],[createKiller,'stalk',1.3,.68],[createKiller,'chase',3.5,.46]];
 for(const [factory,gait,speed,duty]of instantCases)for(const angle of[Math.PI/2,Math.PI]){const before=abruptResidual(factory,gait,speed,duty,hz,angle,false),after=abruptResidual(factory,gait,speed,duty,hz,angle,true);assert.ok(after<before,`${factory.name}/${gait}/${angle}: ${before} -> ${after}`);}
});
