import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

test('Bearings CLOSE stays in flow, and a short window keeps the caption off the right-hand controls', () => {
  const src = readFileSync(new URL('../src/act2/ui.js', import.meta.url), 'utf8');
  assert.equal(src.includes('position:sticky'), false);
  assert.ok(src.includes('class="map-body"'));
  assert.ok(src.includes('More ↓'));
  assert.ok(src.includes('width:min(300px,42vw)'));
  assert.ok(src.includes('font-size:18px'));
  assert.ok(src.includes('.hud.desktop .prompt{left:auto;right:max(16px,env(safe-area-inset-right))'));
});
