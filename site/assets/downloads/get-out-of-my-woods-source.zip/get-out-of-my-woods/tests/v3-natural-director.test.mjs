import test from 'node:test';
import assert from 'node:assert/strict';
import {Director} from '../src/ai/director.js';
import {DIFFICULTY} from '../src/ai/tuning.js';
import {makeRng} from '../src/core/rng.js';
import {BUILDINGS} from '../src/sim/layout.js';

const killer={x:52,z:7.4};
function prolonged(){const d=new Director(makeRng(71),DIFFICULTY.hard);d.time=100;d.sinceContact=100;return d;}

test('prolonged patrol uses a coarse region, independent of precise position or velocity',()=>{
 const a=prolonged(),b=prolonged();
 const p={x:1,z:1,vx:0,vz:0,hidden:null};
 const q={x:7,z:7,vx:5,vz:-5,hidden:null};
 assert.deepEqual(a.nextWaypoint(killer,p,0),b.nextWaypoint(killer,q,0));
});

test('closed-building inspection is a fixed map destination and has a cooldown',()=>{
 const d=prolonged();d.idleFor=50;
 const p={x:-3,z:-25,hidden:null};
 const target=d.nextWaypoint({x:-2,z:-21},p,0);
 assert.equal(target.id,'inspect-cabin2','a nearby exterior position must not prevent walking through its door');
 assert.ok(BUILDINGS.some(b=>b.x===target.x&&b.z===target.z));
 assert.equal(d.nextWaypoint(killer,p,0).id.startsWith('inspect-'),false);
});

test('a hidden player cannot provide a location to patrol or ambush selection',()=>{
 const d=prolonged();d.idleFor=100;
 const p={hidden:{id:'test'},get x(){throw Error('hidden x accessed');},get z(){throw Error('hidden z accessed');}};
 assert.equal(d.nextWaypoint(killer,p,0).id.startsWith('inspect-'),false);
 assert.equal(d.wantsAmbush(killer,p),null);
});

test('contact preserves the full recovery window and cancels pressure refresh and inspection',()=>{
 const d=prolonged();d.idleFor=100;d.pressureNudge=true;d.contact();
 assert.ok(d.relax>=32&&d.relax<=48);
 const p={x:-3,z:-25,hidden:null};
 for(let i=0;i<30;i++)d.update(1,p);
 assert.ok(d.relax>0);assert.equal(d.pressureNudge,false);
 assert.equal(d.nextWaypoint(killer,p,0).id.startsWith('inspect-'),false);
});

test('a moving player eventually refreshes an obsolete patrol route without per-frame repathing',()=>{
 const d=prolonged(),p={x:16,z:16,hidden:null};
 d.update(1,p);assert.equal(d.pressureNudge,true);d.nextWaypoint(killer,p,0);
 for(let i=0;i<10;i++){p.x+=2.9;d.update(1,p);assert.equal(d.pressureNudge,false);}
 for(let i=0;i<3;i++){p.x+=2.9;d.update(1,p);}
 assert.equal(d.pressureNudge,true);
});


test('coarse regions rotate nearby building inspections instead of choosing one forever',()=>{
 const d=prolonged();d.idleFor=100;const p={x:24.2,z:-20.2,hidden:null};
 const first=d.nextWaypoint(killer,p,0);
 d.time+=46;d.sinceContact+=46;
 const second=d.nextWaypoint(killer,p,0);
 assert.ok(first.id.startsWith('inspect-'));assert.ok(second.id.startsWith('inspect-'));
 assert.notEqual(first.id,second.id);
});
