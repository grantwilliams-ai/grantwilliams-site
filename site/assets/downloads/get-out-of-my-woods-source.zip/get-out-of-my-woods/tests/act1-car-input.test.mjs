import test from 'node:test';
import assert from 'node:assert/strict';
import { GameSim } from '../src/sim/game.js';
import { Cinematics } from '../src/game/cinematics.js';

function carSim() {
  const sim = new GameSim({ skipIntro: true, seed: 91 });
  sim.phase = 'car';
  sim.player.inCar = true;
  sim.car.need = 3;
  return sim;
}

function events(sim) {
  return sim.drainEvents().map((event) => event.t);
}

test('one press during a crank starts the next try immediately after crankFail', () => {
  const sim = carSim();
  sim.updateCar(0, { action: true });
  assert.deepEqual(events(sim), ['crank']);

  sim.updateCar(0.4, { action: true });
  sim.updateCar(0.1, { action: true });
  assert.equal(sim.car.tries, 1, 'repeated presses keep only one buffered try');
  assert.deepEqual(events(sim), []);

  sim.updateCar(0.8, { action: false });
  assert.deepEqual(events(sim), ['crankFail', 'crank']);
  assert.equal(sim.car.tries, 2);
  assert.equal(sim.car.crank, 1.3);

  sim.updateCar(1.3, { action: false });
  assert.deepEqual(events(sim), ['crankFail'], 'the buffer produces exactly one extra try');
  assert.equal(sim.car.tries, 2);
});

test('a buffered press cannot interrupt or add a try after the final successful crank', () => {
  const sim = carSim();
  sim.car.tries = sim.car.need - 1;
  sim.car.threat = 12;
  sim.updateCar(0, { action: true });
  assert.equal(sim.car.threat, 8, 'last try retains its existing threat allowance');
  sim.updateCar(0.5, { action: true });
  sim.updateCar(0.8, { action: false });
  assert.deepEqual(events(sim), ['crank', 'engineStart']);
  assert.equal(sim.phase, 'escaped');
  assert.equal(sim.car.tries, sim.car.need);
});

test('crank failure captions are urgent without changing their text or duration', () => {
  const calls = [];
  const cine = new Cinematics({ ui: { caption: (...args) => calls.push(args) } });
  cine.crankFail({ tries: 2 });
  assert.deepEqual(calls, [['Almost. Again.', 1.6, { kind: 'urgent' }]]);
});
