import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { createAct2Killer } from '../src/act2/killer.js';
import { createKiller } from '../src/characters/killer.js';

globalThis.document = { createElement: () => ({ getContext: () => ({
  fillRect() {}, beginPath() {}, ellipse() {}, fill() {},
}) }) };

test('tailored clothing has valid continuous torso skinning and preserves the original fork and rig', () => {
  const actor = createAct2Killer(), original = createKiller(), figure = actor.figure;
  assert.deepEqual(figure.rig.at, original.rig.at, 'cosmetic changes leave gameplay joints untouched');
  const forkVertices = (f) => {
    const g = f.meshes.find(m => m.name === 'killer-hard').geometry, p = g.attributes.position, s = g.attributes.skinIndex;
    return Array.from({ length: p.count }, (_, i) => i).filter(i => s.getX(i) === f.rig.idx.fork).flatMap(i => [p.getX(i), p.getY(i), p.getZ(i)]);
  };
  assert.deepEqual(forkVertices(figure), forkVertices(original));
  const g = figure.meshes.find(m => m.name === 'killer-cloth').geometry;
  const p = g.attributes.position, weights = g.attributes.skinWeight, skin = g.attributes.skinIndex;
  const torsoBones = new Set(['pelvis', 'spine', 'chest'].map(n => figure.rig.idx[n]));
  let blended = 0, minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
  for (let i = 0; i < p.count; i++) {
    const w = Array.from(weights.array.slice(i * 4, i * 4 + 4));
    assert.ok(w.every(Number.isFinite) && Math.abs(w.reduce((a, b) => a + b) - 1) < .000001);
    if (w[0] > 0 && w[1] > 0) blended++;
    if (torsoBones.has(skin.getX(i)) && torsoBones.has(skin.getY(i))) {
      minX = Math.min(minX, p.getX(i)); maxX = Math.max(maxX, p.getX(i));
      minZ = Math.min(minZ, p.getZ(i)); maxZ = Math.max(maxZ, p.getZ(i));
    }
  }
  assert.ok(blended > 300, 'torso and sewn details bend together across spine joints');
  assert.ok(maxX - minX > .65 && maxX - minX < .82, 'broad human shoulders, without padded shell width');
  assert.ok(maxZ - minZ < .5, 'shirt follows a human torso instead of a barrel');
  assert.ok(actor.vertexCount < 11000, 'polish retains the small preview geometry budget');
});

test('weathered sack retains exactly two dark eye cuts, with no emissive reflections', () => {
  const actor = createAct2Killer(), g = actor.figure.meshes.find(m => m.name === 'killer-burlap').geometry;
  const p = g.attributes.position, c = g.attributes.color, eyes = [[], []];
  for (let i = 0; i < p.count; i++) if (c.getX(i) === 0 && c.getY(i) === 0 && c.getZ(i) === 0) {
    eyes[p.getX(i) < 0 ? 0 : 1].push([p.getX(i), p.getY(i)]);
  }
  assert.deepEqual(eyes.map(e => e.length), [30, 30], 'both authored black knife cuts survive tailoring');
  const centers = eyes.map(e => e.reduce((n, v) => n + v[1], 0) / e.length);
  assert.ok(Math.abs(centers[0] - centers[1]) < .025, 'uneven cuts still read as eyes rather than an eye and mouth');
  const normals=g.attributes.normal;
  for(let i=0;i<normals.count;i++)assert.ok(Math.abs(Math.hypot(normals.getX(i),normals.getY(i),normals.getZ(i))-1)<.00001,'cloth and decal shading normals remain valid');
  assert.ok(actor.figure.rig.b('head').children.filter(c => c.isGroup).every(c => !c.visible));
});

test('shirt and overalls keep a fitted silhouette with attached collar and hip openings',()=>{
  const figure=createAct2Killer().figure,g=figure.meshes.find(m=>m.name==='killer-cloth').geometry;
  const p=g.attributes.position,skin=g.attributes.skinIndex,weights=g.attributes.skinWeight,idx=figure.rig.idx;
  const torsoBones=new Set([idx.pelvis,idx.spine,idx.chest]);
  let hem=Infinity,chestWidth=0,chestDepth=0,sleeveRadius=0,collar=0,hips=0;
  for(let i=0;i<p.count;i++){
    const x=p.getX(i),y=p.getY(i),z=p.getZ(i),a=skin.getX(i),b=skin.getY(i);
    if(torsoBones.has(a)&&torsoBones.has(b)){
      hem=Math.min(hem,y);
      if(Math.abs(y-1.55)<.00001){chestWidth=Math.max(chestWidth,Math.abs(x));chestDepth=Math.max(chestDepth,Math.abs(z));}
    }
    if(a===idx.chest&&(b===idx.uarmL||b===idx.uarmR)&&Math.abs(y-1.65)<.00001){
      sleeveRadius=Math.max(sleeveRadius,Math.hypot(x-Math.sign(x)*.375,z));
    }
    if(a===idx.chest&&b===idx.head&&Math.abs(y-1.86)<.00001){
      collar++;assert.ok(weights.getY(i)>.9999,'collar rim follows the tied sack instead of opening a neck gap');
      assert.ok(Math.hypot(x,z)<.1,'collar rim stays tucked inside the sack');
    }
    if(a===idx.pelvis&&(b===idx.thighL||b===idx.thighR)&&Math.abs(y-1.08)<.00001){
      hips++;assert.ok(weights.getX(i)>.9999,'upper trouser opening remains attached to the waist during a stride');
    }
  }
  assert.ok(hem>=.9299&&hem<.95,'overall waist overlaps the hips without a pointed apron below them');
  assert.ok(chestWidth>.32&&chestWidth<.34&&chestDepth>.17&&chestDepth<.19,'shirt has a flatter chest inside its previous envelope');
  assert.ok(sleeveRadius>.1&&sleeveRadius<.11,'sleeve fits around the arm instead of a padded shoulder shell');
  assert.ok(collar>=40&&hips>=40,'both openings have complete attached rings');
});

test('elbows and knees share garment weights without changing the rig or geometry budget',()=>{
  const actor=createAct2Killer(),figure=actor.figure,g=figure.meshes.find(m=>m.name==='killer-cloth').geometry;
  const skin=g.attributes.skinIndex,weights=g.attributes.skinWeight;
  for(const [upper,lower] of [['uarmL','farmL'],['uarmR','farmR'],['thighL','shinL'],['thighR','shinR']]){
    let blended=0;
    for(let i=0;i<skin.count;i++)if(skin.getX(i)===figure.rig.idx[upper]&&skin.getY(i)===figure.rig.idx[lower]&&weights.getX(i)>.01&&weights.getY(i)>.01)blended++;
    assert.ok(blended>=20,`${upper}/${lower} has a cloth bend instead of two rigid rings`);
  }
  assert.equal(actor.vertexCount,9522);
  const positions=g.attributes.position,colors=g.attributes.color,bib=[],sleeve=[];
  for(let i=0;i<positions.count;i++){
    const x=Math.abs(positions.getX(i)),y=positions.getY(i),z=positions.getZ(i),l=colors.getX(i)*.2126+colors.getY(i)*.7152+colors.getZ(i)*.0722;
    if(y>1.38&&y<1.6&&z>.1&&x<.16)bib.push(l);
    if(y>1.35&&y<1.65&&z>.03&&x>.4)sleeve.push(l);
  }
  const mean=values=>values.reduce((a,b)=>a+b,0)/values.length;
  assert.ok(mean(bib)<mean(sleeve)*.8,'dark overalls remain distinct from the faded shirt under warm light');
  for(const name of ['killer-cloth','killer-burlap']){
    const material=figure.meshes.find(m=>m.name===name).material,data=material.roughnessMap.image.data;
    assert.equal(material.roughnessMap.image.width,256,'small shared surface map');
    let lo=255,hi=0;for(let i=0;i<data.length;i+=4){lo=Math.min(lo,data[i]);hi=Math.max(hi,data[i]);assert.equal(data[i+3],255);}
    assert.ok(lo>=220&&hi<=253&&hi-lo>5,'wear remains matte with restrained variation');
  }
});

test('cosmetic cloth bends stay within the previous animated body envelope',()=>{
  // Preview03 measured envelopes, excluding the unchanged pitchfork. Regressing
  // these would reintroduce visible wall penetration while collision stays fixed.
  const cases=[
    [{state:'patrol',speed:0},[-.718605,-.003676,-.208990],[.702938,2.177419,.592858]],
    [{state:'chase',speed:2.85},[-.772161,-.029552,-.825281],[.723582,2.172588,.883293]],
    [{state:'chase',attackPhase:'windup',attackProgress:.6},[-.755773,-.027515,-.509657],[.444150,2.168984,.556056]],
    [{state:'chase',attackPhase:'strike',attackProgress:.6},[-.552550,-.079627,.032709],[.527633,1.892945,1.238675]],
    [{state:'stagger',speed:0},[-.719584,-.004004,-.210910],[.494229,2.183128,1.204712]],
  ];
  const point=new THREE.Vector3();
  for(const [state,min,max] of cases){
    const actor=createAct2Killer();
    for(let frame=0;frame<90;frame++){
      actor.update(1/60,state);actor.root.updateWorldMatrix(true,true);actor.figure.rig.skeleton.update();
      for(const mesh of actor.figure.meshes){const g=mesh.geometry;
        for(let i=0;i<g.attributes.position.count;i++){
          if(g.attributes.skinIndex.getX(i)===actor.figure.rig.idx.fork)continue;
          mesh.getVertexPosition(i,point);
          for(let axis=0;axis<3;axis++)assert.ok(point.getComponent(axis)>=min[axis]-.00001&&point.getComponent(axis)<=max[axis]+.00001,`${state.state}/${state.attackPhase||'carry'} body remains inside its old bounds`);
        }
      }
    }
  }
});
