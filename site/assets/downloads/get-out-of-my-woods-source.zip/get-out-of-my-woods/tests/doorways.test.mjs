// Doorways: a walker aimed roughly at a door gets through it, in and out, open or shut.
import test from 'node:test';
import assert from 'node:assert/strict';
import { GameSim } from '../src/sim/game.js';
import { doorFrame } from '../src/sim/doorways.js';

const DT = 1 / 60;
const input = (x, z) => ({ moveX: 0, moveY: 0, camYaw: 0, run: false, sneak: false, action: false, actionHeld: false, flashlight: false, worldX: x, worldZ: z });

function cross(doorIndex, { inward, open, lateral, aim }) {
  const sim = new GameSim({ seed: 7, difficulty: 'easy', skipIntro: true });
  sim.killer.update = () => {};
  const d = sim.collision.doors[doorIndex];
  if (open) { d.open = true; if (d.motion) d.motion.amount = d.motion.target = 1; }
  const f = doorFrame(d);
  const cx = d.x, cz = d.z;
  const side = inward ? -1 : 1; // start outside (against n) to go in, inside to go out
  const p = sim.player;
  p.x = cx + f.nx * side * 1.6 + f.ux * lateral;
  p.z = cz + f.nz * side * 1.6 + f.uz * lateral;
  const heading = Math.atan2(-f.nx * side, -f.nz * side) + aim;
  p.yaw = heading;
  let opened = open;
  for (let t = 0; t < 6; t += DT) {
    const it = sim.findInteraction();
    const press = !opened && it?.kind === 'door' && !it.door.open;
    if (press) opened = true;
    sim.step(DT, { ...input(), camYaw: heading, moveY: 1, action: press });
    const along = (p.x - cx) * f.nx + (p.z - cz) * f.nz;
    if (along * side < -0.8) return true;
  }
  return false;
}

test('every Act I door can be walked through from a loose approach at the opening', () => {
  const sim = new GameSim({ seed: 7, difficulty: 'easy', skipIntro: true });
  const failures = [];
  for (let i = 0; i < sim.collision.doors.length; i++) {
    for (const inward of [true, false]) for (const open of [true, false]) {
      for (const lateral of [-0.5, 0, 0.5]) for (const aim of [-0.3, 0, 0.3]) {
        // Only approaches whose line goes through the opening or clips its frame are helped; one
        // aimed at the wall beside the door is hers to correct, as it always was.
        const dr = sim.collision.doors[i], fr = doorFrame(dr), sd = inward ? -1 : 1;
        const hd = Math.atan2(-fr.nx * sd, -fr.nz * sd) + aim;
        const strike = lateral + (Math.sin(hd) * fr.ux + Math.cos(hd) * fr.uz) * 1.6 / Math.abs(Math.sin(hd) * fr.nx + Math.cos(hd) * fr.nz);
        if (Math.abs(strike) > dr.width / 2 + 0.3) continue;
        if (!cross(i, { inward, open, lateral, aim })) failures.push(`${sim.collision.doors[i].id} ${inward ? 'in' : 'out'} ${open ? 'open' : 'shut'} lat ${lateral} aim ${aim}`);
      }
    }
  }
  assert.deepEqual(failures.slice(0, 8), []);
});

test('a door closed with her standing in its way still shuts: she steps clear', () => {
  const idle = input();
  const probe = new GameSim({ seed: 7, difficulty: 'easy', skipIntro: true });
  const failures = [];
  for (let i = 0; i < probe.collision.doors.length; i++) {
    for (const [a, b] of [[0, 0.5], [0.3, 0.8], [-0.3, 0.8], [0, 0.05], [0.2, 1.1], [-0.4, 0.4]]) {
      const sim = new GameSim({ seed: 7, difficulty: 'easy', skipIntro: true });
      sim.killer.update = () => {}; Object.assign(sim.killer, { x: 150, z: 150, state: 'wait' });
      const d = sim.collision.doors[i]; d.open = true; d.motion = null;
      const f = doorFrame(d), p = sim.player;
      p.x = d.x + f.ux * a + f.nx * b; p.z = d.z + f.uz * a + f.nz * b; p.yaw = Math.atan2(d.x - p.x, d.z - p.z);
      if (sim.collision.blocked(p.x, p.z, 0.3) || sim.findInteraction()?.kind !== 'door') continue;
      sim.step(DT, { ...idle, action: true });
      for (let t = 0; t < 2.5; t += DT) sim.step(DT, idle);
      if (d.open || sim.collision.doorAmount(d) > 0.01) failures.push(`${d.id} at ${a},${b}`);
      assert.equal(sim.collision.blocked(p.x, p.z, 0.3 - 1e-6), false, `${d.id}: she is not left inside the door`);
    }
  }
  assert.deepEqual(failures, []);
});

test('she leaves brush the way she was looking, and only brush', () => {
  const sim = new GameSim({ seed: 7, difficulty: 'easy', skipIntro: true });
  sim.killer.update = () => {}; Object.assign(sim.killer, { x: 150, z: 150, state: 'wait' });
  const bush = sim.hides.find((h) => h.type === 'bush'), closet = sim.hides.find((h) => h.type !== 'bush');
  const p = sim.player;
  p.hidden = bush; p.x = bush.x; p.z = bush.z; p.yaw = 0.4;
  sim.step(DT, { ...input(), action: true, leaveYaw: -2.1 });
  assert.equal(p.hidden, null); assert.equal(p.yaw, -2.1);
  p.hidden = closet; p.yaw = 0.4;
  sim.step(DT, { ...input(), action: true, leaveYaw: -2.1 });
  assert.equal(p.hidden, null); assert.equal(p.yaw, 0.4);
});

test('closing a door while still pushing the stick does not bounce it open again', () => {
  const probe = new GameSim({ seed: 7, difficulty: 'easy', skipIntro: true });
  const failures = [];
  for (let i = 0; i < probe.collision.doors.length; i++) {
    for (const [a, b] of [[0, 0.05], [0, 0.4], [0.2, 0.8], [0, -0.1]]) for (const dir of [1, -1]) for (const run of [false, true]) {
      const sim = new GameSim({ seed: 7, difficulty: 'easy', skipIntro: true });
      sim.killer.update = () => {}; Object.assign(sim.killer, { x: 150, z: 150, state: 'wait' });
      const d = sim.collision.doors[i]; d.open = true; d.motion = null;
      const f = doorFrame(d), p = sim.player, events = [];
      p.x = d.x + f.ux * a + f.nx * b; p.z = d.z + f.uz * a + f.nz * b; p.yaw = Math.atan2(d.x - p.x, d.z - p.z);
      if (sim.collision.blocked(p.x, p.z, 0.3) || sim.findInteraction()?.kind !== 'door') continue;
      const heading = Math.atan2(f.nx * dir, f.nz * dir), held = { ...input(), camYaw: heading, moveY: 1, run };
      sim.step(DT, { ...held, action: true });
      for (let t = 0; t < 2.5; t += DT) { sim.step(DT, held); for (const e of sim.events.splice(0)) if (/door/i.test(e.t)) events.push(e.t); }
      const along = (p.x - d.x) * f.nx + (p.z - d.z) * f.nz;
      // Pushing in: she ends inside with the door shut behind her. Pushing out from the room she walks
      // back into the shut door and bumps it open, as a shut door always has; that is not a bounce.
      if (dir > 0 && (d.open || along < 0.3)) failures.push(`${d.id} at ${a},${b} ${run ? 'run' : 'walk'} in: open ${d.open} along ${along.toFixed(2)} ${events}`);
    }
  }
  assert.deepEqual(failures.slice(0, 6), []);
});


test('a door she shut stays shut when she walks past it or slides along it, and opens again on E', () => {
  const probe = new GameSim({ seed: 7, difficulty: 'easy', skipIntro: true });
  const failures = [];
  for (let i = 0; i < probe.collision.doors.length; i++) {
    for (const depth of [0.5, 1.0, 1.6]) for (const turn of [0.6, 0.8, 1.0, 1.3, -0.6, -0.8, -1.0, -1.3]) {
      const sim = new GameSim({ seed: 7, difficulty: 'easy', skipIntro: true });
      sim.killer.update = () => {}; Object.assign(sim.killer, { x: 150, z: 150, state: 'wait' });
      const d = sim.collision.doors[i]; d.open = true; d.motion = null;
      const f = doorFrame(d), p = sim.player;
      p.x = d.x + f.nx * depth; p.z = d.z + f.nz * depth; p.yaw = Math.atan2(-f.nx, -f.nz);
      if (sim.collision.blocked(p.x, p.z, 0.3) || sim.findInteraction()?.kind !== 'door') continue;
      sim.step(DT, { ...input(), action: true });
      for (let t = 0; t < 1.2; t += DT) sim.step(DT, input());
      if (d.open) { failures.push(`${d.id} depth ${depth}: did not shut`); continue; }
      // Head back at the door's wall on a slant (turn = radians off square), as an arrow key does
      // in a room whose camera sits in a corner.
      const heading = Math.atan2(-f.nx, -f.nz) + turn;
      for (let t = 0; t < 2.5; t += DT) sim.step(DT, { ...input(), camYaw: heading, moveY: 1 });
      const along = (p.x - d.x) * f.nx + (p.z - d.z) * f.nz;
      if (d.open || along < 0) failures.push(`${d.id} depth ${depth} turn ${turn}: open ${d.open} along ${along.toFixed(2)}`);
    }
  }
  assert.deepEqual(failures.slice(0, 6), []);
  // And E opens it again from where she stands.
  const sim = new GameSim({ seed: 7, difficulty: 'easy', skipIntro: true });
  sim.killer.update = () => {}; Object.assign(sim.killer, { x: 150, z: 150, state: 'wait' });
  const d = sim.collision.doors[0], f = doorFrame(d), p = sim.player;
  d.open = false; d.latched = true; p.x = d.x + f.nx * 1.0; p.z = d.z + f.nz * 1.0; p.yaw = Math.atan2(-f.nx, -f.nz);
  assert.equal(sim.findInteraction()?.label, 'OPEN DOOR');
  sim.step(DT, { ...input(), action: true });
  assert.equal(d.open, true); assert.equal(d.latched, false);
});

test('walking along a wall past an open or shut door does not pull her into it', () => {
  const probe = new GameSim({ seed: 7, difficulty: 'easy', skipIntro: true });
  const failures = [];
  for (let i = 0; i < probe.collision.doors.length; i++) for (const open of [true, false]) for (const dir of [1, -1]) for (const depth of [0.9, 1.4]) {
    const sim = new GameSim({ seed: 7, difficulty: 'easy', skipIntro: true });
    sim.killer.update = () => {}; Object.assign(sim.killer, { x: 150, z: 150, state: 'wait' });
    const d = sim.collision.doors[i]; d.open = open; d.motion = null;
    const f = doorFrame(d), p = sim.player;
    // Start to one side, inside the room, and walk parallel to the wall with a slight lean toward it.
    p.x = d.x + f.nx * depth - f.ux * dir * 1.8; p.z = d.z + f.nz * depth - f.uz * dir * 1.8;
    if (sim.collision.blocked(p.x, p.z, 0.3)) continue;
    const heading = Math.atan2(f.ux * dir - f.nx * 0.15, f.uz * dir - f.nz * 0.15);
    let least = depth;
    for (let t = 0; t < 1.3; t += DT) { sim.step(DT, { ...input(), camYaw: heading, moveY: 1 }); least = Math.min(least, (p.x - d.x) * f.nx + (p.z - d.z) * f.nz); }
    if (least < 0.25 || d.open !== open) failures.push(`${d.id} ${open ? 'open' : 'shut'} dir ${dir} depth ${depth}: least depth ${least.toFixed(2)} open ${d.open}`);
  }
  assert.deepEqual(failures.slice(0, 6), []);
});
