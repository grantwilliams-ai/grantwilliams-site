import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {createPlayer} from '../src/characters/player.js';
import {GameSim} from '../src/sim/game.js';
import {BUILDINGS,localToWorld} from '../src/sim/layout.js';
import {Act2Sim} from '../src/act2/sim.js';

globalThis.document={createElement:()=>({getContext:()=>new Proxy({},{get:(o,k)=>o[k]||(()=>{})})})};
const rates=[20,60,120];
const oldRate={walk:v=>v/2.7,sneak:v=>v/1.6,run:v=>v/3.6};
const duty={walk:.5,sneak:.62,run:.355};
function residual(gait,speed,hz,old=false,turn=0){
 const f=createPlayer();if(old)f.animator.anims={...f.animator.anims,[gait]:{...f.animator.anims[gait],rate:oldRate[gait]}};
 f.setAnim(gait,{restart:true,fade:.001,phase:0,travelDriven:true});f.update(.001,{speed:0});const previous={};let travel=0,time=0;
 for(let i=0;i<hz*6;i++){
  f.root.rotation.y=turn*i/hz;f.root.position.x+=Math.sin(f.root.rotation.y)*speed/hz;f.root.position.z+=Math.cos(f.root.rotation.y)*speed/hz;f.update(1/hz,{speed});f.root.updateMatrixWorld(true);
  for(const [side,offset] of [['L',0],['R',.5]]){
   const ph=f.animator.cur.phase+offset,part=(ph%1)/duty[gait],cycle=Math.floor(ph),point=f.rig.b(`foot${side}`).getWorldPosition(new THREE.Vector3()),prev=previous[side];
   if(part>.15&&part<.8&&prev?.part>.15&&prev.part<.8&&cycle===prev.cycle){travel+=Math.hypot(point.x-prev.point.x,point.z-prev.point.z);time+=1/hz;}
   previous[side]={part,cycle,point};
  }
 }
 return travel/time;
}
for(const hz of rates)test(`actual counselor ankles slide less during middle stance at ${hz} Hz`,()=>{
 for(const [gait,speed] of [['walk',1.9],['walk',2.6],['sneak',1],['sneak',1.35]])for(const turn of [0,.2]){
  const before=residual(gait,speed,hz,true,turn),after=residual(gait,speed,hz,false,turn);
  assert.ok(after<before*.45,`${gait}/${speed}/${turn}: ${before} -> ${after}`);
 }
 assert.equal(residual('run',4.5,hz),residual('run',4.5,hz,true),'running cadence and pose remain unchanged');
});

test('variable travel advances visual phase by distance, independent of frame rate or root heading',()=>{
 for(const gait of ['walk','sneak']){
  const phase=[];
  for(const hz of rates){const f=createPlayer();f.setAnim(gait,{restart:true,fade:.001,phase:0,travelDriven:true});f.update(.001,{speed:0});let distance=0;
   for(let frame=0;frame<hz*2;frame++){const speed=frame<hz*.5?0:frame<hz?1:frame<hz*1.5?2:0;distance+=speed/hz;f.root.rotation.y=frame/hz;f.update(1/hz,{speed});}
   phase.push(f.animator.cur.phase);assert.ok(Math.abs(phase.at(-1)-f.animator.cur.def.rate(distance,f.animator.cur))<1e-10);const frozen=phase.at(-1);for(let i=0;i<20;i++)f.update(0,{speed:2});assert.equal(f.animator.cur.phase,frozen);
  }
  assert.ok(Math.max(...phase)-Math.min(...phase)<1e-10);
 }
});

function renderPlayer(f,p,act2,dt){
 const name=act2?(p.hidden?'hide':p.speed>.1?(p.run||p.gait==='jog'?'run':p.gait==='sneak'?'sneak':'walk'):'idle'):(p.moveMode||'idle');
 f.root.position.set(p.x,p.y||0,p.z);f.root.rotation.y=p.yaw;f.setAnim(name,{travelDriven:true});f.update(dt,{speed:p.speed});
}
for(const hz of rates)test(`both player adapters stop stepping when real collision blocks travel at ${hz} Hz`,()=>{
 const s=new GameSim({seed:42,skipIntro:true}),b=BUILDINGS.find(b=>b.id==='cabin2'),d=s.collision.doors.find(d=>d.id==='cabin2.d0'),f=createPlayer();
 d.open=true;[s.player.x,s.player.z]=localToWorld(b,-1.3,3.3);s.killer.x=120;s.killer.z=100;
 let stopped=0,lastPhase=null;
 for(let i=0;i<hz*3;i++){s.updatePlayer(1/hz,{moveX:0,moveY:1,camYaw:Math.PI/2+b.rot,run:false,sneak:false});renderPlayer(f,s.player,false,1/hz);if(i>hz*2){assert.ok(s.player.speed<1e-6);if(lastPhase!==null)assert.equal(f.animator.cur.phase,lastPhase);lastPhase=f.animator.cur.phase;stopped++;}}
 assert.ok(stopped>0);
 const a=new Act2Sim({arrivalTime:10000}),g=createPlayer();Object.assign(a.p,{x:2.3,z:42.5});lastPhase=null;
 for(let i=0;i<hz*3;i++){a.movePlayer(1/hz,{moveZ:1,run:true});renderPlayer(g,a.p,true,1/hz);if(i>hz*2){assert.ok(a.p.speed<1e-6);if(lastPhase!==null)assert.equal(g.animator.cur.phase,lastPhase);lastPhase=g.animator.cur.phase;}}
});

test('walk, sneak and run changes retain continuous phase and 03G interrupted pose handling',()=>{
 const f=createPlayer();f.setAnim('walk',{restart:true,fade:.001,phase:.37,travelDriven:true});f.update(.4,{speed:1.9});
 for(const name of ['sneak','run','walk','sneak']){
  const phase=f.animator.cur.phase;f.setAnim(name,{fade:.3,travelDriven:true});assert.equal(f.animator.cur.phase,phase);f.update(.04,{speed:1.35});
  const pose=f.animator.appliedPose.a.slice(),beforePhase=f.animator.cur.phase;f.setAnim(name==='walk'?'sneak':'walk',{fade:.3,travelDriven:true});f.update(0,{speed:1.35});assert.deepEqual(f.animator.appliedPose.a,pose);assert.equal(f.animator.cur.phase,beforePhase);
 }
});


test('same-name live-to-film and film-to-live handoffs switch cadence without altering authored clocks',()=>{
 for(const gait of ['walk','sneak']){
  const f=createPlayer();f.setAnim(gait,{restart:true,fade:.001,phase:0});f.update(.2,{speed:1.3});
  assert.ok(Math.abs(f.animator.cur.phase-oldRate[gait](1.3)*.2)<1e-12,'ordinary authored motion keeps its old rate');
  const firstPhase=f.animator.cur.phase,time=f.animator.cur.t;
  f.setAnim(gait,{travelDriven:true});f.update(.1,{speed:1.3});
  const liveRate=f.animator.cur.def.rate(1.3,f.animator.cur);assert.ok(liveRate>oldRate[gait](1.3));assert.ok(Math.abs(f.animator.cur.phase-firstPhase-liveRate*.1)<1e-12);assert.ok(Math.abs(f.animator.cur.t-time-.1)<1e-12);
  const livePhase=f.animator.cur.phase;f.setAnim(gait);f.update(.1,{speed:1.3});
  assert.ok(Math.abs(f.animator.cur.phase-livePhase-oldRate[gait](1.3)*.1)<1e-12,'same-name film request clears live opt-in');
 }
});
