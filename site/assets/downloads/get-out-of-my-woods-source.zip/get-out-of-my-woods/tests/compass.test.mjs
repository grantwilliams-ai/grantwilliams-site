import test from 'node:test';
import assert from 'node:assert/strict';
import { headingDegrees, bearingDegrees, markerOffset } from '../src/ui/compass.js';
import { COMPASS_TARGET, THREAT_NEAR } from '../src/game/compass-target.js';
import { CAR } from '../src/sim/layout.js';

const near = (a, b, eps = 1e-6) => Math.abs(a - b) < eps || Math.abs(Math.abs(a - b) - 360) < eps;

test('the heading follows the map: +x is east, +z is south', () => {
  assert.ok(near(headingDegrees(0), 180)); // yaw 0 faces +z
  assert.ok(near(headingDegrees(Math.PI / 2), 90)); // +x
  assert.ok(near(headingDegrees(Math.PI), 0)); // -z
  assert.ok(near(headingDegrees(-Math.PI / 2), 270)); // -x
  for (const yaw of [-9, -1, 0, 2.5, 7, 40]) { const h = headingDegrees(yaw); assert.ok(h >= 0 && h < 360); }
});

test('a bearing points at the place, from wherever the player stands', () => {
  assert.ok(near(bearingDegrees(0, 0, 10, 0), 90));
  assert.ok(near(bearingDegrees(0, 0, 0, -10), 0));
  assert.ok(near(bearingDegrees(0, 0, 0, 10), 180));
  assert.ok(near(bearingDegrees(5, 5, -5, 5), 270));
  assert.ok(near(bearingDegrees(0, 0, 10, -10), 45));
});

test('the marker rides the tape and waits at the edge when the place is off to the side or behind', () => {
  assert.deepEqual(markerOffset(90, 100, 60), { degrees: 10, off: 0 });
  assert.deepEqual(markerOffset(350, 10, 60), { degrees: 20, off: 0 }); // across north
  assert.deepEqual(markerOffset(10, 350, 60), { degrees: -20, off: 0 });
  assert.deepEqual(markerOffset(0, 120, 60), { degrees: 60, off: 1 });
  assert.deepEqual(markerOffset(0, 200, 60), { degrees: -60, off: -1 }); // behind, nearer on the left
});

test('the compass marks the car only when the objective is the car', () => {
  const sim = (over) => ({ phase: 'play', has: { keys: false, battery: false }, batteryIn: false, ...over });
  assert.equal(COMPASS_TARGET(sim({ phase: 'intro' })), CAR);
  assert.equal(COMPASS_TARGET(sim({})), null);
  assert.equal(COMPASS_TARGET(sim({ has: { keys: true, battery: false } })), null);
  assert.equal(COMPASS_TARGET(sim({ has: { keys: false, battery: true } })), null);
  assert.equal(COMPASS_TARGET(sim({ has: { keys: true, battery: true } })), CAR.hood);
  assert.equal(COMPASS_TARGET(sim({ has: { keys: true, battery: true }, batteryIn: true })), CAR.door);
  assert.equal(COMPASS_TARGET(sim({ phase: 'car', has: { keys: true, battery: true }, batteryIn: true })), null);
});

test('the weather sinks only when he is near', () => {
  assert.equal(THREAT_NEAR(60), 0);
  assert.equal(THREAT_NEAR(32), 0);
  assert.equal(THREAT_NEAR(8), 1);
  assert.equal(THREAT_NEAR(2), 1);
  assert.ok(THREAT_NEAR(20) > 0.4 && THREAT_NEAR(20) < 0.6);
});
