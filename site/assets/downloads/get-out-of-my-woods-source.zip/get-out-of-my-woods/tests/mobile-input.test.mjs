import test, {afterEach} from 'node:test';
import assert from 'node:assert/strict';
import {createInputState,bindInput} from '../src/ui/input.js';

const original={window:globalThis.window,document:globalThis.document,performance:globalThis.performance},fixtures=[];
class Surface {
  constructor(tag='div',parent=null){this.tag=tag;this.parent=parent;this.listeners=new Map();this.dataset={};this.style={};this.attrs={};this.captures=new Set();this.classes=new Set();this.classList={add:n=>this.classes.add(n),remove:n=>this.classes.delete(n),toggle:(n,on)=>on?this.classes.add(n):this.classes.delete(n)};}
  addEventListener(type,fn){if(!this.listeners.has(type))this.listeners.set(type,new Set());this.listeners.get(type).add(fn);}
  removeEventListener(type,fn){this.listeners.get(type)?.delete(fn);}
  fire(type,e){for(const fn of [...(this.listeners.get(type)||[])])fn(e);return e;}
  closest(selector){for(let el=this;el;el=el.parent)for(const s of selector.split(','))if(s===el.tag||(s==='[data-touch]'&&el.dataset.touch)||(s==='[contenteditable]'&&el.attrs.contenteditable))return el;return null;}
  querySelector(s){return this.queries?.[s]||null;}
  getBoundingClientRect(){return {left:0,top:0,width:844,height:390};}
  setAttribute(k,v){this.attrs[k]=v;}
  removeAttribute(k){delete this.attrs[k];}
  setPointerCapture(id){this.captures.add(id);}
  releasePointerCapture(id){if(this.captures.delete(id))this.win.fire('lostpointercapture',{target:this,pointerId:id,preventDefault(){}});}
  get count(){return [...this.listeners.values()].reduce((n,s)=>n+s.size,0);}
}
function fixture({pointer=true}={}){
  const win=new Surface(),doc=new Surface(),root=new Surface(),game=new Surface(),touch=new Surface(),run=new Surface('button',root),action=new Surface('button',root),light=new Surface('button',root);
  for(const node of [win,doc,root,game,touch,run,action,light])node.win=win;
  run.dataset.touch='run';action.dataset.touch='action';light.dataset.touch='light';touch.queries={'.tbtn-run':run};
  win.innerWidth=844;win.matchMedia=()=>({matches:false});if(pointer)win.PointerEvent=class {};
  doc.pointerLockElement=null;doc.getElementById=id=>id==='game'?game:root;
  const f={win,doc,root,game,touch,run,action,light,time:0,playing:true,blocked:false,lightCalls:[]};
  globalThis.window=win;globalThis.document=doc;globalThis.performance={now:()=>f.time};
  const input=f.input=createInputState(),ctx=f.ctx={uiRoot:root,touchEl:touch,gameEl:game,dragLook:true,playing:()=>f.playing,blocked:()=>f.blocked,touchOn:()=>f.playing,onLight:on=>f.lightCalls.push(on)};
  f.io=bindInput(input,ctx);
  f.event=(type,target,props={},route=[win])=>{const e={target,button:0,timeStamp:f.time,defaultPrevented:false,preventDefault(){this.defaultPrevented=true;},...props};for(const node of route)node.fire(type,e);return e;};
  f.down=(target,id,x=40,y=200)=>f.event('pointerdown',target,{pointerId:id,clientX:x,clientY:y},[target===game?game:root,doc,win]);
  f.move=(id,x,y)=>f.event('pointermove',game,{pointerId:id,clientX:x,clientY:y});
  f.end=(id,type='pointerup')=>f.event(type,game,{pointerId:id});
  f.touchEvent=(type,target,points)=>f.event(type,target,{changedTouches:points},[target===game?game:root,doc,win]);
  f.point=(identifier,target,x=40,y=200)=>({identifier,target,clientX:x,clientY:y});
  fixtures.push(f);return f;
}
afterEach(()=>{for(const f of fixtures.splice(0))f.io.dispose();Object.assign(globalThis,original);});

test('PointerEvent browsers preserve250ms native menu taps and drags without a competing touch fallback',()=>{
  const f=fixture();f.blocked=true;f.playing=false;
  for(const tag of ['button','input','div']){
    const control=new Surface(tag,f.root),target=tag==='button'?new Surface('span',control):control;
    const p=f.point(3,target),events=[f.down(target,3),f.touchEvent('touchstart',target,[p])];
    f.time+=250;events.push(f.touchEvent('touchmove',target,[{...p,clientY:240}]),f.end(3),f.touchEvent('touchend',target,[p]));
    assert.ok(events.every(e=>!e.defaultPrevented),'native click, slider and menu scroll must remain available after a slow touch');
  }
  for(const surface of [f.root,f.game,f.doc,f.win])for(const type of ['touchstart','touchmove','touchend','touchcancel'])assert.equal(surface.listeners.get(type)?.size||0,0);
  assert.deepEqual(f.input,createInputState());
});

test('movement plus RUN/light/action handles each pointer once despite delayed compatibility touch events',()=>{
  const f=fixture(),p=f.point(1,f.game);
  f.down(f.game,1);f.move(1,40,144);assert.equal(f.input.moveY,1);
  f.down(f.run,2);f.touchEvent('touchstart',f.run,[f.point(2,f.run)]);
  f.time+=250;f.touchEvent('touchend',f.run,[f.point(2,f.run)]);f.end(2);assert.equal(f.input.run,true);
  f.down(f.light,4);f.touchEvent('touchstart',f.light,[f.point(4,f.light)]);f.time+=250;f.touchEvent('touchend',f.light,[f.point(4,f.light)]);f.end(4);assert.equal(f.lightCalls.length,1);
  f.down(f.action,3);assert.equal(f.input.action,true);assert.equal(f.input.actionHeld,true);f.input.action=false;
  f.touchEvent('touchstart',f.action,[f.point(3,f.action)]);f.time+=250;f.touchEvent('touchmove',f.game,[p]);f.move(1,40,144);
  assert.equal(f.input.action,false);assert.equal(f.input.actionHeld,true);assert.equal(f.input.moveY,1);assert.equal(f.input.run,true);
  f.end(3);assert.equal(f.input.actionHeld,false);assert.equal(f.input.moveY,1);f.end(1);assert.equal(f.input.moveY,0);assert.equal(f.input.run,false);
  f.down(f.run,9);f.down(f.run,9);assert.equal(f.input.run,true,'a duplicate bubbled pointerdown cannot toggle RUN twice');
});

test('releasing one action finger preserves another finger and heldE, including cancellation/capture loss',()=>{
  const f=fixture();f.down(f.action,1);f.down(f.action,2);f.input.action=false;
  f.end(1,'pointercancel');assert.equal(f.input.actionHeld,true);assert.equal(f.action.classes.has('is-down'),true);
  f.event('keydown',f.game,{code:'KeyE'});f.action.releasePointerCapture(2);
  assert.equal(f.input.actionHeld,true,'keyboard still owns action');assert.equal(f.action.classes.has('is-down'),false);
  f.event('keyup',f.game,{code:'KeyE'});assert.equal(f.input.actionHeld,false);
  f.end(2);assert.equal(f.input.actionHeld,false,'duplicate release is harmless');
});

test('lost movement capture clears movement/run and reset releases all captures without stale gameplay holds',()=>{
  const f=fixture();f.down(f.game,1);f.move(1,40,144);f.down(f.run,2);f.end(2);f.down(f.action,3);
  f.touch.releasePointerCapture(1);assert.equal(f.input.moveY,0);assert.equal(f.input.run,false);assert.equal(f.input.actionHeld,true);
  f.down(f.game,4);f.move(4,40,144);f.io.resetPointers();assert.deepEqual(f.input,createInputState());
  assert.equal(f.touch.captures.size+f.action.captures.size+f.run.captures.size,0);assert.equal(f.action.classes.has('is-down'),false);
  f.move(4,40,120);f.end(3);assert.deepEqual(f.input,createInputState());
});

test('legacy touch fallback leaves slow menu taps, sliders, scrolling and unowned endings native',()=>{
  const f=fixture({pointer:false});f.blocked=true;f.playing=false;
  for(const tag of ['button','input','div']){
    const control=new Surface(tag,f.root),p=f.point(5,control),start=f.touchEvent('touchstart',control,[p]);
    f.time+=350;const move=f.touchEvent('touchmove',control,[{...p,clientY:240}]),end=f.touchEvent('touchend',control,[p]);
    assert.ok(!start.defaultPrevented&&!move.defaultPrevented&&!end.defaultPrevented,tag+' keeps native behavior');
  }
  f.blocked=false;f.playing=true;const control=new Surface('button',f.root),p=f.point(6,control);
  assert.equal(f.touchEvent('touchstart',control,[p]).defaultPrevented,false,'a native help button is not a joystick even during play');
  assert.equal(f.touchEvent('touchcancel',control,[p]).defaultPrevented,false);assert.deepEqual(f.input,createInputState());
});

test('legacy multitouch uses eachTouch target and releases only owned identifiers on end/cancel/reset',()=>{
  const f=fixture({pointer:false}),stick=f.point(1,f.game),action=f.point(2,f.action);
  assert.equal(f.touchEvent('touchstart',f.game,[stick,action]).defaultPrevented,true);
  f.touchEvent('touchmove',f.game,[{...stick,clientY:144}]);assert.equal(f.input.moveY,1);assert.equal(f.input.actionHeld,true);
  f.input.action=false;f.touchEvent('touchstart',f.run,[f.point(3,f.run)]);f.time+=250;f.touchEvent('touchend',f.run,[f.point(3,f.run)]);
  assert.equal(f.input.run,true);assert.equal(f.input.action,false);assert.equal(f.input.actionHeld,true);
  f.touchEvent('touchstart',f.action,[f.point(4,f.action)]);f.touchEvent('touchcancel',f.action,[action]);assert.equal(f.input.actionHeld,true);
  f.touchEvent('touchend',f.action,[f.point(4,f.action)]);assert.equal(f.input.actionHeld,false);assert.equal(f.input.moveY,1);
  f.touchEvent('touchcancel',f.game,[stick]);assert.equal(f.input.moveY,0);assert.equal(f.input.run,false);
  f.touchEvent('touchstart',f.game,[stick]);f.touchEvent('touchmove',f.game,[{...stick,clientY:144}]);f.io.resetPointers();
  assert.equal(f.touchEvent('touchend',f.game,[stick]).defaultPrevented,false,'reset clears legacy ownership');assert.deepEqual(f.input,createInputState());
});

test('keyboard action releases after prompt focus changes and disposal prevents chapter input leaking',()=>{
  const f=fixture();f.event('keydown',f.action,{code:'Enter'});assert.equal(f.input.actionHeld,true);
  f.event('keyup',f.game,{code:'Enter'});assert.equal(f.input.actionHeld,false);
  f.down(f.game,1);f.move(1,40,144);f.down(f.action,2);f.io.dispose();f.io.dispose();
  assert.equal([f.win,f.doc,f.root,f.game].reduce((n,s)=>n+s.count,0),0);assert.deepEqual(f.input,createInputState());
  f.down(f.run,3);f.touchEvent('touchstart',f.action,[f.point(4,f.action)]);assert.deepEqual(f.input,createInputState());
});
