// Ordinary fresh-spawn input routes; no actor placement or forced AI state.
import test from 'node:test';
import assert from 'node:assert/strict';
import {GameSim} from '../src/sim/game.js';
import {BUILDINGS,LAYOUT} from '../src/sim/layout.js';
const DT=1/30,IDLE={moveX:0,moveY:0,camYaw:0,run:false,action:false,actionHeld:false};
function play(seed,difficulty,scenario){
 const s=new GameSim({seed,difficulty});const p=s.player,k=s.killer;
 const rec={seed,difficulty,scenario,firstHunt:null,firstVisible:null,firstNearAudible:null,firstChase:null,buildingApproaches:[],trace:[],maxStep:0,route:[]};
 const seenBuildings=new Set();let prior=k.state,clocks=0;
 function tick(input=IDLE){
  const x=k.x,z=k.z;s.step(DT,input);clocks++;
  if(s.phase==='play')rec.maxStep=Math.max(rec.maxStep,Math.hypot(k.x-x,k.z-z));
  const d=Math.hypot(k.x-p.x,k.z-p.z),op=s.collision.sightOpacity(k.x,k.z,p.x,p.z);
  if(rec.firstVisible===null&&d<35&&op<1)rec.firstVisible=+s.time.toFixed(2);
  for(const b of BUILDINGS)if(!seenBuildings.has(b.id)&&Math.hypot(k.x-b.x,k.z-b.z)<10){seenBuildings.add(b.id);rec.buildingApproaches.push({building:b.id,time:+s.time.toFixed(2)});}
  const events=s.drainEvents();
  for(const e of events){
   if(e.t==='huntStarted')rec.firstHunt=+s.time.toFixed(2);
   if(e.t==='spotted'&&rec.firstChase===null)rec.firstChase=+s.time.toFixed(2);
   if(rec.firstNearAudible===null&&(['killerStep','killerBreath','ting'].includes(e.t)||(['doorOpen','doorBash'].includes(e.t)&&e.killer))&&Math.hypot(e.x-p.x,e.z-p.z)<18)rec.firstNearAudible={time:+s.time.toFixed(2),event:e.t,distance:+Math.hypot(e.x-p.x,e.z-p.z).toFixed(1)};
   if(['huntStarted','spotted','hide','hideSeen','lost','evaded','death','doorBash'].includes(e.t))rec.trace.push({time:+s.time.toFixed(2),event:e.t,state:k.state,player:[+p.x.toFixed(1),+p.z.toFixed(1)],killer:[+k.x.toFixed(1),+k.z.toFixed(1)]});
  }
  if(k.state!==prior){prior=k.state;}
  return s.phase!=='dead'&&clocks<600/DT;
 }
 function route(x,z,run=false){
  const path=s.nav.findPath(p.x,p.z,x,z);if(!path)return false;
  for(const [tx,tz]of path){let n=0;while(Math.hypot(tx-p.x,tz-p.z)>.5&&n++<1800){if(!tick({...IDLE,run,moveY:1,camYaw:Math.atan2(tx-p.x,tz-p.z)}))return false;}if(n>=1800)return false;}
  rec.route.push({time:+s.time.toFixed(2),at:[+p.x.toFixed(1),+p.z.toFixed(1)]});return true;
 }
 function wait(seconds){for(let i=0;i<seconds/DT;i++)if(!tick())return false;return true;}
 if(scenario==='user-route'){
  route(-3,-25);wait(12);
  if(s.phase!=='dead')route(-15,-64);
  if(s.phase!=='dead')wait(18);
  if(s.phase!=='dead')route(-33,43);
  if(s.phase!=='dead')route(-32,58);
  if(s.phase!=='dead')wait(120);
 }else if(scenario==='cabin2-closed'){
  const b=BUILDINGS.find(b=>b.id==='cabin2'),d=LAYOUT.doors.find(d=>d.building===b.id),l=Math.hypot(b.x-d.x,b.z-d.z);
  route(d.x+(b.x-d.x)/l*.9,d.z+(b.z-d.z)/l*.9);
  // This is the player's ordinary close-door action, not a collision edit.
  if(s.findInteraction()?.kind==='door')tick({...IDLE,action:true});
  route(b.x,b.z);wait(180);
 }else if(['mess-wait','boathouse-wait','dock-wait'].includes(scenario)){
  const target={'mess-wait':[-15,-64],'boathouse-wait':[-33,43],'dock-wait':[-32,58]}[scenario];route(...target);wait(180);
 }else if(scenario==='spawn-idle')wait(150);
 else if(scenario==='outer-walk'){
  for(let lap=0;lap<2&&s.phase!=='dead';lap++)for(const [x,z]of [[21,-19],[68,-36],[45,-80],[-14,-52],[-82,-72],[-84,13],[-33,33],[50,28]]){if(!route(x,z))break;}
 }
 rec.end={time:+s.time.toFixed(2),phase:s.phase,state:k.state,seen:s.stats.seen,stuck:s.stats.killerStuck,player:[p.x,p.z]};rec.maxStep=+rec.maxStep.toFixed(4);return rec;
}
test('fresh Cabin 2, mess hall and boathouse exploration produces physical encounters',t=>{
 const results=[];
 for(const difficulty of ['normal','hard'])for(const seed of [1000,1001])for(const scenario of ['user-route','cabin2-closed','mess-wait','boathouse-wait','dock-wait']){
  const r=play(seed,difficulty,scenario);const id=`${difficulty}/${seed}/${scenario}`;
  assert.ok(r.firstChase!==null&&r.firstChase<110,`${id}: real sight-triggered chase`);
  assert.ok(r.firstVisible!==null,`${id}: clear nearby sightline`);
  assert.ok(r.firstNearAudible!==null,`${id}: real nearby killer sound`);
  assert.equal(r.end.stuck,0,`${id}: no doorway stall`);
  assert.ok(r.maxStep<.21,`${id}: no hunt teleport`);
  results.push({difficulty,seed,scenario,firstChase:r.firstChase,firstVisible:r.firstVisible,firstNearAudible:r.firstNearAudible});
 }t.diagnostic(JSON.stringify(results));
});
