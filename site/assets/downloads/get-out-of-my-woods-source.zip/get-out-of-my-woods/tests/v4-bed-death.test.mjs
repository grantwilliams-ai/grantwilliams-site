import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { GameSim } from '../src/sim/game.js';
import { LAYOUT } from '../src/sim/layout.js';
import { surfaceY } from '../src/sim/terrain.js';
import { createKiller } from '../src/characters/killer.js';
import { polishKillerAppearance } from '../src/act2/killer.js';
import { createPlayer } from '../src/characters/player.js';
import { playDeath } from '../src/characters/death.js';
import { App } from '../src/game/app.js';
import { audio } from '../src/audio/index.js';

globalThis.document={createElement:()=>({getContext:()=>new Proxy({},{get:(o,k)=>o[k]||(()=>{})})})};

function discovered(type,building='cabin2') {
  const sim=new GameSim({skipIntro:true,seed:42}),h=sim.hides.find(h=>h.type===type&&(!building||h.building===building)),p=sim.player,k=sim.killer;
  assert.ok(h);Object.assign(p,{x:h.x,z:h.z,y:surfaceY(h.x,h.z),hidden:h,seenEntering:true});
  Object.assign(k,{x:h.x,z:h.z-1,checking:h,sawHide:h.id,state:'checkhide',timer:0});
  k.checkHide(.05);return {sim,h,event:sim.events.find(e=>e.t==='death')};
}

function fixture(id='cabin2.bed') {
  const h=LAYOUT.hides.find(h=>h.id===id),scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(62,16/9,.05,100),killer=polishKillerAppearance(createKiller()),player=createPlayer();
  scene.add(killer.root,player.root,camera);player.root.position.set(h.x,surfaceY(h.x,h.z),h.z);
  camera.position.set(h.view.pos[0],surfaceY(h.view.pos[0],h.view.pos[2])+h.view.pos[1],h.view.pos[2]);
  camera.lookAt(h.view.look[0],surfaceY(h.view.look[0],h.view.look[2])+h.view.look[1],h.view.look[2]);
  const initial={position:camera.position.clone(),direction:camera.getWorldDirection(new THREE.Vector3()),fov:camera.fov},q=camera.quaternion.clone(),events=[],post=Object.fromEntries(['uRed','uTear','uFlash','uDesat','uLetterbox'].map(k=>[k,{value:0}]));
  const ctx={scene,camera,killer,player,post,ground:surfaceY,at:{x:initial.position.x,y:initial.position.y,z:initial.position.z,yaw:Math.atan2(initial.direction.x,initial.direction.z)},entryView:initial,hiding:{x:h.x,z:h.z},audioCue:n=>events.push(n),onReveal:()=>events.push('reveal'),onDone:()=>events.push('done'),clearLine:()=>.3};
  return {h,scene,camera,killer,player,initial,q,events,ctx};
}

test('actual cabin bed discovery selects bed without changing closet or other cover routing',()=>{
  for(const building of ['cabin1','cabin2','cabin3']){const {sim,h,event}=discovered('bed',building);assert.equal(event.kind,'bed');assert.equal(sim.player.hidden,h);assert.equal(sim.phase,'dead');}
  assert.equal(discovered('closet').event.kind,'closet');assert.equal(discovered('bush',null).event.kind,'impale');
});

test('unseen bed checks retain the existing probability and miss behavior',()=>{
  for(const roll of [0,1]){
    const sim=new GameSim({skipIntro:true}),h=sim.hides.find(h=>h.id==='cabin2.bed'),k=sim.killer;
    Object.assign(sim.player,{hidden:h,seenEntering:false});Object.assign(k,{checking:h,sawHide:null,timer:0,state:'checkhide',rng:()=>roll});
    k.checkHide(.05);assert.equal(sim.phase==='dead',roll<k.tune.checkHide);
    if(roll===1)assert.ok(sim.events.some(e=>e.t==='hidechecked'));
  }
});

test('bed film keeps the original low viewpoint and invisible counselor across rotated cabins',()=>{
  const point=new THREE.Vector3(),hand=new THREE.Vector3(),fork=new THREE.Vector3(),axis=new THREE.Vector3();
  for(const id of ['cabin1.bed','cabin2.bed','cabin3.bed']){
    const f=fixture(id),playerAt=f.player.root.position.clone(),seq=playDeath('bed',f.ctx),actorAt=f.killer.root.position.clone();
    assert.ok(f.camera.position.distanceTo(f.initial.position)<1e-9);assert.ok(f.camera.quaternion.angleTo(f.q)<1e-6);assert.equal(f.player.root.visible,false);
    for(let i=0;i<330;i++){
      seq.update(1/60);assert.equal(f.player.root.visible,false);assert.ok(f.player.root.position.distanceTo(playerAt)<1e-9);
      assert.ok(Math.hypot(f.camera.position.x-f.initial.position.x,f.camera.position.z-f.initial.position.z)<.09,'camera stays beneath the same bunk');
      assert.ok(Math.abs(f.camera.position.y-f.initial.position.y)<.07);assert.ok(f.killer.root.position.distanceTo(actorAt)<1e-9,'no room relocation during film');
      f.killer.rig.b('fork').getWorldPosition(fork);axis.set(0,1,0).transformDirection(f.killer.rig.b('fork').matrixWorld);
      for(const side of seq.time>=2?['R','L']:['R']){
        f.killer.rig.b('hand'+side).getWorldPosition(hand);hand.sub(fork).addScaledVector(axis,-hand.dot(axis));
        assert.ok(hand.length()<.01,'hands hold the retracted fork and stay attached through the jab');
      }
      if(i===150){
        f.killer.headTop.getWorldPosition(point);assert.ok(point.y-surfaceY(actorAt.x,actorAt.z)<.85,'killer bends to peer below the bunk');
      }
      if(i%10===0){
        for(const mesh of f.killer.meshes)for(let v=0;v<mesh.geometry.attributes.position.count;v++){
          mesh.getVertexPosition(v,point).applyMatrix4(mesh.matrixWorld);assert.ok(point.y>=surfaceY(actorAt.x,actorAt.z)-.025,'full crouch descent stays above floor');
        }
      }
      if(i===223){f.killer.forkTines.getWorldPosition(point);assert.ok(point.distanceTo(f.initial.position)<.07,'low fork reaches the hiding eye at contact');}
    }
    assert.equal(seq.done,true);for(const event of ['reveal','fork_swing','fork_stab','done'])assert.equal(f.events.filter(e=>e===event).length,1);
    seq.restore();seq.restore();assert.equal(f.player.root.visible,true);assert.equal(f.camera.fov,62);assert.equal(f.camera.children.length,0);
    const before=f.events.length;seq.update(.1);assert.equal(f.events.length,before);
  }
});

test('early restore cancels reveal, attack, completion and disposable film effects',()=>{
  const f=fixture(),before=f.scene.children.length,seq=playDeath('bed',f.ctx);seq.update(.1);seq.restore();seq.restore();
  for(let i=0;i<100;i++)seq.update(.1);
  assert.equal(f.events.includes('reveal'),false);assert.equal(f.events.includes('done'),false);assert.equal(f.scene.children.length,before);assert.equal(f.player.root.visible,true);
});

test('the actual sack eye cuts read below the bunk while the fork waits behind the reveal',()=>{
  const point=new THREE.Vector3(),ray=new THREE.Raycaster();
  for(const id of ['cabin1.bed','cabin2.bed','cabin3.bed']){
    const f=fixture(id),seq=playDeath('bed',f.ctx);for(let i=0;i<150;i++)seq.update(1/60);
    f.camera.updateMatrixWorld(true);
    const floor=surfaceY(f.h.x,f.h.z),s=LAYOUT.solids.filter(s=>s.kind==='bunk'&&s.building===f.h.building)
      .sort((a,b)=>Math.hypot(a.x-f.initial.position.x,a.z-f.initial.position.z)-Math.hypot(b.x-f.initial.position.x,b.z-f.initial.position.z))[0];
    // Enclose the real lower plank and mattress, including a little extra width.
    const bed=new THREE.Mesh(new THREE.BoxGeometry(s.hx*2,.26,s.hz*2),new THREE.MeshBasicMaterial({side:THREE.DoubleSide}));
    bed.position.set(s.x,floor+.49,s.z);bed.rotation.y=s.rot;bed.updateMatrixWorld(true);
    const burlap=f.killer.meshes.find(m=>m.name==='killer-burlap'),g=burlap.geometry,eyes=[new THREE.Vector3(),new THREE.Vector3()],counts=[0,0];
    for(let i=0;i<g.attributes.position.count;i++){
      const c=g.attributes.color;if(c.getX(i)!==0||c.getY(i)!==0||c.getZ(i)!==0)continue;
      const side=g.attributes.position.getX(i)<0?0:1;
      burlap.getVertexPosition(i,point).applyMatrix4(burlap.matrixWorld);eyes[side].add(point);counts[side]++;
    }
    for(let i=0;i<2;i++){
      assert.ok(counts[i]>0);const eye=eyes[i].multiplyScalar(1/counts[i]);
      assert.ok(eye.y-floor>.12&&eye.y-floor<.35,'real eye opening sits beneath the .36m underside');
      ray.set(f.camera.position,point.subVectors(eye,f.camera.position).normalize());ray.far=eye.distanceTo(f.camera.position)-.005;
      assert.equal(ray.intersectObject(bed).length,0,'mattress cannot occlude the eye opening');
      point.copy(eye).project(f.camera);assert.ok(Math.abs(point.x)<.8&&Math.abs(point.y)<.8,'eye is within the reveal frame');
    }
    for(const mesh of f.killer.meshes)for(let i=0;i<mesh.geometry.attributes.position.count;i++){
      if(mesh.geometry.attributes.skinIndex.getX(i)!==f.killer.rig.idx.head)continue;
      mesh.getVertexPosition(i,point).applyMatrix4(mesh.matrixWorld);bed.worldToLocal(point);
      assert.ok(Math.abs(point.x)>s.hx||Math.abs(point.z)>s.hz||Math.abs(point.y)>.13,'sack crown stays outside the mattress');
    }
    f.killer.forkTines.getWorldPosition(point);assert.ok(point.distanceTo(f.initial.position)>.75,'inspection keeps the tines away from the lens');
    bed.geometry.dispose();bed.material.dispose();seq.restore();
  }
});

test('App stages a discovered bed in place, retains its overlay until reveal, and resumes the fatality after pause',()=>{
  const {sim,h,event}=discovered('bed'),f=fixture(),calls=[],app=Object.create(App.prototype),old=Object.fromEntries(['music','sfx','pauseAll','resumeAll'].map(k=>[k,audio[k]]));
  Object.assign(audio,{music(){},sfx(){},pauseAll(){},resumeAll(){}});
  const ui=new Proxy({setHide:x=>calls.push(['hide',x]),setPrompt:x=>calls.push(['prompt',x]),setTouchVisible:x=>calls.push(['touch',x])},{get:(o,k)=>o[k]||(()=>{})});
  Object.assign(app,{state:'play',sim,scene:f.scene,mainScene:f.scene,camera:f.camera,killer:f.killer,playerFig:f.player,post:f.ctx.post,ui,cine:{clear(){},blocking:false},rig:{zone:{}},quality:{isTouch:false},world:{clearStage:()=>assert.fail('bed must not clear the surrounding scene')},flash:{setOn(){},aim:new THREE.Vector3(),update(){}},from:new THREE.Vector3(),aim:new THREE.Vector3(),gameOver:()=>calls.push(['done'])});
  try{
    app.onDeath(event);assert.equal(app.deathSeq.kind,'bed');assert.equal(app.playerFig.root.visible,false);assert.deepEqual(calls[0],['hide','bed']);
    app.tickDead(.1);const time=app.deathSeq.time;app.pause();assert.equal(app.state,'paused');assert.equal(app.deathSeq.time,time);
    app.resume();assert.equal(app.state,'dead');assert.equal(app.deathSeq.time,time);assert.equal(calls.some(c=>c[0]==='touch'&&c[1]),false);
    for(let i=0;i<12;i++)app.tickDead(.1);assert.equal(app.deathHide,null);assert.ok(calls.some(c=>c[0]==='hide'&&c[1]===null));
    app.pause();app.resume();assert.equal(app.state,'dead');assert.equal(app.deathHide,null,'resume cannot bring the painted bunk overlay back after the reveal');
    app.deathSeq.restore();assert.equal(sim.player.hidden,h);assert.equal(calls.some(c=>c[0]==='done'),false);
  }finally{Object.assign(audio,old);}
});
