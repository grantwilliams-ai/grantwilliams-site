import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { createPlayer } from '../src/characters/player.js';
import { createAct2Killer } from '../src/act2/killer.js';
import { clearSegment } from '../src/act2/sim.js';
import { createEscapeScene, ESCAPE_SCENE, sampleEscapeScene, sampleEscapePursuit, escapeApproach } from '../src/act2/escape-scene.js';

// Real player/sackhead skeletons and camera geometry; no browser or GPU.
globalThis.document = { createElement:()=>({getContext:()=>({fillRect(){},beginPath(){},ellipse(){},fill(){}})}) };
function fixture({obstacles=[],stagger=0}={}) {
  const scene = new THREE.Scene(),root = new THREE.Group(),van = new THREE.Group(),door = new THREE.Group(),wheel = new THREE.Group(),headlights=[new THREE.Group(),new THREE.Group()];
  scene.background = new THREE.Color(0x081217);scene.fog = new THREE.FogExp2(0x1d3034,.0075);scene.add(root);
  root.add(van);van.position.set(0,0,-118);van.add(door,wheel,...headlights);door.position.set(-1.45,0,-1.7);
  const hemi = new THREE.HemisphereLight(0x94a9b6,0x3d4030,1.03),moon = new THREE.DirectionalLight(0xa6becd,1.85);root.add(hemi,moon);
  const figure = createPlayer(),killerFigure = createAct2Killer();scene.add(figure.root,killerFigure.root);
  const player = {x:-3,z:-117,yaw:Math.PI/2},killer = {x:-4,z:-110,yaw:Math.PI,active:true,state:stagger?'stagger':'chase',stagger};
  figure.root.position.set(player.x,0,player.z);figure.root.rotation.y=player.yaw;killerFigure.root.position.set(killer.x,0,killer.z);
  const camera = new THREE.PerspectiveCamera(58,16/9,.08,210);camera.position.set(-5,2.8,-112);camera.lookAt(-1,1.2,-118);
  const sounds=[],music=[],events=[],loops=[];
  const audio = {sfx:(name,options)=>sounds.push({name,options}),music:name=>music.push(name),ambience(){},setIntensity(){},setRoom(){},setListener(){},loop(name){const handle={name,stopped:false,stop(){this.stopped=true;}};loops.push(handle);return handle;}};
  const app = {scene,camera,figure,killerFigure,heldCrowbar:{visible:true},flash:{visible:true},sim:{player,killer,obstacles},world:{root,van,escapeProps:{driverDoor:door,wheels:[wheel],headlights}},post:Object.fromEntries(['uRed','uDanger','uFade','uFlash','uLetterbox'].map(k=>[k,{value:0}])),say:(text,seconds)=>events.push({text,seconds})};
  return {app,scene:createEscapeScene(app,{audio}),sounds,music,events,loops,door,wheel,headlights,hemi,moon};
}

const advance=(scene,end)=>{while(scene.time+1e-8<end)scene.tick(Math.min(1/60,end-scene.time));scene.tick(end-scene.time);};

test('van lenses stay off before ignition, remain lit through completion, and reset off',()=>{
  const f=fixture(),{app,scene}=f,headlamp=app.world.van.children.find(o=>o.isSpotLight);
  assert.ok(f.headlights.every(lens=>!lens.visible),'creation forces initially bright world lenses off');
  scene.reset();assert.ok(f.headlights.every(lens=>!lens.visible),'reset without a shot is safe');
  scene.begin();advance(scene,5.64);assert.ok(f.headlights.every(lens=>!lens.visible));assert.equal(headlamp.visible,false);
  advance(scene,5.65);assert.ok(f.headlights.every(lens=>lens.visible));assert.equal(headlamp.visible,true);
  advance(scene,24);assert.ok(f.headlights.every(lens=>lens.visible),'lenses remain on at the completed ending');assert.equal(headlamp.visible,false,'real spotlight retains its final cutoff');
  scene.reset();assert.ok(f.headlights.every(lens=>!lens.visible),'replay and title reset the lenses off');
  scene.begin();advance(scene,5.64);assert.ok(f.headlights.every(lens=>!lens.visible));scene.skip();assert.ok(f.headlights.every(lens=>lens.visible));
  scene.dispose();assert.ok(f.headlights.every(lens=>!lens.visible));
});

test('escape timeline boards before ignition, moves after ignition, and ends alive in daylight',()=>{
  assert.equal(sampleEscapeScene(0).stage,'boarding');
  assert.equal(sampleEscapeScene(3.5).seated,true);assert.equal(sampleEscapeScene(3.5).distance,0);
  assert.equal(sampleEscapeScene(5.64).distance,0);assert.ok(Math.abs(sampleEscapeScene(6).door)<1e-9);
  assert.ok(sampleEscapeScene(9).distance>0);assert.equal(sampleEscapeScene(12).stage,'last-pursuit');
  assert.ok(sampleEscapeScene(18.4).distance>90);assert.ok(sampleEscapeScene(18.4).speed>6);
  const end=sampleEscapeScene(ESCAPE_SCENE.duration);assert.equal(end.stage,'survived');assert.equal(end.finished,true);assert.equal(end.exit,0);assert.equal(end.seated,true);assert.equal(end.fade,0);assert.ok(end.speed>6);assert.equal(end.dawn,1);assert.ok(Math.abs(end.door)<1e-9);
});

test('real counselor continuously boards and stays seated while van drives onto the public road',()=>{
  const f=fixture(),{app,scene}=f;const start=app.figure.root.position.clone();scene.begin();
  assert.ok(app.figure.root.position.distanceTo(start)<1e-9);
  let previous=app.figure.root.position.clone(),vanZ=app.world.van.position.z;
  for(let i=0;i<1440;i++){
    scene.tick(1/60);
    assert.equal(app.figure.root.visible,true);assert.ok(app.figure.root.position.toArray().every(Number.isFinite));
    assert.ok(app.figure.root.position.distanceTo(previous)<.35,'entry and road travel never teleport');
    assert.ok(app.world.van.position.z<=vanZ+1e-8,'van reaches the north road without reversing');
    if(scene.time>6.05)assert.ok(app.figure.root.position.distanceTo(previous)>.0001,'driving never stops before the final fade');
    if(scene.time>3.8)assert.ok(Math.abs(f.door.rotation.y)<1e-8,'door remains shut after boarding');
    assert.ok(app.camera.position.toArray().every(Number.isFinite));
    assert.ok(app.figure.rig.bones.every(b=>b.quaternion.toArray().every(Number.isFinite)));
    previous.copy(app.figure.root.position);vanZ=app.world.van.position.z;
  }
  app.world.van.updateMatrixWorld(true);const local=app.world.van.worldToLocal(app.figure.root.position.clone());
  assert.ok(local.distanceTo(new THREE.Vector3(-.65,.08,-.72))<1e-8,'survivor stays in driver seat');
  assert.ok(app.figure.rig.b('thighL').rotation.x<-1,'legs remain folded in the seat');
  assert.equal(app.post.uFade.value,0);assert.equal(app.world.van.position.z,-214);assert.ok(app.world.van.position.x>40&&app.world.van.position.x<46);
  assert.ok(f.events.some(e=>e.text==='You made it out.'));
  scene.dispose();
});

test('seated counselor faces the road and keeps head above the dashboard',()=>{
  const {app,scene}=fixture();scene.begin();advance(scene,4);
  const forward=new THREE.Vector3(0,0,1).applyQuaternion(app.figure.root.quaternion);
  assert.ok(forward.z<-.99);app.figure.root.updateMatrixWorld(true);
  const head=app.figure.rig.b('head').getWorldPosition(new THREE.Vector3());
  assert.ok(head.y>1.45&&head.y<2.1,`head height ${head.y}`);
  assert.ok(Math.abs(app.figure.root.position.x+.65)<1e-8);assert.ok(Math.abs(app.figure.root.position.z+118.72)<1e-8);
  assert.ok(app.figure.rig.b('thighL').rotation.x<-1,'legs are folded into the seat');scene.dispose();
});

test('normal escape cues fire once, pause holds clock, and skipped cues never play',()=>{
  const f=fixture();f.scene.begin();f.scene.tick(4);
  const clock=f.scene.time,count=f.sounds.length,pos=f.app.camera.position.clone();f.scene.tick(0);
  assert.equal(f.scene.time,clock);assert.equal(f.sounds.length,count);assert.ok(pos.distanceTo(f.app.camera.position)<1e-9);
  advance(f.scene,24);assert.equal(f.sounds.filter(s=>s.name==='engine_start').length,1);assert.equal(f.sounds.filter(s=>s.name==='crank_fail').length,1);
  assert.ok(f.loops.every(l=>l.stopped));f.scene.tick(1);assert.equal(f.sounds.filter(s=>s.name==='engine_start').length,1);f.scene.dispose();
  const skipped=fixture();skipped.scene.begin();skipped.scene.tick(.2);const played=skipped.sounds.length;skipped.scene.skip();
  assert.equal(skipped.sounds.length,played);assert.equal(skipped.scene.stage,'survived');assert.equal(skipped.app.post.uFade.value,0);assert.equal(skipped.app.figure.root.visible,true);assert.ok(skipped.loops.every(l=>l.stopped));skipped.scene.dispose();
});

test('reset restores night, camera, door, wheels, actor and van exactly after dawn',()=>{
  const f=fixture(),{app,scene}=f;
  const before={van:app.world.van.position.toArray(),player:app.figure.root.position.toArray(),door:f.door.quaternion.toArray(),wheel:f.wheel.quaternion.toArray(),background:app.scene.background.getHex(),fog:app.scene.fog.color.getHex(),density:app.scene.fog.density,hemi:f.hemi.color.getHex(),ground:f.hemi.groundColor.getHex(),camera:app.camera.position.toArray(),fov:app.camera.fov};
  app.post.uBrightness={value:1.12};scene.begin();app.post.uBrightness.value=1.4;advance(scene,2);assert.notDeepEqual(f.door.quaternion.toArray(),before.door);advance(scene,21);assert.notEqual(app.scene.background.getHex(),before.background);assert.notDeepEqual(f.wheel.quaternion.toArray(),before.wheel);
  scene.reset();assert.deepEqual(app.world.van.position.toArray(),before.van);assert.deepEqual(app.figure.root.position.toArray(),before.player);assert.deepEqual(f.door.quaternion.toArray(),before.door);assert.deepEqual(f.wheel.quaternion.toArray(),before.wheel);
  assert.equal(app.scene.background.getHex(),before.background);assert.equal(app.scene.fog.color.getHex(),before.fog);assert.equal(app.scene.fog.density,before.density);assert.equal(f.hemi.color.getHex(),before.hemi);assert.equal(f.hemi.groundColor.getHex(),before.ground);assert.deepEqual(app.camera.position.toArray(),before.camera);assert.equal(app.camera.fov,before.fov);
  assert.equal(app.post.uBrightness.value,1.4,'settings changed during a pause survive reset');assert.equal(app.heldCrowbar.visible,true);assert.equal(app.flash.visible,true);assert.equal(scene.time,0);assert.equal(scene.stage,null);assert.ok(f.loops.every(l=>l.stopped));scene.dispose();
});

test('pursuer approach keeps real position, cannot cross a wall, and respects a fresh four-second stun',()=>{
  const from={x:-4,z:-110},goal={x:-2.5,z:-118},wall={id:'wall',minX:-6,maxX:0,minZ:-114,maxZ:-113.7};
  const end=escapeApproach(from,goal,[wall]);assert.ok(clearSegment(from,end,.42,[wall]));assert.ok(end.z>=-113.28);
  assert.deepEqual(escapeApproach({x:0,z:0},goal,[]),{x:0,z:0},'boarding does not move a distant killer');
  const f=fixture({stagger:4});f.scene.begin();advance(f.scene,3.9);assert.equal(f.app.sim.killer.x,from.x);assert.equal(f.app.sim.killer.z,from.z);advance(f.scene,5.5);assert.ok(f.app.sim.killer.z<from.z);f.scene.dispose();
});

test('final motion and cues do not depend on frame size',()=>{
  const a=fixture(),b=fixture();a.scene.begin();b.scene.begin();advance(a.scene,14);
  for(let i=0;i<140;i++)b.scene.tick(.1);
  assert.ok(a.app.world.van.position.distanceTo(b.app.world.van.position)<1e-8);assert.ok(a.app.figure.root.position.distanceTo(b.app.figure.root.position)<1e-8);
  assert.deepEqual(a.sounds.map(s=>s.name),b.sounds.map(s=>s.name));a.scene.dispose();b.scene.dispose();
});

test('skip and a long final frame finish with the same seated driving pose as normal playback',()=>{
  const a=fixture(),b=fixture(),c=fixture();a.scene.begin();b.scene.begin();c.scene.begin();
  advance(a.scene,24);b.scene.skip();advance(c.scene,21.9);c.scene.tick(24);
  for(const name of ['pelvis','spine','chest','head','thighL','thighR','shinL','shinR','footL','footR','uarmL','uarmR','farmL','farmR']){
    const expected=a.app.figure.rig.b(name).quaternion;
    assert.ok(expected.angleTo(b.app.figure.rig.b(name).quaternion)<1e-6,`${name}: skip driving pose`);
    assert.ok(expected.angleTo(c.app.figure.rig.b(name).quaternion)<1e-6,`${name}: long-frame driving pose`);
  }
  a.scene.dispose();b.scene.dispose();c.scene.dispose();
});


test('roadside rush and chase stay outside the moving van, then fall behind',()=>{
  let previous;
  for(let t=7.8;t<12.7;t+=1/120){
    const k=sampleEscapePursuit(t),v=sampleEscapeScene(t);
    assert.equal(k.visible,true);assert.ok(Number.isFinite(k.yaw));
    const x=Math.abs(k.x-v.offsetX),z=Math.abs(k.z+v.distance);
    assert.ok(x>2.2||z>3.8,`body and carried fork clear van at ${t}: ${x},${z}`);
    if(previous){assert.ok(Math.hypot(k.x-previous.x,k.z-previous.z)<.08);assert.ok(Math.abs(k.yaw-previous.yaw)<.08,'turn remains smooth');}
    previous=k;
  }
  assert.equal(sampleEscapePursuit(7.79).visible,false);assert.equal(sampleEscapePursuit(12.7).visible,false);
  assert.ok(sampleEscapePursuit(12.6).z+sampleEscapeScene(12.6).distance>15,'van pulls away decisively');
});

test('roadside staging works for a distant inactive enemy without rewriting AI; refresh and reset are stable',()=>{
  const f=fixture(),{app,scene}=f;Object.assign(app.sim.killer,{x:20,z:25,active:false});
  app.killerFigure.root.position.set(20,0,25);app.killerFigure.root.visible=false;
  const original=structuredClone(app.sim.killer);scene.begin();advance(scene,9);
  assert.equal(app.killerFigure.root.visible,true);assert.deepEqual(app.sim.killer,original);
  const position=app.killerFigure.root.position.clone(),yaw=app.killerFigure.root.rotation.y;
  scene.refresh();assert.ok(position.distanceTo(app.killerFigure.root.position)<1e-9);assert.equal(app.killerFigure.root.rotation.y,yaw);assert.equal(app.killerFigure.figure.anim,'chase');
  advance(scene,13);assert.equal(app.killerFigure.root.visible,false);
  scene.skip();assert.equal(app.killerFigure.root.visible,false);scene.reset();
  assert.deepEqual(app.sim.killer,original);assert.deepEqual(app.killerFigure.root.position.toArray(),[20,0,25]);assert.equal(app.killerFigure.root.visible,false);
  assert.ok(app.world.van.children.filter(o=>o.isLight).every(o=>!o.visible));scene.dispose();
});

test('staged pursuit transform is independent of frame size and skip preserves success',()=>{
  const a=fixture(),b=fixture();a.scene.begin();b.scene.begin();advance(a.scene,11.8);b.scene.tick(11.8);
  assert.ok(a.app.killerFigure.root.position.distanceTo(b.app.killerFigure.root.position)<1e-8);
  assert.ok(Math.abs(a.app.killerFigure.root.rotation.y-b.app.killerFigure.root.rotation.y)<1e-8);
  assert.ok(a.app.camera.position.distanceTo(b.app.camera.position)<1e-8);
  a.scene.skip();b.scene.skip();assert.equal(a.scene.stage,'survived');assert.equal(b.scene.stage,'survived');
  assert.equal(a.app.killerFigure.root.visible,false);assert.equal(b.app.killerFigure.root.visible,false);
  a.scene.dispose();b.scene.dispose();
});


test('public-road turn is continuous, follows its heading, and fades while still driving',()=>{
  let before=sampleEscapeScene(15.999);
  for(let t=16;t<=24;t+=.001){
    const s=sampleEscapeScene(t),dx=s.offsetX-before.offsetX,dz=s.distance-before.distance;
    assert.ok(Math.hypot(dx,dz)<.012,'no jump at dawn or the turn');
    assert.ok(s.speed>6,'engine never falls to a stop');
    assert.ok(Math.abs(s.vanYaw-before.vanYaw)<.002,'steering remains continuous');
    if(t>17.31){const direction=new THREE.Vector2(-Math.sin(s.vanYaw),Math.cos(s.vanYaw));assert.ok(new THREE.Vector2(dx,dz).normalize().dot(direction)>.99999,'van faces along its travel');}
    before=s;
  }
  const a=fixture(),{app,scene}=a;scene.begin();advance(scene,19.4);const near=app.camera.position.distanceTo(app.world.van.position);advance(scene,22.3);const far=app.camera.position.distanceTo(app.world.van.position);
  assert.ok(far>near+10,'van recedes from the held final camera');
  for(const aspect of [16/9,390/844]){app.camera.aspect=aspect;app.camera.updateProjectionMatrix();app.camera.updateMatrixWorld(true);const center=app.world.van.position.clone();center.y=1.15;center.project(app.camera);assert.ok(Math.abs(center.x)<.01&&Math.abs(center.y)<.01,'van remains centered in both formats');}
  assert.equal(sampleEscapeScene(22.4).fade,1);assert.ok(sampleEscapeScene(23.2).fade>0&&sampleEscapeScene(23.2).fade<1);assert.equal(sampleEscapeScene(24).fade,0);
  assert.equal(a.loops.some(l=>l.name==='engine_idle'),false);assert.equal(a.sounds.filter(x=>x.name==='car_door').length,2,'no door-open or exit sound after boarding');scene.dispose();
});
