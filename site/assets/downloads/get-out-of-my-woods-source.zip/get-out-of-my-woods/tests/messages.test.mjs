import test from 'node:test';
import assert from 'node:assert/strict';
import { createMessages } from '../src/ui/messages.js';

const run = (m, seconds, step = 0.1) => { for (let t = 0; t < seconds - 1e-9; t += step) m.update(step); };

test('B01: a warning in the same frame interrupts a tutorial, and the tutorial comes back with its reading time', () => {
  const m = createMessages();
  m.say('Route caption', { kind: 'essential', seconds: 5 });
  m.say('Crowbar ready. Face him, then swing.', { kind: 'essential', seconds: 6 });
  m.say('He has seen you.', { kind: 'urgent', seconds: 2 });
  assert.equal(m.text, 'He has seen you.', 'danger shows at once, not behind reading');
  run(m, 2.05);
  assert.equal(m.text, 'Route caption', 'the interrupted line returns first');
  run(m, 5.05);
  assert.equal(m.text, 'Crowbar ready. Face him, then swing.', 'the waiting tutorial still gets its turn');
  assert.ok(Math.abs(m.timeLeft - 6) < 0.15, 'with its full reading time');
  assert.deepEqual(m.recent().slice(0, 2), ['Crowbar ready. Face him, then swing.', 'Route caption']);
});

test('B02: pausing does not lose a line; time only runs on game time', () => {
  const m = createMessages();
  m.say('A clue on the bags.', { kind: 'essential', seconds: 8 });
  run(m, 3.5);
  const left = m.timeLeft;
  for (let i = 0; i < 600; i++) m.update(0); // paused frames
  assert.equal(m.text, 'A clue on the bags.');
  assert.equal(m.timeLeft, left);
  run(m, left - 0.2);
  assert.equal(m.text, 'A clue on the bags.', 'still up just before its time');
  run(m, 0.3);
  assert.equal(m.text, '');
});

test('urgent lines are never held back, and are not kept for recall', () => {
  const m = createMessages();
  m.say('He has seen you.', { kind: 'urgent', seconds: 1 });
  run(m, 1.1);
  m.say('He has seen you.', { kind: 'urgent', seconds: 1 });
  assert.equal(m.text, 'He has seen you.', 'a second sighting shows again at once');
  assert.deepEqual(m.recent(), []);
});

test('a line pressed again stays up instead of flickering; it does not repeat right after it goes', () => {
  const m = createMessages();
  m.say('Locked.', { kind: 'essential', seconds: 3, keep: false });
  run(m, 2);
  const v = m.version;
  m.say('Locked.', { kind: 'essential', seconds: 3, keep: false });
  assert.equal(m.version, v, 'no redraw for the same line');
  assert.ok(m.timeLeft > 2.9);
  run(m, 3.05);
  assert.equal(m.text, '');
  assert.equal(m.say('Locked.', { kind: 'essential', seconds: 3, keep: false }), false, 'not again within the repeat gap');
  run(m, 3.1);
  assert.equal(m.say('Locked.', { kind: 'essential', seconds: 3, keep: false }), true, 'again after the gap');
});

test('flavor never covers an instruction, and an instruction replaces flavor', () => {
  const m = createMessages();
  m.say('Tube socks.', { kind: 'flavor', seconds: 4 });
  m.say('YOUR KEYS.', { kind: 'essential', seconds: 4.5 });
  assert.equal(m.text, 'YOUR KEYS.');
  assert.equal(m.say('Forks. Only spoons.', { kind: 'flavor' }), false);
  assert.equal(m.text, 'YOUR KEYS.');
});

test('the waiting line is bounded and stale lines are dropped, while recent() keeps them', () => {
  const m = createMessages({ waitingLimit: 2 });
  m.say('one', { seconds: 4 });
  m.say('two', { seconds: 4 });
  m.say('three', { seconds: 4 });
  m.say('four', { seconds: 4 });
  assert.deepEqual(m.waiting, ['three', 'four']);
  assert.deepEqual(m.recent().slice(0, 4), ['four', 'three', 'two', 'one']);
});

test('clear() empties the screen and the queue for a retry or chapter change', () => {
  const m = createMessages();
  m.say('kept', { seconds: 4 });
  m.say('waiting', { seconds: 4 });
  m.clear();
  assert.equal(m.text, '');
  assert.deepEqual(m.waiting, []);
  assert.deepEqual(m.recent(), ['waiting', 'kept']);
  m.clear({ keepRecent: false });
  assert.deepEqual(m.recent(), []);
});
