import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { App } from '../src/game/app.js';
import { Cinematics } from '../src/game/cinematics.js';
import { GameSim } from '../src/sim/game.js';
import { audio } from '../src/audio/index.js';

function fixture() {
  const app = Object.create(App.prototype);
  const hoodPivot = new THREE.Group();
  const car = new THREE.Group();
  car.userData = { hoodPivot, setHeadlights() {} };
  Object.assign(app, {
    world: { car, root: new THREE.Group() },
    mainScene: new THREE.Scene(),
    camera: new THREE.PerspectiveCamera(),
    post: { uLetterbox: { value: 1 } },
    seenHunt: false,
    ui: { caption() {} },
  });
  app.cine = new Cinematics(app);
  return { app, hoodPivot };
}

test('a timer-started hunt opens the hood, and skip-intro retry restores it open', () => {
  const { app, hoodPivot } = fixture();
  const originalAmbience = audio.ambience;
  audio.ambience = () => {};
  try {
    app.onEvent({ t: 'huntStarted' });
    assert.equal(app.seenHunt, true);
    assert.ok(Math.abs(hoodPivot.rotation.x + 1.05) < 1e-9, 'timeout hunt opens hood');

    hoodPivot.rotation.x = 0;
    app.sim = new GameSim({ skipIntro: true, seed: 91 });
    app.cine.restoreCar();
    assert.ok(Math.abs(hoodPivot.rotation.x + 1.05) < 1e-9, 'skip-intro retry restores open hood');
  } finally {
    audio.ambience = originalAmbience;
  }
});
