import test from 'node:test';
import assert from 'node:assert/strict';
import { GameSim } from '../src/sim/game.js';
import { Nav, BODY } from '../src/sim/nav.js';
import { LAYOUT } from '../src/sim/layout.js';

const near = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]) < 1e-8;
function doorway(id, side, normal, lateral = 0) {
  const d = LAYOUT.doors.find(d => d.id === id);
  const ux = (d.ex - d.hx) / d.width, uz = (d.ez - d.hz) / d.width;
  const nx = -uz, nz = ux;
  const point = (n, l = 0) => [d.x + nx * n + ux * l, d.z + nz * n + uz * l];
  const start = point(side * normal, lateral), end = point(-side * 2);
  const path = Nav.prototype._throughDoorCentres.call({}, ...start, [end]);
  return { d, point, start, end, path, centre: [d.x, d.z], approach: point(side * 0.85), exit: point(-side * 0.85) };
}

test('frequent chase replans pass the real Mess Hall door instead of turning back forever', t => {
  const s = new GameSim({ seed: 1000, difficulty: 'normal', skipIntro: true });
  Object.assign(s.player, { x: -13.754719234139772, z: -64.5397228166954 });
  Object.assign(s.killer, { x: -15, z: -56.1961878328653, yaw: -0.9370277802354341 });
  s.collision.doors.find(d => d.id === 'mess.d0').open = true;
  assert.equal(s.collision.blocked(-15, -56.75, BODY, true), false, 'door clearance is sufficient');
  s.killer.beginChase();
  const dt = 1 / 30;
  for (let i = 0; i < 10 / dt && s.phase === 'play'; i++) {
    s.step(dt, { moveX: 0, moveY: 0, camYaw: 0 });
    s.drainEvents();
  }
  assert.equal(s.phase, 'dead', 'the visible stationary counselor must be reachable');
  assert.ok(s.time < 8, `approach took ${s.time}s`);
  assert.equal(s.stats.killerStuck, 0);
  t.diagnostic(`doorway reached and attack completed in ${s.time.toFixed(2)}s; zero stuck counters`);
});

test('safe entry skips the already-passed approach from both sides, including rotated doors', () => {
  for (const id of ['mess.d0', 'cabin1.d0']) for (const side of [-1, 1]) {
    const r = doorway(id, side, 0.55);
    assert.ok(near(r.path[0], r.centre), `${id} side ${side}: keep centre first`);
    assert.ok(near(r.path[1], r.exit), `${id} side ${side}: keep exit`);
    assert.equal(r.path.some(p => near(p, r.approach)), false);
  }
});

test('approach is retained outside the normal-distance entry band on both sides', () => {
  for (const id of ['mess.d0', 'cabin1.d0']) for (const side of [-1, 1]) {
    const r = doorway(id, side, 1.2);
    assert.ok(near(r.path[0], r.approach));
    assert.ok(near(r.path[1], r.centre));
    assert.ok(near(r.path[2], r.exit));
  }
});

test('lateral safety retains alignment when the killer is outside body-width clearance', () => {
  for (const id of ['mess.d0', 'cabin1.d0']) for (const side of [-1, 1]) for (const lateralSign of [-1, 1]) {
    const d = LAYOUT.doors.find(d => d.id === id);
    const edge = d.width / 2 - BODY;
    const safe = doorway(id, side, 0.55, lateralSign * (edge - 0.05));
    const outside = doorway(id, side, 0.55, lateralSign * (edge + 0.05));
    assert.ok(near(safe.path[0], safe.centre), `${id}: inside body clearance`);
    assert.ok(near(outside.path[0], outside.approach), `${id}: retain approach outside body clearance`);
  }
});

test('later route legs retain doorway staging instead of using the first-leg exception', () => {
  for (const side of [-1, 1]) {
    const r = doorway('mess.d0', side, 0.55);
    const start = r.point(side * 1.4);
    const path = Nav.prototype._throughDoorCentres.call({}, ...start, [r.start, r.end]);
    assert.ok(near(path[0], r.start));
    assert.ok(near(path[1], r.approach));
    assert.ok(near(path[2], r.centre));
  }
});
