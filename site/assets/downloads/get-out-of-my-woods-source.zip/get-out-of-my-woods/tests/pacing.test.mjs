import test from 'node:test';
import assert from 'node:assert/strict';
import { Director } from '../src/ai/director.js';
import { DIFFICULTY } from '../src/ai/tuning.js';
import { makeRng } from '../src/core/rng.js';
import { GameSim } from '../src/sim/game.js';

const playerAtFirePit = () => ({ x: 3.4, z: 11.4, hidden: null });
const killerStart = { x: -92, z: -66 };

test('stillness escalates once and movement resets it', () => {
  const d = new Director(makeRng(7), DIFFICULTY.normal);
  const p = playerAtFirePit();
  d.update(1, p);
  for (let i = 0; i < DIFFICULTY.normal.idlePressure; i++) d.update(1, p);
  assert.equal(d.idleFor, DIFFICULTY.normal.idlePressure);
  assert.equal(d.pressured, false);
  d.update(1, p);
  assert.equal(d.pressured, true);
  assert.equal(d.pressureNudge, true);
  const waypoint = d.nextWaypoint(killerStart, p, 0);
  assert.ok(Math.hypot(waypoint.x - p.x, waypoint.z - p.z) < 30);
  assert.equal(d.pressureNudge, false);
  d.update(1, p);
  assert.equal(d.pressureNudge, false);
  p.x += 2;
  d.update(1, p);
  assert.equal(d.idleFor, 0);
});

test('contact preserves recovery and hidden players do not trigger pressure', () => {
  const d = new Director(makeRng(11), DIFFICULTY.normal);
  const p = playerAtFirePit();
  for (let i = 0; i < 20; i++) d.update(1, p);
  d.contact();
  assert.ok(d.relax >= 32 && d.relax <= 48);
  assert.equal(d.idleFor, 0);
  assert.equal(d.pressured, false);
  assert.equal(d.pressureNudge, false);
  while (d.relax > 0) {
    d.update(0.25, p);
    if (d.relax > 0) {
      assert.equal(d.idleFor, 0);
      assert.equal(d.pressured, false);
    }
  }
  p.hidden = { id: 'test-hide' };
  d.sinceContact = 100;
  d.update(1, p);
  assert.equal(d.idleFor, 0);
  assert.equal(d.pressured, false);
  assert.equal(d.pressureNudge, false);
});

test('a stationary Normal seed is detected during the opening minute without teleporting', () => {
  const s = new GameSim({ seed: 1000, difficulty: 'normal', skipIntro: true });
  const input = { moveX: 0, moveY: 0, camYaw: 0, run: false, sneak: false, action: false, actionHeld: false, flashlight: false };
  const dt = 1 / 30;
  let first = null;
  let maxStep = 0;
  for (let i = 0; i < 65 / dt && s.phase === 'play'; i++) {
    const x = s.killer.x, z = s.killer.z;
    s.step(dt, input);
    maxStep = Math.max(maxStep, Math.hypot(s.killer.x - x, s.killer.z - z));
    if (first === null && s.stats.seen > 0) first = s.time;
    s.drainEvents();
  }
  assert.ok(first !== null, 'the stationary player should be detected');
  assert.ok(first >= 25 && first <= 65, `first detection was ${first.toFixed(1)}s`);
  assert.ok(maxStep <= 5.5 * dt + 1e-6, `killer moved ${maxStep}m in one step`);
});
