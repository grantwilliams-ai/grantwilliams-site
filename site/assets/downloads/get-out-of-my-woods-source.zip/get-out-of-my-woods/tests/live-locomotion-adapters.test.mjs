import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { App } from '../src/game/app.js';
import { PreviewApp } from '../src/act2/app.js';
import { createAct2Killer } from '../src/act2/killer.js';
import { GameSim } from '../src/sim/game.js';
import { CameraRig } from '../src/game/camera.js';
import { createPlayer } from '../src/characters/player.js';
import { createKiller } from '../src/characters/killer.js';
import { createWallClearance } from '../src/characters/wall-clearance.js';
import { createFootfallSync } from '../src/audio/footfall-sync.js';
import { audio } from '../src/audio/index.js';
const noop=()=>{},context=new Proxy({measureText:()=>({width:20}),createLinearGradient:()=>({addColorStop(){}})},{get:(o,k)=>o[k]??noop});
globalThis.document={createElement:()=>({getContext:()=>context})};
function fixture(){
 const app=Object.create(App.prototype),sim=new GameSim({skipIntro:true,seed:42}),camera=new THREE.PerspectiveCamera(),rig=new CameraRig(camera,sim.collision);
 Object.assign(sim.player,{x:0,z:0,y:0,moveMode:'idle',speed:0,vx:0,vz:0});
 Object.assign(sim.killer,{x:8,z:0,yaw:0,state:'patrol',anim:'walk',speed:1.5,path:[[8,100]],pathI:0});
 const flags={map:false},playerFig=createPlayer(),killer=createKiller(),observed=[];
 killer.setAnim('walk',{restart:true,phase:.2,fade:.001});killer.update(.001,{speed:0});
 const update=killer.update;killer.update=(dt,options)=>{observed.push({dt,...options});update.call(killer,dt,options);};
 Object.assign(app,{state:'play',sim,ui:{input:{moveX:0,moveY:0,lookX:0,lookY:0},mapOpen:()=>flags.map,setObjective:noop,setPrompt:noop,setHold:noop,setStamina:noop,showPause:noop,hideAll:noop,setTouchVisible:noop},
  cine:{blocking:false},rig,playerFig,killer,lastKillerAnim:'walk',headTarget:new THREE.Vector3(),from:new THREE.Vector3(),aim:new THREE.Vector3(),tmpV:new THREE.Vector3(),camera,
  quality:{isTouch:false},settings:{flashes:'reduced',brightness:1},flash:{power:1,setOn:noop,update:noop},world:{setIndoor:noop},glints:{update:noop},
  renderer:{time:0,target:{height:720},gl:{domElement:{height:720}}},post:{uBrightness:{value:1},uDanger:{value:0},uTear:{value:0}},eyes:1,updateMusic:noop});
 return {app,sim,flags,playerFig,killer,observed};
}
function quiet(fn){const old=Object.fromEntries(['setListener','setIntensity','setRoom','sfx','pauseAll','resumeAll','unlock'].map(k=>[k,audio[k]])),calls=[];for(const k of Object.keys(old))audio[k]=noop;audio.sfx=(name,opts={})=>calls.push({name,...opts});try{return fn(calls);}finally{Object.assign(audio,old);}}

for(const hz of [20,60,120])test(`blocked and waypoint frames freeze only Sackhead's live stride at ${hz} Hz`,()=>quiet(()=>{
 const {app,sim,killer,observed}=fixture(),dt=1/hz,k=sim.killer;
 sim.moveKiller=(x,z)=>[x,z];sim.step=d=>k.follow(d,1.5);
 const phase=killer.animator.cur.phase,time=killer.animator.cur.t;
 for(let i=0;i<hz/2;i++)app.tickPlay(dt);
 assert.equal(k.speed,1.5,'AI commanded speed is untouched');assert.equal(killer.animator.cur.phase,phase,'no walking through collision');
 assert.ok(Math.abs(killer.animator.cur.t-time-.5)<1e-10,'upper body clock keeps advancing');assert.ok(observed.every(o=>o.speed===0));
 k.path=[[k.x,k.z+.01],[k.x,k.z+50]];k.pathI=0;app.tickPlay(dt);
 assert.equal(k.pathI,1);assert.equal(k.speed,1.5);assert.equal(observed.at(-1).speed,0);assert.equal(killer.animator.cur.phase,phase);
}));

for(const hz of [20,60,120])test(`actual travel, collision slides and unblocked resume use the rendered distance at ${hz} Hz`,()=>quiet(()=>{
 const {app,sim,killer,observed}=fixture(),dt=1/hz,k=sim.killer;
 // Simulate the same commanded follow velocity against a partial movement constraint.
 sim.moveKiller=(x,z,nx,nz)=>[x+(nx-x)*.25,z+(nz-z)*.25];sim.step=d=>k.follow(d,1.5);
 const phase=killer.animator.cur.phase;app.tickPlay(dt);
 assert.ok(Math.abs(observed.at(-1).speed-.375)<1e-9);assert.equal(k.speed,1.5);assert.ok(killer.animator.cur.phase>phase);
 sim.moveKiller=(x,z)=>[x,z];app.tickPlay(dt);const stopped=killer.animator.cur.phase;
 sim.moveKiller=(x,z,nx,nz)=>[nx,nz];app.tickPlay(dt);
 assert.ok(Math.abs(observed.at(-1).speed-1.5)<1e-9);assert.ok(killer.animator.cur.phase>stopped);
 // An external prior-frame placement does not contribute to this tick's speed.
 k.x+=25;k.path=[[k.x,k.z+50]];app.tickPlay(dt);assert.ok(observed.at(-1).speed<1.500001);
}));

test('same-tick placement jumps never advance a live stride, ordinary catch-up remains allowed',()=>quiet(()=>{
 const {app,sim,killer,observed}=fixture(),k=sim.killer,phase=killer.animator.cur.phase;
 sim.step=()=>{k.x+=20;};app.tickPlay(1/60);assert.equal(observed.at(-1).speed,0);assert.equal(killer.animator.cur.phase,phase);
 sim.step=dt=>{k.x+=5.6*dt;};app.tickPlay(1/60);assert.ok(Math.abs(observed.at(-1).speed-5.6)<1e-10);
 sim.step=noop;app.tickPlay(0);assert.equal(observed.at(-1).speed,0);
}));

test('map keeps pose clocks frozen and close/resume measures only the fresh simulation tick',()=>quiet(()=>{
 const {app,sim,killer,observed,flags}=fixture(),k=sim.killer;sim.step=dt=>{k.z+=1.5*dt;};
 app.tickPlay(1/60);flags.map=true;const phase=killer.animator.cur.phase,time=killer.animator.cur.t;
 for(let i=0;i<120;i++)app.tickPlay(1/60);assert.equal(killer.animator.cur.phase,phase);assert.equal(killer.animator.cur.t,time);
 assert.equal(observed.at(-1).dt,0);k.z+=50;flags.map=false;app.tickPlay(1/60);assert.ok(Math.abs(observed.at(-1).speed-1.5)<1e-9);
}));

test('authored blocking films retain caller speed and attack clocks keep their timing',()=>quiet(()=>{
 const {app,sim,killer,observed}=fixture();app.cine.blocking=true;const before=killer.animator.cur.phase;
 app.tickPlay(.05);assert.equal(observed.at(-1).speed,sim.killer.speed);assert.ok(killer.animator.cur.phase>before);
 app.cine.blocking=false;sim.step=noop;sim.killer.anim='raise';sim.killer.state='strike';app.tickPlay(.05);
 assert.equal(observed.at(-1).speed,0);assert.equal(killer.animator.cur.name,'raise');assert.equal(killer.animator.cur.t,.05);
}));

test('the final wall-clearance layer and fork hand attachment remain intact',()=>quiet(()=>{
 const {app,sim,killer}=fixture();sim.step=noop;Object.assign(sim.killer,{x:.46,z:0,yaw:-Math.PI/2,state:'strike',anim:'raise',speed:4});
 sim.collision={walls:[{x1:0,z1:-10,x2:0,z2:10}],doors:[],blocked:()=>false};app.killerClearance=createWallClearance(killer);
 const order=[],update=killer.update,apply=app.killerClearance.apply;killer.update=(...args)=>{order.push('pose');return update(...args);};app.killerClearance.apply=(...args)=>{order.push('clearance');return apply(...args);};
 for(let i=0;i<20;i++)app.tickPlay(1/60);
 assert.deepEqual(order.slice(-2),['pose','clearance']);assert.ok(app.killerContact.shift<=.320001);assert.equal(app.killerContact.limited,false);
 const hand=killer.rig.b('handR').getWorldPosition(new THREE.Vector3()),fork=killer.rig.b('fork').getWorldPosition(new THREE.Vector3()),axis=new THREE.Vector3(0,1,0).transformDirection(killer.rig.b('fork').matrixWorld);
 hand.sub(fork).addScaledVector(axis,-hand.dot(axis));assert.ok(hand.length()<.04);
 assert.equal(killer.root.position.x,sim.killer.x);assert.equal(killer.root.position.z,sim.killer.z);
}));

test('blocked presentation does not suppress or retime the preserved killer sound accumulator',()=>quiet(calls=>{
 const {app,sim,killer}=fixture(),k=sim.killer;sim.moveKiller=(x,z)=>[x,z];sim.step=dt=>{k.follow(dt,1.5);k.sounds(dt);};
 const phase=killer.animator.cur.phase;for(let i=0;i<180;i++)app.tickPlay(1/60);
 assert.equal(killer.animator.cur.phase,phase);assert.equal(k.speed,1.5);
 const steps=calls.filter(c=>c.name.startsWith('killer_step'));assert.equal(steps.length,4);assert.ok(steps.every(c=>c.volume===1));
}));


test('live player stabilization precedes contact audio and map replay preserves the correction hook',()=>quiet(()=>{
 const {app,sim,flags,playerFig}=fixture();sim.step=noop;const order=[];
 playerFig.stabilizeStance=(dt,options)=>order.push({name:'stance',dt,...options});app.playPlayerFootfall=()=>order.push({name:'audio'});
 app.tickPlay(1/60);assert.deepEqual(order.map(o=>o.name),['stance','audio']);assert.equal(order[0].enabled,true);
 order.length=0;flags.map=true;app.tickPlay(1/60);assert.equal(order[0].dt,0);assert.equal(order[0].enabled,true);
 flags.map=false;app.cine.blocking=true;order.length=0;app.tickPlay(1/60);assert.equal(order[0].enabled,false,'films keep authored pose');
 app.cine.blocking=false;sim.player.hidden={type:'closet',view:{pos:[0,1.3,0],look:[0,1.3,1]}};order.length=0;app.tickPlay(1/60);assert.equal(order[0].enabled,false,'hiding resets locomotion correction');
}));

test('near-wall metadata excludes post-clearance foot correction even when the solver needs no shift',()=>quiet(()=>{
 const {app,sim,killer}=fixture();sim.step=noop;sim.killer.x=2.6;
 sim.collision={walls:[{x1:0,z1:-10,x2:0,z2:10}],doors:[],blocked:()=>false};app.killerClearance=createWallClearance(killer);
 const hooks=[];killer.stabilizeStance=(dt,options)=>hooks.push(options);app.tickPlay(1/60);
 assert.equal(app.killerContact.nearWalls,true);assert.equal(app.killerContact.weight,0);assert.equal(app.killerContact.shift,0);assert.equal(hooks.at(-1).enabled,false);
 sim.killer.x=8;app.tickPlay(1/60);assert.equal(app.killerContact.nearWalls,false);assert.equal(hooks.at(-1).enabled,true);
}));

function secondAct(){
 const app=Object.create(PreviewApp.prototype),player={x:0,z:0,yaw:0,speed:1.9,gait:'walk',run:false,hidden:null,defending:false};
 Object.assign(app,{state:'play',settings:{steps:.45},sim:{phase:'play',player,killer:{active:true,x:20,z:20,yaw:0,speed:1.5,state:'patrol'},weapon:'empty'},figure:createPlayer(),heldCrowbar:{},killerFigure:createAct2Killer(),flash:{position:new THREE.Vector3(),target:{position:new THREE.Vector3()}},viewYaw:0,killerFoot:0,time:0,post:{uDanger:{value:0}},ui:{menu:noop,setMode:noop}});
 return app;
}

test('Act II delegates live correction after both actor poses and disables it at death/escape/hidden boundaries',()=>quiet(()=>{
 const app=secondAct(),sequence=[];
 const update=app.figure.update.bind(app.figure);app.figure.update=(...args)=>{sequence.push('player pose');return update(...args);};
 app.figure.stabilizeStance=(dt,o)=>sequence.push(['player stance',o.enabled]);
 const updateK=app.killerFigure.figure.update.bind(app.killerFigure.figure);app.killerFigure.figure.update=(...args)=>{sequence.push('killer pose');return updateK(...args);};
 app.killerFigure.figure.stabilizeStance=(dt,o)=>sequence.push(['killer stance',o.enabled]);
 app.updateActors(1/60);assert.deepEqual(sequence,['player pose',['player stance',true],'killer pose',['killer stance',true]]);
 for(const phase of ['dead','escape']){sequence.length=0;app.sim.phase=phase;app.updateActors(1/60);assert.equal(sequence[1][1],false);assert.equal(sequence[3][1],false);}
 app.sim.phase='play';app.sim.player.hidden={};app.sim.killer.active=false;sequence.length=0;app.updateActors(1/60);assert.equal(sequence[1][1],false);assert.equal(sequence[3][1],false);
}));

test('pause retains stance memory without posing either actor; scene reset clears the Act II delegate',()=>quiet(()=>{
 const first=fixture().app,second=secondAct();let resets=0,poses=0;
 first.ui.showPause=noop;first.playerFig.resetStance=first.killer.resetStance=second.figure.resetStance=second.killerFigure.figure.resetStance=()=>resets++;
 first.playerFig.stabilizeStance=first.killer.stabilizeStance=second.figure.stabilizeStance=second.killerFigure.figure.stabilizeStance=()=>poses++;
 first.pause();second.pause();assert.equal(first.state,'paused');assert.equal(second.state,'pause');assert.equal(resets,0);assert.equal(poses,0);
 second.killerFigure.reset();assert.equal(resets,1,'chapter reset explicitly releases old anchors');
}));


function turningScene(){
 const f=fixture();f.sim.step=dt=>{
  const p=f.sim.player;f.sim.time+=dt;p.speed=1.9;p.moveMode='walk';p.yaw=f.sim.time*2.2;p.x+=Math.sin(p.yaw)*p.speed*dt;p.z+=Math.cos(p.yaw)*p.speed*dt;
 };return f;
}
const legPose=f=>['thighL','shinL','footL','thighR','shinR','footR'].map(name=>({name,position:f.rig.b(name).position.clone(),quaternion:f.rig.b(name).quaternion.clone()}));
function equalLegs(f,before){for(const b of before){assert.ok(f.rig.b(b.name).position.distanceTo(b.position)<1e-10,b.name+' position');assert.ok(f.rig.b(b.name).quaternion.angleTo(b.quaternion)<1e-7,b.name+' rotation');}}

test('an actually stabilized player pose freezes exactly through map redraws',()=>quiet(()=>{
 const {app,flags,playerFig}=turningScene();let correction=0;const stabilize=playerFig.stabilizeStance;
 playerFig.stabilizeStance=(...args)=>{const r=stabilize(...args);correction=r.maxCorrection;return r;};
 let frames=0;while(correction<.025&&frames++<120)app.tickPlay(1/60);assert.ok(correction>.025,'fixture reaches a nontrivial correction');
 const before=legPose(playerFig),phase=playerFig.animator.cur.phase;flags.map=true;
 for(let i=0;i<120;i++){app.tickPlay(1/60);equalLegs(playerFig,before);assert.equal(playerFig.animator.cur.phase,phase);}
}));

test('pause/resume of a stabilized turn equals uninterrupted next-frame presentation',()=>quiet(()=>{
 const a=turningScene(),b=turningScene();for(let i=0;i<40;i++){a.app.tickPlay(1/60);b.app.tickPlay(1/60);}
 const before=legPose(a.playerFig);a.app.pause();equalLegs(a.playerFig,before);a.app.resume();
 a.app.tickPlay(1/60);b.app.tickPlay(1/60);equalLegs(a.playerFig,legPose(b.playerFig));
}));


for(const hz of [20,60,120])test(`03H footsteps sample the final stabilized soles during held-gait sharp turns at ${hz} Hz`,()=>quiet(calls=>{
 const {app,sim,playerFig}=fixture();app.settings.steps=.45;app.playerFootfalls=createFootfallSync();sim.killer.state='wait';
 const contacts=[],sample=app.playerFootfalls.sample;app.playerFootfalls.sample=data=>{const contact=sample(data);if(contact)contacts.push({...contact,height:data.soles[contact.side]});return contact;};
 let corrected=0;const stabilize=playerFig.stabilizeStance;playerFig.stabilizeStance=(...args)=>{const result=stabilize(...args);if(result.maxCorrection>.01)corrected++;return result;};
 sim.step=dt=>{sim.time+=dt;const p=sim.player,gait=Math.floor((sim.time+1e-8)/3)%2?'run':'walk';p.speed=gait==='run'?4.5:1.9;p.moveMode=gait;p.yaw=Math.sin(sim.time*2)*1.4;p.x+=Math.sin(p.yaw)*p.speed*dt;p.z+=Math.cos(p.yaw)*p.speed*dt;};
 for(let i=0;i<hz*12;i++)app.tickPlay(1/hz);
 const sounds=calls.filter(c=>c.name.startsWith('step_'));assert.ok(corrected>hz,'real stance corrections occurred');assert.ok(contacts.length>=20,'real phase contacts occurred');assert.equal(sounds.length,contacts.length,'each accepted sole produces exactly one sound');
 for(const c of contacts){assert.ok(c.height<=.035+1e-8);assert.ok(c.delay<=.12+1e-8);}assert.equal(new Set(contacts.map(c=>c.phase)).size,contacts.length);
}));


test('an actually stabilized Sackhead pose also freezes through map redraws',()=>quiet(()=>{
 const {app,sim,flags,killer}=fixture();let correction=0;const stabilize=killer.stabilizeStance;
 killer.stabilizeStance=(...args)=>{const r=stabilize(...args);correction=r.maxCorrection;return r;};
 sim.step=dt=>{sim.time+=dt;const k=sim.killer;k.yaw=sim.time*2.2;k.x+=Math.sin(k.yaw)*1.5*dt;k.z+=Math.cos(k.yaw)*1.5*dt;};
 let frames=0;while(correction<.025&&frames++<120)app.tickPlay(1/60);assert.ok(correction>.025,'Sackhead acquires a real planted correction');
 const before=legPose(killer),phase=killer.animator.cur.phase;flags.map=true;
 for(let i=0;i<120;i++){app.tickPlay(1/60);equalLegs(killer,before);assert.equal(killer.animator.cur.phase,phase);}
}));

test('Act II retains both live planted poses through pause and resumes identically',()=>quiet(()=>{
 const a=secondAct(),b=secondAct();let corrections=0;
 const move=app=>{app.time+=1/60;for(const [actor,speed] of [[app.sim.player,1.9],[app.sim.killer,1.5]]){actor.yaw=app.time*2.2;actor.x+=Math.sin(actor.yaw)*speed/60;actor.z+=Math.cos(actor.yaw)*speed/60;}app.updateActors(1/60);};
 for(const figure of [a.figure,a.killerFigure.figure]){const stabilize=figure.stabilizeStance;figure.stabilizeStance=(...args)=>{const r=stabilize(...args);if(r.maxCorrection>.01)corrections++;return r;};}
 for(let i=0;i<40;i++){move(a);move(b);}assert.ok(corrections>10);
 const playerBefore=legPose(a.figure),killerBefore=legPose(a.killerFigure.figure);a.pause();equalLegs(a.figure,playerBefore);equalLegs(a.killerFigure.figure,killerBefore);a.resume();
 move(a);move(b);equalLegs(a.figure,legPose(b.figure));equalLegs(a.killerFigure.figure,legPose(b.killerFigure.figure));
}));


test('wall approach and departure fade support before the unchanged restraint boundary',()=>quiet(()=>{
 for(const hz of [20,60,120]){
  const {app,sim,killer}=fixture();sim.collision={walls:[{x1:0,z1:-10,x2:0,z2:10}],doors:[],blocked:()=>false};app.killerClearance=createWallClearance(killer);
  sim.killer.x=3.7;sim.killer.yaw=-Math.PI/2;let direction=-1,lastResult=null,previous=null,entries=0,exits=0,bandFrames=0;
  const stabilize=killer.stabilizeStance;killer.stabilizeStance=(dt,options)=>{const result=stabilize(dt,options);lastResult={...result,...options};return result;};
  sim.step=dt=>{sim.killer.x+=direction*1.5*dt;};
  for(let i=0;i<hz*2;i++){
   if(sim.killer.x<2.59){direction=1;sim.killer.yaw=Math.PI/2;}
   app.tickPlay(1/hz);const c=app.killerContact;
   assert.ok(Math.abs(c.nearestWallDistance-sim.killer.x)<1e-9);assert.ok(lastResult.maxCorrection<=.160001*lastResult.strength);
   if(c.nearestWallDistance>2.7+1e-8&&c.nearestWallDistance<4.5-1e-8){bandFrames++;assert.ok(lastResult.strength>0&&lastResult.strength<1);}
   if(previous?.nearWalls===false&&c.nearWalls){entries++;assert.ok(previous.correction<.008,'entering wall guard releases only a small residual');assert.equal(lastResult.maxCorrection,0);}
   if(previous?.nearWalls===true&&!c.nearWalls){exits++;assert.ok(lastResult.maxCorrection<.008,'leaving wall guard seeds softly');}
   previous={nearWalls:c.nearWalls,correction:lastResult.maxCorrection};
  }
  assert.equal(entries,1);assert.equal(exits,1);assert.ok(bandFrames>hz*.5);
 }
}));

test('map redraw replays a wall-band scaled stance exactly without multiplying strength twice',()=>quiet(()=>{
 const {app,sim,flags,killer}=fixture();sim.killer.x=3.6;
 sim.collision={walls:[{x1:0,z1:-10,x2:0,z2:10}],doors:[],blocked:()=>false};app.killerClearance=createWallClearance(killer);
 let correction=0,strength=0;const stabilize=killer.stabilizeStance;killer.stabilizeStance=(dt,options)=>{const r=stabilize(dt,options);correction=r.maxCorrection;strength=options.strength;return r;};
 sim.step=dt=>{sim.time+=dt;sim.killer.z+=1.5*dt;sim.killer.yaw=Math.sin(sim.time*2)*.4;};
 let frames=0;while(correction<.015&&frames++<120)app.tickPlay(1/60);assert.ok(correction>.015);assert.ok(Math.abs(strength-.5)<1e-10);
 const before=legPose(killer);flags.map=true;for(let i=0;i<120;i++){app.tickPlay(1/60);equalLegs(killer,before);}
}));


for(const hz of [20,60,120])test(`fast wall approaches fade correction before the guard across gait phases at ${hz} Hz`,t=>quiet(()=>{
 let maximum=0,entries=0,exits=0;
 for(const [gait,speed] of [['walk',1.5],['stalk',2.55],['chase',3.85],['chase',5.1072],['walk',5.8]])for(let phaseIndex=0;phaseIndex<10;phaseIndex++){
  const {app,sim,killer}=fixture();sim.collision={walls:[{x1:0,z1:-100,x2:0,z2:100}],doors:[],blocked:()=>false};app.killerClearance=createWallClearance(killer);
  Object.assign(sim.killer,{x:5,z:0,anim:gait,state:gait==='chase'?'chase':'patrol',speed});app.lastKillerAnim=gait;killer.setAnim(gait,{restart:true,phase:phaseIndex/10,fade:.001});
  let frame=0,stage=0,lastCorrection=0,previous=null;
  const stabilize=killer.stabilizeStance;killer.stabilizeStance=(...args)=>{const r=stabilize(...args);lastCorrection=r.maxCorrection;return r;};
  sim.step=dt=>{if(frame>=hz*.5&&stage===0)stage=1;if(sim.killer.x<2.55)stage=2;sim.killer.yaw=stage===0?0:stage===1?-Math.PI/2:Math.PI/2;sim.killer.x+=Math.sin(sim.killer.yaw)*speed*dt;sim.killer.z+=Math.cos(sim.killer.yaw)*speed*dt;};
  for(;frame<hz*3;frame++){
   app.tickPlay(1/hz);const contact=app.killerContact;
   if(previous&&!previous.nearWalls&&contact.nearWalls){entries++;maximum=Math.max(maximum,previous.correction);assert.ok(previous.correction<.01,`${gait}/${speed}/phase${phaseIndex/10}: ${(previous.correction*100).toFixed(3)}cm`);assert.equal(lastCorrection,0);}
   if(previous?.nearWalls&&!contact.nearWalls){exits++;assert.equal(lastCorrection,0,'guard departure seeds without old anchors');}
   previous={nearWalls:contact.nearWalls,correction:lastCorrection};
  }
 }
 assert.equal(entries,50);assert.equal(exits,50);assert.ok(maximum<.01);t.diagnostic(JSON.stringify({hz,entries,exits,maxGuardResidualMetres:maximum}));
}));


for(const hz of [20,60,120])test(`rapid200ms gait switches retain audio while existing stance corrections release at ${hz} Hz`,t=>quiet(calls=>{
 const {app,sim,playerFig}=fixture();app.settings.steps=.45;app.playerFootfalls=createFootfallSync();sim.killer.state='wait';
 const contacts=[],sample=app.playerFootfalls.sample;app.playerFootfalls.sample=data=>{const c=sample(data);if(c)contacts.push({...c,height:data.soles[c.side]});return c;};
 let correctedBeforeSwitch=0,maxJump=0,worstTime=0,worstMotion=null,maxRawStep=0,maxVisibleStep=0,maxAddedStep=0,previous=null,previousRaw=null,previousFinal=null;const stabilize=playerFig.stabilizeStance;
 playerFig.stabilizeStance=(...args)=>{
  const raw=['L','R'].map(s=>playerFig.rig.b('foot'+s).getWorldPosition(new THREE.Vector3()));const r=stabilize(...args);
  const final=['L','R'].map(s=>playerFig.rig.b('foot'+s).getWorldPosition(new THREE.Vector3()));const offsets=final.map((v,i)=>v.clone().sub(raw[i]));
  if(sim.time<1.5&&r.maxCorrection>.01)correctedBeforeSwitch++;
  if(previous)for(let i=0;i<2;i++){const rawStep=raw[i].distanceTo(previousRaw[i]),visibleStep=final[i].distanceTo(previousFinal[i]);maxRawStep=Math.max(maxRawStep,rawStep);maxVisibleStep=Math.max(maxVisibleStep,visibleStep);maxAddedStep=Math.max(maxAddedStep,visibleStep-rawStep);const change=offsets[i].distanceTo(previous[i]);if(change>maxJump){maxJump=change;worstTime=sim.time;worstMotion={side:i,phase:playerFig.animator.cur.phase,gait:playerFig.animator.cur.name,rawTravel:raw[i].distanceTo(previousRaw[i]),finalTravel:final[i].distanceTo(previousFinal[i])};}}previous=offsets;previousRaw=raw;previousFinal=final;return r;
 };
 sim.step=dt=>{sim.time+=dt;const p=sim.player,gait=sim.time<1.5?'walk':Math.floor((sim.time-1.5+1e-8)/.2)%2?'run':'walk';p.speed=gait==='run'?4.5:1.9;p.moveMode=gait;p.yaw=Math.sin(sim.time*2)*1.4;p.x+=Math.sin(p.yaw)*p.speed*dt;p.z+=Math.cos(p.yaw)*p.speed*dt;};
 for(let i=0;i<hz*12;i++)app.tickPlay(1/hz);
 t.diagnostic(JSON.stringify({hz,maxJump,worstTime,worstMotion,maxRawStep,maxVisibleStep,maxAddedStep,contacts:contacts.length,sounds:calls.filter(c=>c.name.startsWith('step_')).length,uniquePhases:new Set(contacts.map(c=>c.phase)).size}));assert.ok(correctedBeforeSwitch>0,'a real outgoing support correction enters the rapid switches');// Reach projection can release faster than the requested offset slew. Test
 // the visible result: do not increase the authored peak, or add a new >4cm
 // per-frame foot hop during the outgoing support/crossfade.
 assert.ok(maxVisibleStep<=maxRawStep+1e-8,'stabilization does not increase the authored peak foot movement');
 assert.ok(maxAddedStep<.04,'no extra visible foot hop above four centimetres');
 const sounds=calls.filter(c=>c.name.startsWith('step_'));assert.ok(contacts.length>=20);assert.equal(sounds.length,contacts.length);assert.equal(new Set(contacts.map(c=>c.phase)).size,contacts.length);
 for(const c of contacts){assert.ok(c.height<=.035+1e-8);assert.ok(c.delay<=.12+1e-8);}
}));
