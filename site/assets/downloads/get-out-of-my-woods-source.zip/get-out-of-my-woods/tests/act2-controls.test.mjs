import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { audio } from '../src/audio/index.js';
import { PreviewApp } from '../src/act2/app.js';
import { act2PromptText } from '../src/act2/ui.js';
import { keyStrip, flashlightState } from '../src/ui/controls.js';

test('prompts name the action once and drop the click suffix', () => {
  assert.equal(act2PromptText({ kind: 'weapon', text: 'Take crowbar' }, null, 'keyboard'), 'E: TAKE CROWBAR');
  assert.equal(act2PromptText({ kind: 'weapon', text: 'Take crowbar' }, null, 'touch'), 'TAKE CROWBAR');
  assert.equal(act2PromptText({ kind: 'keys', text: 'Hold to take van keys' }, null, 'keyboard'), 'HOLD E: TAKE VAN KEYS');
  assert.equal(act2PromptText({ kind: 'keys', text: 'Hold to take van keys' }, null, 'touch'), 'HOLD: TAKE VAN KEYS');
  assert.equal(act2PromptText({ kind: 'leave', text: 'Leave tent' }, 'tent', 'keyboard'), 'E: LEAVE TENT');
  assert.equal(act2PromptText({ kind: 'hide', text: 'Hide in tent' }, null, 'touch'), 'HIDE IN TENT · ENTRANCE');
  assert.equal(act2PromptText(null, null, 'keyboard'), '');
  assert.equal(act2PromptText({ kind: 'van', text: 'Try driver’s door' }, null, 'keyboard').includes('CLICK'), false);
});

test('Q turns the player and camera only outside films, Bearings, hiding and swings', () => {
  const calls = [];
  const sfx = audio.sfx;
  audio.sfx = (name, opts) => calls.push({ name, opts });
  try {
    const app = Object.create(PreviewApp.prototype);
    app.state = 'play';
    app.viewYaw = 0.4;
    app.presentationYaw = {};
    app.ui = { mapOpen: false };
    app.sim = { player: { yaw: 0.4, x: 3, z: 5, hidden: null, defending: false } };
    assert.equal(app.tryQuickTurn({ quickTurn: true }), true);
    assert.equal(app.sim.player.yaw, 0.4 + Math.PI);
    assert.equal(app.viewYaw, 0.4 + Math.PI);
    assert.equal(app.presentationYaw.player.yaw, app.sim.player.yaw);
    assert.equal(calls[0].name, 'ui_click');
    assert.equal(calls[0].opts.volume, 0.2);
    assert.equal(calls[0].opts.rate, 0.8);
    const blocked = [
      { state: 'intro' },
      { state: 'death' },
      { state: 'escape' },
      { mapOpen: true },
      { hidden: { kind: 'tent' } },
      { defending: true },
      { defend: true },
    ];
    for (const block of blocked) {
      const yaw = app.sim.player.yaw;
      app.state = block.state || 'play';
      app.ui.mapOpen = !!block.mapOpen;
      app.sim.player.hidden = block.hidden || null;
      app.sim.player.defending = !!block.defending;
      assert.equal(app.tryQuickTurn({ quickTurn: true, defend: !!block.defend }), false, JSON.stringify(block));
      assert.equal(app.sim.player.yaw, yaw);
    }
  } finally {
    audio.sfx = sfx;
  }
});

test('Act II controls follow the shared input policy, strip and flashlight words', () => {
  const src = readFileSync(new URL('../src/act2/ui.js', import.meta.url), 'utf8');
  assert.equal(src.includes("matchMedia('(pointer:coarse)')"), false);
  assert.equal(src.includes('maxTouchPoints'), false);
  assert.ok(src.includes('resolveInputMode'));
  assert.ok(src.includes('keyStrip(2)'));
  assert.ok(src.includes('FLASHLIGHT'));
  assert.ok(src.includes('aria-pressed'));
  assert.equal(src.includes('[E]'), false);
  assert.equal(src.includes('E / CLICK TO LEAVE'), false);
  assert.equal(src.includes('CONTROLS'), true);
  assert.ok(keyStrip(2).includes('Q turn'));
  assert.equal(flashlightState(true).text, 'FLASHLIGHT: ON');
});
