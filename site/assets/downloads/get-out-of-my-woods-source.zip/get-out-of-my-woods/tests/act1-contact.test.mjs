import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { GameSim } from '../src/sim/game.js';
import { Collision, doorSegment } from '../src/sim/collision.js';
import { BUILDINGS, TEMPLATES, LAYOUT, localToWorld, worldToLocal } from '../src/sim/layout.js';
import { waterDepth, heightAt, surfaceY } from '../src/sim/terrain.js';
import { PLAYER, KILLER } from '../src/ai/tuning.js';
import { buildBuilding } from '../src/kit/buildings.js';
import { World } from '../src/world/index.js';
import { buildLights } from '../src/world/lights.js';
import { buildAir } from '../src/world/air.js';
import { lit, GLOBALS } from '../src/render/materials.js';
import { createKiller } from '../src/characters/killer.js';
import { polishKillerAppearance } from '../src/act2/killer.js';
import { createWallClearance } from '../src/characters/wall-clearance.js';

// Canvas drawing is irrelevant to geometry; use the real building/rig meshes.
const context = new Proxy({
 measureText:()=>({width:20}),
 createLinearGradient:()=>({addColorStop(){}}),createRadialGradient:()=>({addColorStop(){}}),
 createImageData:(w,h)=>({data:new Uint8ClampedArray(w*h*4)}),getImageData:(x,y,w,h)=>({data:new Uint8ClampedArray(w*h*4)}),
}, {get:(o,k)=>o[k]??(()=>{})});
globalThis.document={createElement:()=>({getContext:()=>context})};
const input=(camYaw,run=false)=>({moveX:0,moveY:1,camYaw,run,sneak:false,action:false,actionHeld:false,flashlight:false});
const rates=[20,60,120];
const axes=d=>{const ux=(d.ex-d.hx)/d.width,uz=(d.ez-d.hz)/d.width;return {nx:-uz,nz:ux};};
const near=(a,b,epsilon=1e-7)=>assert.ok(Math.abs(a-b)<epsilon,`${a} != ${b}`);
const segmentDistance=(x,z,s)=>{
  const dx=s.x2-s.x1,dz=s.z2-s.z1,t=Math.max(0,Math.min(1,((x-s.x1)*dx+(z-s.z1)*dz)/(dx*dx+dz*dz)));
  return Math.hypot(x-s.x1-t*dx,z-s.z1-t*dz);
};

test('every live door segment matches its actual rendered hinge and tip throughout the swing',()=>{
  const inward={front:[0,-1],back:[0,1],left:[1,0],right:[-1,0]};
  for(const b of BUILDINGS){
    const t=TEMPLATES[b.template],g=buildBuilding(b,t);g.position.set(b.x,0,b.z);g.rotation.y=b.rot;
    (g.userData.doors||[]).forEach((render,i)=>{
      const d=LAYOUT.doors.find(d=>d.id===`${b.id}.d${i}`),base=render.pivot.rotation.y,n=inward[t.doors[i].wall];
      const dir=-Math.sin(base)*n[0]-Math.cos(base)*n[1]>=0?1:-1;
      const world={doors:new Map([[d.id,{pivot:render.pivot,base,dir}]])};
      for(const amount of [0,.125,.5,.875,1]){
        World.prototype.setDoor.call(world,d.id,amount);g.updateMatrixWorld(true);
        const hinge=render.pivot.localToWorld(new THREE.Vector3()),tip=render.pivot.localToWorld(new THREE.Vector3(d.width,0,0));
        const s=doorSegment(d,amount);near(s.x1,hinge.x);near(s.z1,hinge.z);near(s.x2,tip.x);near(s.z2,tip.z);
      }
    });
    g.traverse(o=>{if(o.isMesh)o.geometry.dispose();});
  }
});

for(const fps of rates){
  test(`open leaf stops the counselor and sight, while all doorway centres stay usable at ${fps} Hz`,()=>{
    const sim=new GameSim({skipIntro:true,seed:42}),b=BUILDINGS.find(b=>b.id==='cabin2'),d=sim.collision.doors.find(d=>d.id==='cabin2.d0');
    d.open=true;[sim.player.x,sim.player.z]=localToWorld(b,-1.3,3.3);sim.killer.x=120;sim.killer.z=100;
    const leaf=doorSegment(d);
    for(let i=0;i<fps*.6;i++){
      sim.updatePlayer(1/fps,input(Math.PI/2+b.rot));
      assert.ok(segmentDistance(sim.player.x,sim.player.z,leaf)>=PLAYER.radius+.08-1e-7);
    }
    assert.ok(worldToLocal(b,sim.player.x,sim.player.z)[0]<-.9,'the old cross-leaf path is stopped');
    const [ax,az]=localToWorld(b,-1.3,3.3),[bx,bz]=localToWorld(b,.1,3.3);
    assert.ok(sim.collision.wallBetween(ax,az,bx,bz),'open leaf blocks the corresponding visibility/attack ray');
    const [cx,cz]=localToWorld(b,0,5),[dx,dz]=localToWorld(b,0,2.5);
    assert.equal(sim.collision.wallBetween(cx,cz,dx,dz),false,'the door aperture remains clear');
    for(const door of sim.collision.doors)for(const radius of [PLAYER.radius,KILLER.radius])for(const side of [-1,1]){
      door.open=true;door.motion=null;const {nx,nz}=axes(door);
      let x=door.x+nx*side*1.2,z=door.z+nz*side*1.2;
      for(let i=0;i<fps;i++)[x,z]=sim.collision.move(x,z,x-nx*side*2.6/fps,z-nz*side*2.6/fps,radius);
      assert.ok(((x-door.x)*nx+(z-door.z)*nz)*side<-.8,`${door.id} radius ${radius} side ${side}: crossed`);
      assert.equal(sim.collision.blocked(x,z,radius-1e-7),false);
    }
  });

  test(`actual killer navigation passes each open leaf in both directions at ${fps} Hz`,()=>{
    const sim=new GameSim({skipIntro:true,seed:42});sim.player.x=120;sim.player.z=100;
    for(const d of sim.collision.doors)for(const side of [-1,1]){
      d.open=true;d.motion=null;const {nx,nz}=axes(d),k=sim.killer;
      Object.assign(k,{x:d.x+nx*side*1.8,z:d.z+nz*side*1.8,yaw:Math.atan2(-nx*side,-nz*side),state:'chase',doorWait:0});
      assert.ok(k.setPath(d.x-nx*side*1.8,d.z-nz*side*1.8),`${d.id}: path`);
      for(let i=0;i<fps*6&&k.pathI<k.path.length;i++)k.follow(1/fps,3.85);
      assert.ok(((k.x-d.x)*nx+(k.z-d.z)*nz)*side<-.8,`${d.id} side ${side}: crossed`);
      assert.equal(sim.collision.blocked(k.x,k.z,KILLER.radius-1e-7),false);
    }
  });

  test(`moving panels keep either actor clear and closing resumes after vacancy at ${fps} Hz`,()=>{
    for(const opening of [true,false])for(const occupant of ['player','killer']){
      const sim=new GameSim({skipIntro:true,seed:42}),b=BUILDINGS.find(b=>b.id==='cabin2'),d=sim.collision.doors.find(d=>d.id==='cabin2.d0');
      Object.assign(sim.player,{x:120,z:100});Object.assign(sim.killer,{x:125,z:100});
      const body=sim[occupant],radius=occupant==='player'?PLAYER.radius:KILLER.radius;
      [body.x,body.z]=localToWorld(b,opening?-.2:0,opening?3.45:4);
      d.open=opening;sim.emit({t:opening?'doorOpen':'doorClose',id:d.id});
      const start=[body.x,body.z];
      for(let i=0;i<fps;i++){
        const before=[body.x,body.z];
        sim.updateDoors(1/fps);
        assert.ok(segmentDistance(body.x,body.z,doorSegment(d))>=radius+.08-1e-7);
        assert.equal(sim.collision.blocked(body.x,body.z,radius-1e-7),false);
        assert.ok(Math.hypot(body.x-before[0],body.z-before[1])<=2*d.width*1.75*3.5/fps+1e-5,'opening push is bounded by panel motion');
        if(!opening)assert.deepEqual([body.x,body.z],start,'closing cannot relocate an actor');
      }
      if(opening)assert.equal(d.motion,null,'opening gently clears the occupant instead of pinning egress');
      else assert.ok(d.motion,'closing remains partly open while its sweep is occupied');
      const pausedAmount=sim.collision.doorAmount(d);sim.updateDoors(0);near(sim.collision.doorAmount(d),pausedAmount);
      [body.x,body.z]=localToWorld(b,0,opening?2:5.5);
      for(let i=0;i<fps;i++)sim.updateDoors(1/fps);
      assert.equal(d.motion,null);assert.equal(sim.collision.doorAmount(d),opening?1:0);
    }
  });

  test(`ordinary walking opens a shut door from inside or outside at ${fps} Hz`,()=>{
    for(const id of ['cabin2.d0','mess.d0','mess.d1','shack.d0'])for(const side of [-1,1]){
      const sim=new GameSim({skipIntro:true,seed:42}),d=sim.collision.doors.find(d=>d.id===id),{nx,nz}=axes(d);
      Object.assign(sim.killer,{x:120,z:100,state:'wait'});
      Object.assign(sim.player,{x:d.x+nx*side*1.8,z:d.z+nz*side*1.8});
      for(let i=0;i<fps*1.8;i++){
        sim.step(1/fps,input(Math.atan2(-nx*side,-nz*side)));
        assert.equal(sim.collision.blocked(sim.player.x,sim.player.z,PLAYER.radius-1e-6),false,`${id} body stays clear`);
      }
      assert.ok(((sim.player.x-d.x)*nx+(sim.player.z-d.z)*nz)*side<-.8,`${id} side ${side}: ordinary egress`);
      assert.equal(sim.collision.doorAmount(d),1);
    }
  });

  test(`opening with both actors nearby and reversing to close cannot overlap or eject them at ${fps} Hz`,()=>{
    const sim=new GameSim({skipIntro:true,seed:42}),b=BUILDINGS.find(b=>b.id==='cabin2'),d=sim.collision.doors.find(d=>d.id==='cabin2.d0');
    [sim.player.x,sim.player.z]=localToWorld(b,-.2,3.45);
    [sim.killer.x,sim.killer.z]=localToWorld(b,-.2,2.77);
    d.open=true;sim.emit({t:'doorOpen',id:d.id});
    let previous=sim.collision.doorAmount(d);
    for(let i=0;i<fps*.3;i++){
      const positions=[sim.player.x,sim.player.z,sim.killer.x,sim.killer.z];sim.updateDoors(1/fps);
      for(const [body,radius,offset] of [[sim.player,PLAYER.radius,0],[sim.killer,KILLER.radius,2]]){
        assert.equal(sim.collision.blocked(body.x,body.z,radius-1e-7),false);
        assert.ok(Math.hypot(body.x-positions[offset],body.z-positions[offset+1])<=2*d.width*1.75*3.5/fps+1e-5);
      }
      assert.ok(Math.hypot(sim.player.x-sim.killer.x,sim.player.z-sim.killer.z)>=PLAYER.radius+KILLER.radius-1e-7);
      assert.ok(sim.collision.doorAmount(d)>=previous);previous=sim.collision.doorAmount(d);
    }
    assert.ok(d.motion,'second actor prevents pushing the counselor through him');
    d.open=false;sim.emit({t:'doorClose',id:d.id});near(sim.collision.doorAmount(d),previous);
    for(let i=0;i<fps;i++)sim.updateDoors(1/fps);
    assert.equal(sim.collision.doorAmount(d),0);
    // Vacancy lets the same opening finish; no reset/teleport is used for the panel.
    [sim.killer.x,sim.killer.z]=localToWorld(b,1.2,2);
    d.open=true;sim.emit({t:'doorOpen',id:d.id});
    for(let i=0;i<fps;i++)sim.updateDoors(1/fps);
    assert.equal(sim.collision.doorAmount(d),1);
  });

  test(`Act I recovery blocks run-through but permits a deliberate sidestep at ${fps} Hz`,()=>{
    const sim=new GameSim({skipIntro:true,seed:42}),p=sim.player,k=sim.killer;
    Object.assign(p,{x:3.4,z:11.4,vx:0,vz:0});Object.assign(k,{x:3.4,z:10.5,state:'strike',strikePhase:2,timer:.75,yaw:0});
    for(let i=0;i<fps*.5;i++){
      sim.step(1/fps,input(Math.PI,true));
      assert.ok(Math.hypot(p.x-k.x,p.z-k.z)>=PLAYER.radius+KILLER.radius-1e-7);
      assert.equal(sim.phase,'play');
    }
    assert.ok(p.z>k.z,'counselor remains in front of the body');
    for(let i=0;i<fps*.6;i++)sim.updatePlayer(1/fps,input(Math.PI-.9,true));
    for(let i=0;i<fps*.4;i++)sim.updatePlayer(1/fps,input(Math.PI,true));
    assert.ok(p.z<k.z-.8&&p.x>k.x+.7,'the existing recovery allows a clear path around him');
  });

  test(`actor/scenery corner contact remains bounded and can be escaped at ${fps} Hz`,()=>{
    const c=new Collision({trees:[],rocks:[],bushes:[]});
    c._add({kind:'s',x1:149,z1:-5,x2:149,z2:5,t:.1});
    c._add({kind:'s',x1:149,z1:.8,x2:154,z2:.8,t:.1});
    for(const [radius,otherRadius] of [[PLAYER.radius,KILLER.radius],[KILLER.radius,PLAYER.radius]]){
      const other={x:150.05,z:.1};let x=149.1+radius,z=-.9;
      for(let i=0;i<fps;i++){
        const before=[x,z];[x,z]=c.moveWithActor(x,z,x+.7/fps,z+1/fps,radius,other,otherRadius);
        assert.equal(c.blocked(x,z,radius-1e-7),false);
        assert.ok(Math.hypot(x-other.x,z-other.z)>=radius+otherRadius-1e-7);
        assert.ok(Math.hypot(x-before[0],z-before[1])<=Math.hypot(.7,1)/fps+1e-7,'no correction ejects an actor');
      }
      const stoppedZ=z;
      for(let i=0;i<fps;i++)[x,z]=c.moveWithActor(x,z,x-.7/fps,z-1/fps,radius,other,otherRadius);
      assert.ok(z<stoppedZ-.9,'backing away escapes the corner');
    }
  });

  test(`deep-water slide cannot undo actor contact at ${fps} Hz`,()=>{
    const sim=new GameSim({skipIntro:true,seed:42}),yaw=23*Math.PI/12;
    Object.assign(sim.player,{x:-105.8,z:42.7,vx:Math.sin(yaw)*3.3475,vz:Math.cos(yaw)*3.3475});
    Object.assign(sim.killer,{x:-106.135,z:42.119762979464454});
    assert.ok(waterDepth(sim.killer.x,sim.killer.z)<.45,'killer fixture is in navigable shallow water');
    for(let i=0;i<fps*.5;i++){
      sim.updatePlayer(1/fps,input(yaw,true));
      assert.ok(Math.hypot(sim.player.x-sim.killer.x,sim.player.z-sim.killer.z)>=PLAYER.radius+KILLER.radius-1e-7);
      assert.ok(waterDepth(sim.player.x,sim.player.z)<=.8);
      assert.equal(sim.collision.blocked(sim.player.x,sim.player.z,PLAYER.radius-1e-7),false);
    }
  });
}

test('killer movement has reciprocal actor contact and existing overlaps can be escaped',()=>{
  const sim=new GameSim({skipIntro:true,seed:42}),p=sim.player,k=sim.killer;
  Object.assign(p,{x:3.4,z:11.4});Object.assign(k,{x:3.4,z:10,state:'chase',path:[[3.4,13]],pathI:0,yaw:0,doorWait:0});
  for(let i=0;i<60;i++)k.follow(1/60,3.85);
  assert.ok(p.z-k.z>=PLAYER.radius+KILLER.radius-1e-7);
  const clear=sim.collision.moveWithActor(3.4,11.4,3.5,11.4,PLAYER.radius,p,KILLER.radius);
  near(clear[0],3.5);near(clear[1],11.4);
  p.hidden={id:'fixture'};const hidden=sim.moveKiller(k.x,k.z,k.x,k.z+1);
  assert.ok(hidden[1]>p.z,'hidden camera anchors do not become invisible body blockers');
});

test('live open and moving door leaves restrain the actual skinned fork without moving its root',()=>{
  const figure=polishKillerAppearance(createKiller()),clearance=createWallClearance(figure),point=new THREE.Vector3();
  const d={...LAYOUT.doors.find(d=>d.id==='cabin2.d0'),open:true};
  for(const fps of rates)for(const amount of [.3,.7,1])for(const anim of ['chase','strike']){
    d.motion={amount};const leaf=doorSegment(d),dx=leaf.x2-leaf.x1,dz=leaf.z2-leaf.z1,length=Math.hypot(dx,dz),nx=-dz/length,nz=dx/length;
    const x=(leaf.x1+leaf.x2)/2+nx*.46,z=(leaf.z1+leaf.z2)/2+nz*.46;
    figure.root.position.set(x,0,z);figure.root.rotation.y=Math.atan2(-nx,-nz);figure.setAnim(anim,{restart:true,fade:.001});clearance.reset();
    for(let i=0;i<fps*.2;i++){
      figure.update(1/fps,{speed:4});const result=clearance.apply({walls:[],doors:[d]},1/fps);
      near(figure.root.position.x,x);near(figure.root.position.z,z);assert.ok(result.shift<=.320001);
      for(const mesh of figure.meshes)for(let v=0;v<mesh.geometry.attributes.position.count;v++){
        mesh.getVertexPosition(v,point).applyMatrix4(mesh.matrixWorld);
        const along=((point.x-leaf.x1)*dx+(point.z-leaf.z1)*dz)/length;
        if(point.y>.08&&point.y<2.8&&along>=0&&along<=length)
          assert.ok((point.x-leaf.x1)*nx+(point.z-leaf.z1)*nz>=.08-1e-6,`${fps} Hz ${anim} amount ${amount}: ${JSON.stringify(result)}`);
      }
    }
  }
});

test('additive light pools stay on terrain beneath raised floors and decks',()=>{
  const {group}=buildLights({tier:'low'});
  let vertices=0,elevated=0;
  for(const mesh of group.children.filter(o=>o.renderOrder===3)){
    const p=mesh.geometry.attributes.position;
    for(let i=0;i<p.count;i++){
      const x=p.getX(i),y=p.getY(i),z=p.getZ(i),ground=heightAt(x,z);
      assert.ok(Math.abs(y-(ground+.07))<2e-6,`pool vertex ${i} climbs onto a raised surface`);
      if(surfaceY(x,z)>ground+.05)elevated++;
      vertices++;
    }
  }
  assert.ok(vertices>0);assert.ok(elevated>0,'the fixture covers raised floors/decks');
});

test('cabin reverse shots alone move the existing fill to the rear wall',()=>{
  for(const b of BUILDINGS.filter(q=>q.template==='cabin')){
    const world={lights:{fill:{pos:new THREE.Vector3(),radius:0}}};
    World.prototype.setIndoor.call(world,b.id,`${b.id}.rear`);
    const [x,z]=localToWorld(b,0,-2.2),base=surfaceY(b.x,b.z);
    near(world.lights.fill.pos.x,x);near(world.lights.fill.pos.y,base+2);near(world.lights.fill.pos.z,z);
    assert.equal(world.indoorId,b.id);assert.equal(world.indoorTarget,1);
    World.prototype.setIndoor.call(world,b.id,`${b.id}.room`);
    near(world.lights.fill.pos.x,b.x);near(world.lights.fill.pos.y,base+2);near(world.lights.fill.pos.z,b.z);
  }
  const b=BUILDINGS.find(q=>q.id==='mess'),world={lights:{fill:{pos:new THREE.Vector3(),radius:0}}};
  World.prototype.setIndoor.call(world,b.id,`${b.id}.rear`);
  near(world.lights.fill.pos.x,b.x);near(world.lights.fill.pos.z,b.z);
});

test('mist uses bounded in-plane roll and halves calm and storm opacity together',()=>{
  const air=buildAir({tier:'low',mist:6,particles:0},[]),mist=air.group.children.find(o=>o.isInstancedMesh),camera=new THREE.PerspectiveCamera();
  air.update(0,12,camera,0,0,false);near(mist.material.opacity,.16);
  const matrix=new THREE.Matrix4(),position=new THREE.Vector3(),quaternion=new THREE.Quaternion(),scale=new THREE.Vector3(),yaw=new THREE.Quaternion(),up=new THREE.Vector3(0,1,0);
  let rolled=0;
  for(let i=0;i<mist.count;i++){
    matrix.fromArray(mist.instanceMatrix.array,i*16);matrix.decompose(position,quaternion,scale);
    yaw.setFromAxisAngle(up,Math.atan2(-position.x,-position.z));
    const local=yaw.invert().multiply(quaternion);
    assert.ok(Math.abs(local.x)<1e-6&&Math.abs(local.y)<1e-6,'roll remains in the card plane');
    assert.ok(Math.abs(local.z)<=Math.sin(.24/2)+1e-6,'roll cannot turn a wide card into a vertical wall');
    if(Math.abs(local.z)>1e-4)rolled++;
  }
  assert.ok(rolled>0,'authored patch rotation reaches the rendered instances');
  air.update(0,12,camera,1,0,false);near(mist.material.opacity,.135);
});

test('Mess Hall sign has a faint warm emissiveMap lift on its existing texture',()=>{
  const b=BUILDINGS.find(q=>q.id==='mess'),group=buildBuilding(b,TEMPLATES[b.template]);
  let sign;
  group.traverse(o=>{if(o.isMesh&&o.material.emissiveMap)sign=o;});
  assert.ok(sign);assert.equal(sign.material.map,sign.material.emissiveMap);
  assert.equal(sign.material.emissive.getHex(),0xffc890);assert.equal(sign.material.emissiveIntensity,.16);
});

test('wind corridor defaults disabled and preserves the original falloff and cache key',()=>{
  GLOBALS.uSubject.value.w=0;
  const mat=lit({wind:.12}),shader={uniforms:{},vertexShader:'#include <common>\n#include <begin_vertex>',fragmentShader:'#include <common>\n#include <clipping_planes_fragment>'};
  mat.onBeforeCompile(shader);
  assert.strictEqual(shader.uniforms.uSubject,GLOBALS.uSubject);assert.equal(GLOBALS.uSubject.value.w,0);
  assert.match(shader.fragmentShader,/uSubject\.w > 0\.5 && depth < 3\.3/);
  assert.match(shader.fragmentShader,/subjectT > 0\.0 && subjectT < 1\.0 && subjectPerp <= 0\.8/);
  assert.match(shader.fragmentShader,/\(depth - 1\.6\) \/ 1\.7 < cell \+ 0\.12/);
  assert.equal(mat.customProgramCacheKey(),'wind0.1200');
});
