import test from 'node:test';
import assert from 'node:assert/strict';
import { audio } from '../src/audio/index.js';
import { createMessages } from '../src/ui/messages.js';
import { PreviewApp, captionFor, SESSION_CHECKPOINT } from '../src/act2/app.js';

function appAt(state = 'play') {
  const app = Object.create(PreviewApp.prototype);
  app.messages = createMessages();
  app.time = 10;
  app.state = state;
  app.captionUntil = 0;
  app.checkpointNoted = false;
  app.defendUntil = 0;
  app.viewYaw = 0;
  app.caption = '';
  app.ui = { caption(text) { app.caption = text; } };
  app.sim = { events: [], player: { hidden: null }, killer: { x: 4, z: -6 } };
  return app;
}

test('caption kinds match the shared rules, and locked keeps one key', () => {
  const urgent = ['spotted', 'investigate', 'lost', 'hideSeen', 'killerArrival', 'attackWindup', 'attackMiss', 'defend', 'defendMiss', 'locked'];
  for (const type of urgent) {
    const line = captionFor({ type, text: type === 'defend' ? 'Hit.' : type === 'defendMiss' ? 'Miss.' : 'x', reason: 'range' });
    assert.equal(line.kind, 'urgent', type);
  }
  assert.equal(captionFor({ type: 'locked' }).key, 'locked');
  assert.equal(captionFor({ type: 'route', text: 'North.', id: 'yard' }).kind, 'essential');
  assert.equal(captionFor({ type: 'inspect', text: 'A note.', clue: true, id: 'note' }).kind, 'essential');
  assert.equal(captionFor({ type: 'inspect', text: 'He is opening it. Get out now.' }).kind, 'urgent');
  assert.equal(captionFor({ type: 'weapon' }).kind, 'essential');
  assert.equal(captionFor({ type: 'keys' }).kind, 'essential');
  assert.equal(captionFor({ type: 'bridgeNoise', text: 'The boards creak under you.', x: -20 }).kind, 'flavor');
  assert.equal(captionFor({ type: 'attack' }), null);
  assert.equal(captionFor({ type: 'attackWindup' }).text, 'Move!');
  assert.equal(captionFor({ type: 'attackMiss', text: 'He missed. Keep moving.' }).text, 'He missed. Keep moving.');
});

test('repeated locked presses keep one line up instead of re-flashing it', () => {
  const app = appAt();
  app.sim.events = [{ type: 'locked' }];
  app.events();
  const version = app.messages.version;
  const left = app.messages.timeLeft;
  app.sim.events = [{ type: 'locked' }, { type: 'locked' }];
  app.events();
  assert.equal(app.messages.text, 'Keys. Check the hand beside the van.');
  assert.equal(app.messages.version, version);
  assert.ok(app.messages.timeLeft >= left);
  assert.equal(app.caption, app.messages.text);
  assert.deepEqual(app.messages.recent(), []);
});

test('a warning cuts in front of a route line and the route line returns', () => {
  const app = appAt();
  app.sim.events = [{ type: 'route', text: 'The footbridge.', id: 'bridge', stage: 2 }];
  app.events();
  assert.equal(app.messages.kind, 'essential');
  app.sim.events = [{ type: 'spotted' }];
  app.events();
  assert.equal(app.messages.text, 'He has seen you.');
  app.advanceCaptions(2.05);
  assert.equal(app.messages.text, 'The footbridge.');
  assert.ok(app.messages.recent().includes('The footbridge.'));
  assert.equal(app.messages.recent().includes('He has seen you.'), false);
});

test('pause and settings do not spend caption time; resume shows the same line', () => {
  const app = appAt();
  app.say('A note on the bags.', 8, { kind: 'essential', key: 'clue' });
  app.advanceCaptions(2);
  const left = app.messages.timeLeft;
  app.state = 'pause';
  app.advanceCaptions(30);
  app.state = 'settings';
  app.advanceCaptions(30);
  assert.equal(app.messages.text, 'A note on the bags.');
  assert.equal(app.messages.timeLeft, left);
  app.state = 'play';
  app.syncCaption();
  assert.equal(app.caption, 'A note on the bags.');
  app.advanceCaptions(left + 0.05);
  assert.equal(app.messages.text, '');
  assert.equal(app.caption, '');
});

test('windup and miss play a positional sound and an urgent line', () => {
  const app = appAt();
  const calls = [];
  const sfx = audio.sfx;
  audio.sfx = (name, opts) => calls.push({ name, opts });
  try {
    app.sim.events = [{ type: 'attackWindup', text: 'Move!' }];
    app.events();
    assert.equal(app.messages.text, 'Move!');
    assert.equal(app.messages.kind, 'urgent');
    app.sim.events = [{ type: 'attackMiss', text: 'He missed. Keep moving.' }];
    app.events();
  } finally {
    audio.sfx = sfx;
  }
  assert.equal(calls[0].name, 'fork_swing');
  assert.equal(calls[0].opts.x, 4);
  assert.equal(calls[0].opts.z, -6);
  assert.ok(calls[0].opts.volume < 0.6);
  assert.equal(calls[1].name, 'fork_thunk');
  assert.equal(calls[1].opts.x, 4);
  assert.equal(app.messages.text, 'He missed. Keep moving.');
  assert.equal(app.messages.kind, 'urgent');
});

test('a refused checkpoint is said once, as an essential line', () => {
  const app = appAt();
  app.campaign = { checkpointSaved: () => false };
  app.noteSessionCheckpoint();
  assert.equal(app.messages.text, SESSION_CHECKPOINT);
  assert.equal(app.messages.kind, 'essential');
  const version = app.messages.version;
  app.noteSessionCheckpoint();
  assert.equal(app.messages.version, version);
  const saved = appAt();
  saved.campaign = { checkpointSaved: () => true };
  saved.noteSessionCheckpoint();
  assert.equal(saved.messages.text, '');
  const alone = appAt();
  alone.noteSessionCheckpoint();
  assert.equal(alone.messages.text, '');
});

test('an untyped film line shows at once; an intro line stays essential', () => {
  const death = appAt('death');
  death.say('Your legs give way.', 1.8);
  assert.equal(death.messages.kind, 'urgent');
  const intro = appAt('intro');
  intro.say('Beyond the broken gate. The road should have been clear.', 4, { kind: 'essential', key: 'intro' });
  assert.equal(intro.messages.kind, 'essential');
  intro.say('', 0);
  assert.equal(intro.messages.text, '');
  assert.ok(intro.messages.recent().includes('Beyond the broken gate. The road should have been clear.'));
});
