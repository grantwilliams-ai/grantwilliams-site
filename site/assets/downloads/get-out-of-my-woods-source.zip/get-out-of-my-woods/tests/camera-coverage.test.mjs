import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {CameraRig} from '../src/game/camera.js';
import {GameSim} from '../src/sim/game.js';
import {BUILDINGS,TEMPLATES,LAYOUT,localToWorld,worldToLocal} from '../src/sim/layout.js';
import {surfaceY} from '../src/sim/terrain.js';
import {buildBuilding} from '../src/kit/buildings.js';
const ctx=new Proxy({measureText:()=>({width:20}),createLinearGradient:()=>({addColorStop(){}})},{get:(o,k)=>o[k]??(()=>{})});
globalThis.document={createElement:()=>({getContext:()=>ctx})};
const idle={moveX:0,moveY:0,lookX:0,lookY:0};
function fixture(aspect=16/9){const sim=new GameSim({skipIntro:true,seed:42}),camera=new THREE.PerspectiveCamera(60,aspect,.08,420),rig=new CameraRig(camera,sim.collision);Object.assign(sim.killer,{x:120,z:100,state:'wait',timer:9999});return {sim,camera,rig};}
function place(f,b,x,z){const p=f.sim.player;[p.x,p.z]=localToWorld(b,x,z);p.y=surfaceY(p.x,p.z);p.yaw=b.rot;p.hidden=null;p.vx=p.vz=0;}
function update(f,input=idle,dt=1/60){f.rig.update(dt,f.sim.player,input);f.camera.updateMatrixWorld(true);}
function project(f,b,x,y,z){const [wx,wz]=localToWorld(b,x,z);return new THREE.Vector3(wx,surfaceY(wx,wz)+y,wz).project(f.camera);}
function framed(v,label){assert.ok(Math.abs(v.x)<.95&&Math.abs(v.y)<.95&&v.z>-1&&v.z<1,`${label}: ${v.toArray()}`);}
const fixtures=[
 ...BUILDINGS.filter(b=>b.template==='cabin').flatMap(b=>[['closet',-1.55,-3.1],['vault',0,-3.2],['desk',1.35,-2.8],['door',0,3.3],['bed',1.55,2]].map(([name,x,z])=>({b,name,x,z}))),
 ...[['rear',6,-4.8],['lost',-7.25,3.65],['kitchen',7.5,-2],['front',-3,4.6],['pantry',3.75,3.2],['passage',3,-.5]].map(([name,x,z])=>({b:BUILDINGS.find(b=>b.id==='mess'),name,x,z})),
 ...[['tackle',2,2.6],['motor',2.2,-2.6],['canoe',.3,-2.2],['door',0,5.6]].map(([name,x,z])=>({b:BUILDINGS.find(b=>b.id==='boathouse'),name,x,z})),
 ...[['toolbox',-1.9,-1.1],['bench',.9,-1.2],['locker',-1.75,-.6],['door',-1,2.2]].map(([name,x,z])=>({b:BUILDINGS.find(b=>b.id==='shed'),name,x,z})),
 ...[['bench',.6,-1.4],['door',0,2.2]].map(([name,x,z])=>({b:BUILDINGS.find(b=>b.id==='shack'),name,x,z})),
];
for(const [layout,aspect] of [['portrait panel',390/552],['small portrait panel',320/276],['landscape',844/390],['desktop',16/9]]){
 test(`all 31 collision-clear interaction approaches retain the full counselor in ${layout}`,()=>{const f=fixture(aspect);for(const {b,name,x,z} of fixtures){place(f,b,x,z);f.rig.zone=null;update(f);assert.equal(f.sim.collision.blocked(f.sim.player.x,f.sim.player.z,.3-1e-6),false,`${b.id} ${name} valid standing point`);for(const y of [.15,1,1.7])framed(project(f,b,x,y,z),`${b.id} ${name} y${y}`);}});
}

test('new reverse angles have clear mesh sightlines to rear interactions',()=>{
 const f=fixture(390/552),ray=new THREE.Raycaster();
 for(const b of BUILDINGS.filter(b=>b.template==='cabin'||b.template==='messhall')){
  const t=TEMPLATES[b.template],group=buildBuilding(b,t);group.position.set(b.x,surfaceY(b.x,b.z),b.z);group.rotation.y=b.rot;
  for(const d of group.userData.doors)d.pivot.rotation.y=1.75;
  group.updateMatrixWorld(true);
  for(const q of fixtures.filter(q=>q.b.id===b.id&&(b.template==='cabin'?['closet','vault','desk']:['rear','kitchen']).includes(q.name))){
   place(f,b,q.x,q.z);f.rig.zone=null;update(f);assert.equal(f.rig.zone.id,b.id+'.rear');
   for(const y of [1.15,1.65]){
    const [wx,wz]=localToWorld(b,q.x,q.z),target=new THREE.Vector3(wx,surfaceY(wx,wz)+y,wz),distance=f.camera.position.distanceTo(target);
    ray.set(f.camera.position,target.clone().sub(f.camera.position).normalize());ray.far=distance-.05;
    const hits=ray.intersectObject(group,true).filter(h=>!h.object.material.transparent);
    assert.equal(hits.length,0,`${b.id} ${q.name} y${y} mesh obscures subject at ${hits[0]?.distance}`);
   }
  }
  group.traverse(o=>{if(o.isMesh)o.geometry.dispose();});
 }
});

test('rear-shot hysteresis prevents boundary chatter and does not leak across Mess Hall partition',()=>{
 const f=fixture();for(const b of BUILDINGS.filter(b=>b.template==='cabin'||b.template==='messhall')){
  const x=b.template==='cabin'?0:6;
  for(const [z,rear] of [[-1.7,false],[-1.8,true],[-1.79,true],[-1.3,true],[-1.21,true],[-1.19,false],[-1.5,false],[-1.79,false],[-1.81,true]]){place(f,b,x,z);update(f);assert.equal(f.rig.zone.id.endsWith('.rear'),rear,`${b.id} z${z}`);}
 }
 const b=BUILDINGS.find(b=>b.id==='mess');place(f,b,6,-3);update(f);place(f,b,2.9,-3);update(f);assert.equal(f.rig.zone.id,'mess.hall');
});

for(const fps of [20,60,120])test(`held movement survives new shots and real exits at ${fps}Hz`,()=>{
 for(const b of BUILDINGS.filter(b=>b.template==='cabin'||b.template==='messhall')){
  const f=fixture(),dt=1/fps,x=b.template==='cabin'?0:6,z=b.template==='cabin'?-2.8:-.6,worldYaw=b.rot+(b.template==='cabin'?0:Math.PI);
  place(f,b,x,z);update(f);const initial=f.rig.moveYaw,angle=worldYaw-initial,input={...idle,moveX:-Math.sin(angle),moveY:Math.cos(angle)},cuts=[];
  for(let i=0;i<fps*4;i++){
   f.sim.step(dt,{...input,camYaw:f.rig.moveYaw});update(f,input,dt);
   assert.ok(Math.abs(f.rig.moveYaw-initial)<1e-9,`${b.id} held direction changed`);
   assert.equal(f.sim.collision.blocked(f.sim.player.x,f.sim.player.z,.3-1e-6),false,`${b.id} collision`);
   if(f.rig.justCut)cuts.push(f.rig.zone?.id??'outside');
  }
  const [,finalZ]=worldToLocal(b,f.sim.player.x,f.sim.player.z);
  assert.ok(b.template==='cabin'?finalZ>4.5:finalZ< -5.8,`${b.id} exits: ${finalZ}`);
  assert.deepEqual(cuts,b.template==='cabin'?[b.id+'.room','outside']:[b.id+'.rear','outside']);
  update(f,idle);update(f,idle);assert.equal(f.rig.holdMove,false);
 }
});

test('rear-shot return crossing, portrait rotation and bounded pan preserve movement basis',()=>{
 const f=fixture(),b=BUILDINGS.find(b=>b.id==='cabin2');place(f,b,0,-.6);update(f);const yaw=f.rig.moveYaw;
 for(const aspect of [390/552,844/390,390/552]){f.camera.aspect=aspect;f.camera.updateProjectionMatrix();for(const z of [-1.81,-1.3,-1.19]){place(f,b,0,z);update(f,{...idle,moveY:1});assert.equal(f.rig.moveYaw,yaw);}}
 const boat=BUILDINGS.find(b=>b.id==='boathouse');place(f,boat,2,2.6);update(f);const panYaw=f.rig.moveYaw,position=f.camera.position.clone();for(const z of [2.4,2.5,2.6,2.7]){place(f,boat,2,z);update(f,{...idle,moveY:1});assert.equal(f.rig.moveYaw,panYaw);assert.equal(f.camera.position.distanceTo(position),0);}
});

test('all 25 authored hiding views and FOV remain unchanged by framing work',()=>{
 const f=fixture(390/552);for(const hide of LAYOUT.hides){f.sim.player.hidden=hide;f.rig.hidePan=0;update(f);assert.equal(f.camera.position.x,hide.view.pos[0]);assert.equal(f.camera.position.z,hide.view.pos[2]);assert.equal(f.camera.fov,62);assert.ok(Math.abs(f.camera.position.y-(hide.view.pos[1]+surfaceY(hide.view.pos[0],hide.view.pos[2])))<.0061);}
});

test('rear cabin framing includes the interaction surfaces and counselor width, below the central lamp',()=>{
 const f=fixture(390/552);for(const b of BUILDINGS.filter(b=>b.template==='cabin')){
  for(const [x,z,targets] of [[-1.55,-3.1,[[-1.77,.1,-3.6],[-1.77,2.05,-2.6]]],[0,-3.2,[[-.5,.7,-4],[.5,2.05,-4]]],[1.35,-2.8,[[1.95,.8,-2.48],[2.95,.8,-2.48]]]]){
   place(f,b,x,z);f.rig.zone=null;update(f);
   for(const [tx,ty,tz]of targets)framed(project(f,b,tx,ty,tz),`${b.id} target ${tx},${ty},${tz}`);
   for(const dx of [-.22,.22])for(const y of [.15,1,1.7])framed(project(f,b,x+dx,y,z),`${b.id} body width`);
  }
  const local=worldToLocal(b,f.camera.position.x,f.camera.position.z);assert.ok(Math.abs(local[0])<1e-9&&Math.abs(local[1]-2.9)<1e-9);assert.ok(f.camera.position.y-surfaceY(f.camera.position.x,f.camera.position.z)<1.9,'camera stays below hanging lamp');
 }
});

test('the Mess Hall partition prevents crossing its x boundary while rear shots are active',()=>{
 const b=BUILDINGS.find(b=>b.id==='mess');for(const side of [-1,1]){
  const f=fixture();place(f,b,3+side*.55,-3.1);update(f);const expected=f.rig.zone.id;
  const worldYaw=side===1?-Math.PI/2:Math.PI/2,angle=worldYaw-f.rig.moveYaw,input={...idle,moveX:-Math.sin(angle),moveY:Math.cos(angle)};
  for(let i=0;i<120;i++){f.sim.step(1/60,{...input,camYaw:f.rig.moveYaw});update(f,input);assert.equal(f.rig.zone.id,expected);assert.equal(f.rig.justCut,false);assert.equal(f.sim.collision.blocked(f.sim.player.x,f.sim.player.z,.3-1e-6),false);}
  const [x]=worldToLocal(b,f.sim.player.x,f.sim.player.z);assert.ok(side===1?x>3.3:x<2.7,'partition keeps body on its original side');
 }
});

test('the back dining aisle and boathouse side aisle frame collision-clear walkers without mesh obstruction',()=>{
 for(const [name,aspect]of [['portrait',390/552],['landscape',844/390],['desktop',16/9]]){
  const f=fixture(aspect),ray=new THREE.Raycaster();
  for(const [id,points]of [['mess',[[-8.55,-4.8],[-8.2,-4.45],[-7.85,-3.75],[-8.55,-3.05],[-6.8,-4.8]]],['boathouse',[[2.8,4.6],[2.8,4.95],[2.8,5.3]]]]){
   const b=BUILDINGS.find(b=>b.id===id),group=buildBuilding(b,TEMPLATES[b.template]);group.position.set(b.x,surfaceY(b.x,b.z),b.z);group.rotation.y=b.rot;group.updateMatrixWorld(true);
   for(const [x,z]of points){place(f,b,x,z);f.rig.zone=null;update(f);assert.equal(f.sim.collision.blocked(f.sim.player.x,f.sim.player.z,.3-1e-6),false);for(const y of [.15,1,1.7])framed(project(f,b,x,y,z),`${name} ${id} ${x},${z}`);
    for(const y of [1.15,1.65]){const p=f.sim.player,target=new THREE.Vector3(p.x,p.y+y,p.z),dist=f.camera.position.distanceTo(target);ray.set(f.camera.position,target.clone().sub(f.camera.position).normalize());ray.far=dist-.05;assert.equal(ray.intersectObject(group,true).filter(h=>!h.object.material.transparent).length,0,`${id} ${x},${z}: obscured body`);}
   }
   group.traverse(o=>{if(o.isMesh)o.geometry.dispose();});
  }
 }
});

test('dining rear angle has hysteresis on both free-walk boundaries',()=>{
 const f=fixture(),b=BUILDINGS.find(b=>b.id==='mess');
 for(const [x,z,rear]of [[-5.7,-4.5,false],[-5.81,-4.5,true],[-5.4,-4.5,true],[-5.31,-4.5,true],[-5.29,-4.5,false],[-5.7,-4.5,false],[-8.4,-2.6,false],[-8.4,-2.71,true],[-8.4,-2.3,true],[-8.4,-2.21,true],[-8.4,-2.19,false],[-8.4,-2.6,false]]){place(f,b,x,z);update(f);assert.equal(f.rig.zone.id==='mess.hall-rear',rear,`${x},${z}`);}
});
