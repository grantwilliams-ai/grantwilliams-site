import test from 'node:test';
import assert from 'node:assert/strict';
import { Killer } from '../src/ai/killer.js';
import { DIFFICULTY, PLAYER } from '../src/ai/tuning.js';
import { GameSim } from '../src/sim/game.js';

// A deterministic corridor fixture makes the knowledge boundary explicit: the
// wall may close, but the simulation still knows the player's true position.
function corridor() {
  const events = [];
  const sim = {
    time: 0, act: 0, storm: 0, hides: [],
    player: { x: 0, z: 12, vx: 0, vz: 5, yaw: 0, flashlight: true, moveMode: 'run', speed: 5, stamina: 0.2, hidden: null },
    collision: { doors: [], sightOpacity: () => sim.wall ? 2 : 0, wallBetween: () => !!sim.wall, resolve: (x,z) => [x,z], move: (ax,az,x,z) => [x,z] },
    moveKiller: (ax,az,x,z) => [x,z],
    nav: { findPath: (ax,az,x,z) => [[x,z]] },
    director: { contact: () => { sim.recovery = true; }, nextWaypoint: () => ({x:50,z:50}), wantsAmbush: () => null, wantsCarGuard: () => null },
    stats: { killerStuck: 0 }, emit: e => events.push(e), buildingAt: () => null,
    kill: kind => { sim.dead = kind; }, nearSolidBehindPlayer: () => false,
  };
  const killer = new Killer(sim, DIFFICULTY.normal, () => 0.5, {x:0,z:0});
  sim.killer = killer;
  return {sim,killer,events};
}

test('breaking sight prevents stale suspicion from starting a phantom chase', () => {
  const {sim,killer,events} = corridor();
  killer.state = 'notice'; killer.awareness = 1.3; killer.timer = 2; sim.wall = true;
  killer.update(1/30);
  assert.equal(killer.state, 'notice');
  assert.equal(events.some(e => e.t === 'spotted'), false);
});

test('pursuit follows remembered direction, then searches last sighting rather than true location', () => {
  const {sim,killer,events} = corridor();
  killer.beginChase(); killer.update(0.1);
  const seen = {...killer.lastSeen};
  sim.wall = true; sim.player.x = 100; sim.player.z = -100;
  for (let i=0;i<29;i++) { sim.time += 0.1; killer.update(0.1); }
  assert.equal(killer.state, 'search');
  assert.ok(killer.spots.every(p => Math.hypot(p.x-seen.x,p.z-seen.z)<14));
  assert.equal(killer.lastSeen.x, seen.x);
  assert.ok(events.some(e => e.t === 'lost'));
  assert.ok(sim.recovery);
  killer.searchLeft = 0.01; killer.update(0.1);
  assert.equal(killer.state, 'patrol');
  assert.ok(events.some(e => e.t === 'evaded'));
  sim.wall = false; sim.player.x = killer.x; sim.player.z = killer.z+4;
  killer.yaw = 0; killer.headYaw = 0;
  for (let i=0;i<45 && killer.state !== 'chase';i++) killer.update(1/30);
  assert.equal(killer.state, 'chase', 'visible rediscovery remains dangerous during director recovery');
});

test('a visible chase never ends simply because a stopwatch expired', () => {
  const {killer} = corridor();
  killer.beginChase(); killer.chaseT = 100;
  killer.update(0.1);
  assert.equal(killer.state, 'chase');
});

test('unseen search expires even while following a long path', () => {
  const {killer} = corridor();
  killer.state='search'; killer.searchLeft=0.05; killer.timer=0;
  killer.path=[[100,100]];
  killer.searchState(0.1);
  assert.equal(killer.state,'patrol');
  assert.equal(killer.path,null);
});

test('an occupied hide gets a readable inspection beat before the check resolves', () => {
  const {sim,killer,events}=corridor();
  const hide={id:'closet',x:0,z:0,type:'closet',view:{pos:[0,0,1]}};
  sim.player.hidden=hide; killer.state='search'; killer.searchLeft=10;
  killer.path=[[0,0]]; killer.checking=hide;
  killer.searchState(0.1);
  assert.equal(killer.state,'checkhide');
  assert.ok(killer.timer >= 1.5);
  assert.ok(events.some(e=>e.t==='hideDanger'));
  assert.equal(sim.dead,undefined);
});

test('a moving close first miss causes one cosmetic graze; distant and wall misses do not', () => {
  const {sim,killer,events}=corridor();
  sim.player.z=2; killer.state='strike'; killer.strikePhase=1; killer.timer=0;
  killer.strike(0.01);
  assert.equal(sim.dead,undefined);
  assert.equal(sim.player.wounded,true);
  assert.ok(events.some(e=>e.t==='graze'));
  killer.strikePhase=1; killer.timer=0; killer.swings=0;
  killer.strike(0.01);
  assert.equal(events.filter(e=>e.t==='graze').length,1);
  for (const mode of ['wall','distance']) {
    const {sim:s,killer:k,events:e}=corridor();
    s.player.z=mode==='wall'?2:7; s.wall=mode==='wall';
    k.strikePhase=1;k.timer=0;k.strike(0.01);
    assert.equal(e.some(x=>x.t==='graze'),false);
  }
});

test('hiding restores stamina without injury movement penalties or extra controls', () => {
  const s=new GameSim({seed:81,skipIntro:true});
  s.player.hidden=s.hides[0];s.player.stamina=0;s.player.winded=true;s.player.wounded=true;
  s.updatePlayer(3,{});
  assert.equal(s.player.stamina,PLAYER.staminaBackStill*3);
  assert.equal(s.player.winded,false);
  assert.equal(s.player.speed,0);
  assert.equal(s.player.wounded,true);
});

test('entering cover uses current visibility, including notice, and cannot hide during a visible strike', () => {
  const s=new GameSim({seed:82,skipIntro:true});
  const hide=s.hides[0];s.findInteraction=()=>({kind:'hide',spot:hide});
  for (const state of ['notice','chase','strike']) {
    s.player.hidden=null;s.killer.state=state;s.killer.sees=false;
    s.killer.observe=()=>({visible:true});
    s.updateInteraction(0.1,{action:true});
    assert.equal(s.player.seenEntering,true,state);
    assert.equal(s.killer.state,'chase',state);
  }
  s.player.hidden=null;s.killer.state='chase';s.killer.sees=true;
  s.killer.observe=()=>({visible:false});
  s.updateInteraction(0.1,{action:true});
  assert.equal(s.player.seenEntering,false,'rounding a corner this frame beats stale sight');
});

test('clean misses do not manufacture a wound, close call, impact cue or stamina', () => {
  for (const mode of ['wall','distance']) {
    const {sim,killer,events}=corridor();
    sim.closeCalls=0;sim.player.z=mode==='wall'?2:8;sim.wall=mode==='wall';
    const stamina=sim.player.stamina;
    killer.state='strike';killer.strikePhase=1;killer.timer=0;
    killer.strike(0.01);
    assert.equal(sim.player.stamina,stamina);
    assert.equal(sim.closeCalls,0);
    assert.equal(events.some(e=>e.t==='miss'||e.t==='graze'),false);
    assert.equal(killer.strikePhase,2,'a clean swing still has recovery time');
  }
});

test('pin films require an upright tree or wall, not low furniture or rocks', () => {
  const trunk={x:1,z:0,r:0.4};
  const s={player:{x:0,z:0},killer:{x:-1,z:0},forest:{trees:[]},collision:{
    blocked:x=>x>=0.6,trunkAt:()=>trunk,walls:[],doors:[],
  }};
  assert.equal(GameSim.prototype.nearSolidBehindPlayer.call(s),false,'unidentified rock is low');
  s.collision.trunkAt=()=>null;
  assert.equal(GameSim.prototype.nearSolidBehindPlayer.call(s),false,'table/car is low');
  s.collision.trunkAt=()=>trunk;s.forest.trees=[{...trunk,solid:true}];
  assert.equal(GameSim.prototype.nearSolidBehindPlayer.call(s),true,'real tree');
  s.forest.trees=[];s.collision.trunkAt=()=>null;
  s.collision.walls=[{x1:0.7,z1:-2,x2:0.7,z2:2}];
  assert.equal(GameSim.prototype.nearSolidBehindPlayer.call(s),true,'upright wall');
});

test('status is not a radar for ambient investigations or a false promise after witnessed hiding', () => {
  const s=new GameSim({seed:85,skipIntro:true});
  s.killer.state='investigate';s.killer.pursuitActive=false;
  assert.equal(s.pursuitStatus(),'clear');
  s.killer.pursuitActive=true;
  assert.equal(s.pursuitStatus(),'searching');
  s.player.hidden=s.hides[0];s.player.seenEntering=true;
  assert.equal(s.pursuitStatus(),'pursuit');
  s.player.seenEntering=false;
  assert.equal(s.pursuitStatus(),'hidden');
});

test('real cabin route: encounter, sprint, break sight, unseen hide, search departure and rediscovery', t => {
  const s=new GameSim({seed:91,skipIntro:true});
  const p=s.player,k=s.killer,dt=1/30;
  // Only starting positions are arranged. Every subsequent movement is input,
  // actual collision/navigation and the live killer FSM; neither actor teleports.
  Object.assign(p,{x:-17,z:-4,yaw:-Math.PI/2});
  Object.assign(k,{x:-1,z:-4,yaw:-Math.PI/2,timer:5});
  const idle={moveX:0,moveY:0,camYaw:0,run:false,action:false,actionHeld:false};
  const trace=[];let maxStep=0;
  const tick=(input=idle)=>{
    const x=k.x,z=k.z;s.step(dt,input);
    maxStep=Math.max(maxStep,Math.hypot(k.x-x,k.z-z));
    for(const e of s.drainEvents()) if(['noticed','spotted','hide','lost','evaded','death','hideSeen'].includes(e.t)) {
      trace.push({event:e.t,time:+s.time.toFixed(2),state:k.state});
    }
  };
  const route=(x,z,run=true,stopOnRediscovery=false)=>{
    const path=s.nav.findPath(p.x,p.z,x,z);assert.ok(path,'route exists');
    for(const pt of path){
      let n=0;
      while(Math.hypot(pt[0]-p.x,pt[1]-p.z)>.35 && s.phase==='play'){
        assert.ok(n++<450,'each path leg completes');
        tick({...idle,moveY:1,camYaw:Math.atan2(pt[0]-p.x,pt[1]-p.z),run});
        if(stopOnRediscovery && s.stats.seen>=2)return;
      }
    }
  };
  for(let i=0;i<300 && k.state!=='chase';i++)tick();
  assert.equal(k.state,'chase');assert.equal(s.stats.seen,1);
  route(-27,-5);
  const hide=s.hides.find(h=>h.id==='cabin1.closet');route(hide.x,hide.z,false);
  assert.equal(s.findInteraction()?.kind,'hide');assert.equal(k.observe().visible,false);
  tick({...idle,action:true});
  assert.equal(p.hidden?.id,hide.id);assert.equal(p.seenEntering,false);
  for(let i=0;i<1200 && s.phase==='play' && !trace.some(e=>e.event==='evaded');i++)tick();
  assert.equal(s.phase,'play');assert.equal(k.state,'patrol');
  assert.ok(trace.some(e=>e.event==='lost'));assert.ok(trace.some(e=>e.event==='evaded'));
  assert.equal(p.stamina,1,'hiding recovers a complete sprint');
  tick({...idle,action:true});route(-12,3,true,true);
  assert.equal(s.stats.seen,2,'he can see and reacquire during director recovery');
  assert.equal(s.phase,'play');assert.ok(maxStep <= 5.8*dt+1e-6,'killer never teleports');
  t.diagnostic(JSON.stringify({trace,maxKillerStep:+maxStep.toFixed(4)}));
});
