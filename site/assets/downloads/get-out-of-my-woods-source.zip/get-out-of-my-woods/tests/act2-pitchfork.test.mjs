import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { createAct2Killer } from '../src/act2/killer.js';
import { presentationYawStep } from '../src/act2/app.js';

// Geometry and IK are CPU-only. Texture pixels are irrelevant to these checks.
globalThis.document = { createElement: () => ({ getContext: () => ({
  fillRect() {}, beginPath() {}, ellipse() {}, fill() {},
}) }) };
const vector = () => new THREE.Vector3();
function tip(actor) {
  actor.root.updateWorldMatrix(true, true);
  return actor.root.worldToLocal(actor.figure.forkTip.getWorldPosition(vector()));
}
function fullyGrippedHandErrors(actor) {
  actor.root.updateWorldMatrix(true, true);
  const pose = actor.figure.animator.P.a, rig = actor.figure.rig;
  return [['R', 9, 11], ['L', 10, 12]].filter(([, weight]) => pose[weight] > .999).map(([side, , u]) =>
    rig.b(`hand${side}`).getWorldPosition(vector()).distanceTo(rig.b('fork').localToWorld(vector().set(0, pose[u], 0))));
}

test('carried pitchfork clears a counselor at the .8m physical separation throughout a chase', () => {
  const actor = createAct2Killer();
  actor.root.position.set(13, 0, -21); actor.root.rotation.y = 1.1;
  const hard = actor.figure.meshes.find(m => m.name === 'killer-hard');
  const pos = hard.geometry.attributes.position, skin = hard.geometry.attributes.skinIndex;
  const indices = Array.from({ length: pos.count }, (_, i) => i).filter(i => skin.getX(i) === actor.figure.rig.idx.fork);
  for (let frame = 0; frame < 180; frame++) {
    actor.update(1 / 60, { state: 'chase', speed: 2.85 });
    assert.ok(tip(actor).z < .3, 'tines are carried beside him, never through a nearby counselor');
    actor.figure.rig.skeleton.update();
    for (const i of indices) {
      const point = hard.getVertexPosition(i, vector());
      assert.ok(point.z < .4, 'the entire rigid fork, including its butt, clears the counselor capsule');
    }
    assert.ok(fullyGrippedHandErrors(actor).every(e => e < .002), 'carrying hand stays on the handle after movement and rotation');
  }
});

test('windup stays retracted, contact reaches 1.8m exactly at strike .6, and recovery clears the counselor', () => {
  const actor = createAct2Killer();
  actor.root.position.set(-20, 0, 17); actor.root.rotation.y = -2.2;
  for (const phase of ['windup', 'strike', 'recover']) for (let i = 0; i <= 100; i++) {
    actor.update(1 / 60, { state: 'chase', attackPhase: phase, attackProgress: i / 100 });
    const p = tip(actor);
    assert.ok(p.toArray().every(Number.isFinite));
    assert.ok(p.z <= 1.80001, 'no authored body lunge adds hidden extra weapon reach');
    if (phase !== 'strike') assert.ok(p.z < .3, `${phase} does not hold the tines through her body`);
    if (phase === 'strike' && i === 60) {
      assert.ok(Math.abs(p.z - 1.8) < .00001);
      assert.ok(Math.abs(p.x) < .00001);
      assert.ok(Math.abs(p.y - 1.18) < .00001, 'impact is at counselor torso height');
    }
    assert.ok(fullyGrippedHandErrors(actor).every(e => e < .002), `hands stay attached in ${phase} at ${i}%`);
  }
});

test('attack contact follows simulation progress independently of render frame timing', () => {
  const actor = createAct2Killer();
  let expected;
  for (const dt of [1 / 144, 1 / 30, .1, 0]) {
    actor.update(dt, { state: 'chase', attackPhase: 'strike', attackProgress: .6 });
    const p = tip(actor);
    if (expected) assert.ok(p.distanceTo(expected) < .000001);
    expected = p;
  }
  actor.update(1 / 60, { state: 'chase', speed: 2.8 });
  assert.ok(tip(actor).z < .3, 'an interrupted/finished strike cannot leave an extended fork in a crossfade');
});

test('presentation yaw follows the shortest arc with a frame-rate independent bound', () => {
  const start={yaw:170*Math.PI/180,x:0,z:0},target=-170*Math.PI/180;
  const first=presentationYawStep(start,target,1/60,{rate:10});
  const second=presentationYawStep(first,target,1/60,{rate:10});
  const coarse=presentationYawStep(start,target,2/60,{rate:10});
  const delta=Math.atan2(Math.sin(first.yaw-start.yaw),Math.cos(first.yaw-start.yaw));
  assert.ok(delta>0&&delta<=10/60+1e-9,'crosses zero through the short positive arc');
  assert.ok(Math.abs(second.yaw-coarse.yaw)<1e-9,'two fine steps equal one coarse step');
  const bounded=presentationYawStep({yaw:0,x:0,z:0},Math.PI,1/120,{rate:7});
  assert.ok(Math.abs(bounded.yaw-7/120)<1e-9);
  const stopped=presentationYawStep(bounded,Math.PI,0,{rate:7});
  assert.equal(stopped.yaw,bounded.yaw);
});

test('attack, defense, teleport and reset use immediate presentation yaw', () => {
  const previous={yaw:0,x:0,z:0};
  for(const label of ['killer attack','crowbar defense','hidden or non-play state']){
    const state=presentationYawStep(previous,Math.PI,1/120,{rate:1,snap:true});
    assert.equal(state.yaw,Math.PI,label);
  }
  const teleported=presentationYawStep(previous,Math.PI,1/120,{rate:1,x:2,z:0});
  assert.equal(teleported.yaw,Math.PI);assert.equal(teleported.x,2);
  const ordinary=presentationYawStep(previous,Math.PI/2,1/120,{rate:1,x:.1,z:0});
  assert.ok(Math.abs(ordinary.yaw-1/120)<1e-9);
  const reset=presentationYawStep(null,1.2,0,{rate:1});
  assert.equal(reset.yaw,1.2);
});

// Distance from the handle (the fork's own y axis, butt to tine bar) to a point between two joints.
function handleGap(rig, from, to, t) {
  const p = rig.b(from).getWorldPosition(vector()).lerp(rig.b(to).getWorldPosition(vector()), t);
  rig.b('fork').worldToLocal(p);
  return Math.hypot(p.x, p.z, p.y - Math.max(-.15, Math.min(1.57, p.y)));
}

test('the carried handle stands clear of his own right arm in every live carry', () => {
  const actor = createAct2Killer(), rig = actor.figure.rig;
  for (const state of [{ state: 'patrol', speed: 0 }, { state: 'patrol', speed: 1.4 }, { state: 'investigate', speed: 1.9 },
    { state: 'chase', speed: 2.85 }, { state: 'inspect', speed: 0 }, { state: 'search', speed: 0 }, { state: 'stagger', speed: 0 }]) {
    actor.reset();
    for (let frame = 0; frame < 500; frame++) {
      actor.update(1 / 60, state); actor.root.updateWorldMatrix(true, true);
      // Mid upper arm and mid forearm; the old carry ran the handle through both (gaps of 3-5 cm).
      assert.ok(handleGap(rig, 'uarmR', 'farmR', .5) > .15, `${state.state} ${state.speed}: handle through the upper arm at frame ${frame}`);
      assert.ok(handleGap(rig, 'farmR', 'handR', .5) > .15, `${state.state} ${state.speed}: handle through the forearm at frame ${frame}`);
    }
  }
});

test('beside a cabin wall the drawn figure steps the fork out of it, in live play only', () => {
  const actor = createAct2Killer(), wall = [{ id: 'wall', minX: -.9, maxX: -.5, minZ: -6, maxZ: 6, height: 3.05 }];
  const hard = actor.figure.meshes.find(m => m.name === 'killer-hard'), skin = hard.geometry.attributes.skinIndex;
  const indices = Array.from({ length: skin.count }, (_, i) => i).filter(i => skin.getX(i) === actor.figure.rig.idx.fork);
  const deepest = () => { actor.root.updateWorldMatrix(true, true); return Math.max(...indices.map(i => -.5 - hard.getVertexPosition(i, vector()).applyMatrix4(hard.matrixWorld).x)); };
  // His body circle (0.42 m) touches the wall on his fork side.
  actor.root.position.set(-.08, 0, -2);
  let staged = -Infinity, live = -Infinity;
  for (let frame = 0; frame < 120; frame++) {
    actor.root.position.z += 1.4 / 60; actor.update(1 / 60, { state: 'patrol', speed: 1.4 });
    staged = Math.max(staged, deepest());
    actor.stabilizeStance(1 / 60, { enabled: true, obstacles: wall });
    live = Math.max(live, deepest());
    assert.ok(actor.figure.root.position.length() <= .3 + 1e-9, 'the step is bounded');
  }
  assert.ok(staged > .1, 'unassisted, the tines stand in the wall');
  assert.ok(live < .001, `fork stays out of the wall (${live})`);
  actor.update(1 / 60, { state: 'patrol', speed: 1.4 });
  assert.equal(actor.figure.root.position.length(), 0, 'films and resets place him exactly');
});
