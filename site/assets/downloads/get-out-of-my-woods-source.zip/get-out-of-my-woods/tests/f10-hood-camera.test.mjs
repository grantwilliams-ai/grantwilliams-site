// F10: at INSTALL BATTERY the third-person camera could be squeezed onto the player's back by the car,
// showing neither the car nor the player. While the battery goes in, the counselor now faces the engine
// and the camera turns to look at the hood from behind them.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { GameSim } from '../src/sim/game.js';
import { CAR } from '../src/sim/layout.js';
import { CameraRig } from '../src/game/camera.js';

const wrap = (a) => Math.atan2(Math.sin(a), Math.cos(a));
const still = { moveX: 0, moveY: 0, lookX: 0, lookY: 0 };

// North of the hood, facing north: the car is at the player's back.
function atHood(sim) {
  Object.assign(sim.player, { x: CAR.hood.x, z: CAR.hood.z + 1.7, vx: 0, vz: 0, yaw: 0, speed: 0, hidden: null, vaultT: 0, moveMode: 'idle' });
  sim.has.battery = true;
  sim.batteryIn = false;
  sim.noise = () => {};
}

function rigFor(sim, yaw) {
  const rig = new CameraRig(new THREE.PerspectiveCamera(60, 16 / 9, 0.08, 420), sim.collision);
  rig.yaw = rig.moveYaw = yaw;
  rig.first = true;
  return rig;
}

test('F10: with the car at the player\'s back, the camera is squeezed onto their shoulder (the bug)', () => {
  const sim = new GameSim({ skipIntro: true, seed: 7 });
  atHood(sim);
  assert.equal(sim.findInteraction()?.kind, 'battery');
  const rig = rigFor(sim, 0);
  for (let i = 0; i < 60; i++) rig.update(1 / 60, sim.player, still);
  assert.ok(rig.dist < 0.9, `camera pulled in to ${rig.dist.toFixed(2)} m, where the player figure is hidden`);
});

test('F10: while the battery goes in, the camera turns to the hood and gets its distance back', () => {
  const sim = new GameSim({ skipIntro: true, seed: 7 });
  atHood(sim);
  const rig = rigFor(sim, 0);
  rig.focus = CAR.hood;
  for (let i = 0; i < 90; i++) rig.update(1 / 60, sim.player, still);
  const want = Math.atan2(CAR.hood.x - sim.player.x, CAR.hood.z - sim.player.z);
  assert.ok(Math.abs(wrap(rig.yaw - want)) < 0.1, 'looks at the hood from behind the player');
  assert.ok(rig.dist > 2.5, `camera back at ${rig.dist.toFixed(2)} m`);
  rig.focus = null;
  const yaw = rig.yaw;
  rig.update(1 / 60, sim.player, still);
  assert.equal(rig.yaw, yaw, 'releasing E leaves the camera where it is; no snap back');
});

test('F10: holding E at the hood turns the counselor to the engine, without fighting movement or shortening the install', () => {
  const sim = new GameSim({ skipIntro: true, seed: 7 });
  atHood(sim);
  for (let i = 0; i < 30; i++) sim.updateInteraction(1 / 60, { actionHeld: true });
  const want = Math.atan2(CAR.hood.x - sim.player.x, CAR.hood.z - sim.player.z);
  assert.ok(Math.abs(wrap(sim.player.yaw - want)) < 0.05, 'faces the hood within half a second');
  assert.ok(sim.holdT > 0.45 && !sim.batteryIn, 'the install still takes its full time');
  sim.player.yaw = 0;
  sim.player.speed = 2;
  sim.updateInteraction(1 / 60, { actionHeld: true });
  assert.equal(sim.player.yaw, 0, 'a moving player is not turned');
  sim.player.speed = 0;
  for (let i = 0; i < 120; i++) sim.updateInteraction(1 / 60, { actionHeld: true });
  assert.equal(sim.batteryIn, true);
});

test('F10: searching a container does not turn the player or the camera', () => {
  const sim = new GameSim({ skipIntro: true, seed: 7 });
  const spot = GameSim.searchSpots()[0];
  Object.assign(sim.player, { x: spot.wx, z: spot.wz, vx: 0, vz: 0, yaw: 1.234, speed: 0, hidden: null, vaultT: 0 });
  sim.noise = () => {};
  sim.updateInteraction(0.3, { actionHeld: true });
  assert.equal(sim.player.yaw, 1.234);
});
