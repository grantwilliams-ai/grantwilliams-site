import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { Act2Sim } from '../src/act2/sim.js';
import { captionFor } from '../src/act2/app.js';

const place = (s, x, z) => Object.assign(s.killer, { x, z, yaw: Math.PI, active: true, state: 'patrol', target: { x, z }, path: [] });

test('a crowbar hit says four seconds and a miss says the crowbar is not used up', () => {
  const hit = new Act2Sim({ difficulty: 'standard', arrivalTime: 10000 });
  hit.weapon = 'ready';
  Object.assign(hit.p, { x: 0, z: 0, yaw: 0 });
  place(hit, 0, 2);
  assert.equal(hit.defend(), true);
  assert.match(hit.events.at(-1).text, /four seconds/);
  assert.match(hit.events.at(-1).text, /used up/);
  assert.equal(hit.killer.stagger, 4);
  assert.equal(hit.weapon, 'spent');

  const miss = new Act2Sim({ difficulty: 'standard', arrivalTime: 10000 });
  miss.weapon = 'ready';
  Object.assign(miss.p, { x: 0, z: 20, yaw: 0 });
  place(miss, 0, 24);
  assert.equal(miss.defend(), false);
  assert.equal(miss.weapon, 'ready');
  assert.match(miss.events.at(-1).text, /not used up/);

  const line = captionFor({ type: 'weapon' });
  assert.match(line.text, /four seconds/);
  assert.match(line.text, /A miss does not/);
  assert.equal(line.kind, 'essential');
});

test('the Act II death screen no longer says first night', () => {
  const src = readFileSync(new URL('../src/act2/ui.js', import.meta.url), 'utf8');
  assert.equal(src.includes('first night'), false);
  assert.ok(src.includes('No need to replay Act I.'));
});
