import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { audio } from '../src/audio/index.js';
import { PreviewApp, SESSION_CHECKPOINT } from '../src/act2/app.js';
import { createMessages } from '../src/ui/messages.js';

function quietAudio() {
  const saved = { unlock: audio.unlock, resumeAll: audio.resumeAll, sfx: audio.sfx };
  audio.unlock = () => {};
  audio.resumeAll = () => {};
  audio.sfx = () => {};
  return () => Object.assign(audio, saved);
}

test('resume() puts the same caption back on screen', () => {
  const restore = quietAudio();
  try {
    const app = Object.create(PreviewApp.prototype);
    app.messages = createMessages();
    app.time = 4;
    app.state = 'pause';
    app.pausedFrom = 'play';
    app.caption = '';
    app.ui = { setMode() {}, caption(text) { app.caption = text; } };
    app.resetPresentationYaw = () => {};
    app.messages.say('A note on the bags.', { kind: 'essential', seconds: 6, key: 'clue' });
    app.caption = '';
    app.resume();
    assert.equal(app.state, 'play');
    assert.equal(app.caption, 'A note on the bags.');
    assert.ok(app.messages.timeLeft > 5);
  } finally {
    restore();
  }
});

test('frame() spends caption time and clears the line when it ends', () => {
  const app = Object.create(PreviewApp.prototype);
  app.disposed = false;
  app.state = 'play';
  app.time = 0;
  app.last = 1000;
  app.messages = createMessages();
  app.caption = '';
  app.ui = { caption(text) { app.caption = text; } };
  app.tickPlay = () => {};
  app.renderer = { render() {} };
  app.messages.say('The camp office.', { kind: 'essential', seconds: 0.5, key: 'office' });
  const raf = globalThis.requestAnimationFrame;
  globalThis.requestAnimationFrame = () => 1;
  try {
    app.frame(1100);
    assert.equal(app.caption, 'The camp office.');
    assert.ok(app.messages.timeLeft < 0.5);
    for (let t = 1200; t <= 1700; t += 100) app.frame(t);
    assert.equal(app.messages.text, '');
    assert.equal(app.caption, '');
  } finally {
    globalThis.requestAnimationFrame = raf;
  }
});

test('beginPlay says the session-only checkpoint before the office line', () => {
  const app = Object.create(PreviewApp.prototype);
  app.messages = createMessages();
  app.time = 0;
  app.state = 'intro';
  app.checkpointNoted = false;
  app.campaign = { checkpointSaved: () => false };
  app.caption = '';
  app.ui = { setMode() {}, caption(text) { app.caption = text; } };
  app.stopEngine = () => {};
  app.resetPresentationYaw = () => {};
  app.world = { car: { position: { set() {} } } };
  app.post = { uLetterbox: { value: 1 }, uFade: { value: 0 } };
  app.figure = { root: { visible: false } };
  app.camera = { position: { set() {} } };
  app.say = PreviewApp.prototype.say;
  app.syncCaption = PreviewApp.prototype.syncCaption;
  app.noteSessionCheckpoint = PreviewApp.prototype.noteSessionCheckpoint;
  app.beginPlay();
  assert.equal(app.messages.text, SESSION_CHECKPOINT);
  assert.equal(app.messages.kind, 'essential');
  assert.ok(app.messages.recent().includes(SESSION_CHECKPOINT));
  assert.ok(app.messages.waiting.includes('The camp office. Someone there might know another way out.'));
  const saved = Object.create(PreviewApp.prototype);
  Object.assign(saved, app, { messages: createMessages(), checkpointNoted: false, caption: '', campaign: { checkpointSaved: () => true } });
  saved.beginPlay();
  assert.equal(saved.messages.text.includes('Checkpoint kept'), false);
});

test('tickPlay wires Q into a snap turn behind the player', () => {
  const restore = quietAudio();
  try {
    const app = Object.create(PreviewApp.prototype);
    app.state = 'play';
    app.viewYaw = 0.2;
    app.pitch = 0.1;
    app.lightOn = true;
    app.snapCamera = false;
    app.presentationYaw = {};
    app.sim = { player: { yaw: 0.2, x: 1, z: 2, hidden: null, defending: false }, step() {} };
    app.ui = {
      mapOpen: false,
      read: () => ({ lookX: 0, lookY: 0, light: false, quickTurn: true, forward: 0, strafe: 0, run: false, sneak: false, action: false, actionHeld: false, defend: false }),
      hud() {},
    };
    app.updateActors = () => {};
    app.events = () => {};
    app.world = { update() {} };
    app.camera = { getWorldDirection(v) { v.set(0, 0, 1); return v; } };
    let sawSnap = false;
    app.cameraPlay = () => { sawSnap = app.snapCamera === true; };
    app.tickPlay(1 / 60);
    assert.equal(app.sim.player.yaw, 0.2 + Math.PI);
    assert.equal(app.viewYaw, 0.2 + Math.PI);
    assert.equal(sawSnap, true);
  } finally {
    restore();
  }
});

test('a snapped camera is already behind the player; a lerped one has not crossed overhead', () => {
  const app = Object.create(PreviewApp.prototype);
  app.pitch = 0.2;
  app.sim = { player: { x: 0, y: 0, z: 0, hidden: null }, obstacles: [] };
  app.camera = new THREE.PerspectiveCamera();
  app.camera.position.set(0, 1.55, -5.1);
  app.viewYaw = Math.PI;
  app.snapCamera = true;
  app.cameraPlay(1 / 60);
  assert.ok(app.camera.position.z > 3, `snap z ${app.camera.position.z}`);
  assert.equal(app.snapCamera, false);
  app.camera.position.set(0, 1.55, -5.1);
  app.viewYaw = Math.PI;
  app.snapCamera = false;
  app.cameraPlay(1 / 60);
  assert.ok(app.camera.position.z < 0, `lerp z ${app.camera.position.z}`);
});

test('a timed film line replaces the one on screen and both stay in recent', () => {
  const app = Object.create(PreviewApp.prototype);
  app.messages = createMessages();
  app.time = 0;
  app.state = 'intro';
  app.captionUntil = 0;
  app.caption = '';
  app.ui = { caption(text) { app.caption = text; } };
  const first = 'Beyond the broken gate. The road should have been clear.';
  const crash = 'That tree was dragged here.';
  app.say(first, 4, { kind: 'essential', key: 'intro' });
  app.time = 3.2;
  app.say(crash, 3.4, { kind: 'essential', key: 'crash-tree' });
  assert.equal(app.messages.text, crash);
  assert.equal(app.caption, crash);
  assert.deepEqual(app.messages.waiting, []);
  assert.ok(app.messages.recent().includes(first));
  assert.ok(app.messages.recent().includes(crash));
  const version = app.messages.version;
  app.say(crash, 2, { kind: 'essential', key: 'crash-tree' });
  assert.equal(app.messages.version, version);
});
