import test from 'node:test';
import assert from 'node:assert/strict';
import { App } from '../src/game/app.js';
import { audio } from '../src/audio/index.js';
import { createCuePriority } from '../src/audio/cue-priority.js';

function thunderScene() {
  const app = Object.create(App.prototype);
  Object.assign(app, {state:'play',sim:{},disposed:false,thunderTimers:new Set(),settings:{flashes:'reduced'},world:{lightning(){}},post:{uFlash:{value:0},uTear:{value:0}}});
  return app;
}

test('lightning retains its remaining delay across pause and can finish during a death', () => {
  const app = thunderScene(), calls = [], original = audio.sfx;
  audio.sfx = (name, opts) => calls.push([name, opts.volume]);
  try {
    app.onEvent({t:'lightning',strength:1});app.tickThunder(.15);
    app.state='paused';app.tickThunder(60);assert.deepEqual(calls,[]);
    app.state='dead';app.tickThunder(.2);assert.deepEqual(calls,[]);
    app.tickThunder(.06);assert.deepEqual(calls,[['thunder_near',.55]]);
    app.tickThunder(20);assert.equal(calls.length,1);assert.equal(app.thunderTimers.size,0);
  } finally { audio.sfx=original; }
});

test('retry/transfer cleanup and stale-night guards prevent late thunder', () => {
  const app = thunderScene(), original = audio.sfx;
  audio.sfx=()=>assert.fail('old-night thunder played');
  try {
    app.onEvent({t:'lightning',strength:1});app.clearThunder();app.tickThunder(1);
    app.onEvent({t:'lightning',strength:1});app.sim={};app.tickThunder(1);
    app.onEvent({t:'lightning',strength:1});app.state='gameover';app.tickThunder(1);
    assert.equal(app.thunderTimers.size,0);
  } finally { audio.sfx=original; }
});

test('a long frame emits one strongest thunder roll rather than a catch-up burst', () => {
  const app=thunderScene(), calls=[], original=audio.sfx;
  audio.sfx=(name,opts)=>calls.push([name,opts.volume]);
  try {
    for(const strength of [.5,1,.7])app.onEvent({t:'lightning',strength});
    app.tickThunder(5);assert.deepEqual(calls,[['thunder_near',.55]]);assert.equal(app.thunderTimers.size,0);
  } finally { audio.sfx=original; }
});

function focusFixture() {
  const node=()=>({events:[],gain:{cancelAndHoldAtTime(t){this.owner.events.push(['hold',t]);},setTargetAtTime(v,t,s){this.owner.events.push(['target',v,t,s]);},cancelScheduledValues(t){this.owner.events.push(['cancel',t]);},setValueAtTime(v,t){this.owner.events.push(['set',v,t]);}}});
  const weather=[node(),node()],score=node(),stingers=node();
  for(const n of [...weather,score,stingers])n.gain.owner=n;
  const ctx={currentTime:10};return {ctx,weather,score,stingers,focus:createCuePriority(ctx,{weather,score,stingers})};
}

test('first warnings and footsteps keep their gain; only a closely stacked stinger is trimmed', () => {
  const {focus,weather,score,stingers}=focusFixture();
  assert.equal(focus.cue('killer_step',10),1);assert.equal(focus.cue('stinger_spot',10),1);
  assert.equal(focus.cue('stinger_near',10.4),.65);assert.equal(focus.cue('stinger_jump',12),1);
  for(const node of [...weather,score,stingers])assert.deepEqual(node.events,[]);
});

test('successive strikes extend a smooth background dip, and chapter reset removes it', () => {
  const {focus,weather,score,stingers}=focusFixture();
  focus.cue('fork_swing',10);focus.cue('fork_stab',10.2);
  for(const node of [...weather,score,stingers]){
    assert.deepEqual(node.events.at(-1),['target',1,11.45,.28]);
    assert.equal(node.events.at(-2)[1],weather.includes(node)?.55:.72);
  }
  focus.reset();assert.equal(focus.cue('stinger_spot',10.3),1);
  for(const node of [...weather,score,stingers])assert.deepEqual(node.events.at(-1),['set',1,10]);
});
